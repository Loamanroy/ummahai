const WebSocket = require('ws');

async function testWebSocket() {
    const ws = new WebSocket('ws://localhost:8008/api/support/chat');
    
    ws.on('open', function open() {
        console.log('WebSocket connected');
        
        // Send initial connection data
        const initData = {
            user_id: 'test_user_ws',
            language: 'ru'
        };
        ws.send(JSON.stringify(initData));
        
        // Send test message after a short delay
        setTimeout(() => {
            const testMessage = {
                type: 'user_message',
                message: 'Помогите с торговлей',
                language: 'ru'
            };
            console.log('Sending message:', testMessage);
            const startTime = Date.now();
            ws.send(JSON.stringify(testMessage));
            
            // Store start time for response measurement
            ws.startTime = startTime;
        }, 1000);
    });
    
    ws.on('message', function message(data) {
        const response = JSON.parse(data);
        console.log('Received:', response);
        
        if (response.type === 'ai_response' && ws.startTime) {
            const responseTime = Date.now() - ws.startTime;
            console.log(`Response time: ${responseTime}ms`);
            
            // Test English message
            setTimeout(() => {
                const englishMessage = {
                    type: 'user_message',
                    message: 'Help with trading',
                    language: 'en'
                };
                console.log('Sending English message:', englishMessage);
                ws.startTime = Date.now();
                ws.send(JSON.stringify(englishMessage));
            }, 2000);
        }
    });
    
    ws.on('error', function error(err) {
        console.error('WebSocket error:', err);
    });
    
    ws.on('close', function close() {
        console.log('WebSocket disconnected');
    });
    
    // Close after 10 seconds
    setTimeout(() => {
        ws.close();
    }, 10000);
}

testWebSocket();
