import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.ummah.ai.platform',
  appName: 'UMMAH AI Platform',
  webDir: 'dist'
};

export default config;
