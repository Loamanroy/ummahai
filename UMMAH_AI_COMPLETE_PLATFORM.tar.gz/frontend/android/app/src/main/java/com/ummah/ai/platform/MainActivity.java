package com.ummah.ai.platform;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
