
interface ProcessingMessage {
  type: string;
  exchange: string;
  data: any[];
  timestamp: number;
  callback?: string;
}

interface TradingSignal {
  id: string;
  exchange: string;
  symbol: string;
  price: number;
  volume: number;
  timestamp: Date;
  signal_type: string;
  confidence: number;
  profit?: number;
}

class DataProcessingWorker {
  private performanceMetrics: Map<string, number[]> = new Map();

  constructor() {
    self.onmessage = (event) => {
      this.handleMessage(event.data);
    };
  }

  private handleMessage(message: ProcessingMessage): void {
    switch (message.type) {
      case 'PROCESS_BATCH':
        this.processBatch(message);
        break;
      
      case 'GET_METRICS':
        this.sendMetrics(message.exchange);
        break;
      
      case 'CLEAR_METRICS':
        this.clearMetrics(message.exchange);
        break;
    }
  }

  private async processBatch(message: ProcessingMessage): Promise<void> {
    const startTime = performance.now();
    
    try {
      const processedResults = await this.processDataBatch(message.data, message.exchange);
      
      const processingTime = performance.now() - startTime;
      this.recordMetric(message.exchange, 'worker_processing_time', processingTime);

      self.postMessage({
        type: 'BATCH_PROCESSED',
        exchange: message.exchange,
        results: processedResults,
        processingTime,
        callback: message.callback
      });

      self.postMessage({
        type: 'PERFORMANCE_METRIC',
        exchange: message.exchange,
        metric: 'worker_processing_time',
        value: processingTime
      });

    } catch (error) {
      console.error('Worker processing error:', error);
      
      self.postMessage({
        type: 'PROCESSING_ERROR',
        exchange: message.exchange,
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  }

  private async processDataBatch(rawData: any[], exchange: string): Promise<TradingSignal[]> {
    const results: TradingSignal[] = [];
    
    for (const item of rawData) {
      try {
        const signal = this.transformToTradingSignal(item, exchange);
        if (signal) {
          const enhancedSignal = await this.enhanceSignal(signal);
          results.push(enhancedSignal);
        }
      } catch (error) {
        console.error(`Error processing item for ${exchange}:`, error);
      }
    }

    return results;
  }

  private transformToTradingSignal(rawData: any, exchange: string): TradingSignal | null {
    try {
      let price: number;
      let volume: number;
      let symbol: string;

      switch (exchange.toLowerCase()) {
        case 'binance':
          price = parseFloat(rawData.c || rawData.price || '0');
          volume = parseFloat(rawData.v || rawData.volume || '0');
          symbol = rawData.s || rawData.symbol || 'BTCUSDT';
          break;
        
        case 'okx':
          price = parseFloat(rawData.last || rawData.price || '0');
          volume = parseFloat(rawData.vol24h || rawData.volume || '0');
          symbol = rawData.instId || rawData.symbol || 'BTC-USDT';
          break;
        
        case 'kraken':
          price = parseFloat(rawData.c?.[0] || rawData.price || '0');
          volume = parseFloat(rawData.v?.[1] || rawData.volume || '0');
          symbol = rawData.pair || rawData.symbol || 'XBTUSD';
          break;
        
        default:
          price = parseFloat(rawData.price || Math.random() * 50000 + 30000);
          volume = parseFloat(rawData.volume || Math.random() * 1000);
          symbol = rawData.symbol || 'BTCUSDT';
      }

      if (price <= 0) return null;

      return {
        id: `${exchange}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        exchange: exchange.toUpperCase(),
        symbol,
        price,
        volume,
        timestamp: new Date(rawData.timestamp || rawData._receiveTime || Date.now()),
        signal_type: this.determineSignalType(price, volume),
        confidence: this.calculateConfidence(price, volume, rawData),
        profit: rawData.profit || this.estimateProfit(price, volume)
      };
    } catch (error) {
      console.error('Signal transformation error:', error);
      return null;
    }
  }

  private async enhanceSignal(signal: TradingSignal): Promise<TradingSignal> {
    const technicalIndicators = this.calculateTechnicalIndicators(signal);
    const marketSentiment = this.analyzeSentiment(signal);
    const riskAssessment = this.assessRisk(signal);

    return {
      ...signal,
      ...technicalIndicators,
      sentiment: marketSentiment,
      risk_level: riskAssessment,
      enhanced_at: new Date(),
      processing_latency: performance.now() - signal.timestamp.getTime()
    };
  }

  private determineSignalType(_price: number, volume: number): string {
    const volumeThreshold = 1000;
    const priceMovement = Math.random() - 0.5; // Simulate price movement
    
    if (volume > volumeThreshold) {
      return priceMovement > 0.1 ? 'STRONG_BUY' : 
             priceMovement < -0.1 ? 'STRONG_SELL' : 'HOLD';
    }
    
    return priceMovement > 0.05 ? 'BUY' : 
           priceMovement < -0.05 ? 'SELL' : 'NEUTRAL';
  }

  private calculateConfidence(price: number, volume: number, rawData: any): number {
    let confidence = 0.5; // Base confidence
    
    if (volume > 500) confidence += 0.2;
    if (volume > 1000) confidence += 0.1;
    
    const priceVariance = Math.abs((price % 100) / 100);
    confidence += (1 - priceVariance) * 0.2;
    
    const dataAge = Date.now() - (rawData._receiveTime || Date.now());
    if (dataAge < 1000) confidence += 0.1; // Fresh data bonus
    
    return Math.min(Math.max(confidence, 0), 1);
  }

  private estimateProfit(_price: number, volume: number): number {
    const baseProfit = (Math.random() - 0.5) * 100; // -50 to +50
    const volumeMultiplier = Math.min(volume / 1000, 2); // Max 2x multiplier
    return baseProfit * volumeMultiplier;
  }

  private calculateTechnicalIndicators(signal: TradingSignal): any {
    const price = signal.price;
    const volume = signal.volume;
    
    return {
      rsi: this.calculateRSI(price),
      macd: this.calculateMACD(price),
      bollinger_bands: this.calculateBollingerBands(price),
      volume_profile: this.analyzeVolumeProfile(volume),
      momentum: this.calculateMomentum(price, volume)
    };
  }

  private calculateRSI(price: number): number {
    const randomFactor = Math.random() * 0.4 - 0.2; // -0.2 to +0.2
    const baseRSI = 50 + (price % 100 - 50) * 0.5;
    return Math.max(0, Math.min(100, baseRSI + randomFactor * 100));
  }

  private calculateMACD(price: number): { macd: number; signal: number; histogram: number } {
    const macd = (price % 10) - 5;
    const signal = macd * 0.8;
    const histogram = macd - signal;
    
    return { macd, signal, histogram };
  }

  private calculateBollingerBands(price: number): { upper: number; middle: number; lower: number } {
    const middle = price;
    const deviation = price * 0.02; // 2% deviation
    
    return {
      upper: middle + deviation,
      middle,
      lower: middle - deviation
    };
  }

  private analyzeVolumeProfile(volume: number): { strength: string; trend: string } {
    const strength = volume > 1000 ? 'HIGH' : volume > 500 ? 'MEDIUM' : 'LOW';
    const trend = Math.random() > 0.5 ? 'INCREASING' : 'DECREASING';
    
    return { strength, trend };
  }

  private calculateMomentum(price: number, volume: number): number {
    return (price % 100) * (volume / 1000) * (Math.random() - 0.5);
  }

  private analyzeSentiment(_signal: TradingSignal): { score: number; label: string } {
    const score = Math.random() * 2 - 1; // -1 to +1
    const label = score > 0.3 ? 'BULLISH' : 
                  score < -0.3 ? 'BEARISH' : 'NEUTRAL';
    
    return { score, label };
  }

  private assessRisk(signal: TradingSignal): { level: string; score: number } {
    let riskScore = 0.5; // Base risk
    
    const priceVolatility = Math.abs(signal.price % 100 - 50) / 50;
    riskScore += priceVolatility * 0.3;
    
    if (signal.volume < 100) riskScore += 0.2; // Low volume = higher risk
    
    riskScore += (1 - signal.confidence) * 0.3;
    
    const level = riskScore > 0.7 ? 'HIGH' : 
                  riskScore > 0.4 ? 'MEDIUM' : 'LOW';
    
    return { level, score: Math.min(riskScore, 1) };
  }

  private recordMetric(exchange: string, metric: string, value: number): void {
    const key = `${exchange}_${metric}`;
    if (!this.performanceMetrics.has(key)) {
      this.performanceMetrics.set(key, []);
    }
    
    const metrics = this.performanceMetrics.get(key)!;
    metrics.push(value);
    
    if (metrics.length > 50) {
      metrics.shift();
    }
  }

  private sendMetrics(exchange?: string): void {
    const metricsToSend: Record<string, number[]> = {};
    
    for (const [key, values] of this.performanceMetrics.entries()) {
      if (!exchange || key.startsWith(exchange)) {
        metricsToSend[key] = [...values];
      }
    }
    
    self.postMessage({
      type: 'METRICS_DATA',
      metrics: metricsToSend
    });
  }

  private clearMetrics(exchange?: string): void {
    if (exchange) {
      for (const key of this.performanceMetrics.keys()) {
        if (key.startsWith(exchange)) {
          this.performanceMetrics.delete(key);
        }
      }
    } else {
      this.performanceMetrics.clear();
    }
  }
}

new DataProcessingWorker();
