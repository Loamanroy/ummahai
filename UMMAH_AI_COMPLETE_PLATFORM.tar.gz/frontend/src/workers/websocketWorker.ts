class WebSocketWorkerManager {
  private workers: Map<string, Worker> = new Map();
  private connections: Map<string, WebSocket> = new Map();
  private messageQueue: Map<string, any[]> = new Map();
  private batchSize = 50;
  private batchTimeout = 10; // 10ms for ultra-low latency
  private performanceMetrics: Map<string, number[]> = new Map();

  constructor() {
    this.initializeWorkers();
  }

  private initializeWorkers(): void {
    const workerCount = Math.min(navigator.hardwareConcurrency || 4, 8);
    
    for (let i = 0; i < workerCount; i++) {
      const worker = new Worker(
        new URL('./dataProcessingWorker.ts', import.meta.url),
        { type: 'module' }
      );
      
      worker.onmessage = (event) => {
        this.handleWorkerMessage(event.data);
      };
      
      this.workers.set(`worker-${i}`, worker);
    }
  }

  public createOptimizedConnection(
    exchange: string,
    wsUrl: string,
    onMessage: (data: any) => void,
    onError?: (error: Event) => void
  ): void {
    const startTime = performance.now();
    
    const ws = new WebSocket(wsUrl);

    ws.binaryType = 'arraybuffer';
    if ('bufferedAmountLowThreshold' in ws) {
      ws.bufferedAmountLowThreshold = 1024;
    }

    ws.onopen = () => {
      const latency = performance.now() - startTime;
      this.recordMetric(exchange, 'connection_time', latency);
      
      console.log(`Optimized connection established to ${exchange} in ${latency.toFixed(2)}ms`);
      
      const subscribeMessage = JSON.stringify({
        method: 'SUBSCRIBE',
        params: ['btcusdt@ticker', 'ethusdt@ticker'],
        id: Date.now()
      });
      
      ws.send(subscribeMessage);
    };

    ws.onmessage = (event) => {
      const receiveTime = performance.now();
      
      try {
        let data;
        if (event.data instanceof ArrayBuffer) {
          const decoder = new TextDecoder();
          data = JSON.parse(decoder.decode(event.data));
        } else {
          data = JSON.parse(event.data);
        }

        data._receiveTime = receiveTime;
        data._exchange = exchange;

        this.batchMessage(exchange, data, onMessage);
        
        this.recordMetric(exchange, 'message_latency', performance.now() - receiveTime);
      } catch (error) {
        console.error(`Message parsing error for ${exchange}:`, error);
      }
    };

    ws.onerror = (error) => {
      console.error(`WebSocket error for ${exchange}:`, error);
      if (onError) onError(error);
    };

    ws.onclose = (event) => {
      console.log(`Connection closed for ${exchange}:`, event.code, event.reason);
      this.handleReconnection(exchange, wsUrl, onMessage, onError);
    };

    this.connections.set(exchange, ws);
  }

  private batchMessage(exchange: string, data: any, callback: (data: any) => void): void {
    if (!this.messageQueue.has(exchange)) {
      this.messageQueue.set(exchange, []);
    }

    const queue = this.messageQueue.get(exchange)!;
    queue.push(data);

    if (queue.length >= this.batchSize) {
      this.processBatch(exchange, callback);
    } else {
      setTimeout(() => {
        if (queue.length > 0) {
          this.processBatch(exchange, callback);
        }
      }, this.batchTimeout);
    }
  }

  private processBatch(exchange: string, callback: (data: any) => void): void {
    const queue = this.messageQueue.get(exchange);
    if (!queue || queue.length === 0) return;

    const batch = queue.splice(0, this.batchSize);
    const processingStart = performance.now();

    const availableWorker = this.getAvailableWorker();
    if (availableWorker) {
      availableWorker.postMessage({
        type: 'PROCESS_BATCH',
        exchange,
        data: batch,
        timestamp: processingStart
      });
    } else {
      this.processInMainThread(batch, callback);
    }

    this.recordMetric(exchange, 'batch_processing_time', performance.now() - processingStart);
  }

  private processInMainThread(batch: any[], callback: (data: any) => void): void {
    const processedData = batch.map(item => ({
      ...item,
      processed: true,
      processingTime: performance.now() - item._receiveTime
    }));

    requestAnimationFrame(() => {
      processedData.forEach(callback);
    });
  }

  private getAvailableWorker(): Worker | null {
    const workers = Array.from(this.workers.values());
    return workers[Math.floor(Math.random() * workers.length)];
  }

  private handleWorkerMessage(data: any): void {
    switch (data.type) {
      case 'BATCH_PROCESSED':
        requestAnimationFrame(() => {
          data.results.forEach((item: any) => {
            if (data.callback) {
              data.callback(item);
            }
          });
        });
        break;
      
      case 'PERFORMANCE_METRIC':
        this.recordMetric(data.exchange, data.metric, data.value);
        break;
    }
  }

  private handleReconnection(
    exchange: string,
    wsUrl: string,
    onMessage: (data: any) => void,
    onError?: (error: Event) => void
  ): void {
    const baseDelay = 100; // Start with 100ms
    const maxDelay = 5000; // Max 5 seconds
    const jitter = Math.random() * 100; // Add randomness
    
    const delay = Math.min(baseDelay * Math.pow(2, this.getReconnectAttempts(exchange)), maxDelay) + jitter;
    
    setTimeout(() => {
      console.log(`Attempting reconnection to ${exchange}...`);
      this.createOptimizedConnection(exchange, wsUrl, onMessage, onError);
    }, delay);
  }

  private getReconnectAttempts(exchange: string): number {
    const key = `${exchange}_reconnect_attempts`;
    const attempts = parseInt(localStorage.getItem(key) || '0');
    localStorage.setItem(key, (attempts + 1).toString());
    return attempts;
  }

  private recordMetric(exchange: string, metric: string, value: number): void {
    const key = `${exchange}_${metric}`;
    if (!this.performanceMetrics.has(key)) {
      this.performanceMetrics.set(key, []);
    }
    
    const metrics = this.performanceMetrics.get(key)!;
    metrics.push(value);
    
    if (metrics.length > 100) {
      metrics.shift();
    }

    if (metric === 'message_latency' && value > 50) {
      console.warn(`High latency detected for ${exchange}: ${value.toFixed(2)}ms`);
    }
  }

  public getPerformanceMetrics(exchange?: string): Record<string, number[]> {
    if (exchange) {
      const result: Record<string, number[]> = {};
      for (const [key, values] of this.performanceMetrics.entries()) {
        if (key.startsWith(exchange)) {
          result[key] = [...values];
        }
      }
      return result;
    }
    
    return Object.fromEntries(this.performanceMetrics.entries());
  }

  public getAverageLatency(exchange: string): number {
    const key = `${exchange}_message_latency`;
    const metrics = this.performanceMetrics.get(key);
    if (!metrics || metrics.length === 0) return 0;
    
    return metrics.reduce((sum, val) => sum + val, 0) / metrics.length;
  }

  public disconnect(exchange?: string): void {
    if (exchange) {
      const ws = this.connections.get(exchange);
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.close();
      }
      this.connections.delete(exchange);
      this.messageQueue.delete(exchange);
    } else {
      this.connections.forEach((ws) => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.close();
        }
      });
      this.connections.clear();
      this.messageQueue.clear();
    }
  }

  public destroy(): void {
    this.disconnect();
    this.workers.forEach(worker => worker.terminate());
    this.workers.clear();
    this.performanceMetrics.clear();
  }
}

export const wsWorkerManager = new WebSocketWorkerManager();
export default WebSocketWorkerManager;
