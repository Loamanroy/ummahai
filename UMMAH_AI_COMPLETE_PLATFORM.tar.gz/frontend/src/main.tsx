import React from 'react'
import ReactDOM from 'react-dom/client'
import './polyfills'
import App from './App.tsx'
import './index.css'

if ('serviceWorker' in navigator && import.meta.env.MODE === 'production') {
  window.addEventListener('load', async () => {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js', {
        scope: '/'
      });
      
      console.log('SW registered successfully:', registration.scope);
      
      registration.addEventListener('updatefound', () => {
        const newWorker = registration.installing;
        if (newWorker) {
          newWorker.addEventListener('statechange', () => {
            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
              console.log('New service worker available, consider refreshing');
            }
          });
        }
      });
      
    } catch (error) {
      console.error('SW registration failed:', error);
    }
  });
}

const reportWebVitals = (metric: any) => {
  if (import.meta.env.MODE === 'development') {
    console.log(`${metric.name}: ${metric.value}`);
  }
  
  if (import.meta.env.MODE === 'production' && (window as any).gtag) {
    (window as any).gtag('event', metric.name, {
      event_category: 'Web Vitals',
      value: Math.round(metric.name === 'CLS' ? metric.value * 1000 : metric.value),
      non_interaction: true,
    });
  }
};

if (typeof window !== 'undefined') {
  import('web-vitals').then((webVitals) => {
    const { onCLS, onINP, onFCP, onLCP, onTTFB } = webVitals;
    if (onCLS) onCLS(reportWebVitals);
    if (onINP) onINP(reportWebVitals);
    if (onFCP) onFCP(reportWebVitals);
    if (onLCP) onLCP(reportWebVitals);
    if (onTTFB) onTTFB(reportWebVitals);
  }).catch(() => {
    console.log('Web vitals not available');
  });
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
