/**
 * Voice Command Router for XR Trading Interface
 * Handles voice command processing and routing to appropriate actions
 */



const COMMAND_PATTERNS = {
  buy: /(?:купи|покупай|buy)\s*(.+)?/i,
  sell: /(?:продай|продавай|sell)\s*(.+)?/i,
  status: /(?:статус|status|как дела|состояние)/i,
  balance: /(?:баланс|balance|сколько денег|деньги)/i,
  
  switch_exchange: /(?:переключи|switch|смени)\s*(?:на|to)\s*(.+)/i,
  connect: /(?:подключи|connect|соедини)\s*(.+)?/i,
  
  analyze: /(?:анализ|analyze|проанализируй)\s*(.+)?/i,
  signals: /(?:сигналы|signals|покажи сигналы)/i,
  
  tor_access: /(?:тор|tor|анонимно|скрытно)/i,
  zkp_verify: /(?:верификация|verify|проверь|zkp)/i,
  
  withdraw: /(?:вывод|withdraw|выведи)\s*(.+)?/i,
  
  help: /(?:помощь|help|что ты умеешь)/i,
  stop: /(?:стоп|stop|остановись|хватит)/i,
};

const RESPONSES = {
  ru: {
    buy_executed: 'Ордер на покупку размещен',
    sell_executed: 'Ордер на продажу размещен',
    status_ok: 'Система работает нормально',
    balance_info: 'Текущий баланс отображен на экране',
    exchange_switched: 'Биржа переключена',
    analysis_started: 'Запускаю анализ рынка',
    signals_displayed: 'Показываю активные сигналы',
    tor_activated: 'TOR доступ активирован',
    zkp_verified: 'ZKP верификация выполнена',
    withdrawal_initiated: 'Вывод средств инициирован',
    help_message: 'Доступные команды: купи, продай, статус, баланс, анализ, сигналы, тор, вывод',
    command_stopped: 'Команда остановлена',
    unknown_command: 'Команда не распознана. Скажите "помощь" для списка команд',
    error_occurred: 'Произошла ошибка при выполнении команды'
  }
};

/**
 * Routes voice commands to appropriate actions
 */
export async function routeVoiceCommand(
  command: string, 
  exchange: string = 'binance'
): Promise<string> {
  try {
    const normalizedCommand = command.toLowerCase().trim();
    
    if (COMMAND_PATTERNS.buy.test(normalizedCommand)) {
      const match = normalizedCommand.match(COMMAND_PATTERNS.buy);
      const asset = match?.[1] || 'BTC';
      await executeBuyOrder(asset, exchange);
      return `${RESPONSES.ru.buy_executed} ${asset.toUpperCase()}`;
    }
    
    if (COMMAND_PATTERNS.sell.test(normalizedCommand)) {
      const match = normalizedCommand.match(COMMAND_PATTERNS.sell);
      const asset = match?.[1] || 'BTC';
      await executeSellOrder(asset, exchange);
      return `${RESPONSES.ru.sell_executed} ${asset.toUpperCase()}`;
    }
    
    if (COMMAND_PATTERNS.status.test(normalizedCommand)) {
      const status = await getSystemStatus(exchange);
      return `${RESPONSES.ru.status_ok}. ${status}`;
    }
    
    if (COMMAND_PATTERNS.balance.test(normalizedCommand)) {
      const balance = await getBalance(exchange);
      return `${RESPONSES.ru.balance_info}. ${balance}`;
    }
    
    if (COMMAND_PATTERNS.switch_exchange.test(normalizedCommand)) {
      const match = normalizedCommand.match(COMMAND_PATTERNS.switch_exchange);
      const newExchange = match?.[1]?.trim();
      if (newExchange) {
        await switchExchange(newExchange);
        return `${RESPONSES.ru.exchange_switched} на ${newExchange.toUpperCase()}`;
      }
    }
    
    if (COMMAND_PATTERNS.analyze.test(normalizedCommand)) {
      const match = normalizedCommand.match(COMMAND_PATTERNS.analyze);
      const asset = match?.[1] || 'рынок';
      await startAnalysis(asset, exchange);
      return `${RESPONSES.ru.analysis_started} для ${asset}`;
    }
    
    if (COMMAND_PATTERNS.signals.test(normalizedCommand)) {
      await displaySignals(exchange);
      return RESPONSES.ru.signals_displayed;
    }
    
    if (COMMAND_PATTERNS.tor_access.test(normalizedCommand)) {
      await activateTorAccess(exchange);
      return RESPONSES.ru.tor_activated;
    }
    
    if (COMMAND_PATTERNS.zkp_verify.test(normalizedCommand)) {
      await verifyZKP(exchange);
      return RESPONSES.ru.zkp_verified;
    }
    
    if (COMMAND_PATTERNS.withdraw.test(normalizedCommand)) {
      const match = normalizedCommand.match(COMMAND_PATTERNS.withdraw);
      const amount = match?.[1] || 'доступные средства';
      await initiateWithdrawal(amount, exchange);
      return `${RESPONSES.ru.withdrawal_initiated}: ${amount}`;
    }
    
    if (COMMAND_PATTERNS.help.test(normalizedCommand)) {
      return RESPONSES.ru.help_message;
    }
    
    if (COMMAND_PATTERNS.stop.test(normalizedCommand)) {
      return RESPONSES.ru.command_stopped;
    }
    
    return RESPONSES.ru.unknown_command;
    
  } catch (error) {
    console.error('Voice command routing error:', error);
    return RESPONSES.ru.error_occurred;
  }
}

/**
 * Execute buy order
 */
async function executeBuyOrder(asset: string, exchange: string): Promise<void> {
  try {
    const response = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/trading/buy`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        exchange,
        symbol: `${asset.toUpperCase()}USDT`,
        quantity: 0.001, // Default small quantity
        type: 'market'
      })
    });
    
    if (!response.ok) {
      throw new Error('Buy order failed');
    }
    
    console.log(`Buy order executed for ${asset} on ${exchange}`);
  } catch (error) {
    console.error('Buy order error:', error);
    throw error;
  }
}

/**
 * Execute sell order
 */
async function executeSellOrder(asset: string, exchange: string): Promise<void> {
  try {
    const response = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/trading/sell`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        exchange,
        symbol: `${asset.toUpperCase()}USDT`,
        quantity: 0.001, // Default small quantity
        type: 'market'
      })
    });
    
    if (!response.ok) {
      throw new Error('Sell order failed');
    }
    
    console.log(`Sell order executed for ${asset} on ${exchange}`);
  } catch (error) {
    console.error('Sell order error:', error);
    throw error;
  }
}

/**
 * Get system status
 */
async function getSystemStatus(exchange: string): Promise<string> {
  try {
    const response = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/exchanges/${exchange}/status`);
    const data = await response.json();
    
    return `Биржа ${exchange}: ${data.status === 'connected' ? 'подключена' : 'отключена'}`;
  } catch (error) {
    console.error('Status check error:', error);
    return 'Статус недоступен';
  }
}

/**
 * Get balance information
 */
async function getBalance(exchange: string): Promise<string> {
  try {
    const response = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/accounts/balance?exchange=${exchange}`);
    const data = await response.json();
    
    const usdtBalance = data.balances?.find((b: any) => b.asset === 'USDT')?.free || 0;
    return `USDT: ${parseFloat(usdtBalance).toFixed(2)}`;
  } catch (error) {
    console.error('Balance check error:', error);
    return 'Баланс недоступен';
  }
}

/**
 * Switch exchange
 */
async function switchExchange(newExchange: string): Promise<void> {
  console.log(`Switching to exchange: ${newExchange}`);
  
  
  await new Promise(resolve => setTimeout(resolve, 500));
}

/**
 * Start market analysis
 */
async function startAnalysis(asset: string, exchange: string): Promise<void> {
  try {
    const response = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/ai/analyze`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        exchange,
        asset,
        timeframe: '1h',
        indicators: ['RSI', 'MACD', 'Bollinger Bands']
      })
    });
    
    if (!response.ok) {
      throw new Error('Analysis request failed');
    }
    
    console.log(`Analysis started for ${asset} on ${exchange}`);
  } catch (error) {
    console.error('Analysis error:', error);
    throw error;
  }
}

/**
 * Display trading signals
 */
async function displaySignals(exchange: string): Promise<void> {
  console.log(`Displaying signals for ${exchange}`);
  await new Promise(resolve => setTimeout(resolve, 300));
}

/**
 * Activate TOR access
 */
async function activateTorAccess(exchange: string): Promise<void> {
  try {
    const response = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/tor-proxy`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ exchange, action: 'activate' })
    });
    
    if (!response.ok) {
      throw new Error('TOR activation failed');
    }
    
    console.log(`TOR access activated for ${exchange}`);
  } catch (error) {
    console.error('TOR activation error:', error);
    throw error;
  }
}

/**
 * Verify ZKP
 */
async function verifyZKP(exchange: string): Promise<void> {
  try {
    const formData = new FormData();
    formData.append('zkp_id', `${exchange}-${Date.now()}`);
    
    const response = await fetch(`${import.meta.env.VITE_BACKEND_URL}/zkp/prove`, {
      method: 'POST',
      body: formData
    });
    
    if (!response.ok) {
      throw new Error('ZKP verification failed');
    }
    
    console.log(`ZKP verified for ${exchange}`);
  } catch (error) {
    console.error('ZKP verification error:', error);
    throw error;
  }
}

/**
 * Initiate withdrawal
 */
async function initiateWithdrawal(amount: string, exchange: string): Promise<void> {
  try {
    const numericAmount = parseFloat(amount) || 100; // Default to 100 if parsing fails
    
    const response = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/withdraw`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        exchange,
        amount: numericAmount,
        currency: 'USDT'
      })
    });
    
    if (!response.ok) {
      throw new Error('Withdrawal failed');
    }
    
    console.log(`Withdrawal initiated: ${numericAmount} USDT from ${exchange}`);
  } catch (error) {
    console.error('Withdrawal error:', error);
    throw error;
  }
}

/**
 * Parse voice command for specific parameters
 */
export function parseVoiceCommand(command: string): {
  action: string;
  parameters: Record<string, any>;
} {
  const normalizedCommand = command.toLowerCase().trim();
  
  for (const [action, pattern] of Object.entries(COMMAND_PATTERNS)) {
    const match = normalizedCommand.match(pattern);
    if (match) {
      return {
        action,
        parameters: {
          fullMatch: match[0],
          groups: match.slice(1),
          originalCommand: command
        }
      };
    }
  }
  
  return {
    action: 'unknown',
    parameters: { originalCommand: command }
  };
}

/**
 * Get available voice commands
 */
export function getAvailableCommands(): string[] {
  return [
    'купи [актив]', 'продай [актив]',
    'статус', 'баланс',
    'переключи на [биржа]',
    'анализ [актив]', 'сигналы',
    'тор', 'верификация',
    'вывод [сумма]',
    'помощь', 'стоп'
  ];
}
