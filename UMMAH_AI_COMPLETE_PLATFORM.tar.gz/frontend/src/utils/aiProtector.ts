interface ThreatData {
  id: string;
  type: 'market_manipulation' | 'unusual_volume' | 'price_anomaly' | 'network_attack' | 'api_abuse';
  severity: 'low' | 'medium' | 'high' | 'critical';
  exchange: string;
  timestamp: number;
  description: string;
  mitigated: boolean;
}

interface ProtectionStrategy {
  name: string;
  enabled: boolean;
  threshold: number;
  action: 'alert' | 'pause' | 'stop' | 'reroute';
}

class AIProtectorService {
  private threats: ThreatData[] = [];
  private strategies: Map<string, ProtectionStrategy> = new Map();
  private isActive = true;
  private callbacks: ((threat: ThreatData) => void)[] = [];
  private monitoringInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.initializeStrategies();
    this.startMonitoring();
  }

  private initializeStrategies(): void {
    this.strategies.set('market_manipulation', {
      name: 'Market Manipulation Detection',
      enabled: true,
      threshold: 0.8,
      action: 'pause'
    });

    this.strategies.set('unusual_volume', {
      name: 'Unusual Volume Detection',
      enabled: true,
      threshold: 0.7,
      action: 'alert'
    });

    this.strategies.set('price_anomaly', {
      name: 'Price Anomaly Detection',
      enabled: true,
      threshold: 0.9,
      action: 'reroute'
    });

    this.strategies.set('network_attack', {
      name: 'Network Attack Detection',
      enabled: true,
      threshold: 0.95,
      action: 'stop'
    });

    this.strategies.set('api_abuse', {
      name: 'API Abuse Detection',
      enabled: true,
      threshold: 0.6,
      action: 'alert'
    });
  }

  private startMonitoring(): void {
    this.monitoringInterval = setInterval(() => {
      if (this.isActive) {
        this.performThreatAnalysis();
      }
    }, 5000); // Check every 5 seconds
  }

  private performThreatAnalysis(): void {
    const threatTypes: ThreatData['type'][] = [
      'market_manipulation',
      'unusual_volume', 
      'price_anomaly',
      'network_attack',
      'api_abuse'
    ];

    const exchanges = ['Binance', 'OKX', 'Kraken', 'Coinbase', 'Bybit'];
    const severities: ThreatData['severity'][] = ['low', 'medium', 'high', 'critical'];

    if (Math.random() < 0.1) {
      const threat: ThreatData = {
        id: `threat_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        type: threatTypes[Math.floor(Math.random() * threatTypes.length)],
        severity: severities[Math.floor(Math.random() * severities.length)],
        exchange: exchanges[Math.floor(Math.random() * exchanges.length)],
        timestamp: Date.now(),
        description: this.generateThreatDescription(),
        mitigated: false
      };

      this.processThreat(threat);
    }
  }

  private generateThreatDescription(): string {
    const descriptions = [
      'Unusual trading pattern detected',
      'Abnormal price movement identified',
      'Suspicious API request frequency',
      'Potential wash trading activity',
      'Network latency spike detected',
      'Order book manipulation suspected',
      'Coordinated trading behavior observed',
      'Anomalous volume surge detected'
    ];

    return descriptions[Math.floor(Math.random() * descriptions.length)];
  }

  private processThreat(threat: ThreatData): void {
    this.threats.push(threat);
    
    const strategy = this.strategies.get(threat.type);
    if (strategy && strategy.enabled) {
      this.executeMitigation(threat, strategy);
    }

    this.notifyCallbacks(threat);
    
    if (threat.severity === 'low') {
      setTimeout(() => {
        this.mitigateThreat(threat.id);
      }, 30000);
    }
  }

  private executeMitigation(threat: ThreatData, strategy: ProtectionStrategy): void {
    console.log(`Executing ${strategy.action} for ${threat.type} threat on ${threat.exchange}`);
    
    switch (strategy.action) {
      case 'alert':
        console.warn(`ALERT: ${threat.description} on ${threat.exchange}`);
        break;
      case 'pause':
        console.warn(`PAUSE: Trading paused on ${threat.exchange} due to ${threat.type}`);
        break;
      case 'stop':
        console.error(`STOP: All operations stopped due to ${threat.type} on ${threat.exchange}`);
        break;
      case 'reroute':
        console.info(`REROUTE: Traffic rerouted from ${threat.exchange} due to ${threat.type}`);
        break;
    }
  }

  public mitigateThreat(threatId: string): void {
    const threat = this.threats.find(t => t.id === threatId);
    if (threat) {
      threat.mitigated = true;
      console.log(`Threat ${threatId} has been mitigated`);
    }
  }

  public getActiveThreats(): ThreatData[] {
    return this.threats.filter(t => !t.mitigated);
  }

  public getAllThreats(): ThreatData[] {
    return [...this.threats];
  }

  public getThreatsByExchange(exchange: string): ThreatData[] {
    return this.threats.filter(t => t.exchange === exchange);
  }

  public getThreatsBySeverity(severity: ThreatData['severity']): ThreatData[] {
    return this.threats.filter(t => t.severity === severity);
  }

  public enableProtection(): void {
    this.isActive = true;
    console.log('AI Protection enabled');
  }

  public disableProtection(): void {
    this.isActive = false;
    console.log('AI Protection disabled');
  }

  public isProtectionActive(): boolean {
    return this.isActive;
  }

  public updateStrategy(type: string, updates: Partial<ProtectionStrategy>): void {
    const strategy = this.strategies.get(type);
    if (strategy) {
      this.strategies.set(type, { ...strategy, ...updates });
    }
  }

  public getStrategies(): ProtectionStrategy[] {
    return Array.from(this.strategies.values());
  }

  public subscribe(callback: (threat: ThreatData) => void): () => void {
    this.callbacks.push(callback);
    
    return () => {
      const index = this.callbacks.indexOf(callback);
      if (index > -1) {
        this.callbacks.splice(index, 1);
      }
    };
  }

  private notifyCallbacks(threat: ThreatData): void {
    this.callbacks.forEach(callback => {
      try {
        callback(threat);
      } catch (error) {
        console.error('Error in threat callback:', error);
      }
    });
  }

  public destroy(): void {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }
    this.callbacks.length = 0;
  }
}

export default AIProtectorService;
export type { ThreatData, ProtectionStrategy };
