interface SyncConfig {
  maxLatency: number;
  batchSize: number;
  syncInterval: number;
  enablePredictiveSync: boolean;
}

class RealTimeSyncManager {
  private config: SyncConfig;
  private syncQueue: Map<string, any[]> = new Map();
  private lastSyncTime: Map<string, number> = new Map();
  private predictiveCache: Map<string, any> = new Map();
  private performanceMetrics: Map<string, number[]> = new Map();

  constructor(config: Partial<SyncConfig> = {}) {
    this.config = {
      maxLatency: 10, // 10ms maximum latency
      batchSize: 25,
      syncInterval: 5, // 5ms sync interval for ultra-fast updates
      enablePredictiveSync: true,
      ...config
    };

    this.startSyncLoop();
  }

  private startSyncLoop(): void {
    const syncLoop = () => {
      const startTime = performance.now();
      
      this.processSyncQueue();
      
      const processingTime = performance.now() - startTime;
      this.recordMetric('sync_processing_time', processingTime);

      setTimeout(syncLoop, this.config.syncInterval);
    };

    syncLoop();
  }

  public addToSyncQueue(channel: string, data: any): void {
    const timestamp = performance.now();
    
    if (!this.syncQueue.has(channel)) {
      this.syncQueue.set(channel, []);
    }

    const queue = this.syncQueue.get(channel)!;
    queue.push({
      ...data,
      _syncTimestamp: timestamp,
      _channel: channel
    });

    if (this.isCriticalUpdate(data)) {
      this.processChannelImmediately(channel);
    }
  }

  private isCriticalUpdate(data: any): boolean {
    return data.type === 'price_alert' || 
           data.type === 'emergency_stop' || 
           data.priority === 'high' ||
           data.latency_critical === true;
  }

  private processChannelImmediately(channel: string): void {
    const queue = this.syncQueue.get(channel);
    if (!queue || queue.length === 0) return;

    const startTime = performance.now();
    const batch = queue.splice(0, this.config.batchSize);
    
    this.processBatch(channel, batch);
    
    const processingTime = performance.now() - startTime;
    this.recordMetric('immediate_processing_time', processingTime);
  }

  private processSyncQueue(): void {
    for (const [channel, queue] of this.syncQueue.entries()) {
      if (queue.length === 0) continue;

      const lastSync = this.lastSyncTime.get(channel) || 0;
      const timeSinceLastSync = performance.now() - lastSync;

      if (queue.length >= this.config.batchSize || 
          timeSinceLastSync >= this.config.syncInterval) {
        
        const batch = queue.splice(0, this.config.batchSize);
        this.processBatch(channel, batch);
        this.lastSyncTime.set(channel, performance.now());
      }
    }
  }

  private processBatch(channel: string, batch: any[]): void {
    const startTime = performance.now();

    try {
      batch.sort((a, b) => a._syncTimestamp - b._syncTimestamp);

      batch.forEach(item => {
        const itemLatency = performance.now() - item._syncTimestamp;
        
        if (itemLatency > this.config.maxLatency) {
          console.warn(`High sync latency detected: ${itemLatency.toFixed(2)}ms for channel ${channel}`);
        }

        this.processItem(channel, item);
        this.recordMetric('item_latency', itemLatency);
      });

      if (this.config.enablePredictiveSync) {
        this.updatePredictiveCache(channel, batch);
      }

    } catch (error) {
      console.error(`Sync processing error for channel ${channel}:`, error);
    }

    const totalProcessingTime = performance.now() - startTime;
    this.recordMetric('batch_processing_time', totalProcessingTime);
  }

  private processItem(channel: string, item: any): void {
    const event = new CustomEvent(`sync:${channel}`, {
      detail: {
        data: item,
        timestamp: performance.now(),
        latency: performance.now() - item._syncTimestamp
      }
    });

    requestAnimationFrame(() => {
      document.dispatchEvent(event);
    });
  }

  private updatePredictiveCache(channel: string, batch: any[]): void {
    const latest = batch[batch.length - 1];
    if (!latest) return;

    const prediction = this.generatePrediction(channel, batch);
    if (prediction) {
      this.predictiveCache.set(channel, {
        ...prediction,
        _predicted: true,
        _confidence: this.calculatePredictionConfidence(batch),
        _timestamp: performance.now()
      });
    }
  }

  private generatePrediction(channel: string, batch: any[]): any | null {
    if (batch.length < 2) return null;

    try {
      const recent = batch.slice(-3); // Use last 3 items for prediction
      
      if (recent[0].price && typeof recent[0].price === 'number') {
        const prices = recent.map(item => item.price);
        const trend = this.calculateTrend(prices);
        
        return {
          ...recent[recent.length - 1],
          price: recent[recent.length - 1].price + trend,
          volume: this.predictVolume(recent),
          _prediction_type: 'linear_trend'
        };
      }

      return null;
    } catch (error) {
      console.error('Prediction generation error:', error);
      return null;
    }
  }

  private calculateTrend(values: number[]): number {
    if (values.length < 2) return 0;
    
    const differences: number[] = [];
    for (let i = 1; i < values.length; i++) {
      differences.push(values[i] - values[i - 1]);
    }
    
    return differences.reduce((sum, diff) => sum + diff, 0) / differences.length;
  }

  private predictVolume(recent: any[]): number {
    const volumes = recent.map(item => item.volume || 0);
    const avgVolume = volumes.reduce((sum, vol) => sum + vol, 0) / volumes.length;
    
    const variance = avgVolume * 0.1; // 10% variance
    return avgVolume + (Math.random() - 0.5) * variance;
  }

  private calculatePredictionConfidence(batch: any[]): number {
    if (batch.length < 3) return 0.5;

    const prices = batch.map(item => item.price || 0);
    const variance = this.calculateVariance(prices);
    const maxVariance = Math.max(...prices) * 0.1; // 10% of max price

    return Math.max(0.1, Math.min(0.9, 1 - (variance / maxVariance)));
  }

  private calculateVariance(values: number[]): number {
    const mean = values.reduce((sum, val) => sum + val, 0) / values.length;
    const squaredDiffs = values.map(val => Math.pow(val - mean, 2));
    return squaredDiffs.reduce((sum, diff) => sum + diff, 0) / values.length;
  }

  public getPrediction(channel: string): any | null {
    const prediction = this.predictiveCache.get(channel);
    if (!prediction) return null;

    const age = performance.now() - prediction._timestamp;
    if (age > 100) {
      this.predictiveCache.delete(channel);
      return null;
    }

    return prediction;
  }

  public subscribe(channel: string, callback: (data: any) => void): () => void {
    const handler = (event: CustomEvent) => {
      callback(event.detail);
    };

    document.addEventListener(`sync:${channel}`, handler as EventListener);

    return () => {
      document.removeEventListener(`sync:${channel}`, handler as EventListener);
    };
  }

  private recordMetric(metric: string, value: number): void {
    if (!this.performanceMetrics.has(metric)) {
      this.performanceMetrics.set(metric, []);
    }

    const metrics = this.performanceMetrics.get(metric)!;
    metrics.push(value);

    if (metrics.length > 100) {
      metrics.shift();
    }

    if (metric.includes('latency') && value > this.config.maxLatency) {
      console.warn(`High ${metric}: ${value.toFixed(2)}ms`);
    }
  }

  public getPerformanceMetrics(): Record<string, any> {
    const metrics: Record<string, any> = {};

    for (const [key, values] of this.performanceMetrics.entries()) {
      metrics[key] = {
        count: values.length,
        average: values.reduce((sum, val) => sum + val, 0) / values.length,
        min: Math.min(...values),
        max: Math.max(...values),
        latest: values[values.length - 1]
      };
    }

    return {
      metrics,
      queue_sizes: Object.fromEntries(
        Array.from(this.syncQueue.entries()).map(([key, queue]) => [key, queue.length])
      ),
      cache_size: this.predictiveCache.size,
      config: this.config
    };
  }

  public clearChannel(channel: string): void {
    this.syncQueue.delete(channel);
    this.lastSyncTime.delete(channel);
    this.predictiveCache.delete(channel);
  }

  public destroy(): void {
    this.syncQueue.clear();
    this.lastSyncTime.clear();
    this.predictiveCache.clear();
    this.performanceMetrics.clear();
  }
}

export const realTimeSyncManager = new RealTimeSyncManager();
export default RealTimeSyncManager;
