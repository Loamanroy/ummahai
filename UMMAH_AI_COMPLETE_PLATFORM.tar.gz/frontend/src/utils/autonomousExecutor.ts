interface ExecutionOrder {
  id: string;
  exchange: string;
  symbol: string;
  side: 'buy' | 'sell';
  amount: number;
  price: number;
  type: 'market' | 'limit' | 'stop';
  status: 'pending' | 'executing' | 'completed' | 'failed' | 'cancelled';
  timestamp: number;
  executedAt?: number;
  profit?: number;
}

interface ExecutionMetrics {
  totalOrders: number;
  successfulOrders: number;
  failedOrders: number;
  totalProfit: number;
  averageExecutionTime: number;
  successRate: number;
}

interface ExecutionStrategy {
  name: string;
  enabled: boolean;
  riskLevel: 'low' | 'medium' | 'high';
  maxOrderSize: number;
  stopLoss: number;
  takeProfit: number;
}

class AutonomousExecutorService {
  private orders: ExecutionOrder[] = [];
  private isActive = false;
  private strategies: Map<string, ExecutionStrategy> = new Map();
  private metrics: ExecutionMetrics = {
    totalOrders: 0,
    successfulOrders: 0,
    failedOrders: 0,
    totalProfit: 0,
    averageExecutionTime: 0,
    successRate: 0
  };
  private callbacks: ((order: ExecutionOrder) => void)[] = [];
  private executionInterval: number | null = null;

  constructor() {
    this.initializeStrategies();
  }

  private initializeStrategies(): void {
    this.strategies.set('conservative', {
      name: 'Conservative Trading',
      enabled: true,
      riskLevel: 'low',
      maxOrderSize: 0.01,
      stopLoss: 0.02,
      takeProfit: 0.03
    });

    this.strategies.set('balanced', {
      name: 'Balanced Trading',
      enabled: true,
      riskLevel: 'medium',
      maxOrderSize: 0.05,
      stopLoss: 0.03,
      takeProfit: 0.05
    });

    this.strategies.set('aggressive', {
      name: 'Aggressive Trading',
      enabled: false,
      riskLevel: 'high',
      maxOrderSize: 0.1,
      stopLoss: 0.05,
      takeProfit: 0.08
    });
  }

  public startExecution(): void {
    if (!this.isActive) {
      this.isActive = true;
      this.executionInterval = window.setInterval(() => {
        this.processOrders();
        this.generateNewOrders();
      }, 2000);
      console.log('Autonomous execution started');
    }
  }

  public stopExecution(): void {
    if (this.isActive) {
      this.isActive = false;
      if (this.executionInterval) {
        window.clearInterval(this.executionInterval);
        this.executionInterval = null;
      }
      console.log('Autonomous execution stopped');
    }
  }

  private processOrders(): void {
    const pendingOrders = this.orders.filter(order => order.status === 'pending');
    
    pendingOrders.forEach(order => {
      if (Math.random() > 0.3) { // 70% execution chance
        this.executeOrder(order);
      }
    });
  }

  private executeOrder(order: ExecutionOrder): void {
    order.status = 'executing';
    
    setTimeout(() => {
      const success = Math.random() > 0.1; // 90% success rate
      
      if (success) {
        order.status = 'completed';
        order.executedAt = Date.now();
        order.profit = this.calculateProfit(order);
        this.metrics.successfulOrders++;
        this.metrics.totalProfit += order.profit;
      } else {
        order.status = 'failed';
        this.metrics.failedOrders++;
      }
      
      this.updateMetrics();
      this.notifyCallbacks(order);
    }, Math.random() * 1000 + 500); // 0.5-1.5 second execution time
  }

  private calculateProfit(order: ExecutionOrder): number {
    const baseProfit = order.amount * order.price * 0.001; // 0.1% base profit
    const randomFactor = (Math.random() - 0.5) * 0.02; // ±1% random variation
    return baseProfit * (1 + randomFactor);
  }

  private generateNewOrders(): void {
    if (!this.isActive) return;
    
    const activeStrategies = Array.from(this.strategies.values()).filter(s => s.enabled);
    
    if (activeStrategies.length === 0) return;
    
    if (Math.random() < 0.2) {
      const strategy = activeStrategies[Math.floor(Math.random() * activeStrategies.length)];
      const exchanges = ['Binance', 'OKX', 'Kraken', 'Coinbase', 'Bybit'];
      const symbols = ['BTC/USDT', 'ETH/USDT', 'BNB/USDT', 'ADA/USDT', 'SOL/USDT'];
      
      const order: ExecutionOrder = {
        id: `order_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        exchange: exchanges[Math.floor(Math.random() * exchanges.length)],
        symbol: symbols[Math.floor(Math.random() * symbols.length)],
        side: Math.random() > 0.5 ? 'buy' : 'sell',
        amount: Math.random() * strategy.maxOrderSize,
        price: Math.random() * 50000 + 30000, // Random price between 30k-80k
        type: Math.random() > 0.7 ? 'limit' : 'market',
        status: 'pending',
        timestamp: Date.now()
      };
      
      this.orders.push(order);
      this.metrics.totalOrders++;
      this.notifyCallbacks(order);
    }
  }

  private updateMetrics(): void {
    this.metrics.successRate = this.metrics.totalOrders > 0 
      ? (this.metrics.successfulOrders / this.metrics.totalOrders) * 100 
      : 0;
    
    const completedOrders = this.orders.filter(o => o.status === 'completed' && o.executedAt);
    if (completedOrders.length > 0) {
      const totalExecutionTime = completedOrders.reduce((sum, order) => {
        return sum + (order.executedAt! - order.timestamp);
      }, 0);
      this.metrics.averageExecutionTime = totalExecutionTime / completedOrders.length;
    }
  }

  public createManualOrder(orderData: Partial<ExecutionOrder>): string {
    const order: ExecutionOrder = {
      id: `manual_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      exchange: orderData.exchange || 'Binance',
      symbol: orderData.symbol || 'BTC/USDT',
      side: orderData.side || 'buy',
      amount: orderData.amount || 0.01,
      price: orderData.price || 50000,
      type: orderData.type || 'market',
      status: 'pending',
      timestamp: Date.now()
    };
    
    this.orders.push(order);
    this.metrics.totalOrders++;
    this.notifyCallbacks(order);
    
    return order.id;
  }

  public cancelOrder(orderId: string): boolean {
    const order = this.orders.find(o => o.id === orderId);
    if (order && order.status === 'pending') {
      order.status = 'cancelled';
      this.notifyCallbacks(order);
      return true;
    }
    return false;
  }

  public getOrders(): ExecutionOrder[] {
    return [...this.orders];
  }

  public getOrdersByStatus(status: ExecutionOrder['status']): ExecutionOrder[] {
    return this.orders.filter(order => order.status === status);
  }

  public getOrdersByExchange(exchange: string): ExecutionOrder[] {
    return this.orders.filter(order => order.exchange === exchange);
  }

  public getMetrics(): ExecutionMetrics {
    return { ...this.metrics };
  }

  public getStrategies(): ExecutionStrategy[] {
    return Array.from(this.strategies.values());
  }

  public updateStrategy(name: string, updates: Partial<ExecutionStrategy>): void {
    const strategy = this.strategies.get(name);
    if (strategy) {
      this.strategies.set(name, { ...strategy, ...updates });
    }
  }

  public isExecutionActive(): boolean {
    return this.isActive;
  }

  public subscribe(callback: (order: ExecutionOrder) => void): () => void {
    this.callbacks.push(callback);
    
    return () => {
      const index = this.callbacks.indexOf(callback);
      if (index > -1) {
        this.callbacks.splice(index, 1);
      }
    };
  }

  private notifyCallbacks(order: ExecutionOrder): void {
    this.callbacks.forEach(callback => {
      try {
        callback(order);
      } catch (error) {
        console.error('Error in execution callback:', error);
      }
    });
  }

  public destroy(): void {
    this.stopExecution();
    this.callbacks.length = 0;
  }
}

export default AutonomousExecutorService;
export type { ExecutionOrder, ExecutionMetrics, ExecutionStrategy };
