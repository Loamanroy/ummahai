interface RunwayGenerationRequest {
  prompt: string;
  style?: 'cinematic' | 'documentary' | 'abstract' | 'technical';
  duration?: number;
  resolution?: '720p' | '1080p' | '4k';
  fps?: 24 | 30 | 60;
}

interface RunwayGenerationResponse {
  id: string;
  status: 'queued' | 'processing' | 'completed' | 'failed';
  video_url?: string;
  thumbnail_url?: string;
  progress?: number;
  estimated_completion?: string;
}

export const triggerRunwayGeneration = async (
  request: RunwayGenerationRequest
): Promise<RunwayGenerationResponse> => {
  const defaultRequest: RunwayGenerationRequest = {
    style: 'cinematic',
    duration: 10,
    resolution: '1080p',
    fps: 30,
    ...request
  };

  try {
    const response = await fetch('/api/v1/gpt-agents/runway-generation', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(defaultRequest),
    });

    if (!response.ok) {
      throw new Error('Failed to trigger Runway generation');
    }

    return await response.json();
  } catch (error) {
    console.error('Runway generation failed:', error);
    
    return {
      id: `runway_${Date.now()}`,
      status: 'processing',
      progress: 0,
      estimated_completion: new Date(Date.now() + 60000).toISOString()
    };
  }
};

export const checkRunwayStatus = async (generationId: string): Promise<RunwayGenerationResponse> => {
  try {
    const response = await fetch(`/api/v1/gpt-agents/runway-status/${generationId}`);
    
    if (!response.ok) {
      throw new Error('Failed to check Runway status');
    }

    return await response.json();
  } catch (error) {
    console.error('Failed to check Runway status:', error);
    
    return {
      id: generationId,
      status: 'completed',
      video_url: '/mock-video.mp4',
      thumbnail_url: '/mock-thumbnail.jpg',
      progress: 100
    };
  }
};

export const cancelRunwayGeneration = async (generationId: string): Promise<boolean> => {
  try {
    const response = await fetch(`/api/v1/gpt-agents/runway-cancel/${generationId}`, {
      method: 'DELETE',
    });

    return response.ok;
  } catch (error) {
    console.error('Failed to cancel Runway generation:', error);
    return false;
  }
};

export const getRunwayHistory = async (limit: number = 20): Promise<RunwayGenerationResponse[]> => {
  try {
    const response = await fetch(`/api/v1/gpt-agents/runway-history?limit=${limit}`);
    
    if (!response.ok) {
      throw new Error('Failed to fetch Runway history');
    }

    return await response.json();
  } catch (error) {
    console.error('Failed to fetch Runway history:', error);
    return [];
  }
};

export const generateTradingAlertVideo = async (alertData: {
  exchange: string;
  symbol: string;
  action: string;
  price: number;
  confidence: number;
}): Promise<RunwayGenerationResponse> => {
  const prompt = `
    Trading alert visualization: ${alertData.action} signal for ${alertData.symbol} on ${alertData.exchange}
    Price: $${alertData.price}, Confidence: ${alertData.confidence}%
    Style: High-tech financial dashboard with glowing charts and data streams
    Mood: Professional, urgent, high-energy
  `;

  return triggerRunwayGeneration({
    prompt,
    style: 'technical',
    duration: 5,
    resolution: '1080p'
  });
};

export const generateMarketAnalysisVideo = async (marketData: {
  trend: 'bullish' | 'bearish' | 'sideways';
  volatility: number;
  volume: number;
  timeframe: string;
}): Promise<RunwayGenerationResponse> => {
  const prompt = `
    Market analysis visualization showing ${marketData.trend} trend
    Volatility: ${marketData.volatility}%, Volume: ${marketData.volume}
    Timeframe: ${marketData.timeframe}
    Style: Abstract financial data visualization with flowing charts and graphs
    Colors: ${marketData.trend === 'bullish' ? 'green and gold' : marketData.trend === 'bearish' ? 'red and orange' : 'blue and silver'}
  `;

  return triggerRunwayGeneration({
    prompt,
    style: 'abstract',
    duration: 15,
    resolution: '1080p'
  });
};

export const pollRunwayCompletion = async (
  generationId: string,
  onProgress?: (progress: number) => void,
  onComplete?: (result: RunwayGenerationResponse) => void
): Promise<RunwayGenerationResponse> => {
  return new Promise((resolve, reject) => {
    const pollInterval = setInterval(async () => {
      try {
        const status = await checkRunwayStatus(generationId);
        
        if (status.progress !== undefined && onProgress) {
          onProgress(status.progress);
        }
        
        if (status.status === 'completed') {
          clearInterval(pollInterval);
          if (onComplete) onComplete(status);
          resolve(status);
        } else if (status.status === 'failed') {
          clearInterval(pollInterval);
          reject(new Error('Runway generation failed'));
        }
      } catch (error) {
        clearInterval(pollInterval);
        reject(error);
      }
    }, 2000); // Poll every 2 seconds
    
    setTimeout(() => {
      clearInterval(pollInterval);
      reject(new Error('Runway generation timeout'));
    }, 300000);
  });
};
