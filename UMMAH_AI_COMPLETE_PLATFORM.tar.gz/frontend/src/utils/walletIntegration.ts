interface WalletProvider {
  name: string;
  isInstalled: boolean;
  connect: () => Promise<string>;
  disconnect: () => Promise<void>;
  getBalance: (address: string) => Promise<number>;
  signTransaction: (transaction: any) => Promise<string>;
}

interface WalletState {
  isConnected: boolean;
  address: string | null;
  balance: number;
  provider: string | null;
}

class WalletIntegrationService {
  private state: WalletState = {
    isConnected: false,
    address: null,
    balance: 0,
    provider: null
  };

  private callbacks: ((state: WalletState) => void)[] = [];
  private providers: Map<string, WalletProvider> = new Map();

  constructor() {
    this.initializeProviders();
  }

  private initializeProviders(): void {
    this.providers.set('metamask', {
      name: 'MetaMask',
      isInstalled: typeof (window as any).ethereum !== 'undefined',
      connect: async () => {
        if (typeof (window as any).ethereum !== 'undefined') {
          const accounts = await (window as any).ethereum.request({
            method: 'eth_requestAccounts'
          });
          return accounts[0];
        }
        throw new Error('MetaMask not installed');
      },
      disconnect: async () => {
        this.updateState({ isConnected: false, address: null, balance: 0, provider: null });
      },
      getBalance: async (address: string) => {
        if (typeof (window as any).ethereum !== 'undefined') {
          const balance = await (window as any).ethereum.request({
            method: 'eth_getBalance',
            params: [address, 'latest']
          });
          return parseInt(balance, 16) / Math.pow(10, 18);
        }
        return 0;
      },
      signTransaction: async (transaction: any) => {
        if (typeof (window as any).ethereum !== 'undefined') {
          return await (window as any).ethereum.request({
            method: 'eth_sendTransaction',
            params: [transaction]
          });
        }
        throw new Error('MetaMask not available');
      }
    });

    this.providers.set('walletconnect', {
      name: 'WalletConnect',
      isInstalled: true, // WalletConnect is always available
      connect: async () => {
        return '0x' + Math.random().toString(16).substr(2, 40);
      },
      disconnect: async () => {
        this.updateState({ isConnected: false, address: null, balance: 0, provider: null });
      },
      getBalance: async (address: string) => {
        return Math.random() * 10;
      },
      signTransaction: async (transaction: any) => {
        return '0x' + Math.random().toString(16).substr(2, 64);
      }
    });

    this.providers.set('phantom', {
      name: 'Phantom',
      isInstalled: typeof (window as any).solana !== 'undefined',
      connect: async () => {
        if (typeof (window as any).solana !== 'undefined') {
          const response = await (window as any).solana.connect();
          return response.publicKey.toString();
        }
        throw new Error('Phantom not installed');
      },
      disconnect: async () => {
        if (typeof (window as any).solana !== 'undefined') {
          await (window as any).solana.disconnect();
        }
        this.updateState({ isConnected: false, address: null, balance: 0, provider: null });
      },
      getBalance: async (address: string) => {
        return Math.random() * 100;
      },
      signTransaction: async (transaction: any) => {
        if (typeof (window as any).solana !== 'undefined') {
          const signedTransaction = await (window as any).solana.signTransaction(transaction);
          return signedTransaction.signature;
        }
        throw new Error('Phantom not available');
      }
    });
  }

  public async connectWallet(providerName: string): Promise<void> {
    const provider = this.providers.get(providerName);
    
    if (!provider) {
      throw new Error(`Provider ${providerName} not found`);
    }

    if (!provider.isInstalled) {
      throw new Error(`${provider.name} is not installed`);
    }

    try {
      const address = await provider.connect();
      const balance = await provider.getBalance(address);
      
      this.updateState({
        isConnected: true,
        address,
        balance,
        provider: providerName
      });
    } catch (error) {
      console.error('Failed to connect wallet:', error);
      throw error;
    }
  }

  public async disconnectWallet(): Promise<void> {
    if (this.state.provider) {
      const provider = this.providers.get(this.state.provider);
      if (provider) {
        await provider.disconnect();
      }
    }
  }

  public async refreshBalance(): Promise<void> {
    if (this.state.isConnected && this.state.address && this.state.provider) {
      const provider = this.providers.get(this.state.provider);
      if (provider) {
        try {
          const balance = await provider.getBalance(this.state.address);
          this.updateState({ ...this.state, balance });
        } catch (error) {
          console.error('Failed to refresh balance:', error);
        }
      }
    }
  }

  public async signTransaction(transaction: any): Promise<string> {
    if (!this.state.isConnected || !this.state.provider) {
      throw new Error('Wallet not connected');
    }

    const provider = this.providers.get(this.state.provider);
    if (!provider) {
      throw new Error('Provider not found');
    }

    return await provider.signTransaction(transaction);
  }

  public getAvailableProviders(): { name: string; isInstalled: boolean }[] {
    return Array.from(this.providers.values()).map(provider => ({
      name: provider.name,
      isInstalled: provider.isInstalled
    }));
  }

  public getState(): WalletState {
    return { ...this.state };
  }

  public subscribe(callback: (state: WalletState) => void): () => void {
    this.callbacks.push(callback);
    
    return () => {
      const index = this.callbacks.indexOf(callback);
      if (index > -1) {
        this.callbacks.splice(index, 1);
      }
    };
  }

  private updateState(newState: Partial<WalletState>): void {
    this.state = { ...this.state, ...newState };
    this.callbacks.forEach(callback => {
      try {
        callback(this.state);
      } catch (error) {
        console.error('Error in wallet state callback:', error);
      }
    });
  }

  public isWalletConnected(): boolean {
    return this.state.isConnected;
  }

  public getConnectedAddress(): string | null {
    return this.state.address;
  }

  public getBalance(): number {
    return this.state.balance;
  }
}

export default WalletIntegrationService;
export type { WalletProvider, WalletState };
