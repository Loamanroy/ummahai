interface PerformanceConfig {
  enableWebWorkers: boolean;
  batchSize: number;
  batchTimeout: number;
  enableConnectionPooling: boolean;
  maxConnections: number;
  enableCaching: boolean;
  cacheTimeout: number;
}

class PerformanceOptimizer {
  private config: PerformanceConfig;
  private performanceObserver: PerformanceObserver | null = null;
  private metrics: Map<string, number[]> = new Map();
  private connectionPool: Map<string, WebSocket[]> = new Map();
  private cache: Map<string, { data: any; timestamp: number; ttl: number }> = new Map();

  constructor(config: Partial<PerformanceConfig> = {}) {
    this.config = {
      enableWebWorkers: true,
      batchSize: 50,
      batchTimeout: 10, // 10ms for ultra-low latency
      enableConnectionPooling: true,
      maxConnections: 5,
      enableCaching: true,
      cacheTimeout: 30000, // 30 seconds
      ...config
    };

    this.initializePerformanceMonitoring();
    this.startCacheCleanup();
  }

  private initializePerformanceMonitoring(): void {
    if ('PerformanceObserver' in window) {
      this.performanceObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          this.recordMetric('performance', entry.name, entry.duration);
        }
      });

      this.performanceObserver.observe({ 
        entryTypes: ['measure', 'navigation', 'resource'] 
      });
    }
  }

  public recordMetric(category: string, name: string, value: number): void {
    const key = `${category}_${name}`;
    if (!this.metrics.has(key)) {
      this.metrics.set(key, []);
    }

    const metrics = this.metrics.get(key)!;
    metrics.push(value);

    if (metrics.length > 100) {
      metrics.shift();
    }

    if (category === 'latency' && value > 100) {
      console.warn(`High latency detected for ${name}: ${value.toFixed(2)}ms`);
    }
  }

  public getAverageMetric(category: string, name: string): number {
    const key = `${category}_${name}`;
    const metrics = this.metrics.get(key);
    if (!metrics || metrics.length === 0) return 0;

    return metrics.reduce((sum, val) => sum + val, 0) / metrics.length;
  }

  public optimizeRender(callback: () => void): void {
    requestAnimationFrame(() => {
      const startTime = performance.now();
      callback();
      const endTime = performance.now();
      this.recordMetric('render', 'callback_duration', endTime - startTime);
    });
  }

  public batchOperations<T>(
    operations: (() => T)[],
    onComplete: (results: T[]) => void
  ): void {
    const results: T[] = [];
    let processed = 0;

    const processBatch = () => {
      const batchStart = performance.now();
      const batchEnd = Math.min(processed + this.config.batchSize, operations.length);

      for (let i = processed; i < batchEnd; i++) {
        try {
          results[i] = operations[i]();
        } catch (error) {
          console.error(`Batch operation ${i} failed:`, error);
        }
      }

      processed = batchEnd;
      const batchDuration = performance.now() - batchStart;
      this.recordMetric('batch', 'processing_time', batchDuration);

      if (processed < operations.length) {
        setTimeout(processBatch, this.config.batchTimeout);
      } else {
        onComplete(results);
      }
    };

    processBatch();
  }

  public memoize<T extends (...args: any[]) => any>(
    fn: T,
    keyGenerator?: (...args: Parameters<T>) => string
  ): T {
    const cache = new Map<string, { result: ReturnType<T>; timestamp: number }>();

    return ((...args: Parameters<T>): ReturnType<T> => {
      const key = keyGenerator ? keyGenerator(...args) : JSON.stringify(args);
      const cached = cache.get(key);

      if (cached && Date.now() - cached.timestamp < this.config.cacheTimeout) {
        this.recordMetric('cache', 'hit', 1);
        return cached.result;
      }

      const startTime = performance.now();
      const result = fn(...args);
      const endTime = performance.now();

      cache.set(key, { result, timestamp: Date.now() });
      this.recordMetric('cache', 'miss', 1);
      this.recordMetric('function', fn.name || 'anonymous', endTime - startTime);

      return result;
    }) as T;
  }

  public debounce<T extends (...args: any[]) => any>(
    fn: T,
    delay: number
  ): (...args: Parameters<T>) => void {
    let timeoutId: NodeJS.Timeout;

    return (...args: Parameters<T>) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        const startTime = performance.now();
        fn(...args);
        const endTime = performance.now();
        this.recordMetric('debounce', fn.name || 'anonymous', endTime - startTime);
      }, delay);
    };
  }

  public throttle<T extends (...args: any[]) => any>(
    fn: T,
    limit: number
  ): (...args: Parameters<T>) => void {
    let inThrottle: boolean;

    return (...args: Parameters<T>) => {
      if (!inThrottle) {
        const startTime = performance.now();
        fn(...args);
        const endTime = performance.now();
        
        this.recordMetric('throttle', fn.name || 'anonymous', endTime - startTime);
        inThrottle = true;
        
        setTimeout(() => {
          inThrottle = false;
        }, limit);
      }
    };
  }

  public cacheData(key: string, data: any, ttl: number = this.config.cacheTimeout): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl
    });
  }

  public getCachedData(key: string): any | null {
    const cached = this.cache.get(key);
    if (!cached) {
      this.recordMetric('cache', 'miss', 1);
      return null;
    }

    if (Date.now() - cached.timestamp > cached.ttl) {
      this.cache.delete(key);
      this.recordMetric('cache', 'expired', 1);
      return null;
    }

    this.recordMetric('cache', 'hit', 1);
    return cached.data;
  }

  private startCacheCleanup(): void {
    setInterval(() => {
      const now = Date.now();
      let cleaned = 0;

      for (const [key, cached] of this.cache.entries()) {
        if (now - cached.timestamp > cached.ttl) {
          this.cache.delete(key);
          cleaned++;
        }
      }

      if (cleaned > 0) {
        this.recordMetric('cache', 'cleanup', cleaned);
      }
    }, 60000); // Clean every minute
  }

  public getPerformanceReport(): Record<string, any> {
    const report: Record<string, any> = {};

    for (const [key, values] of this.metrics.entries()) {
      const [category, name] = key.split('_', 2);
      if (!report[category]) {
        report[category] = {};
      }

      report[category][name] = {
        count: values.length,
        average: values.reduce((sum, val) => sum + val, 0) / values.length,
        min: Math.min(...values),
        max: Math.max(...values),
        latest: values[values.length - 1]
      };
    }

    report.cache_size = this.cache.size;
    report.connection_pools = Object.fromEntries(
      Array.from(this.connectionPool.entries()).map(([key, pool]) => [key, pool.length])
    );

    return report;
  }

  public destroy(): void {
    if (this.performanceObserver) {
      this.performanceObserver.disconnect();
    }
    
    this.metrics.clear();
    this.cache.clear();
    this.connectionPool.clear();
  }
}

export const performanceOptimizer = new PerformanceOptimizer();
export default PerformanceOptimizer;
