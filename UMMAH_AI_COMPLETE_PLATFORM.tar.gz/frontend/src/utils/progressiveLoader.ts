/**
 * Progressive Loading Utilities
 * Implements progressive loading for large datasets and components
 */

export interface LoadingState<T> {
  data: T[];
  loading: boolean;
  hasMore: boolean;
  error: string | null;
  page: number;
  totalCount?: number;
}

export interface ProgressiveLoadOptions {
  pageSize?: number;
  initialLoad?: boolean;
  cacheKey?: string;
  maxRetries?: number;
}

/**
 * Progressive data loader class
 */
export class ProgressiveLoader<T> {
  private cache = new Map<string, T[]>();
  private loadingStates = new Map<string, boolean>();
  
  constructor(
    private fetchFn: (page: number, pageSize: number) => Promise<{ data: T[]; total?: number }>,
    private options: ProgressiveLoadOptions = {}
  ) {}

  /**
   * Load data progressively with pagination
   */
  async loadPage(
    page: number,
    currentState: LoadingState<T>
  ): Promise<LoadingState<T>> {
    const { pageSize = 20, cacheKey = 'default', maxRetries = 3 } = this.options;
    const loadingKey = `${cacheKey}-${page}`;
    
    if (this.loadingStates.get(loadingKey)) {
      return currentState; // Already loading this page
    }

    this.loadingStates.set(loadingKey, true);
    
    try {
      let attempt = 0;
      let result;
      
      while (attempt < maxRetries) {
        try {
          result = await this.fetchFn(page, pageSize);
          break;
        } catch (error) {
          attempt++;
          if (attempt >= maxRetries) throw error;
          await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
        }
      }
      
      if (!result) {
        throw new Error('Failed to load data after retries');
      }

      if (cacheKey) {
        const cacheKeyForPage = `${cacheKey}-page-${page}`;
        this.cache.set(cacheKeyForPage, result.data);
      }

      const newData = page === 1 ? result.data : [...currentState.data, ...result.data];
      
      return {
        data: newData,
        loading: false,
        hasMore: result.data.length === pageSize,
        error: null,
        page: page,
        totalCount: result.total
      };
      
    } catch (error) {
      return {
        ...currentState,
        loading: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred'
      };
    } finally {
      this.loadingStates.delete(loadingKey);
    }
  }

  /**
   * Get cached data for a specific page
   */
  getCachedPage(page: number, cacheKey = 'default'): T[] | null {
    return this.cache.get(`${cacheKey}-page-${page}`) || null;
  }

  /**
   * Clear cache for a specific key or all cache
   */
  clearCache(cacheKey?: string): void {
    if (cacheKey) {
      for (const key of this.cache.keys()) {
        if (key.startsWith(cacheKey)) {
          this.cache.delete(key);
        }
      }
    } else {
      this.cache.clear();
    }
  }
}

/**
 * React hook for progressive loading
 */
export function useProgressiveLoader<T>(
  fetchFn: (page: number, pageSize: number) => Promise<{ data: T[]; total?: number }>,
  options: ProgressiveLoadOptions = {}
) {
  const [state, setState] = React.useState<LoadingState<T>>({
    data: [],
    loading: false,
    hasMore: true,
    error: null,
    page: 0
  });

  const loader = React.useMemo(
    () => new ProgressiveLoader(fetchFn, options),
    [fetchFn, options]
  );

  const loadMore = React.useCallback(async () => {
    if (state.loading || !state.hasMore) return;
    
    setState(prev => ({ ...prev, loading: true }));
    const newState = await loader.loadPage(state.page + 1, state);
    setState(newState);
  }, [loader, state]);

  const refresh = React.useCallback(async () => {
    loader.clearCache(options.cacheKey);
    setState({
      data: [],
      loading: true,
      hasMore: true,
      error: null,
      page: 0
    });
    const newState = await loader.loadPage(1, {
      data: [],
      loading: false,
      hasMore: true,
      error: null,
      page: 0
    });
    setState(newState);
  }, [loader, options.cacheKey]);

  React.useEffect(() => {
    if (options.initialLoad !== false && state.page === 0) {
      loadMore();
    }
  }, []);

  return {
    ...state,
    loadMore,
    refresh,
    canLoadMore: !state.loading && state.hasMore && !state.error
  };
}

/**
 * Intersection Observer hook for infinite scrolling
 */
export function useInfiniteScroll(
  callback: () => void,
  options: IntersectionObserverInit = {}
) {
  const targetRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const target = targetRef.current;
    if (!target) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          callback();
        }
      },
      {
        threshold: 0.1,
        rootMargin: '100px',
        ...options
      }
    );

    observer.observe(target);
    return () => observer.disconnect();
  }, [callback, options]);

  return targetRef;
}

import React from 'react';
