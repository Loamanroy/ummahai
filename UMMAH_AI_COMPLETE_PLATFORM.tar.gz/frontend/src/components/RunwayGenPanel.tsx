import React, { useState } from 'react';
import { Card, CardContent } from '../components/ui/card';
import { Button } from '../components/ui/button';

interface RunwayGenPanelProps {
  onVideoGenerated?: (videoUrl: string) => void;
}

export const RunwayGenPanel: React.FC<RunwayGenPanelProps> = ({ onVideoGenerated }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [generatedVideo, setGeneratedVideo] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    try {
      const response = await fetch('/api/v1/gpt-agents/generate-video', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: prompt,
          style: 'cinematic',
          duration: 10
        }),
      });
      
      const data = await response.json();
      if (data.video_url) {
        setGeneratedVideo(data.video_url);
        onVideoGenerated?.(data.video_url);
      }
    } catch (error) {
      console.error('Video generation failed:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Card className="bg-gray-900 border border-gray-700 text-white">
      <CardContent className="p-4">
        <h3 className="text-lg font-semibold mb-4">🎬 Runway AI Video Generator</h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Video Prompt</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the video you want to generate..."
              className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white resize-none"
              rows={3}
            />
          </div>
          
          <Button
            onClick={handleGenerate}
            disabled={isGenerating || !prompt.trim()}
            className="w-full bg-purple-600 hover:bg-purple-700"
          >
            {isGenerating ? '🎬 Generating Video...' : '🚀 Generate Video'}
          </Button>
          
          {generatedVideo && (
            <div className="mt-4">
              <h4 className="text-sm font-medium mb-2">Generated Video:</h4>
              <video
                src={generatedVideo}
                controls
                className="w-full rounded-lg"
                style={{ maxHeight: '300px' }}
              />
            </div>
          )}
          
          <div className="text-xs text-gray-400 space-y-1">
            <div>🎯 AI-Powered Video Generation</div>
            <div>⚡ Real-time Runway ML Integration</div>
            <div>🎨 Cinematic Style Processing</div>
            <div>📊 Trading Alert Visualization</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default RunwayGenPanel;
