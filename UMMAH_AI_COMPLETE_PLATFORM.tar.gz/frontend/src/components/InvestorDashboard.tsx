import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar } from 'recharts';

interface InvestorDashboardProps {
  className?: string;
}

const InvestorDashboard: React.FC<InvestorDashboardProps> = ({ className }) => {
  const [portfolioValue, setPortfolioValue] = useState(125000);
  const [dailyPnL, setDailyPnL] = useState(2350);
  const [totalReturn, setTotalReturn] = useState(18.7);
  const [activePositions, setActivePositions] = useState(12);

  const portfolioData = [
    { time: '00:00', value: 122000 },
    { time: '04:00', value: 123500 },
    { time: '08:00', value: 124200 },
    { time: '12:00', value: 125000 },
    { time: '16:00', value: 124800 },
    { time: '20:00', value: 125000 }
  ];

  const assetAllocation = [
    { asset: 'BTC', percentage: 35, value: 43750 },
    { asset: 'ETH', percentage: 25, value: 31250 },
    { asset: 'SOL', percentage: 15, value: 18750 },
    { asset: 'USDT', percentage: 10, value: 12500 },
    { asset: 'Others', percentage: 15, value: 18750 }
  ];

  const recentTrades = [
    { pair: 'BTC/USDT', side: 'BUY', amount: '0.5', price: '67,500', pnl: '+$1,250', time: '14:32' },
    { pair: 'ETH/USDT', side: 'SELL', amount: '5.2', price: '3,850', pnl: '+$890', time: '14:28' },
    { pair: 'SOL/USDT', side: 'BUY', amount: '25', price: '145', pnl: '+$210', time: '14:15' }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setPortfolioValue(prev => prev + (Math.random() - 0.5) * 100);
      setDailyPnL(prev => prev + (Math.random() - 0.5) * 50);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className={`space-y-4 ${className}`}>
      <Card className="bg-gray-900 border border-gray-700 text-white">
        <CardContent className="p-6">
          <h2 className="text-xl font-bold mb-4">Investor Dashboard</h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-gray-800 p-4 rounded">
              <div className="text-sm text-gray-400">Portfolio Value</div>
              <div className="text-2xl font-bold text-green-400">
                ${portfolioValue.toLocaleString()}
              </div>
            </div>
            <div className="bg-gray-800 p-4 rounded">
              <div className="text-sm text-gray-400">Daily P&L</div>
              <div className={`text-2xl font-bold ${dailyPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {dailyPnL >= 0 ? '+' : ''}${dailyPnL.toLocaleString()}
              </div>
            </div>
            <div className="bg-gray-800 p-4 rounded">
              <div className="text-sm text-gray-400">Total Return</div>
              <div className="text-2xl font-bold text-green-400">
                +{totalReturn}%
              </div>
            </div>
            <div className="bg-gray-800 p-4 rounded">
              <div className="text-sm text-gray-400">Active Positions</div>
              <div className="text-2xl font-bold text-blue-400">
                {activePositions}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-gray-800 p-4 rounded">
              <h3 className="text-lg font-semibold mb-3">Portfolio Performance</h3>
              <LineChart width={400} height={200} data={portfolioData}>
                <CartesianGrid stroke="#374151" />
                <XAxis dataKey="time" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
                  labelStyle={{ color: '#F3F4F6' }}
                />
                <Line type="monotone" dataKey="value" stroke="#10B981" strokeWidth={2} />
              </LineChart>
            </div>

            <div className="bg-gray-800 p-4 rounded">
              <h3 className="text-lg font-semibold mb-3">Asset Allocation</h3>
              <BarChart width={400} height={200} data={assetAllocation}>
                <CartesianGrid stroke="#374151" />
                <XAxis dataKey="asset" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
                  labelStyle={{ color: '#F3F4F6' }}
                />
                <Bar dataKey="percentage" fill="#3B82F6" />
              </BarChart>
            </div>
          </div>

          <div className="mt-6 bg-gray-800 p-4 rounded">
            <h3 className="text-lg font-semibold mb-3">Recent Trades</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-700">
                    <th className="text-left py-2">Pair</th>
                    <th className="text-left py-2">Side</th>
                    <th className="text-left py-2">Amount</th>
                    <th className="text-left py-2">Price</th>
                    <th className="text-left py-2">P&L</th>
                    <th className="text-left py-2">Time</th>
                  </tr>
                </thead>
                <tbody>
                  {recentTrades.map((trade, index) => (
                    <tr key={index} className="border-b border-gray-700">
                      <td className="py-2">{trade.pair}</td>
                      <td className="py-2">
                        <span className={`px-2 py-1 rounded text-xs ${
                          trade.side === 'BUY' ? 'bg-green-600' : 'bg-red-600'
                        }`}>
                          {trade.side}
                        </span>
                      </td>
                      <td className="py-2">{trade.amount}</td>
                      <td className="py-2">${trade.price}</td>
                      <td className="py-2 text-green-400">{trade.pnl}</td>
                      <td className="py-2 text-gray-400">{trade.time}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-4 flex gap-2">
            <Button className="bg-blue-600 hover:bg-blue-700">
              Detailed Analytics
            </Button>
            <Button className="bg-green-600 hover:bg-green-700">
              Withdraw Profits
            </Button>
            <Button className="bg-purple-600 hover:bg-purple-700">
              Risk Settings
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default InvestorDashboard;
