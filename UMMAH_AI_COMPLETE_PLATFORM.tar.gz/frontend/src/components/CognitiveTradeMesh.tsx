import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { generateReport, generateVideoReport } from '../utils/reportUtils';
import { triggerRunwayGeneration } from '../utils/runwayUtils';
import { executeRealOrder } from '../utils/realOrderExecutor';
import RunwayGenPanel from './RunwayGenPanel';
import Canvas3DRouteGraph from './Canvas3DRouteGraph';
import BioIDModule from './BioIDModule';

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: '/marker-icon-2x.png',
  iconUrl: '/marker-icon.png',
  shadowUrl: '/marker-shadow.png',
});

type ExchangeName = 'Binance' | 'OKX' | 'Kraken' | 'Coinbase' | 'Bybit';

interface ExchangeSignal {
  exchange: string;
  volume: number;
  latency: number;
  timestamp: number;
  reroute?: RouteConnection;
  alert?: boolean;
  orderIntent?: OrderIntent;
}

interface OrderIntent {
  exchange: string;
  symbol: string;
  side: 'buy' | 'sell';
  type: 'market' | 'limit' | 'stop' | 'stop_limit';
  quantity: number;
  price?: number;
  stopPrice?: number;
  timeInForce?: 'GTC' | 'IOC' | 'FOK';
  reduceOnly?: boolean;
}

interface LatencyMetric {
  time: number;
  latency: number;
}

interface RouteConnection {
  from: ExchangeName;
  to: ExchangeName;
}

interface WalletConnectorProps {
  onConnect?: () => void;
}

interface AIStrategyProtectorProps {
  threats?: number;
}

interface AutonomousExecutorProps {
  status?: string;
}

const WalletConnector: React.FC<WalletConnectorProps> = ({ onConnect }) => {
  const [connected, setConnected] = useState(false);

  const handleConnect = () => {
    setConnected(true);
    onConnect?.();
  };

  return (
    <div className="bg-gray-800 text-white p-4 rounded">
      <h3 className="text-lg font-bold mb-2">Wallet Connector</h3>
      <button
        onClick={handleConnect}
        className={`px-4 py-2 rounded ${connected ? 'bg-green-600' : 'bg-blue-600'}`}
        disabled={connected}
      >
        {connected ? '✅ Connected' : '🔌 Connect Wallet'}
      </button>
      {connected && (
        <div className="mt-2 text-sm">
          <p>🛡 Quantum encryption active</p>
          <p>🔐 ZK-proof verified</p>
        </div>
      )}
    </div>
  );
};

const AIStrategyProtector: React.FC<AIStrategyProtectorProps> = ({ threats = 0 }) => {
  const [protection, setProtection] = useState(true);

  return (
    <div className="bg-gray-800 text-white p-4 rounded">
      <h3 className="text-lg font-bold mb-2">AI Strategy Protector</h3>
      <div className="space-y-2">
        <p className="text-sm">🛡 Protection: {protection ? 'ACTIVE' : 'INACTIVE'}</p>
        <p className="text-sm">⚠ Threats detected: {threats}</p>
        <p className="text-sm">🧠 AI learning: ENABLED</p>
        <button
          onClick={() => setProtection(!protection)}
          className={`px-3 py-1 rounded text-xs ${protection ? 'bg-green-600' : 'bg-red-600'}`}
        >
          {protection ? 'Disable' : 'Enable'} Protection
        </button>
      </div>
    </div>
  );
};

const AutonomousExecutor: React.FC<AutonomousExecutorProps> = ({ status = 'ACTIVE' }) => {
  const [earnings, setEarnings] = useState(2847.50);

  useEffect(() => {
    const interval = setInterval(() => {
      setEarnings(prev => prev + Math.random() * 10);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-gray-800 text-white p-4 rounded">
      <h3 className="text-lg font-bold mb-2">Autonomous Executor</h3>
      <div className="space-y-2">
        <p className="text-sm">Status: <span className="text-green-400">{status}</span></p>
        <p className="text-sm">Earnings: <span className="text-green-400">${earnings.toFixed(2)}</span></p>
        <p className="text-sm">🤖 Auto-trading: ON</p>
        <p className="text-sm">⚡ Execution speed: 12ms</p>
      </div>
    </div>
  );
};

const CognitiveTradeMesh: React.FC = () => {
  const [signals, setSignals] = useState<ExchangeSignal[]>([]);
  const [reportStatus, setReportStatus] = useState('');
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [voiceLog, setVoiceLog] = useState<string[]>([]);
  const [dynamicReroutes, setDynamicReroutes] = useState<RouteConnection[]>([]);
  const [alerts, setAlerts] = useState<ExchangeSignal[]>([]);
  const [latencyMetrics, setLatencyMetrics] = useState<LatencyMetric[]>([]);
  const [executedOrders, setExecutedOrders] = useState<OrderIntent[]>([]);
  const [lastCommand, setLastCommand] = useState('');
  const [stressLevel, setStressLevel] = useState(0);
  const [adaptiveMode, setAdaptiveMode] = useState(true);
  const [showBioAuth, setShowBioAuth] = useState(false);
  const [show3DGraph, setShow3DGraph] = useState(false);
  const [showRunwayGen, setShowRunwayGen] = useState(false);

  const exchangePositions: Record<ExchangeName, [number, number]> = {
    'Binance': [35.6762, 139.6503],
    'OKX': [22.3193, 114.1694],
    'Kraken': [37.7749, -122.4194],
    'Coinbase': [40.7128, -74.0060],
    'Bybit': [1.3521, 103.8198]
  };

  const reroutes: RouteConnection[] = [
    { from: 'Binance', to: 'OKX' },
    { from: 'OKX', to: 'Kraken' },
    { from: 'Kraken', to: 'Coinbase' },
    { from: 'Coinbase', to: 'Bybit' }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      const exchanges = ['Binance', 'OKX', 'Kraken', 'Coinbase', 'Bybit'];
      const newSignal: ExchangeSignal = {
        exchange: exchanges[Math.floor(Math.random() * exchanges.length)],
        volume: Math.random() * 1000,
        latency: Math.random() * 200 + 20,
        timestamp: Date.now()
      };

      if (Math.random() > 0.7) {
        newSignal.reroute = {
          from: exchanges[Math.floor(Math.random() * exchanges.length)] as ExchangeName,
          to: exchanges[Math.floor(Math.random() * exchanges.length)] as ExchangeName
        };
        setDynamicReroutes(prev => [...prev.slice(-19), newSignal.reroute!]);
      }

      if (Math.random() > 0.8) {
        newSignal.alert = true;
        setAlerts(prev => [...prev.slice(-9), newSignal]);
        triggerRunwayGeneration({ prompt: `Alert triggered at ${newSignal.exchange}` });
      }

      if (Math.random() > 0.6) {
        newSignal.orderIntent = {
          exchange: newSignal.exchange,
          symbol: 'BTCUSDT',
          side: Math.random() > 0.5 ? 'buy' : 'sell',
          type: 'limit',
          quantity: Math.random() * 10,
          price: Math.random() * 50000 + 30000
        };
        executeRealOrder(newSignal.orderIntent);
        setExecutedOrders(prev => [...prev.slice(-49), newSignal.orderIntent!]);
      }

      setLatencyMetrics(prev => [...prev.slice(-19), { time: Date.now(), latency: newSignal.latency }]);
      setSignals(prev => [...prev.slice(-99), newSignal]);

      if (signals.length > 5 && adaptiveMode) {
        const avgLatency = signals.slice(-5).reduce((sum, s) => sum + s.latency, 0) / 5;
        setStressLevel(Math.min(100, avgLatency / 2));
      }
    }, 3000);

    const reportInterval = setInterval(() => {
      generateReport();
      generateVideoReport();
    }, 600000);

    return () => {
      clearInterval(interval);
      clearInterval(reportInterval);
    };
  }, [signals, adaptiveMode]);

  const handleGenerateReport = async () => {
    try {
      setReportStatus('Generating comprehensive report...');
      const reportData = await generateReport();
      setReportStatus(`Report generated: ${reportData.totalTrades} trades, ${reportData.successRate}% success rate`);
    } catch (e) {
      setReportStatus('Error during report generation.');
    }
  };

  const handleGenerateVideoReport = async () => {
    try {
      setReportStatus('Generating video report...');
      const videoUrl = await generateVideoReport({ style: 'professional', duration: 60 });
      if (videoUrl) {
        setReportStatus('Video report generated successfully');
      } else {
        setReportStatus('Video report generation failed');
      }
    } catch (e) {
      setReportStatus('Error during video report generation.');
    }
  };

  const initVoiceControl = () => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      const recognition = new SpeechRecognition();

      recognition.continuous = true;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        const command = event.results[event.results.length - 1][0].transcript.toLowerCase();
        setLastCommand(command);
        setVoiceLog(prev => [...prev.slice(-4), `Command: ${command}`]);

        if (command.includes('execute strategy')) {
          setVoiceLog(prev => [...prev, 'Autonomous strategy triggered']);
        } else if (command.includes('secure wallet')) {
          setShowBioAuth(true);
          setVoiceLog(prev => [...prev, 'Wallet security activated']);
        } else if (command.includes('generate report')) {
          handleGenerateReport();
        } else if (command.includes('generate video')) {
          handleGenerateVideoReport();
        } else if (command.includes('generate image')) {
          setShowRunwayGen(true);
          setVoiceLog(prev => [...prev, 'Image generation panel opened']);
        } else if (command.includes('place order')) {
          const orderIntent: OrderIntent = {
            exchange: 'Binance',
            symbol: 'BTCUSDT',
            side: 'buy',
            type: 'limit',
            quantity: 0.1,
            price: 45000
          };
          executeRealOrder(orderIntent);
          setVoiceLog(prev => [...prev, 'Order placed via voice command']);
        } else if (command.includes('show 3d')) {
          setShow3DGraph(true);
          setVoiceLog(prev => [...prev, '3D route graph displayed']);
        } else if (command.includes('show pnl')) {
          setVoiceLog(prev => [...prev, 'PnL panel focused']);
        } else if (command.includes('show orders')) {
          setVoiceLog(prev => [...prev, 'Order feed displayed']);
        } else if (command.includes('adaptive mode')) {
          setAdaptiveMode(!adaptiveMode);
          setVoiceLog(prev => [...prev, `Adaptive mode ${!adaptiveMode ? 'enabled' : 'disabled'}`]);
        } else if (command.includes('show signals')) {
          setVoiceLog(prev => [...prev, `Showing ${signals.length} signals`]);
        } else if (command.includes('stop trading')) {
          setVoiceLog(prev => [...prev, 'Trading paused']);
        }
      };

      recognition.onerror = (event: any) => {
        setVoiceLog(prev => [...prev, `Voice error: ${event.error}`]);
      };

      if (voiceEnabled) {
        recognition.start();
        setVoiceLog(prev => [...prev, 'Voice control activated']);
      } else {
        recognition.stop();
        setVoiceLog(prev => [...prev, 'Voice control deactivated']);
      }

      return recognition;
    }
    return null;
  };

  useEffect(() => {
    const recognition = initVoiceControl();
    return () => {
      if (recognition) {
        recognition.stop();
      }
    };
  }, [voiceEnabled]);

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="mb-4">
        <h1 className="text-3xl font-bold mb-2">🧠 Cognitive Trade Mesh</h1>
        <p className="text-gray-400">Quantum-enhanced multi-exchange trading with real-time intelligence</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        <div className="bg-gray-900 p-4 rounded-lg border border-gray-700">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">Live Exchange Signals</h2>
            <button
                onClick={() => setVoiceEnabled(!voiceEnabled)}
              className={`px-3 py-1 rounded text-sm ${voiceEnabled ? 'bg-green-600' : 'bg-gray-600'}`}
            >
              🎤 {voiceEnabled ? 'Voice ON' : 'Voice OFF'}
            </button>
          </div>

          <div className="space-y-2 mb-4 max-h-40 overflow-y-auto">
            {signals.map((signal, idx) => (
              <div key={idx} className="text-sm p-2 bg-gray-800 rounded">
                <span className="text-blue-400">{signal.exchange}</span>:
                <span className="text-green-400"> {signal.volume.toFixed(2)} BTC</span> at
                <span className="text-yellow-400"> {signal.latency.toFixed(0)}ms</span>
              </div>
            ))}
          </div>

          <button
            onClick={generateReport}
            className="w-full bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded font-semibold"
            >
              📊 Generate Report
          </button>

          {reportStatus && (
            <p className="text-sm mt-2 p-2 bg-gray-800 rounded">{reportStatus}</p>
          )}

          {voiceLog.length > 0 && (
            <div className="mt-4">
              <h4 className="text-sm font-semibold mb-2">Voice Commands:</h4>
              <div className="space-y-1 max-h-20 overflow-y-auto">
                {voiceLog.map((log, idx) => (
                  <p key={idx} className="text-xs text-gray-400">{log}</p>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="bg-gray-900 p-4 rounded-lg border border-gray-700">
          <h2 className="text-xl font-bold mb-4">Global Exchange Network</h2>
          <div style={{ height: '400px' }}>
            <MapContainer
              center={[20, 0]}
              zoom={2}
              style={{ height: '100%', width: '100%' }}
              className="rounded"
            >
              <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              />
              {Object.entries(exchangePositions).map(([name, pos], i) => (
                <Marker key={i} position={pos}>
                  <Popup>
                    <div className="text-black">
                      <strong>{name}</strong><br/>
                      Status: Connected<br/>
                      Latency: {Math.floor(Math.random() * 100 + 20)}ms
                    </div>
                  </Popup>
                </Marker>
              ))}
              {reroutes.map((route, i) => (
                <Polyline
                  key={i}
                  positions={[exchangePositions[route.from], exchangePositions[route.to]]}
                  color="#00ff88"
                  weight={2}
                  opacity={0.7}
                />
              ))}
            </MapContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <WalletConnector />
        <AIStrategyProtector threats={Math.floor(Math.random() * 5)} />
        <AutonomousExecutor />
      </div>

      {/* Advanced Features Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        {/* Latency Metrics Chart */}
        <div className="bg-gray-900 p-4 rounded-lg border border-gray-700">
          <h3 className="text-lg font-bold mb-4">📊 Real-time Latency Metrics</h3>
          {latencyMetrics.length > 0 && (
            <LineChart width={400} height={200} data={latencyMetrics}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="time" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="latency" stroke="#00ff88" strokeWidth={2} />
            </LineChart>
          )}
          <div className="mt-2 text-sm">
            <p>🎯 Stress Level: <span className={`${stressLevel > 50 ? 'text-red-400' : 'text-green-400'}`}>{stressLevel.toFixed(1)}%</span></p>
            <p>🔄 Adaptive Mode: <span className={`${adaptiveMode ? 'text-green-400' : 'text-gray-400'}`}>{adaptiveMode ? 'ENABLED' : 'DISABLED'}</span></p>
          </div>
        </div>

        {/* Executed Orders Feed */}
        <div className="bg-gray-900 p-4 rounded-lg border border-gray-700">
          <h3 className="text-lg font-bold mb-4">⚡ Real-time Order Execution</h3>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {executedOrders.slice(-10).map((order, idx) => (
              <div key={idx} className="text-sm p-2 bg-gray-800 rounded">
                <span className={`${order.side === 'buy' ? 'text-green-400' : 'text-red-400'}`}>
                  {order.side.toUpperCase()}
                </span> {order.quantity.toFixed(4)} {order.symbol} on
                <span className="text-blue-400"> {order.exchange}</span>
                {order.price && <span className="text-yellow-400"> @ ${order.price.toFixed(2)}</span>}
              </div>
            ))}
          </div>
          <p className="text-xs text-gray-400 mt-2">Last Command: {lastCommand}</p>
        </div>
      </div>

      {/* Alert System */}
      {alerts.length > 0 && (
        <div className="bg-red-900 border border-red-700 p-4 rounded-lg mb-6">
          <h3 className="text-lg font-bold mb-2">🚨 Active Alerts</h3>
          <div className="space-y-2">
            {alerts.slice(-5).map((alert, idx) => (
              <div key={idx} className="text-sm p-2 bg-red-800 rounded">
                Alert at <span className="text-red-400">{alert.exchange}</span> - Volume: {alert.volume.toFixed(2)} BTC
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Advanced Component Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {showBioAuth && (
          <BioIDModule
            onAuthSuccess={() => setVoiceLog(prev => [...prev, 'Biometric authentication successful'])}
            onAuthFailure={() => setVoiceLog(prev => [...prev, 'Biometric authentication failed'])}
          />
        )}

        {showRunwayGen && (
          <RunwayGenPanel
            onVideoGenerated={(url) => setVoiceLog(prev => [...prev, `Video generated: ${url}`])}
          />
        )}

        {show3DGraph && (
          <div className="lg:col-span-2">
            <Canvas3DRouteGraph
              reroutes={dynamicReroutes.map((r, i) => ({
                id: `route-${i}`,
                position: [Math.random() * 6 - 3, Math.random() * 4 - 2, Math.random() * 6 - 3] as [number, number, number],
                exchange: r.from,
                status: 'active' as const,
                latency: Math.random() * 200 + 20
              }))}
              alerts={alerts.slice(-3).map((_, i) => ({
                id: `alert-${i}`,
                position: [Math.random() * 6 - 3, Math.random() * 4 - 2, Math.random() * 6 - 3] as [number, number, number],
                type: 'trading' as const,
                severity: 'high' as const
              }))}
            />
          </div>
        )}
      </div>

      {/* Control Panel */}
      <div className="bg-gray-900 p-4 rounded-lg border border-gray-700">
        <h3 className="text-lg font-bold mb-4">🎛 Advanced Controls</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          <button
            onClick={() => setShowBioAuth(!showBioAuth)}
            className={`px-3 py-2 rounded text-sm ${showBioAuth ? 'bg-green-600' : 'bg-gray-600'}`}
          >
            🧬 Bio Auth
          </button>
          <button
            onClick={() => setShow3DGraph(!show3DGraph)}
            className={`px-3 py-2 rounded text-sm ${show3DGraph ? 'bg-blue-600' : 'bg-gray-600'}`}
          >
            🌐 3D Graph
          </button>
          <button
            onClick={() => setShowRunwayGen(!showRunwayGen)}
            className={`px-3 py-2 rounded text-sm ${showRunwayGen ? 'bg-purple-600' : 'bg-gray-600'}`}
          >
            🎬 Video Gen
          </button>
          <button
            onClick={() => setAdaptiveMode(!adaptiveMode)}
            className={`px-3 py-2 rounded text-sm ${adaptiveMode ? 'bg-green-600' : 'bg-red-600'}`}
          >
            🔄 Adaptive
          </button>
        </div>
      </div>
    </div>
  );
};

export default CognitiveTradeMesh;
