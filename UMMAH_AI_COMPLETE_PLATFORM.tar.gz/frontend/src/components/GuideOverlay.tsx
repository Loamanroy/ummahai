import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { X, ArrowRight } from 'lucide-react';

/**
 * Represents a single step in the user guide
 */
interface GuideStep {
  /** Title of the guide step */
  title: string;
  /** Content/description of the guide step */
  content: string;
  /** Target element or area this step refers to */
  target: string;
}

/**
 * Props for the GuideOverlay component
 */
interface GuideOverlayProps {
  /** Whether the guide overlay is visible */
  isVisible: boolean;
  /** Current step data */
  currentStep: GuideStep;
  /** Current step number (0-based) */
  stepNumber: number;
  /** Total number of steps in the guide */
  totalSteps: number;
  /** Callback when user clicks next */
  onNext: () => void;
  /** Callback when user closes the guide */
  onClose: () => void;
}

/**
 * GuideOverlay - Interactive user guide overlay component
 * 
 * Displays a modal overlay with step-by-step guidance for using the platform.
 * Includes progress indicators, navigation controls, and responsive design.
 * 
 * @param props - Component props
 * @param props.isVisible - Whether the overlay should be displayed
 * @param props.currentStep - Current guide step data
 * @param props.stepNumber - Current step number (0-based)
 * @param props.totalSteps - Total number of guide steps
 * @param props.onNext - Callback for next button click
 * @param props.onClose - Callback for close button click
 * @returns JSX.Element | null - Rendered guide overlay or null if not visible
 */
const GuideOverlay: React.FC<GuideOverlayProps> = ({
  isVisible,
  currentStep,
  stepNumber,
  totalSteps,
  onNext,
  onClose
}) => {
  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <Card className="bg-gradient-to-br from-blue-900 to-purple-900 border border-cyan-400 text-white max-w-md mx-4">
        <CardContent className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="text-xl font-bold text-cyan-400">{currentStep.title}</h3>
              <p className="text-sm text-gray-300">Step {stepNumber + 1} of {totalSteps}</p>
            </div>
            <Button
              onClick={onClose}
              className="bg-transparent hover:bg-red-600 p-1"
              size="sm"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
          
          <p className="text-gray-200 mb-6">{currentStep.content}</p>
          
          <div className="flex justify-between items-center">
            <div className="flex space-x-1">
              {Array.from({ length: totalSteps }).map((_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full ${
                    index <= stepNumber ? 'bg-cyan-400' : 'bg-gray-600'
                  }`}
                />
              ))}
            </div>
            
            <Button
              onClick={onNext}
              className="bg-cyan-600 hover:bg-cyan-700 text-white"
            >
              {stepNumber < totalSteps - 1 ? (
                <>
                  Next <ArrowRight className="w-4 h-4 ml-1" />
                </>
              ) : (
                'Finish'
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GuideOverlay;
