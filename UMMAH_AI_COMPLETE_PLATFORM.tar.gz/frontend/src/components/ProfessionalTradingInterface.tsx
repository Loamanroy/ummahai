import React, { useState, useEffect, useRef } from 'react';
import { BarChart3, Activity, Volume2, Target, Zap, MessageCircle } from 'lucide-react';
import { AISupportChat } from './AISupportChat';
import { LanguageSwitcher } from './LanguageSwitcher';

interface MarketData {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  high24h: number;
  low24h: number;
  marketCap: number;
}

interface FootprintData {
  price: number;
  buyVolume: number;
  sellVolume: number;
  totalVolume: number;
  delta: number;
  timestamp: number;
}

interface VolumeProfile {
  price: number;
  volume: number;
  percentage: number;
  poc: boolean; // Point of Control
}

interface OrderBookLevel {
  price: number;
  size: number;
  total: number;
}

interface OrderBook {
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  spread: number;
}

export const ProfessionalTradingInterface: React.FC = () => {
  const [selectedSymbol, setSelectedSymbol] = useState('BTC/USDT');
  const [marketData, setMarketData] = useState<MarketData[]>([]);
  const [footprintData, setFootprintData] = useState<FootprintData[]>([]);
  const [volumeProfile, setVolumeProfile] = useState<VolumeProfile[]>([]);
  const [orderBook, setOrderBook] = useState<OrderBook | null>(null);
  const [timeframe, setTimeframe] = useState('1m');
  const [showFootprint, setShowFootprint] = useState(true);
  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState('ru');
  const [showVolumeProfile, setShowVolumeProfile] = useState(true);
  const [showOrderFlow, setShowOrderFlow] = useState(true);
  
  const chartRef = useRef<HTMLCanvasElement>(null);
  const footprintRef = useRef<HTMLCanvasElement>(null);
  const volumeProfileRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    loadMarketData();
    loadFootprintData();
    loadVolumeProfile();
    loadOrderBook();
    
    const interval = setInterval(() => {
      updateRealTimeData();
    }, 100); // 100ms updates for millisecond precision
    
    return () => clearInterval(interval);
  }, [selectedSymbol, timeframe]);

  const loadMarketData = async () => {
    const symbols = ['BTC/USDT', 'ETH/USDT', 'BNB/USDT', 'ADA/USDT', 'SOL/USDT'];
    const data: MarketData[] = symbols.map(symbol => ({
      symbol,
      price: Math.random() * 50000 + 20000,
      change: (Math.random() - 0.5) * 2000,
      changePercent: (Math.random() - 0.5) * 10,
      volume: Math.random() * 1000000000,
      high24h: Math.random() * 55000 + 25000,
      low24h: Math.random() * 45000 + 15000,
      marketCap: Math.random() * 1000000000000
    }));
    setMarketData(data);
  };

  const loadFootprintData = async () => {
    const data: FootprintData[] = [];
    const basePrice = 45000;
    
    for (let i = 0; i < 100; i++) {
      const price = basePrice + (Math.random() - 0.5) * 1000;
      const buyVolume = Math.random() * 1000;
      const sellVolume = Math.random() * 1000;
      
      data.push({
        price,
        buyVolume,
        sellVolume,
        totalVolume: buyVolume + sellVolume,
        delta: buyVolume - sellVolume,
        timestamp: Date.now() - (100 - i) * 60000
      });
    }
    setFootprintData(data);
  };

  const loadVolumeProfile = async () => {
    const data: VolumeProfile[] = [];
    const basePrice = 45000;
    let maxVolume = 0;
    
    for (let i = 0; i < 50; i++) {
      const price = basePrice - 2500 + (i * 100);
      const volume = Math.random() * 10000;
      maxVolume = Math.max(maxVolume, volume);
      
      data.push({
        price,
        volume,
        percentage: 0, // Will be calculated
        poc: false
      });
    }
    
    let pocIndex = 0;
    let maxVol = 0;
    
    data.forEach((item, index) => {
      item.percentage = (item.volume / maxVolume) * 100;
      if (item.volume > maxVol) {
        maxVol = item.volume;
        pocIndex = index;
      }
    });
    
    data[pocIndex].poc = true;
    setVolumeProfile(data);
  };

  const loadOrderBook = async () => {
    const basePrice = 45000;
    const bids: OrderBookLevel[] = [];
    const asks: OrderBookLevel[] = [];
    
    let totalBids = 0;
    let totalAsks = 0;
    
    for (let i = 0; i < 20; i++) {
      const price = basePrice - (i * 10);
      const size = Math.random() * 5 + 0.1;
      totalBids += size;
      
      bids.push({
        price,
        size,
        total: totalBids
      });
    }
    
    for (let i = 0; i < 20; i++) {
      const price = basePrice + (i * 10);
      const size = Math.random() * 5 + 0.1;
      totalAsks += size;
      
      asks.push({
        price,
        size,
        total: totalAsks
      });
    }
    
    setOrderBook({
      bids,
      asks,
      spread: asks[0]?.price - bids[0]?.price || 0
    });
  };

  const updateRealTimeData = () => {
    setMarketData(prev => prev.map(item => ({
      ...item,
      price: item.price + (Math.random() - 0.5) * 10,
      change: item.change + (Math.random() - 0.5) * 5,
      volume: item.volume + Math.random() * 1000000
    })));
  };

  const renderFootprintChart = () => {
    if (!footprintRef.current || !footprintData.length) return;
    
    const canvas = footprintRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    const cellHeight = canvas.height / footprintData.length;
    const maxVolume = Math.max(...footprintData.map(d => d.totalVolume));
    
    footprintData.forEach((data, index) => {
      const y = index * cellHeight;
      const buyWidth = (data.buyVolume / maxVolume) * (canvas.width / 2);
      const sellWidth = (data.sellVolume / maxVolume) * (canvas.width / 2);
      
      ctx.fillStyle = data.delta > 0 ? '#10B981' : '#EF4444';
      ctx.fillRect(0, y, buyWidth, cellHeight - 1);
      
      ctx.fillStyle = '#EF4444';
      ctx.fillRect(canvas.width / 2, y, sellWidth, cellHeight - 1);
      
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '10px monospace';
      ctx.fillText(data.price.toFixed(2), 5, y + cellHeight / 2);
      ctx.fillText(data.totalVolume.toFixed(0), canvas.width - 50, y + cellHeight / 2);
    });
  };

  const renderVolumeProfile = () => {
    if (!volumeProfileRef.current || !volumeProfile.length) return;
    
    const canvas = volumeProfileRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    const barHeight = canvas.height / volumeProfile.length;
    
    volumeProfile.forEach((profile, index) => {
      const y = index * barHeight;
      const barWidth = (profile.percentage / 100) * canvas.width;
      
      ctx.fillStyle = profile.poc ? '#F59E0B' : '#6B7280';
      ctx.fillRect(0, y, barWidth, barHeight - 1);
      
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '10px monospace';
      ctx.fillText(profile.price.toFixed(2), barWidth + 5, y + barHeight / 2);
    });
  };

  useEffect(() => {
    renderFootprintChart();
  }, [footprintData]);

  useEffect(() => {
    renderVolumeProfile();
  }, [volumeProfile]);

  const formatNumber = (num: number, decimals: number = 2) => {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    }).format(num);
  };

  const formatVolume = (volume: number) => {
    if (volume >= 1e9) return `${(volume / 1e9).toFixed(2)}B`;
    if (volume >= 1e6) return `${(volume / 1e6).toFixed(2)}M`;
    if (volume >= 1e3) return `${(volume / 1e3).toFixed(2)}K`;
    return volume.toFixed(2);
  };

  return (
    <div className="h-screen bg-gray-900 text-white flex flex-col">
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-xl font-bold">UMMAH AI Professional Trading</h1>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-sm text-green-400">Live Market Data</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <select 
              value={selectedSymbol}
              onChange={(e) => setSelectedSymbol(e.target.value)}
              className="bg-gray-700 border border-gray-600 rounded px-3 py-1 text-sm"
            >
              {marketData.map(item => (
                <option key={item.symbol} value={item.symbol}>{item.symbol}</option>
              ))}
            </select>
            
            <div className="flex space-x-1">
              {['1m', '5m', '15m', '1h', '4h', '1d'].map(tf => (
                <button
                  key={tf}
                  onClick={() => setTimeframe(tf)}
                  className={`px-3 py-1 text-xs rounded ${
                    timeframe === tf ? 'bg-blue-600' : 'bg-gray-700 hover:bg-gray-600'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Trading Interface */}
      <div className="flex-1 flex">
        {/* Left Panel - Market Data */}
        <div className="w-80 bg-gray-800 border-r border-gray-700 flex flex-col">
          {/* Market Overview */}
          <div className="p-4 border-b border-gray-700">
            <h3 className="text-sm font-semibold mb-3">Market Overview</h3>
            <div className="space-y-2">
              {marketData.slice(0, 5).map(item => (
                <div key={item.symbol} className="flex items-center justify-between text-sm">
                  <span className="font-medium">{item.symbol}</span>
                  <div className="text-right">
                    <div className="font-mono">${formatNumber(item.price)}</div>
                    <div className={`text-xs ${item.change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {item.change >= 0 ? '+' : ''}{formatNumber(item.changePercent, 2)}%
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Order Book */}
          <div className="flex-1 p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold">Order Book</h3>
              <div className="text-xs text-gray-400">
                Spread: ${orderBook?.spread.toFixed(2)}
              </div>
            </div>
            
            {orderBook && (
              <div className="space-y-1">
                {/* Asks */}
                <div className="space-y-0.5">
                  {orderBook.asks.slice(0, 10).reverse().map((ask, index) => (
                    <div key={index} className="flex justify-between text-xs font-mono">
                      <span className="text-red-400">{formatNumber(ask.price)}</span>
                      <span className="text-gray-300">{ask.size.toFixed(4)}</span>
                      <span className="text-gray-500">{ask.total.toFixed(2)}</span>
                    </div>
                  ))}
                </div>
                
                {/* Current Price */}
                <div className="border-t border-b border-gray-600 py-2 text-center">
                  <div className="text-lg font-bold text-yellow-400">
                    ${formatNumber(marketData.find(m => m.symbol === selectedSymbol)?.price || 0)}
                  </div>
                </div>
                
                {/* Bids */}
                <div className="space-y-0.5">
                  {orderBook.bids.slice(0, 10).map((bid, index) => (
                    <div key={index} className="flex justify-between text-xs font-mono">
                      <span className="text-green-400">{formatNumber(bid.price)}</span>
                      <span className="text-gray-300">{bid.size.toFixed(4)}</span>
                      <span className="text-gray-500">{bid.total.toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Center Panel - Charts */}
        <div className="flex-1 flex flex-col">
          {/* Chart Controls */}
          <div className="bg-gray-800 border-b border-gray-700 p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => setShowFootprint(!showFootprint)}
                  className={`flex items-center space-x-2 px-3 py-1 rounded text-sm ${
                    showFootprint ? 'bg-blue-600' : 'bg-gray-700'
                  }`}
                >
                  <BarChart3 className="w-4 h-4" />
                  <span>Footprint</span>
                </button>
                
                <button
                  onClick={() => setShowVolumeProfile(!showVolumeProfile)}
                  className={`flex items-center space-x-2 px-3 py-1 rounded text-sm ${
                    showVolumeProfile ? 'bg-blue-600' : 'bg-gray-700'
                  }`}
                >
                  <Volume2 className="w-4 h-4" />
                  <span>Volume Profile</span>
                </button>
                
                <button
                  onClick={() => setShowOrderFlow(!showOrderFlow)}
                  className={`flex items-center space-x-2 px-3 py-1 rounded text-sm ${
                    showOrderFlow ? 'bg-blue-600' : 'bg-gray-700'
                  }`}
                >
                  <Activity className="w-4 h-4" />
                  <span>Order Flow</span>
                </button>
              </div>
              
              <div className="flex items-center space-x-2 text-sm text-gray-400">
                <Zap className="w-4 h-4" />
                <span>Real-time: 100ms</span>
              </div>
            </div>
          </div>

          {/* Main Chart Area */}
          <div className="flex-1 flex">
            {/* Price Chart */}
            <div className="flex-1 relative">
              <canvas
                ref={chartRef}
                width={800}
                height={600}
                className="w-full h-full bg-gray-900"
              />
              
              {/* Footprint Overlay */}
              {showFootprint && (
                <div className="absolute top-4 left-4 w-64 h-96 bg-gray-800/90 rounded border border-gray-600">
                  <div className="p-2 border-b border-gray-600">
                    <h4 className="text-xs font-semibold">Footprint Chart</h4>
                  </div>
                  <canvas
                    ref={footprintRef}
                    width={240}
                    height={360}
                    className="w-full h-full"
                  />
                </div>
              )}
            </div>

            {/* Volume Profile */}
            {showVolumeProfile && (
              <div className="w-48 bg-gray-800 border-l border-gray-700">
                <div className="p-2 border-b border-gray-600">
                  <h4 className="text-xs font-semibold">Volume Profile</h4>
                </div>
                <canvas
                  ref={volumeProfileRef}
                  width={180}
                  height={600}
                  className="w-full h-full"
                />
              </div>
            )}
          </div>
        </div>

        {/* Right Panel - Trading Controls */}
        <div className="w-80 bg-gray-800 border-l border-gray-700 flex flex-col">
          {/* Quick Stats */}
          <div className="p-4 border-b border-gray-700">
            <h3 className="text-sm font-semibold mb-3">Market Statistics</h3>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-gray-700 p-2 rounded">
                <div className="text-gray-400">24h High</div>
                <div className="font-mono text-green-400">
                  ${formatNumber(marketData.find(m => m.symbol === selectedSymbol)?.high24h || 0)}
                </div>
              </div>
              <div className="bg-gray-700 p-2 rounded">
                <div className="text-gray-400">24h Low</div>
                <div className="font-mono text-red-400">
                  ${formatNumber(marketData.find(m => m.symbol === selectedSymbol)?.low24h || 0)}
                </div>
              </div>
              <div className="bg-gray-700 p-2 rounded">
                <div className="text-gray-400">Volume</div>
                <div className="font-mono">
                  {formatVolume(marketData.find(m => m.symbol === selectedSymbol)?.volume || 0)}
                </div>
              </div>
              <div className="bg-gray-700 p-2 rounded">
                <div className="text-gray-400">Market Cap</div>
                <div className="font-mono">
                  {formatVolume(marketData.find(m => m.symbol === selectedSymbol)?.marketCap || 0)}
                </div>
              </div>
            </div>
          </div>

          {/* AI Analysis */}
          <div className="p-4 border-b border-gray-700">
            <h3 className="text-sm font-semibold mb-3">AI Analysis</h3>
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span>Trend Strength</span>
                <div className="flex items-center space-x-1">
                  <div className="w-16 h-2 bg-gray-600 rounded">
                    <div className="w-3/4 h-full bg-green-400 rounded"></div>
                  </div>
                  <span className="text-green-400">Strong</span>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span>Volume Analysis</span>
                <div className="flex items-center space-x-1">
                  <div className="w-16 h-2 bg-gray-600 rounded">
                    <div className="w-1/2 h-full bg-yellow-400 rounded"></div>
                  </div>
                  <span className="text-yellow-400">Moderate</span>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span>Support/Resistance</span>
                <div className="flex items-center space-x-1">
                  <Target className="w-3 h-3 text-blue-400" />
                  <span className="text-blue-400">$44,850</span>
                </div>
              </div>
            </div>
          </div>

          {/* Performance Metrics */}
          <div className="flex-1 p-4">
            <h3 className="text-sm font-semibold mb-3">Performance</h3>
            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span>Latency</span>
                <span className="text-green-400 font-mono">0.8ms</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Data Accuracy</span>
                <span className="text-green-400">100%</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Updates/sec</span>
                <span className="text-blue-400 font-mono">10,000</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Uptime</span>
                <span className="text-green-400">99.99%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Language Switcher - Top Right */}
      <div className="absolute top-4 right-4 z-40">
        <LanguageSwitcher
          currentLanguage={currentLanguage}
          onLanguageChange={setCurrentLanguage}
          showLabel={false}
        />
      </div>

      {/* AI Support Chat */}
      <AISupportChat
        isOpen={isSupportOpen}
        onToggle={() => setIsSupportOpen(!isSupportOpen)}
        currentLanguage={currentLanguage}
        onLanguageChange={setCurrentLanguage}
        userId="trading_user"
        className="z-50"
      />

      {/* Support Button in Trading Controls */}
      {!isSupportOpen && (
        <button
          onClick={() => setIsSupportOpen(true)}
          className="fixed bottom-20 right-6 z-40 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white p-3 rounded-full shadow-lg transition-all duration-300 hover:scale-110 flex items-center space-x-2"
          title={currentLanguage === 'ru' ? 'AI Поддержка' : 
                 currentLanguage === 'en' ? 'AI Support' :
                 currentLanguage === 'ar' ? 'دعم الذكي' : 'AI Destek'}
        >
          <MessageCircle className="w-5 h-5" />
          <span className="text-sm font-medium hidden sm:block">
            {currentLanguage === 'ru' ? 'Поддержка' : 
             currentLanguage === 'en' ? 'Support' :
             currentLanguage === 'ar' ? 'دعم' : 'Destek'}
          </span>
        </button>
      )}
    </div>
  );
};
