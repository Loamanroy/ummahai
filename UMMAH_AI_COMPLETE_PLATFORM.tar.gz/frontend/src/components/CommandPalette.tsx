import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Search, Command, ArrowRight, Hash, Settings, Zap, Shield, Eye, BarChart3 } from 'lucide-react';

/**
 * Command item interface for the command palette
 */
interface CommandItem {
  /** Unique identifier for the command */
  id: string;
  /** Display title of the command */
  title: string;
  /** Optional subtitle or description */
  subtitle?: string;
  /** Icon component to display */
  icon?: React.ComponentType<{ className?: string }>;
  /** Category for grouping commands */
  category: string;
  /** Keywords for search matching */
  keywords: string[];
  /** Function to execute when command is selected */
  action: () => void;
  /** Whether the command is currently available */
  enabled?: boolean;
}

/**
 * Props for the CommandPalette component
 */
interface CommandPaletteProps {
  /** Whether the command palette is visible */
  isOpen: boolean;
  /** Function to close the command palette */
  onClose: () => void;
  /** Array of available commands */
  commands: CommandItem[];
  /** Placeholder text for the search input */
  placeholder?: string;
}

/**
 * CommandPalette - Quick navigation and action command palette
 * 
 * Provides a searchable command interface for quick access to platform features.
 * Supports keyboard navigation, fuzzy search, command categorization, and
 * customizable command actions. Designed for power users who prefer keyboard
 * navigation over mouse interactions.
 * 
 * @param props - Component props
 * @param props.isOpen - Whether the command palette is visible
 * @param props.onClose - Function to close the command palette
 * @param props.commands - Array of available commands
 * @param props.placeholder - Placeholder text for search input
 * @returns JSX.Element | null - Rendered command palette or null if closed
 */
const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  commands,
  placeholder = "Type a command or search..."
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  /**
   * Filter and sort commands based on search query
   */
  const filteredCommands = useMemo(() => {
    if (!searchQuery.trim()) {
      return commands.filter(cmd => cmd.enabled !== false);
    }

    const query = searchQuery.toLowerCase();
    const filtered = commands.filter(cmd => {
      if (cmd.enabled === false) return false;
      
      return (
        cmd.title.toLowerCase().includes(query) ||
        cmd.subtitle?.toLowerCase().includes(query) ||
        cmd.category.toLowerCase().includes(query) ||
        cmd.keywords.some(keyword => keyword.toLowerCase().includes(query))
      );
    });

    return filtered.sort((a, b) => {
      const aTitle = a.title.toLowerCase();
      const bTitle = b.title.toLowerCase();
      
      if (aTitle.startsWith(query) && !bTitle.startsWith(query)) return -1;
      if (!aTitle.startsWith(query) && bTitle.startsWith(query)) return 1;
      
      return aTitle.localeCompare(bTitle);
    });
  }, [commands, searchQuery]);

  /**
   * Group filtered commands by category
   */
  const groupedCommands = useMemo(() => {
    const groups: Record<string, CommandItem[]> = {};
    
    filteredCommands.forEach(cmd => {
      if (!groups[cmd.category]) {
        groups[cmd.category] = [];
      }
      groups[cmd.category].push(cmd);
    });
    
    return groups;
  }, [filteredCommands]);

  /**
   * Execute the selected command
   */
  const executeCommand = (command: CommandItem) => {
    try {
      command.action();
      onClose();
      setSearchQuery('');
      setSelectedIndex(0);
    } catch (error) {
      console.error('Error executing command:', error);
    }
  };

  /**
   * Handle keyboard navigation
   */
  const handleKeyDown = (event: React.KeyboardEvent) => {
    switch (event.key) {
      case 'Escape':
        event.preventDefault();
        onClose();
        break;
        
      case 'ArrowDown':
        event.preventDefault();
        setSelectedIndex(prev => 
          prev < filteredCommands.length - 1 ? prev + 1 : 0
        );
        break;
        
      case 'ArrowUp':
        event.preventDefault();
        setSelectedIndex(prev => 
          prev > 0 ? prev - 1 : filteredCommands.length - 1
        );
        break;
        
      case 'Enter':
        event.preventDefault();
        if (filteredCommands[selectedIndex]) {
          executeCommand(filteredCommands[selectedIndex]);
        }
        break;
    }
  };

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  useEffect(() => {
    setSelectedIndex(0);
  }, [searchQuery]);

  useEffect(() => {
    if (listRef.current) {
      const selectedElement = listRef.current.children[selectedIndex] as HTMLElement;
      if (selectedElement) {
        selectedElement.scrollIntoView({
          block: 'nearest',
          behavior: 'smooth'
        });
      }
    }
  }, [selectedIndex]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-start justify-center pt-20">
      <Card className="bg-gray-900 border border-gray-700 text-white w-full max-w-2xl mx-4 max-h-96 overflow-hidden">
        <CardContent className="p-0">
          {/* Search Input */}
          <div className="flex items-center p-4 border-b border-gray-700">
            <Command className="w-5 h-5 text-gray-400 mr-3" />
            <input
              ref={inputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={placeholder}
              className="flex-1 bg-transparent text-white placeholder-gray-400 outline-none text-lg"
            />
            <Button
              onClick={onClose}
              className="bg-transparent hover:bg-gray-800 p-1 ml-2"
              size="sm"
            >
              <span className="text-xs text-gray-400">ESC</span>
            </Button>
          </div>

          {/* Commands List */}
          <div ref={listRef} className="max-h-80 overflow-y-auto">
            {Object.keys(groupedCommands).length === 0 ? (
              <div className="p-8 text-center text-gray-400">
                <Search className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>No commands found</p>
                <p className="text-sm mt-1">Try a different search term</p>
              </div>
            ) : (
              Object.entries(groupedCommands).map(([category, categoryCommands]) => (
                <div key={category}>
                  <div className="px-4 py-2 text-xs font-semibold text-gray-400 uppercase tracking-wide bg-gray-800">
                    {category}
                  </div>
                  {categoryCommands.map((command) => {
                    const globalIndex = filteredCommands.indexOf(command);
                    const isSelected = globalIndex === selectedIndex;
                    const IconComponent = command.icon || Hash;
                    
                    return (
                      <div
                        key={command.id}
                        onClick={() => executeCommand(command)}
                        className={`flex items-center p-3 cursor-pointer transition-colors ${
                          isSelected 
                            ? 'bg-blue-600 text-white' 
                            : 'hover:bg-gray-800 text-gray-200'
                        }`}
                      >
                        <IconComponent className="w-4 h-4 mr-3 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="font-medium truncate">{command.title}</div>
                          {command.subtitle && (
                            <div className="text-sm text-gray-400 truncate">
                              {command.subtitle}
                            </div>
                          )}
                        </div>
                        <ArrowRight className="w-4 h-4 ml-2 flex-shrink-0 opacity-50" />
                      </div>
                    );
                  })}
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          <div className="px-4 py-2 border-t border-gray-700 bg-gray-800">
            <div className="flex items-center justify-between text-xs text-gray-400">
              <div className="flex items-center space-x-4">
                <span>↑↓ Navigate</span>
                <span>↵ Select</span>
                <span>ESC Close</span>
              </div>
              <div>{filteredCommands.length} commands</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

/**
 * Default command set for the UMMAH AI Platform
 */
export const createDefaultCommands = (actions: {
  toggleParanoiaMode: () => void;
  toggleSimplifiedView: () => void;
  showRegistration: () => void;
  showCreateAgent: () => void;
  navigateToExchanges: () => void;
  toggleTheme: () => void;
  showGuide: () => void;
  refreshData: () => void;
}): CommandItem[] => [
  {
    id: 'paranoia-toggle',
    title: 'Toggle Paranoia Mode',
    subtitle: 'Enable/disable enhanced security monitoring',
    icon: Shield,
    category: 'Security',
    keywords: ['paranoia', 'security', 'stealth', 'protection'],
    action: actions.toggleParanoiaMode
  },
  {
    id: 'simplified-view',
    title: 'Toggle Simplified View',
    subtitle: 'Switch between full and simplified dashboard',
    icon: Eye,
    category: 'View',
    keywords: ['simple', 'view', 'mode', 'interface'],
    action: actions.toggleSimplifiedView
  },
  {
    id: 'registration',
    title: 'Open Registration',
    subtitle: 'Start investor registration process',
    icon: Settings,
    category: 'Account',
    keywords: ['register', 'signup', 'account', 'investor'],
    action: actions.showRegistration
  },
  {
    id: 'create-agent',
    title: 'Create AI Agent',
    subtitle: 'Build a new custom AI trading agent',
    icon: Zap,
    category: 'AI',
    keywords: ['agent', 'ai', 'create', 'bot', 'trading'],
    action: actions.showCreateAgent
  },
  {
    id: 'exchanges',
    title: 'View Exchanges',
    subtitle: 'Navigate to exchange interfaces',
    icon: BarChart3,
    category: 'Trading',
    keywords: ['exchange', 'trading', 'binance', 'coinbase'],
    action: actions.navigateToExchanges
  },
  {
    id: 'theme-toggle',
    title: 'Change Theme',
    subtitle: 'Switch between available themes',
    icon: Settings,
    category: 'Appearance',
    keywords: ['theme', 'appearance', 'dark', 'light', 'color'],
    action: actions.toggleTheme
  },
  {
    id: 'help-guide',
    title: 'Show Help Guide',
    subtitle: 'Display interactive platform guide',
    icon: Settings,
    category: 'Help',
    keywords: ['help', 'guide', 'tutorial', 'learn'],
    action: actions.showGuide
  },
  {
    id: 'refresh-data',
    title: 'Refresh Data',
    subtitle: 'Reload all dashboard data',
    icon: Settings,
    category: 'System',
    keywords: ['refresh', 'reload', 'update', 'sync'],
    action: actions.refreshData
  }
];

export default CommandPalette;
export type { CommandItem, CommandPaletteProps };
