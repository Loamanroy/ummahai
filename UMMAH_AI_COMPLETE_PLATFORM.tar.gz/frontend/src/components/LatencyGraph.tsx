import React from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Button } from '@/components/ui/button';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

const latencyMetrics: Array<{ time: string; latency: number }> = [];

const DefenseModule = {
  exportFusionMap: () => {
    const graph = document.querySelector('#fusion-graph-container canvas');
    if (graph) {
      html2canvas(graph as HTMLElement).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF();
        const imgWidth = 180;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        pdf.addImage(imgData, 'PNG', 15, 15, imgWidth, imgHeight);
        pdf.save('fusion-map.pdf');
      });
    } else {
      const latencyGraph = document.querySelector('#latency-graph-container');
      if (latencyGraph) {
        html2canvas(latencyGraph as HTMLElement).then(canvas => {
          const imgData = canvas.toDataURL('image/png');
          const pdf = new jsPDF();
          const imgWidth = 180;
          const imgHeight = (canvas.height * imgWidth) / canvas.width;
          pdf.addImage(imgData, 'PNG', 15, 15, imgWidth, imgHeight);
          pdf.save('latency-metrics.pdf');
        });
      }
    }
  }
};

const addSampleLatencyData = () => {
  const now = new Date();
  for (let i = 0; i < 10; i++) {
    const time = new Date(now.getTime() - (9 - i) * 60000);
    latencyMetrics.push({
      time: time.toLocaleTimeString(),
      latency: Math.random() * 50 + 10 // Random latency between 10-60ms
    });
  }
};

if (latencyMetrics.length === 0) {
  addSampleLatencyData();
}

export const LatencyGraph: React.FC = () => {
  return (
    <div className="bg-gray-800 p-4 rounded mt-4" id="latency-graph-container">
      <h3 className="text-white font-semibold mb-2">Latency Over Time</h3>
      <LineChart width={500} height={250} data={latencyMetrics.slice(-10)}>
        <CartesianGrid stroke="#ccc" />
        <XAxis dataKey="time" />
        <YAxis />
        <Tooltip />
        <Line type="monotone" dataKey="latency" stroke="#82ca9d" />
      </LineChart>
      <Button
        className="mt-3 bg-green-700 text-white px-4 py-1 rounded hover:bg-green-800"
        onClick={DefenseModule.exportFusionMap}
      >
        Export Fusion Map (PDF)
      </Button>
    </div>
  );
};

export default LatencyGraph;
