import React, { useState, useEffect } from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { X, Bot, Zap, Settings, Loader2 } from 'lucide-react';

interface AgentTemplate {
  name: string;
  type: string;
  description: string;
  capabilities: string[];
  parameters: {
    model: string;
    temperature: number;
    max_tokens: number;
  };
}

/**
 * Props for the CreateAgentForm component
 */
interface CreateAgentFormProps {
  /** Whether the form modal is visible */
  isVisible: boolean;
  /** Callback function to close the form */
  onClose: () => void;
  /** Callback function when a new agent is successfully created */
  onAgentCreated: (agent: any) => void;
}

/**
 * CreateAgentForm - Modal form for creating custom AI agents from templates
 * 
 * Provides a comprehensive interface for users to create custom AI agents by selecting
 * from predefined templates and customizing parameters. Includes template selection,
 * agent naming, parameter tuning (temperature, max tokens), and real-time creation.
 * 
 * @param props - Component props
 * @param props.isVisible - Controls modal visibility
 * @param props.onClose - Callback to close the modal
 * @param props.onAgentCreated - Callback when agent creation succeeds
 * @returns JSX.Element - Rendered create agent form modal
 */
const CreateAgentForm: React.FC<CreateAgentFormProps> = ({
  isVisible,
  onClose,
  onAgentCreated
}) => {
  const [templates, setTemplates] = useState<AgentTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<AgentTemplate | null>(null);
  const [customName, setCustomName] = useState('');
  const [customParameters, setCustomParameters] = useState({
    temperature: 0.3,
    max_tokens: 1000
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isCreating, setIsCreating] = useState(false);

  useEffect(() => {
    if (isVisible) {
      fetchTemplates();
    }
  }, [isVisible]);

  /**
   * Fetches available agent templates from the API
   * Falls back to hardcoded templates if API request fails
   */
  const fetchTemplates = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/v1/gpt-agents/templates');
      if (response.ok) {
        const data = await response.json();
        setTemplates(data);
      } else {
        console.error('Failed to fetch templates');
        setTemplates([
          {
            name: "Trading Analyst",
            type: "Trading AI",
            description: "Analyzes market trends and provides trading insights",
            capabilities: ["market_analysis", "trend_detection", "risk_assessment"],
            parameters: { model: "gpt-4", temperature: 0.3, max_tokens: 1000 }
          },
          {
            name: "Security Monitor",
            type: "Security AI", 
            description: "Monitors system security and detects threats",
            capabilities: ["threat_detection", "anomaly_analysis", "security_assessment"],
            parameters: { model: "gpt-4", temperature: 0.2, max_tokens: 800 }
          },
          {
            name: "Market Predictor",
            type: "Prediction AI",
            description: "Predicts market movements using AI analysis",
            capabilities: ["price_prediction", "sentiment_analysis", "technical_analysis"],
            parameters: { model: "gpt-4", temperature: 0.4, max_tokens: 1200 }
          }
        ]);
      }
    } catch (error) {
      console.error('Error fetching templates:', error);
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Handles the creation of a new custom agent
   * Validates input and sends creation request to the API
   */
  const handleCreateAgent = async () => {
    if (!selectedTemplate || !customName.trim()) {
      return;
    }

    setIsCreating(true);
    try {
      const response = await fetch('/api/v1/gpt-agents/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          template_name: selectedTemplate.name,
          custom_name: customName.trim(),
          custom_parameters: customParameters
        })
      });

      if (response.ok) {
        const newAgent = await response.json();
        onAgentCreated(newAgent);
        handleClose();
      } else {
        console.error('Failed to create agent');
      }
    } catch (error) {
      console.error('Error creating agent:', error);
    } finally {
      setIsCreating(false);
    }
  };

  /**
   * Handles closing the form and resetting all state
   */
  const handleClose = () => {
    setSelectedTemplate(null);
    setCustomName('');
    setCustomParameters({ temperature: 0.3, max_tokens: 1000 });
    onClose();
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <Card className="bg-gradient-to-br from-gray-900 to-gray-800 border border-cyan-400 text-white max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center">
              <Bot className="w-6 h-6 mr-2 text-cyan-400" />
              <h2 className="text-2xl font-bold text-cyan-400">Create Custom AI Agent</h2>
            </div>
            <Button
              onClick={handleClose}
              className="bg-transparent hover:bg-red-600 p-2"
              size="sm"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
              <span className="ml-2 text-gray-300">Loading templates...</span>
            </div>
          ) : (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4 text-cyan-400">Choose Agent Template</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {templates.map((template, index) => (
                    <Card
                      key={index}
                      className={`cursor-pointer transition-all duration-200 ${
                        selectedTemplate?.name === template.name
                          ? 'border-cyan-400 bg-cyan-900/20 shadow-lg shadow-cyan-400/20'
                          : 'border-gray-600 bg-gray-800 hover:border-gray-500'
                      }`}
                      onClick={() => setSelectedTemplate(template)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center mb-2">
                          <Zap className="w-5 h-5 mr-2 text-cyan-400" />
                          <h4 className="font-semibold text-white">{template.name}</h4>
                        </div>
                        <p className="text-sm text-gray-400 mb-3">{template.description}</p>
                        <div className="text-xs text-gray-500">
                          <span className="bg-gray-700 px-2 py-1 rounded">{template.type}</span>
                        </div>
                        <div className="mt-2">
                          <div className="text-xs text-gray-400">Capabilities:</div>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {template.capabilities.slice(0, 3).map((cap, capIndex) => (
                              <span key={capIndex} className="text-xs bg-blue-900/50 text-blue-300 px-1 py-0.5 rounded">
                                {cap.replace('_', ' ')}
                              </span>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {selectedTemplate && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-cyan-400 mb-2">
                      Agent Name
                    </label>
                    <input
                      type="text"
                      value={customName}
                      onChange={(e) => setCustomName(e.target.value)}
                      placeholder="Enter a custom name for your agent"
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:border-cyan-400 focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-cyan-400 mb-2">
                        Temperature ({customParameters.temperature})
                      </label>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.1"
                        value={customParameters.temperature}
                        onChange={(e) => setCustomParameters(prev => ({
                          ...prev,
                          temperature: parseFloat(e.target.value)
                        }))}
                        className="w-full"
                      />
                      <div className="text-xs text-gray-400 mt-1">
                        Controls randomness: 0 = focused, 1 = creative
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-cyan-400 mb-2">
                        Max Tokens
                      </label>
                      <input
                        type="number"
                        min="100"
                        max="4000"
                        step="100"
                        value={customParameters.max_tokens}
                        onChange={(e) => setCustomParameters(prev => ({
                          ...prev,
                          max_tokens: parseInt(e.target.value)
                        }))}
                        className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-cyan-400 focus:outline-none"
                      />
                      <div className="text-xs text-gray-400 mt-1">
                        Maximum response length
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-800 p-4 rounded-lg">
                    <h4 className="font-semibold text-cyan-400 mb-2">Selected Template Details</h4>
                    <p className="text-sm text-gray-300 mb-2">{selectedTemplate.description}</p>
                    <div className="text-xs text-gray-400">
                      <strong>Type:</strong> {selectedTemplate.type}<br/>
                      <strong>Capabilities:</strong> {selectedTemplate.capabilities.join(', ')}
                    </div>
                  </div>
                </div>
              )}

              <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
                <Button
                  onClick={handleClose}
                  className="bg-gray-600 hover:bg-gray-700 text-white"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleCreateAgent}
                  disabled={!selectedTemplate || !customName.trim() || isCreating}
                  className="bg-cyan-600 hover:bg-cyan-700 text-white flex items-center"
                >
                  {isCreating ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <Settings className="w-4 h-4 mr-2" />
                      Create Agent
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default CreateAgentForm;
