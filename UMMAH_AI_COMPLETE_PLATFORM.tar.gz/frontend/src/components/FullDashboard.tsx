import { useEffect, useState, Suspense, lazy } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { HelpCircle, Eye, EyeOff, Palette } from 'lucide-react';

// import WalletConnectProvider from '@walletconnect/web3-provider';
import WalletPanel from './WalletPanel';
import AIModulesPanel from './AIModulesPanel';
import InfrastructurePanel from './InfrastructurePanel';
import GuideOverlay from './GuideOverlay';
import AIAgentsPanel from './AIAgentsPanel';
import SceneEditor from './SceneEditor';
import CreateAgentForm from './CreateAgentForm';
import KeyboardShortcuts from './KeyboardShortcuts';
import CommandPalette, { createDefaultCommands } from './CommandPalette';
import LayoutCustomizer, { defaultLayoutPresets, type LayoutComponent } from './LayoutCustomizer';
const InvestorDashboard = lazy(() => import('./InvestorDashboard'));
const StrategyMonitor = lazy(() => import('./StrategyMonitor'));
const FusionVisualizer = lazy(() => import('./FusionVisualizer'));
const ThreatMap = lazy(() => import('./ThreatMap'));
const UmmahNova = lazy(() => import('./UmmahNova'));

import LatencyGraph from './LatencyGraph';
import AlertSystemPanel from './AlertSystem';
import RealTimeWidget from './RealTimeWidget';
import JA3Heatmap from './JA3Heatmap';
import RegistrationFlow from './auth/RegistrationFlow';
import ThemeSwitcher from './ThemeSwitcher';
import SpaceBackground from './backgrounds/SpaceBackground';
import CyberpunkBackground from './backgrounds/CyberpunkBackground';
import SmartCityBackground from './backgrounds/SmartCityBackground';
import '../styles/themes.css';

/**
 * FullDashboard - Main dashboard component for the UMMAH AI Platform
 * 
 * This is the primary dashboard interface that orchestrates all platform components
 * including AI agents, trading systems, security monitoring, and user interfaces.
 * Features real-time data visualization, theme switching, wallet management,
 * and comprehensive system monitoring with paranoia mode for enhanced security.
 * 
 * @returns JSX.Element - The complete dashboard interface
 */
const FullDashboard = () => {
  const navigate = useNavigate();
  const [systemStatus, setSystemStatus] = useState('All Systems Operational');
  const [walletConnected, setWalletConnected] = useState(false);
  const [paranoiaMode, setParanoiaMode] = useState(false);
  const [cerebellumStatus, setCerebellumStatus] = useState('CerebellumBot vX: Dormant');
  const [showRegistration, setShowRegistration] = useState(false);
  const [simplifiedView, setSimplifiedView] = useState(false);
  const [showCreateAgentForm, setShowCreateAgentForm] = useState(false);
  const [showGuide, setShowGuide] = useState(false);
  const [currentGuideStep, setCurrentGuideStep] = useState(0);
  const [currentTheme, setCurrentTheme] = useState('space');
  const [showThemeSwitcher, setShowThemeSwitcher] = useState(false);
  const [showCommandPalette, setShowCommandPalette] = useState(false);
  const [showLayoutCustomizer, setShowLayoutCustomizer] = useState(false);
  const [keyboardShortcutsEnabled, setKeyboardShortcutsEnabled] = useState(true);
  const [isWalletConnecting, setIsWalletConnecting] = useState(false);
  const [walletError, setWalletError] = useState<string | null>(null);
  const [agentActionLoading, setAgentActionLoading] = useState<number | null>(null);
  const [agentActionError, setAgentActionError] = useState<string | null>(null);
  const [dashboardLayout, setDashboardLayout] = useState<LayoutComponent[]>([
    {
      id: 'wallet-panel',
      name: 'Wallet & Signing',
      visible: true,
      gridArea: { row: 1, column: 1, rowSpan: 1, columnSpan: 2 },
      minSize: { rows: 1, columns: 2 }
    },
    {
      id: 'ai-modules',
      name: 'AI Modules Overview',
      visible: true,
      gridArea: { row: 1, column: 3, rowSpan: 1, columnSpan: 2 },
      minSize: { rows: 1, columns: 2 }
    },
    {
      id: 'fusion-visualizer',
      name: '3D Fusion Map',
      visible: true,
      gridArea: { row: 2, column: 1, rowSpan: 2, columnSpan: 2 },
      minSize: { rows: 2, columns: 2 }
    },
    {
      id: 'threat-map',
      name: 'Threat Detection',
      visible: true,
      gridArea: { row: 2, column: 3, rowSpan: 1, columnSpan: 2 },
      minSize: { rows: 1, columns: 2 }
    },
    {
      id: 'ai-agents',
      name: 'AI Agents Control',
      visible: true,
      gridArea: { row: 3, column: 3, rowSpan: 1, columnSpan: 2 },
      minSize: { rows: 1, columns: 2 }
    },
    {
      id: 'infrastructure',
      name: 'Infrastructure & Stealth',
      visible: true,
      gridArea: { row: 4, column: 1, rowSpan: 1, columnSpan: 4 },
      minSize: { rows: 1, columns: 4 }
    }
  ]);
  const [aiAgents, setAiAgents] = useState([
    { 
      id: 1, 
      name: 'CerebellumBot vX', 
      status: 'Active & Breathing', 
      activity: 'Analyzing market patterns across 20 exchanges', 
      type: 'Trading AI',
      performance: {
        uptime: 86400, // 24 hours in seconds
        tasksCompleted: 1247,
        successRate: 98.7,
        avgResponseTime: 85
      },
      lastActivity: new Date().toISOString(),
      createdAt: '2024-01-15T10:30:00Z'
    },
    { 
      id: 2, 
      name: 'Quantum Predictor', 
      status: 'Processing', 
      activity: 'Running quantum algorithms for price prediction', 
      type: 'Prediction AI',
      performance: {
        uptime: 72000, // 20 hours in seconds
        tasksCompleted: 892,
        successRate: 94.2,
        avgResponseTime: 120
      },
      lastActivity: new Date().toISOString(),
      createdAt: '2024-01-16T08:15:00Z'
    },
    { 
      id: 3, 
      name: 'Stealth Executor', 
      status: 'Standby', 
      activity: 'Monitoring for execution opportunities', 
      type: 'Execution AI',
      performance: {
        uptime: 79200, // 22 hours in seconds
        tasksCompleted: 456,
        successRate: 99.1,
        avgResponseTime: 65
      },
      lastActivity: new Date().toISOString(),
      createdAt: '2024-01-14T14:20:00Z'
    },
    { 
      id: 4, 
      name: 'Threat Detector', 
      status: 'Scanning', 
      activity: 'Analyzing JA3 fingerprints and network threats', 
      type: 'Security AI',
      performance: {
        uptime: 90000, // 25 hours in seconds
        tasksCompleted: 2103,
        successRate: 96.8,
        avgResponseTime: 45
      },
      lastActivity: new Date().toISOString(),
      createdAt: '2024-01-13T12:45:00Z'
    }
  ]);

  const connectWallet = async (walletType?: string) => {
    try {
      setIsWalletConnecting(true);
      setWalletError(null);
      console.log(`Connecting to ${walletType || 'default'} wallet...`);
      
      setTimeout(() => {
        setWalletConnected(true);
        setIsWalletConnecting(false);
        console.log(`${walletType || 'Wallet'} connected successfully`);
      }, 1500);
    } catch (error) {
      console.error('Wallet connection failed:', error);
      setWalletError(`Failed to connect to ${walletType || 'wallet'}. Please try again.`);
      setIsWalletConnecting(false);
    }
  };

  const toggleParanoiaMode = () => {
    setParanoiaMode(!paranoiaMode);
    if (!paranoiaMode) {
      setCerebellumStatus('CerebellumBot vX: PARANOIA MODE ACTIVE');
      console.log('PARANOIA MODE ACTIVATED - Maximum stealth protocols engaged');
    } else {
      setCerebellumStatus('CerebellumBot vX: Standard Operations');
      console.log('Standard mode restored');
    }
  };

  const guideSteps = [
    {
      title: "Welcome to UMMAH AI Platform",
      content: "This is a quantum-enhanced trading platform with advanced AI agents. Let me show you around.",
      target: "header"
    },
    {
      title: "AI Agents Panel",
      content: "These are your AI agents working 24/7. Each has specialized functions for trading, security, and analysis.",
      target: "ai-agents"
    },
    {
      title: "Real-time Data",
      content: "Live market data, weather, and prayer times are updated in real-time to provide context for trading decisions.",
      target: "realtime-widget"
    },
    {
      title: "Wallet & Security",
      content: "Connect your wallet securely with multiple authentication layers and encryption protocols.",
      target: "wallet-panel"
    },
    {
      title: "Threat Detection",
      content: "Advanced security monitoring with JA3 fingerprinting and global threat analysis.",
      target: "threat-detection"
    }
  ];

  /**
   * Toggles between simplified and full dashboard view
   * Simplified view hides complex panels for easier navigation
   */
  const toggleSimplifiedView = () => {
    setSimplifiedView(!simplifiedView);
  };

  /**
   * Initiates the user guide overlay
   * Starts from the first step of the guided tour
   */
  const startGuide = () => {
    setShowGuide(true);
    setCurrentGuideStep(0);
  };

  /**
   * Advances to the next step in the user guide
   * Closes guide when reaching the final step
   */
  const nextGuideStep = () => {
    if (currentGuideStep < guideSteps.length - 1) {
      setCurrentGuideStep(currentGuideStep + 1);
    } else {
      setShowGuide(false);
      setCurrentGuideStep(0);
    }
  };

  useEffect(() => {
    setTimeout(() => {
      setSystemStatus('AI Mesh, Blockchain, Storage Synced');
      setCerebellumStatus('CerebellumBot vX: Active & Breathing');
    }, 1000);

    setTimeout(() => {
      console.log('Stealth Chain Replication Enabled');
      console.log('Zero-Day Threat Detection Activated');
      console.log('Trace Fusion Map Online');
      console.log('ZK Wallet bridge initialized via zkSync/StarkEx');
      console.log('TOR Chain active — geo-shuffled proxies in motion');
    }, 2000);

    const agentUpdateInterval = setInterval(() => {
      setAiAgents(prev => prev.map(agent => ({
        ...agent,
        activity: getRandomActivity(agent.type)
      })));
    }, 5000);

    return () => clearInterval(agentUpdateInterval);
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', currentTheme);
  }, [currentTheme]);

  const handleThemeChange = (theme: string) => {
    setCurrentTheme(theme);
  };

  useEffect(() => {
    try {
      const savedLayout = localStorage.getItem('ummah-dashboard-layout');
      if (savedLayout) {
        setDashboardLayout(JSON.parse(savedLayout));
      }
    } catch (error) {
      console.error('Failed to load saved layout:', error);
    }
  }, []);

  const commandActions = {
    toggleParanoiaMode,
    toggleSimplifiedView,
    showRegistration: () => setShowRegistration(true),
    showCreateAgent: () => setShowCreateAgentForm(true),
    navigateToExchanges: () => navigate('/exchanges'),
    toggleTheme: () => setShowThemeSwitcher(!showThemeSwitcher),
    showGuide: startGuide,
    refreshData: () => {
      window.location.reload();
    }
  };

  const keyboardShortcuts = [
    {
      key: 'ctrl+k',
      description: 'Open command palette',
      action: () => setShowCommandPalette(true)
    },
    {
      key: 'ctrl+shift+p',
      description: 'Toggle paranoia mode',
      action: toggleParanoiaMode
    },
    {
      key: 'ctrl+shift+s',
      description: 'Toggle simplified view',
      action: toggleSimplifiedView
    },
    {
      key: 'ctrl+shift+l',
      description: 'Open layout customizer',
      action: () => setShowLayoutCustomizer(true)
    },
    {
      key: 'ctrl+shift+t',
      description: 'Toggle theme switcher',
      action: () => setShowThemeSwitcher(!showThemeSwitcher)
    },
    {
      key: 'ctrl+shift+h',
      description: 'Show help guide',
      action: startGuide
    },
    {
      key: 'ctrl+shift+r',
      description: 'Refresh dashboard',
      action: () => window.location.reload()
    },
    {
      key: 'escape',
      description: 'Close overlays',
      action: () => {
        setShowCommandPalette(false);
        setShowLayoutCustomizer(false);
        setShowThemeSwitcher(false);
        setShowGuide(false);
      }
    }
  ];

  const getComponentVisibility = (componentId: string) => {
    const component = dashboardLayout.find(comp => comp.id === componentId);
    return component?.visible ?? true;
  };

  const renderBackground = () => {
    switch (currentTheme) {
      case 'space':
        return <SpaceBackground />;
      case 'cyberpunk':
        return <CyberpunkBackground />;
      case 'smart-city':
        return <SmartCityBackground />;
      default:
        return <SpaceBackground />;
    }
  };

  const getRandomActivity = (type: string) => {
    const activities = {
      'Trading AI': [
        'Analyzing arbitrage opportunities across exchanges',
        'Executing stealth trades on Binance and OKX',
        'Monitoring whale movements and order flow',
        'Optimizing position sizes based on volatility'
      ],
      'Prediction AI': [
        'Processing quantum algorithms for BTC prediction',
        'Analyzing social sentiment and news impact',
        'Running Monte Carlo simulations',
        'Calculating probability matrices for market moves'
      ],
      'Execution AI': [
        'Waiting for optimal entry signals',
        'Managing risk parameters across positions',
        'Coordinating with other AI agents',
        'Preparing stealth execution protocols'
      ],
      'Security AI': [
        'Scanning for suspicious network activity',
        'Analyzing TLS fingerprints and patterns',
        'Monitoring for potential threats',
        'Updating security protocols and defenses'
      ]
    };
    const typeActivities = activities[type as keyof typeof activities] || ['Processing data'];
    return typeActivities[Math.floor(Math.random() * typeActivities.length)];
  };

  if (showRegistration) {
    return <RegistrationFlow />;
  }

  return (
    <>
      {/* Dynamic Theme Background */}
      {renderBackground()}
      
      {/* Theme-aware overlay effects */}
      <div className="fixed inset-0 opacity-20 pointer-events-none" style={{ zIndex: -1 }}>
        <div className="matrix-rain"></div>
        <div className="quantum-particles">
          <div className="quantum-particle"></div>
          <div className="quantum-particle"></div>
          <div className="quantum-particle"></div>
          <div className="quantum-particle"></div>
          <div className="quantum-particle"></div>
        </div>
        <div className="data-stream">
          <div className="data-line"></div>
          <div className="data-line"></div>
          <div className="data-line"></div>
          <div className="data-line"></div>
        </div>
        <div className="neural-lines">
          <div className="neural-line neural-line-1"></div>
          <div className="neural-line neural-line-2"></div>
          <div className="neural-line neural-line-3"></div>
        </div>
      </div>
      
      <div className="min-h-screen text-white p-4 space-y-4 relative" style={{ zIndex: 1 }}>
      {/* Main Header */}
      <Card className="card-enhanced pulse-border">
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h1 className="text-3xl font-bold mb-2 glow-text">
                UMMAH AI Platform
              </h1>
              <p className="text-sm mb-2 glow-text">Quantum-Class Mesh Liquidity AI</p>
              <p className="text-xs text-green-400 glow-text-green">{systemStatus}</p>
            </div>
            <div className="flex gap-3">
              <Button
                onClick={startGuide}
                className="bg-cyan-600 hover:bg-cyan-700 text-white font-semibold px-4 py-2 rounded-lg transition-all duration-200"
              >
                <HelpCircle className="w-4 h-4 mr-2" />
                Guide
              </Button>
              <Button
                onClick={toggleSimplifiedView}
                className="bg-purple-600 hover:bg-purple-700 text-white font-semibold px-4 py-2 rounded-lg transition-all duration-200"
              >
                {simplifiedView ? <Eye className="w-4 h-4 mr-2" /> : <EyeOff className="w-4 h-4 mr-2" />}
                {simplifiedView ? 'Full View' : 'Simple View'}
              </Button>
              <Button
                onClick={() => setShowThemeSwitcher(true)}
                className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white font-semibold px-4 py-2 rounded-lg transition-all duration-200"
              >
                <Palette className="w-4 h-4 mr-2" />
                Themes
              </Button>
              <Button 
                onClick={() => setShowCommandPalette(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded-lg transition-all duration-200"
                title="Command Palette (Ctrl+K)"
              >
                ⌘ Commands
              </Button>
              <Button 
                onClick={() => setShowLayoutCustomizer(true)}
                className="bg-green-600 hover:bg-green-700 text-white font-semibold px-4 py-2 rounded-lg transition-all duration-200"
                title="Customize Layout (Ctrl+Shift+L)"
              >
                ⚙️ Layout
              </Button>
              <Button 
                onClick={() => setKeyboardShortcutsEnabled(!keyboardShortcutsEnabled)}
                className={`${keyboardShortcutsEnabled ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-600 hover:bg-gray-700'} text-white font-semibold px-4 py-2 rounded-lg transition-all duration-200`}
                title="Toggle Keyboard Shortcuts"
              >
                ⌨️ {keyboardShortcutsEnabled ? 'Shortcuts ON' : 'Shortcuts OFF'}
              </Button>
              <Button
                onClick={() => setShowRegistration(true)}
                className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white font-semibold px-6 py-3 rounded-lg transition-all duration-200 transform hover:scale-105"
              >
                Investor Registration
              </Button>
              <Button 
                onClick={toggleParanoiaMode}
                className={`${paranoiaMode ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'} text-white font-bold px-6 py-3`}
              >
                {paranoiaMode ? 'PARANOIA: ON' : 'PARANOIA: OFF'}
              </Button>
            </div>
          </div>
          <div className="bg-gray-800 p-3 rounded border border-gray-600">
            <p className="text-sm font-mono glow-text">{cerebellumStatus}</p>
            <p className="text-xs text-gray-400 mt-1">
              CerebellumBot vX — это не аккаунт на бирже. Это существо. Оно дышит в фоне, предсказывает, действует, и остаётся невидимым.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Real-time Information Widget */}
      <RealTimeWidget />

      {/* Error Messages */}
      {agentActionError && (
        <div className="bg-red-900/50 border border-red-500 rounded-lg p-4 mb-4">
          <div className="flex items-center">
            <div className="text-red-400 mr-2">⚠️</div>
            <div className="text-red-200">{agentActionError}</div>
              <button onClick={() => setAgentActionError(null)}
              className="ml-auto text-red-400 hover:text-red-300"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Dashboard Panels */}
      {(getComponentVisibility('wallet-panel') || getComponentVisibility('ai-modules')) && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {getComponentVisibility('wallet-panel') && (
            <WalletPanel 
              walletConnected={walletConnected} 
              connectWallet={connectWallet}
              isConnecting={isWalletConnecting}
              error={walletError}
            />
          )}
          {!simplifiedView && getComponentVisibility('ai-modules') && (
            <AIModulesPanel paranoiaMode={paranoiaMode} />
          )}
        </div>
      )}

      {/* AI Agents Control Center */}
      {getComponentVisibility('ai-agents') && (
        <AIAgentsPanel 
          agents={aiAgents} 
          onCreateAgent={() => setShowCreateAgentForm(true)}
          actionLoading={agentActionLoading}
          actionError={agentActionError}
          onMonitorAgent={async (agentId) => {
            try {
              setAgentActionLoading(agentId);
              setAgentActionError(null);
              console.log(`Opening monitoring dashboard for agent ${agentId}`);
              
              await new Promise(resolve => setTimeout(resolve, 800));
              
              setAiAgents(prev => prev.map(agent => 
                agent.id === agentId 
                  ? { ...agent, status: 'Monitoring', activity: 'Real-time performance monitoring active' }
                  : agent
              ));
              setAgentActionLoading(null);
            } catch (error) {
              console.error(`Failed to start monitoring for agent ${agentId}:`, error);
              setAgentActionError(`Failed to start monitoring for agent ${agentId}. Please try again.`);
              setAgentActionLoading(null);
            }
          }}
          onConfigureAgent={async (agentId) => {
            try {
              setAgentActionLoading(agentId);
              setAgentActionError(null);
              console.log(`Opening configuration panel for agent ${agentId}`);
              
              await new Promise(resolve => setTimeout(resolve, 600));
              
              setAiAgents(prev => prev.map(agent => 
                agent.id === agentId 
                  ? { ...agent, status: 'Configuring', activity: 'Configuration panel opened' }
                  : agent
              ));
              setAgentActionLoading(null);
            } catch (error) {
              console.error(`Failed to configure agent ${agentId}:`, error);
              setAgentActionError(`Failed to configure agent ${agentId}. Please try again.`);
              setAgentActionLoading(null);
            }
          }}
        />
      )}

      {!simplifiedView && getComponentVisibility('infrastructure') && <InfrastructurePanel />}
      
      {/* Threat Detection & Alerts */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <AlertSystemPanel />
        <JA3Heatmap />
      </div>

      {/* Real-time Visualization */}
      {!simplifiedView && (
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
          <LatencyGraph />
          <div className="bg-gray-900 border border-gray-700 rounded-lg p-4">
            <h3 className="text-white font-semibold mb-4">3D Fusion Map</h3>
            <div id="fusion-graph-container" className="h-64 bg-gray-800 rounded"></div>
            {getComponentVisibility('fusion-visualizer') && (
              <Suspense fallback={<div className="flex items-center justify-center h-64 text-cyan-400">Loading 3D Visualizer...</div>}>
                <FusionVisualizer />
              </Suspense>
            )}
          </div>
          {getComponentVisibility('threat-map') && (
            <Suspense fallback={<div className="flex items-center justify-center h-64 bg-gray-800 rounded-lg text-cyan-400">Loading Threat Map...</div>}>
              <ThreatMap />
            </Suspense>
          )}
        </div>
      )}

      {/* Advanced Dashboard Components */}
      {!simplifiedView && (
        <Suspense fallback={<div className="flex items-center justify-center h-32 bg-gray-800 rounded-lg text-cyan-400">Loading Investor Dashboard...</div>}>
          <InvestorDashboard />
        </Suspense>
      )}
      {!simplifiedView && (
        <Suspense fallback={<div className="flex items-center justify-center h-32 bg-gray-800 rounded-lg text-cyan-400">Loading Strategy Monitor...</div>}>
          <StrategyMonitor />
        </Suspense>
      )}

      {/* UMMAH NOVA Advanced Components */}
      {!simplifiedView && (
        <Suspense fallback={<div className="flex items-center justify-center h-64 bg-gray-800 rounded-lg text-cyan-400">Loading UMMAH NOVA...</div>}>
          <UmmahNova />
        </Suspense>
      )}

      {/* 3D Scene Editor */}
      {!simplifiedView && <SceneEditor />}

      {/* Exchange Status Grid */}
      <Card className="card-enhanced">
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold mb-4">Exchange Network Status</h2>
          <div className="grid grid-cols-4 md:grid-cols-5 lg:grid-cols-10 gap-2">
            {['Binance', 'OKX', 'Bybit', 'Kraken', 'Bitfinex', 'Coinbase', 'Gemini', 'KuCoin', 'Bitstamp', 'Poloniex', 'Huobi', 'Bittrex', 'Gate.io', 'Deribit', 'Upbit', 'Liquid', 'Coincheck', 'ZB.com', 'BitFlyer', 'MEXC'].map((exchange) => (
              <div 
                key={exchange} 
                className="bg-gray-800 p-2 rounded text-center cursor-pointer hover:bg-gray-700 hover:border-gray-500 transition-all duration-200 border border-gray-600 transform hover:scale-105"
                onClick={() => navigate(`/exchanges/${exchange}`)}
              >
                <div className="text-xs font-mono">{exchange}</div>
                <div className="text-green-400 text-xs">LIVE</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      </div>

      {/* Guide Overlay */}
      <div style={{ zIndex: 1000 }}>
        <GuideOverlay
          isVisible={showGuide}
          currentStep={guideSteps[currentGuideStep]}
          stepNumber={currentGuideStep}
          totalSteps={guideSteps.length}
          onNext={nextGuideStep}
          onClose={() => setShowGuide(false)}
        />
      </div>

      {/* Create Agent Form */}
      <div style={{ zIndex: 1000 }}>
        <CreateAgentForm
          isVisible={showCreateAgentForm}
          onClose={() => setShowCreateAgentForm(false)}
          onAgentCreated={(newAgent) => {
            setAiAgents(prev => [...prev, {
              id: prev.length + 1,
              name: newAgent.name,
              status: 'Active',
              activity: 'Initializing custom agent capabilities',
              type: newAgent.type,
              performance: {
                uptime: 0,
                tasksCompleted: 0,
                successRate: 100.0,
                avgResponseTime: 0
              },
              lastActivity: new Date().toISOString(),
              createdAt: newAgent.created_at
            }]);
            setShowCreateAgentForm(false);
          }}
        />
      </div>

      {/* Theme Switcher */}
      <div style={{ zIndex: 1000 }}>
        <ThemeSwitcher
          currentTheme={currentTheme}
          onThemeChange={handleThemeChange}
          isVisible={showThemeSwitcher}
          onClose={() => setShowThemeSwitcher(false)}
        />
      </div>

      {/* Keyboard Shortcuts */}
      <div style={{ zIndex: 100 }}>
        <KeyboardShortcuts 
          shortcuts={keyboardShortcuts}
          enabled={keyboardShortcutsEnabled}
        />
      </div>

      {/* Command Palette */}
      <div style={{ zIndex: 1000 }}>
        <CommandPalette
          isOpen={showCommandPalette}
          onClose={() => setShowCommandPalette(false)}
          commands={createDefaultCommands(commandActions)}
          placeholder="Type a command or search..."
        />
      </div>

      {/* Layout Customizer */}
      <div style={{ zIndex: 1000 }}>
        <LayoutCustomizer
          isOpen={showLayoutCustomizer}
          onClose={() => setShowLayoutCustomizer(false)}
          currentLayout={dashboardLayout}
          onLayoutChange={setDashboardLayout}
          presets={defaultLayoutPresets}
        />
      </div>
    </>
  );
};

export default FullDashboard;
