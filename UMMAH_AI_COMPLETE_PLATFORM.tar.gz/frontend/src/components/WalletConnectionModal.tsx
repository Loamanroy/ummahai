import React, { useState } from 'react';
import { X, Wallet, ExternalLink, Shield, AlertTriangle } from 'lucide-react';

interface WalletOption {
  id: string;
  name: string;
  icon: string;
  description: string;
  supported: boolean;
}

interface WalletConnectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnect: (walletId: string) => void;
}

const walletOptions: WalletOption[] = [
  {
    id: 'metamask',
    name: 'MetaMask',
    icon: '🦊',
    description: 'Connect using MetaMask wallet',
    supported: true
  },
  {
    id: 'binance',
    name: 'Binance Wallet',
    icon: '🟡',
    description: 'Connect using Binance Chain Wallet',
    supported: true
  },
  {
    id: 'trustwallet',
    name: 'Trust Wallet',
    icon: '🔷',
    description: 'Connect using Trust Wallet',
    supported: true
  },
  {
    id: 'walletconnect',
    name: 'WalletConnect',
    icon: '🔗',
    description: 'Connect using WalletConnect protocol',
    supported: true
  },
  {
    id: 'coinbase',
    name: 'Coinbase Wallet',
    icon: '🔵',
    description: 'Connect using Coinbase Wallet',
    supported: false
  },
  {
    id: 'phantom',
    name: 'Phantom',
    icon: '👻',
    description: 'Connect using Phantom wallet (Solana)',
    supported: false
  }
];

export const WalletConnectionModal: React.FC<WalletConnectionModalProps> = ({
  isOpen,
  onClose,
  onConnect
}) => {
  const [selectedWallet, setSelectedWallet] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);

  if (!isOpen) return null;

  const handleConnect = async (walletId: string) => {
    setIsConnecting(true);
    setSelectedWallet(walletId);

    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      onConnect(walletId);
      onClose();
    } catch (error) {
      console.error('Wallet connection failed:', error);
    } finally {
      setIsConnecting(false);
      setSelectedWallet(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      
      <div className="relative bg-gray-800 rounded-2xl p-6 w-full max-w-md mx-4 border border-gray-700">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-white">Connect Wallet</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        <div className="mb-6">
          <div className="flex items-center space-x-2 p-3 bg-blue-900/20 border border-blue-500/30 rounded-lg">
            <Shield className="w-5 h-5 text-blue-400" />
            <p className="text-sm text-blue-300">
              Your wallet will be used to execute trades and manage funds securely.
            </p>
          </div>
        </div>

        <div className="space-y-3 mb-6">
          {walletOptions.map((wallet) => (
            <button
              key={wallet.id}
              onClick={() => wallet.supported && handleConnect(wallet.id)}
              disabled={!wallet.supported || isConnecting}
              className={`w-full flex items-center justify-between p-4 rounded-lg border transition-all ${
                wallet.supported
                  ? 'border-gray-600 hover:border-gray-500 hover:bg-gray-700/50 cursor-pointer'
                  : 'border-gray-700 bg-gray-800/50 cursor-not-allowed opacity-50'
              } ${
                selectedWallet === wallet.id && isConnecting
                  ? 'border-blue-500 bg-blue-900/20'
                  : ''
              }`}
            >
              <div className="flex items-center space-x-3">
                <span className="text-2xl">{wallet.icon}</span>
                <div className="text-left">
                  <p className="text-white font-medium">{wallet.name}</p>
                  <p className="text-gray-400 text-sm">{wallet.description}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                {!wallet.supported && (
                  <span className="text-xs text-yellow-400 bg-yellow-400/10 px-2 py-1 rounded">
                    Coming Soon
                  </span>
                )}
                {selectedWallet === wallet.id && isConnecting ? (
                  <div className="w-5 h-5 border-2 border-blue-400 border-t-transparent rounded-full animate-spin" />
                ) : (
                  <ExternalLink className="w-4 h-4 text-gray-400" />
                )}
              </div>
            </button>
          ))}
        </div>

        <div className="border-t border-gray-700 pt-4">
          <div className="flex items-start space-x-2">
            <AlertTriangle className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-400">
              <p className="mb-1">
                <strong className="text-yellow-400">Security Notice:</strong>
              </p>
              <ul className="space-y-1">
                <li>• Never share your private keys or seed phrases</li>
                <li>• Always verify transaction details before signing</li>
                <li>• Use hardware wallets for large amounts</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
