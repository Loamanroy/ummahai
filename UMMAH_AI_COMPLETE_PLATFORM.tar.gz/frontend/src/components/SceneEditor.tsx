import React, { useState, useRef, useCallback } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, useGLTF, TransformControls, Grid, Sky, Environment } from '@react-three/drei';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Upload, Download, RotateCcw, Move, RotateCw, Scale, Trash2, Eye, EyeOff } from 'lucide-react';
import * as THREE from 'three';

interface SceneObject {
  id: string;
  name: string;
  position: [number, number, number];
  rotation: [number, number, number];
  scale: [number, number, number];
  url: string;
  visible: boolean;
}

interface GLTFModelProps {
  url: string;
  position: [number, number, number];
  rotation: [number, number, number];
  scale: [number, number, number];
  isSelected: boolean;
  onSelect: () => void;
}

/**
 * GLTFModel - 3D model component for rendering GLTF/GLB files in the scene
 * 
 * Renders a 3D model from a GLTF or GLB file with transform controls and selection handling.
 * Provides visual feedback when selected and supports interactive transformation.
 * 
 * @param props - Component props
 * @param props.url - URL or blob URL of the GLTF/GLB file to load
 * @param props.position - 3D position coordinates [x, y, z]
 * @param props.rotation - 3D rotation values [x, y, z] in radians
 * @param props.scale - 3D scale factors [x, y, z]
 * @param props.isSelected - Whether this model is currently selected
 * @param props.onSelect - Callback function when model is clicked/selected
 * @returns JSX.Element - Rendered 3D model group
 */
const GLTFModel: React.FC<GLTFModelProps> = ({ url, position, rotation, scale, isSelected, onSelect }) => {
  const { scene } = useGLTF(url);
  const meshRef = useRef<THREE.Group>(null);

  useFrame(() => {
    if (meshRef.current && isSelected) {
      meshRef.current.rotation.y += 0.01;
    }
  });

  return (
    <group
      ref={meshRef}
      position={position}
      rotation={rotation}
      scale={scale}
      onClick={onSelect}
    >
      <primitive object={scene.clone()} />
    </group>
  );
};

/**
 * SceneEditor - Interactive 3D scene editor with GLTF/GLB support
 * 
 * Provides a comprehensive 3D scene editing interface allowing users to:
 * - Load and manage GLTF/GLB 3D models
 * - Transform objects with translate, rotate, and scale controls
 * - Switch between different background themes (space, cyberpunk, smart city)
 * - Export and import scene configurations
 * - Toggle object visibility and manage scene hierarchy
 * 
 * Features include:
 * - Real-time 3D viewport with orbit controls
 * - Transform gizmos for precise object manipulation
 * - Object hierarchy panel with visibility controls
 * - Scene export/import functionality
 * - Multiple background environment presets
 * 
 * @returns JSX.Element - Complete 3D scene editor interface
 */
const SceneEditor: React.FC = () => {
  const [objects, setObjects] = useState<SceneObject[]>([]);
  const [selectedObjectId, setSelectedObjectId] = useState<string | null>(null);
  const [transformMode, setTransformMode] = useState<'translate' | 'rotate' | 'scale'>('translate');
  const [showGrid, setShowGrid] = useState(true);
  const [backgroundTheme, setBackgroundTheme] = useState<'space' | 'cyberpunk' | 'smart_city'>('space');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && (file.name.endsWith('.gltf') || file.name.endsWith('.glb'))) {
      const url = URL.createObjectURL(file);
      const newObject: SceneObject = {
        id: `object_${Date.now()}`,
        name: file.name,
        position: [0, 0, 0],
        rotation: [0, 0, 0],
        scale: [1, 1, 1],
        url,
        visible: true
      };
      setObjects(prev => [...prev, newObject]);
    }
  }, []);

  const handleObjectSelect = useCallback((objectId: string) => {
    setSelectedObjectId(objectId);
  }, []);

  const updateObjectTransform = useCallback((objectId: string, property: 'position' | 'rotation' | 'scale', value: [number, number, number]) => {
    setObjects(prev => prev.map(obj => 
      obj.id === objectId ? { ...obj, [property]: value } : obj
    ));
  }, []);

  const deleteObject = useCallback((objectId: string) => {
    setObjects(prev => prev.filter(obj => obj.id !== objectId));
    if (selectedObjectId === objectId) {
      setSelectedObjectId(null);
    }
  }, [selectedObjectId]);

  const toggleObjectVisibility = useCallback((objectId: string) => {
    setObjects(prev => prev.map(obj => 
      obj.id === objectId ? { ...obj, visible: !obj.visible } : obj
    ));
  }, []);

  const exportScene = useCallback(() => {
    const sceneData = {
      objects: objects.map(obj => ({
        ...obj,
        url: obj.name // Store filename instead of blob URL for export
      })),
      backgroundTheme,
      timestamp: new Date().toISOString()
    };
    
    const dataStr = JSON.stringify(sceneData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `scene_${Date.now()}.json`;
    link.click();
    
    URL.revokeObjectURL(url);
  }, [objects, backgroundTheme]);

  const importScene = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.name.endsWith('.json')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const sceneData = JSON.parse(e.target?.result as string);
          if (sceneData.objects) {
            setObjects(sceneData.objects);
            if (sceneData.backgroundTheme) {
              setBackgroundTheme(sceneData.backgroundTheme);
            }
          }
        } catch (error) {
          console.error('Failed to import scene:', error);
        }
      };
      reader.readAsText(file);
    }
  }, []);

  const resetScene = useCallback(() => {
    setObjects([]);
    setSelectedObjectId(null);
  }, []);

  const getBackgroundComponent = () => {
    switch (backgroundTheme) {
      case 'space':
        return <Sky sunPosition={[0, 0, -1]} />;
      case 'cyberpunk':
        return <Environment preset="night" />;
      case 'smart_city':
        return <Environment preset="city" />;
      default:
        return <Sky sunPosition={[0, 0, -1]} />;
    }
  };

  return (
    <Card className="bg-gray-900 border border-gray-700 text-white">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">3D Scene Editor</h2>
          <div className="flex gap-2">
            <Button
              onClick={() => fileInputRef.current?.click()}
              className="bg-blue-600 hover:bg-blue-700 text-white text-sm"
            >
              <Upload className="w-4 h-4 mr-1" />
              Load GLTF/GLB
            </Button>
            <Button
              onClick={exportScene}
              className="bg-green-600 hover:bg-green-700 text-white text-sm"
            >
              <Download className="w-4 h-4 mr-1" />
              Export Scene
            </Button>
            <Button
              onClick={resetScene}
              className="bg-red-600 hover:bg-red-700 text-white text-sm"
            >
              <RotateCcw className="w-4 h-4 mr-1" />
              Reset
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* 3D Viewport */}
          <div className="lg:col-span-3 h-96 bg-gray-800 rounded-lg overflow-hidden">
            <Canvas camera={{ position: [5, 5, 5], fov: 60 }}>
              {getBackgroundComponent()}
              <ambientLight intensity={0.5} />
              <directionalLight position={[10, 10, 5]} intensity={1} />
              
              {showGrid && <Grid infiniteGrid />}
              
              {objects.map(obj => (
                obj.visible && (
                  <React.Fragment key={obj.id}>
                    <GLTFModel
                      url={obj.url}
                      position={obj.position}
                      rotation={obj.rotation}
                      scale={obj.scale}
                      isSelected={selectedObjectId === obj.id}
                      onSelect={() => handleObjectSelect(obj.id)}
                    />
                    {selectedObjectId === obj.id && (
                      <TransformControls
                        mode={transformMode}
                        onObjectChange={(e) => {
                          if (e?.target) {
                            const target = e.target as any;
                            if (transformMode === 'translate') {
                              updateObjectTransform(obj.id, 'position', [
                                target.position.x,
                                target.position.y,
                                target.position.z
                              ]);
                            } else if (transformMode === 'rotate') {
                              updateObjectTransform(obj.id, 'rotation', [
                                target.rotation.x,
                                target.rotation.y,
                                target.rotation.z
                              ]);
                            } else if (transformMode === 'scale') {
                              updateObjectTransform(obj.id, 'scale', [
                                target.scale.x,
                                target.scale.y,
                                target.scale.z
                              ]);
                            }
                          }
                        }}
                      />
                    )}
                  </React.Fragment>
                )
              ))}
              
              <OrbitControls enablePan enableZoom enableRotate />
            </Canvas>
          </div>

          {/* Control Panel */}
          <div className="space-y-4">
            {/* Transform Controls */}
            <div className="bg-gray-800 p-3 rounded-lg">
              <h3 className="text-sm font-semibold mb-2">Transform Mode</h3>
              <div className="grid grid-cols-3 gap-1">
                <Button
                  onClick={() => setTransformMode('translate')}
                  className={`text-xs ${transformMode === 'translate' ? 'bg-blue-600' : 'bg-gray-600'}`}
                >
                  <Move className="w-3 h-3" />
                </Button>
                <Button
                  onClick={() => setTransformMode('rotate')}
                  className={`text-xs ${transformMode === 'rotate' ? 'bg-blue-600' : 'bg-gray-600'}`}
                >
                  <RotateCw className="w-3 h-3" />
                </Button>
                <Button
                  onClick={() => setTransformMode('scale')}
                  className={`text-xs ${transformMode === 'scale' ? 'bg-blue-600' : 'bg-gray-600'}`}
                >
                  <Scale className="w-3 h-3" />
                </Button>
              </div>
            </div>

            {/* Background Theme */}
            <div className="bg-gray-800 p-3 rounded-lg">
              <h3 className="text-sm font-semibold mb-2">Background</h3>
              <select
                value={backgroundTheme}
                onChange={(e) => setBackgroundTheme(e.target.value as any)}
                className="w-full bg-gray-700 text-white text-xs p-2 rounded"
              >
                <option value="space">Space</option>
                <option value="cyberpunk">Cyberpunk</option>
                <option value="smart_city">Smart City</option>
              </select>
            </div>

            {/* Scene Objects */}
            <div className="bg-gray-800 p-3 rounded-lg">
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-sm font-semibold">Objects ({objects.length})</h3>
                <Button
                  onClick={() => setShowGrid(!showGrid)}
                  className="text-xs bg-gray-600 hover:bg-gray-700"
                >
                  Grid: {showGrid ? 'ON' : 'OFF'}
                </Button>
              </div>
              <div className="space-y-1 max-h-32 overflow-y-auto">
                {objects.map(obj => (
                  <div
                    key={obj.id}
                    className={`flex items-center justify-between p-2 rounded text-xs ${
                      selectedObjectId === obj.id ? 'bg-blue-600' : 'bg-gray-700'
                    }`}
                  >
                    <span
                      className="cursor-pointer flex-1 truncate"
                      onClick={() => handleObjectSelect(obj.id)}
                    >
                      {obj.name}
                    </span>
                    <div className="flex gap-1">
                      <Button
                        onClick={() => toggleObjectVisibility(obj.id)}
                        className="p-1 bg-transparent hover:bg-gray-600"
                      >
                        {obj.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                      </Button>
                      <Button
                        onClick={() => deleteObject(obj.id)}
                        className="p-1 bg-transparent hover:bg-red-600"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Hidden File Inputs */}
        <input
          ref={fileInputRef}
          type="file"
          accept=".gltf,.glb"
          onChange={handleFileUpload}
          className="hidden"
        />
        <input
          type="file"
          accept=".json"
          onChange={importScene}
          className="hidden"
          id="import-scene"
        />
      </CardContent>
    </Card>
  );
};

export default SceneEditor;
