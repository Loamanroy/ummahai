import React, { useEffect } from 'react';

interface LatencyData {
  latency: number;
  timestamp: number;
}

interface CognitiveSelfRewriteEngineProps {
  data: LatencyData[];
}

const CognitiveSelfRewriteEngine: React.FC<CognitiveSelfRewriteEngineProps> = ({ data }) => {
  useEffect(() => {
    if (data.length > 5) {
      const avgLatency = data.reduce((a, b) => a + b.latency, 0) / data.length;
      if (avgLatency > 1200) {
        console.warn('Optimizer: High average latency detected. Rerouting...');
      }
    }
  }, [data]);

  return (
    <div className="bg-gray-800 text-white p-4 rounded">
      <h3 className="text-lg font-bold mb-2">Cognitive Self-Rewrite Engine</h3>
      <div className="space-y-2">
        <p className="text-sm">🧠 Neural optimization: ACTIVE</p>
        <p className="text-sm">⚡ Auto-rewrite cycles: {data.length}</p>
        <p className="text-sm">📊 Performance monitoring: ENABLED</p>
        {data.length > 5 && (
          <p className="text-sm">
            📈 Avg latency: {(data.reduce((a, b) => a + b.latency, 0) / data.length).toFixed(0)}ms
          </p>
        )}
      </div>
    </div>
  );
};

export default CognitiveSelfRewriteEngine;
