import React, { useEffect, useState, useRef, useMemo } from 'react';
import ForceGraph3D from 'react-force-graph-3d';
import * as THREE from 'three';

interface GraphNode {
  id: string;
  group: number;
  alert?: boolean;
  x?: number;
  y?: number;
  z?: number;
  fx?: number;
  fy?: number;
  fz?: number;
  val?: number;
  color?: string;
  metadata?: {
    name: string;
    description: string;
    metrics: Record<string, number>;
    location?: { lat: number; lng: number; country: string };
    realTimeData?: Record<string, any>;
  };
}

interface GraphLink {
  source: string;
  target: string;
  value?: number;
  color?: string;
  width?: number;
  dataFlow?: number;
  connectionType?: 'data' | 'control' | 'threat' | 'financial';
}

const forceGraphData: { nodes: GraphNode[]; links: GraphLink[] } = { 
  nodes: [{ id: 'UMMAH', group: 0 }], 
  links: [] 
};

const exchanges = [
  'Binance', 'OKX', 'Bybit', 'Kraken', 'Bitfinex', 'Coinbase', 'Gemini', 'KuCoin', 'Bitstamp',
  'Poloniex', 'Huobi', 'Bittrex', 'Gate.io', 'Deribit', 'Upbit', 'Liquid', 'Coincheck', 'ZB.com',
  'BitFlyer', 'MEXC'
];

const JA3ClusterMap = {
  fingerprints: {} as Record<string, Set<string>>,
  addFingerprint: (exchange: string, fp: string) => {
    if (!JA3ClusterMap.fingerprints[exchange]) {
      JA3ClusterMap.fingerprints[exchange] = new Set();
    }
    JA3ClusterMap.fingerprints[exchange].add(fp);
  },
  report: () => {
    console.log('JA3 Cluster Map:', JA3ClusterMap.fingerprints);
  }
};

/**
 * Initialize sample data for the fusion visualizer graph
 * 
 * Creates sample nodes and links for the first 10 exchanges with random
 * alert status and JA3 fingerprints for demonstration purposes.
 */
const initializeSampleData = () => {
  exchanges.slice(0, 10).forEach((exchange) => {
    const hasAlert = Math.random() > 0.8; // 20% chance of alert
    forceGraphData.nodes.push({ 
      id: exchange, 
      group: 1, 
      alert: hasAlert 
    });
    forceGraphData.links.push({ source: 'UMMAH', target: exchange });
    
    JA3ClusterMap.addFingerprint(exchange, `fp_${exchange}_${Math.random().toString(36).substr(2, 9)}`);
  });
};

if (forceGraphData.nodes.length === 1) {
  initializeSampleData();
}

/**
 * FusionVisualizer - 3D network visualization component for exchange monitoring
 * 
 * Displays a 3D force-directed graph showing connections between UMMAH AI platform
 * and various cryptocurrency exchanges. Includes threat detection visualization,
 * JA3 fingerprint clustering, and real-time alert monitoring.
 * 
 * Features:
 * - 3D WebGL visualization with fallback to 2D grid
 * - Interactive node clicking for alert investigation
 * - Real-time threat filtering and monitoring
 * - JA3 fingerprint tracking and clustering
 * - WebGL compatibility detection
 * 
 * @returns {JSX.Element} - Rendered fusion visualizer component
 */
export const FusionVisualizer: React.FC = () => {
  const [use3D, setUse3D] = useState(true);
  const [graphData, setGraphData] = useState(forceGraphData);
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [viewMode, setViewMode] = useState<'network' | 'geographic' | 'threat' | 'topology'>('network');
  const [realTimeData, setRealTimeData] = useState<Record<string, any>>({});
  const [showMetrics, setShowMetrics] = useState(true);
  const fgRef = useRef<any>(null);

  /**
   * Handle node click events in the 3D graph
   * 
   * @param {any} node - The clicked node object containing id and alert status
   */
  const handleNodeClick = (node: any) => {
    console.log('Node clicked:', node);
    setSelectedNode(node);
    
    if (node.alert) {
      alert(`ALERT: ${node.id} flagged for anomaly.`);
    }
    
    setRealTimeData(prev => ({
      ...prev,
      [node.id]: {
        activity: Math.random(),
        latency: Math.random() * 100,
        throughput: Math.random() * 1000,
        lastUpdate: new Date().toISOString()
      }
    }));
  };

  /**
   * Render the fusion visualizer graph
   * 
   * Updates the graph data state to trigger a re-render of the visualization.
   */
  const render = () => {
    console.log('Rendering Trace Fusion Map canvas...');
    setGraphData({ ...forceGraphData });
  };

  /**
   * Enhanced node rendering with Three.js materials and real-time data
   */
  const nodeThreeObject = useMemo(() => {
    return (node: any) => {
      const geometry = new THREE.SphereGeometry(node.val || 5, 16, 16);
      const material = new THREE.MeshLambertMaterial({
        color: node.color || (node.alert ? '#ff4444' : '#4a90e2'),
        transparent: true,
        opacity: selectedNode?.id === node.id ? 1.0 : 0.8
      });
      
      const mesh = new THREE.Mesh(geometry, material);
      
      if (realTimeData[node.id]) {
        const activity = realTimeData[node.id].activity || 0;
        mesh.scale.setScalar(1 + activity * 0.5);
        
        if (activity > 0.7) {
          const pulseGeometry = new THREE.RingGeometry(8, 12, 16);
          const pulseMaterial = new THREE.MeshBasicMaterial({
            color: '#00ff88',
            transparent: true,
            opacity: 0.3
          });
          const pulseRing = new THREE.Mesh(pulseGeometry, pulseMaterial);
          mesh.add(pulseRing);
        }
      }
      
      return mesh;
    };
  }, [selectedNode, realTimeData]);



  /**
   * Real-time data simulation effect
   */
  useEffect(() => {
    const interval = setInterval(() => {
      if (showMetrics) {
        const updatedData: Record<string, any> = {};
        graphData.nodes.forEach((node: any) => {
          updatedData[node.id] = {
            activity: Math.random(),
            latency: 20 + Math.random() * 80,
            throughput: 100 + Math.random() * 900,
            lastUpdate: new Date().toISOString()
          };
        });
        setRealTimeData(updatedData);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [graphData.nodes, showMetrics]);

  useEffect(() => {
    const filterThreats = (type = 'anomaly') => {
      const filtered = graphData.nodes.filter(n => n.alert || n.group === 99);
      console.log(`Filtered Threats (${type}):`, filtered.map(n => n.id));
      return filtered;
    };
    (window as any).FusionVisualizer = { render };
    (window as any).filterThreats = filterThreats;
  }, [graphData]);



  /**
   * Check if WebGL is supported in the current browser
   * 
   * @returns {boolean} - True if WebGL is supported, false otherwise
   */
  const checkWebGLCompatibility = () => {
    try {
      const canvas = document.createElement('canvas');
      return !!(
        window.WebGLRenderingContext &&
        (canvas.getContext('webgl') || canvas.getContext('experimental-webgl'))
      );
    } catch (e) {
      return false;
    }
  };

  if (use3D && checkWebGLCompatibility()) {
    return (
      <div className="fusion-visualizer w-full h-64 bg-gray-800 rounded relative" id="fusion-graph-container">
        <ForceGraph3D
          ref={fgRef}
          graphData={graphData}
          nodeAutoColorBy="group"
          linkDirectionalArrowLength={4}
          linkDirectionalParticles={2}
          nodeLabel={(node: any) => {
            const data = realTimeData[node.id];
            return `${node.id}${node.alert ? ' ⚠️ WARNING' : ''}
${data ? `Latency: ${data.latency?.toFixed(1)}ms
Throughput: ${data.throughput?.toFixed(0)} ops/s
Activity: ${(data.activity * 100)?.toFixed(1)}%` : ''}`;
          }}
          onNodeClick={handleNodeClick}
          backgroundColor="rgba(0,0,0,0)"
          width={500}
          height={250}
          nodeColor={(node: any) => {
            if (selectedNode?.id === node.id) return '#00ff88';
            if (node.alert) return '#ff4444';
            const activity = realTimeData[node.id]?.activity || 0;
            return activity > 0.7 ? '#ffaa00' : '#4a90e2';
          }}
          linkColor={(link: any) => {
            const sourceActivity = realTimeData[link.source]?.activity || 0;
            const targetActivity = realTimeData[link.target]?.activity || 0;
            const avgActivity = (sourceActivity + targetActivity) / 2;
            return avgActivity > 0.5 ? 'rgba(0,255,136,0.6)' : 'rgba(255,255,255,0.2)';
          }}
          nodeRelSize={6}
          linkWidth={(link: any) => {
            const sourceActivity = realTimeData[link.source]?.activity || 0;
            const targetActivity = realTimeData[link.target]?.activity || 0;
            const avgActivity = (sourceActivity + targetActivity) / 2;
            return 2 + avgActivity * 4;
          }}
          nodeThreeObject={nodeThreeObject}

          enableNodeDrag={true}
          enableNavigationControls={true}
          showNavInfo={false}
        />
        
        {/* Control Panel */}
        <div className="absolute top-2 left-2 bg-gray-800 p-2 rounded text-white text-xs">
          <div className="grid grid-cols-3 gap-2 mb-2">
            <div className="bg-blue-600 p-1 rounded text-center">Nodes: {graphData.nodes.length}</div>
            <div className="bg-green-600 p-1 rounded text-center">Links: {graphData.links.length}</div>
            <div className="bg-purple-600 p-1 rounded text-center">Active: {graphData.nodes.filter((n: any) => n.alert).length}</div>
          </div>
          
          {/* View Mode Controls */}
          <div className="flex gap-1 mb-2">
            {(['network', 'geographic', 'threat', 'topology'] as const).map(mode => (
              <button
                key={mode}
                  onClick={() => setViewMode(mode)}
                className={`px-2 py-1 rounded text-xs ${
                  viewMode === mode ? 'bg-cyan-600' : 'bg-gray-600 hover:bg-gray-500'
                }`}
              >
                {mode.charAt(0).toUpperCase() + mode.slice(1)}
              </button>
            ))}
          </div>
          
          {/* Metrics Toggle */}
            <button onClick={() => setShowMetrics(!showMetrics)}
            className={`px-2 py-1 rounded text-xs ${
              showMetrics ? 'bg-green-600' : 'bg-gray-600 hover:bg-gray-500'
            }`}
          >
            {showMetrics ? '📊 Metrics ON' : '📊 Metrics OFF'}
          </button>
        </div>
        
        {/* Selected Node Info */}
        {selectedNode && (
          <div className="absolute bottom-2 left-2 bg-gray-800 p-3 rounded text-white text-xs max-w-xs">
            <h4 className="font-bold text-cyan-400 mb-1">{selectedNode.id}</h4>
            {selectedNode.metadata && (
              <>
                <p className="mb-1">{selectedNode.metadata.description}</p>
                {selectedNode.metadata.location && (
                  <p className="text-gray-300">📍 {selectedNode.metadata.location.country}</p>
                )}
              </>
            )}
            {realTimeData[selectedNode.id] && (
              <div className="mt-2 grid grid-cols-2 gap-1 text-xs">
                <div>Latency: {realTimeData[selectedNode.id].latency?.toFixed(1)}ms</div>
                <div>Activity: {(realTimeData[selectedNode.id].activity * 100)?.toFixed(1)}%</div>
              </div>
            )}
          </div>
        )}
        
        <div className="absolute top-2 right-2 bg-green-800 p-2 rounded text-white text-xs">
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span>3D Enhanced</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="fusion-visualizer w-full h-64 bg-gray-800 rounded flex flex-col justify-center relative"
      id="fusion-graph-container"
    >
      <div className="bg-gray-700 p-4 rounded text-center text-white h-full flex flex-col justify-center">
        <h3 className="text-lg font-bold mb-4">3D Fusion Map</h3>
        <div className="grid grid-cols-3 gap-2 mb-4">
          <div className="bg-blue-600 p-2 rounded text-xs">Nodes: {graphData.nodes.length}</div>
          <div className="bg-green-600 p-2 rounded text-xs">Links: {graphData.links.length}</div>
          <div className="bg-purple-600 p-2 rounded text-xs">Active: {graphData.nodes.filter((n: any) => n.alert).length}</div>
        </div>
        <div className="grid grid-cols-5 gap-2">
          {exchanges.slice(0, 10).map(ex => {
            const node = graphData.nodes.find((n: any) => n.id === ex);
            const hasAlert = node?.alert;
            return (
              <div 
                key={ex}
                className={`bg-gray-600 p-2 rounded text-xs cursor-pointer hover:bg-gray-500 ${hasAlert ? 'border-2 border-red-500' : ''}`}
                onClick={() => {
                  if (hasAlert) {
                    alert(`ALERT: ${ex} flagged for anomaly.`);
                  } else {
                    console.log(`Node clicked: ${ex}`);
                  }
                }}
              >
                {ex}{hasAlert ? ' WARNING' : ''}
              </div>
            );
          })}
        </div>
        <div className="mt-4 text-xs text-gray-300">
          WebGL not supported - Interactive node grid active
        </div>
          <button onClick={() => setUse3D(true)}
          className="mt-2 bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded text-xs transition-colors"
        >
          Retry 3D Mode
        </button>
      </div>
      
      <div className="absolute top-2 right-2 bg-yellow-800 p-2 rounded text-white text-xs">
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
          <span>Fallback Mode</span>
        </div>
      </div>
    </div>
  );
};

export default FusionVisualizer;
