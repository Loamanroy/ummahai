import React, { useEffect } from 'react';

interface QuantumSignal {
  exchange: string;
  latency: number;
  impact: number;
  timestamp: number;
  type: string;
}

interface QuantumSignalEmulatorProps {
  onSignal: (signal: QuantumSignal) => void;
}

const QuantumSignalEmulator: React.FC<QuantumSignalEmulatorProps> = ({ onSignal }) => {
  useEffect(() => {
    const interval = setInterval(() => {
      const signal: QuantumSignal = {
        exchange: ['Binance', 'OKX', 'Kraken'][Math.floor(Math.random() * 3)],
        latency: Math.random() * 2000,
        impact: Math.random() * 10,
        timestamp: Date.now(),
        type: 'quantum-anomaly'
      };
      onSignal(signal);
    }, 3000);
    
    return () => clearInterval(interval);
  }, [onSignal]);

  return null;
};

export default QuantumSignalEmulator;
