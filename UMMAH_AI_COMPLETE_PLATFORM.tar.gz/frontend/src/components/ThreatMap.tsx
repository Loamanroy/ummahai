import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

L.Icon.Default.mergeOptions({
  iconRetinaUrl: '/marker-icon-2x.png',
  iconUrl: '/marker-icon.png',
  shadowUrl: '/marker-shadow.png',
});

interface ThreatData {
  id: number;
  location: string;
  type: string;
  severity: 'high' | 'medium' | 'low';
  lat: number;
  lng: number;
  exchange?: string;
  timestamp?: string;
  details?: string;
  impact_score?: number;
}

const ThreatMap = () => {
  const [threats, setThreats] = useState<ThreatData[]>([]);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected'>('connecting');
  const [errorMessage, setErrorMessage] = useState<string>('');

  const fetchThreatData = async () => {
    try {
      const baseUrl = import.meta.env.VITE_BACKEND_URL || window.location.origin;
      const response = await fetch(`${baseUrl}/api/v1/realtime/geo-threats`, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        credentials: 'omit'
      });
      if (response.ok) {
        const threatData = await response.json();
        const processedThreats = threatData.data.map((threat: any, index: number) => {
          const dynamicSeverity = Math.random() > 0.6 ? 'high' : Math.random() > 0.3 ? 'medium' : 'low';
          const impactScore = Math.random() * 10;
          return {
            id: index + 1,
            location: getLocationName(threat.location[0], threat.location[1]),
            type: getThreatType(dynamicSeverity),
            severity: dynamicSeverity,
            lat: threat.location[0],
            lng: threat.location[1],
            exchange: threat.exchange,
            timestamp: new Date().toISOString(),
            details: generateThreatDetails(dynamicSeverity),
            impact_score: impactScore
          };
        });
        setThreats(processedThreats);
        setConnectionStatus('connected');
        setErrorMessage('');
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Failed to fetch threat data:', error);
      setConnectionStatus('disconnected');
      setErrorMessage(error instanceof Error ? error.message : 'Unknown error');
      
      const fallbackThreats: ThreatData[] = [
        { id: 1, location: 'New York', type: 'JA3 Anomaly Detection', severity: 'high', lat: 40.7128, lng: -74.0060, exchange: 'Binance', details: 'Suspicious TLS fingerprint patterns detected', impact_score: 8.5 },
        { id: 2, location: 'London', type: 'Order Pattern Analysis', severity: 'medium', lat: 51.5074, lng: -0.1278, exchange: 'Kraken', details: 'Unusual trading volume spikes identified', impact_score: 6.2 },
        { id: 3, location: 'Tokyo', type: 'Latency Spike Alert', severity: 'low', lat: 35.6762, lng: 139.6503, exchange: 'Bitfinex', details: 'Network latency above threshold', impact_score: 3.1 },
        { id: 4, location: 'Singapore', type: 'Volume Manipulation', severity: 'high', lat: 1.3521, lng: 103.8198, exchange: 'OKX', details: 'Coordinated trading activity detected', impact_score: 9.1 }
      ];
      setThreats(fallbackThreats);
    }
  };

  const getLocationName = (lat: number, lng: number): string => {
    const locations = [
      { name: 'New York', lat: 40.7128, lng: -74.0060 },
      { name: 'London', lat: 51.5074, lng: -0.1278 },
      { name: 'Tokyo', lat: 35.6762, lng: 139.6503 },
      { name: 'Singapore', lat: 1.3521, lng: 103.8198 },
      { name: 'Frankfurt', lat: 50.1109, lng: 8.6821 }
    ];
    
    const closest = locations.reduce((prev, curr) => {
      const prevDist = Math.abs(prev.lat - lat) + Math.abs(prev.lng - lng);
      const currDist = Math.abs(curr.lat - lat) + Math.abs(curr.lng - lng);
      return currDist < prevDist ? curr : prev;
    });
    
    return closest.name;
  };

  const getThreatType = (severity: string): string => {
    const types = {
      high: ['JA3 Anomaly Detection', 'Volume Manipulation', 'Coordinated Attack Pattern', 'TLS Fingerprint Spoofing'],
      medium: ['Order Pattern Analysis', 'Unusual Trading Volume', 'Latency Anomaly', 'API Rate Limiting'],
      low: ['Latency Spike Alert', 'Minor Volume Fluctuation', 'Connection Timeout', 'Network Congestion']
    };
    const typeArray = types[severity as keyof typeof types];
    return typeArray[Math.floor(Math.random() * typeArray.length)];
  };

  const generateThreatDetails = (severity: string): string => {
    const details = {
      high: [
        'Suspicious TLS fingerprint patterns detected',
        'Coordinated trading activity identified',
        'Advanced persistent threat indicators',
        'Zero-day exploit attempt blocked'
      ],
      medium: [
        'Unusual trading volume spikes identified',
        'API request pattern anomalies',
        'Potential bot activity detected',
        'Network traffic irregularities'
      ],
      low: [
        'Network latency above threshold',
        'Minor connection instabilities',
        'Routine security scan detected',
        'Standard traffic fluctuations'
      ]
    };
    const detailArray = details[severity as keyof typeof details];
    return detailArray[Math.floor(Math.random() * detailArray.length)];
  };

  useEffect(() => {
    fetchThreatData();
    
    const interval = setInterval(() => {
      fetchThreatData();
      setLastUpdate(new Date());
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'bg-red-500 border-red-400';
      case 'medium': return 'bg-yellow-500 border-yellow-400';
      case 'low': return 'bg-green-500 border-green-400';
      default: return 'bg-gray-500 border-gray-400';
    }
  };

  const getConnectionStatusColor = () => {
    switch (connectionStatus) {
      case 'connected': return 'text-green-400';
      case 'connecting': return 'text-yellow-400';
      case 'disconnected': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const handleThreatDetails = (threat: ThreatData) => {
    const details = `
Threat Details:
Location: ${threat.location}
Type: ${threat.type}
Exchange: ${threat.exchange}
Severity: ${threat.severity.toUpperCase()}
Impact Score: ${threat.impact_score?.toFixed(2)}
Details: ${threat.details}
Timestamp: ${new Date(threat.timestamp || '').toLocaleString()}
Coordinates: ${threat.lat.toFixed(4)}, ${threat.lng.toFixed(4)}
    `;
    alert(details);
  };

  return (
    <Card className="bg-gray-900 border border-gray-700 text-white">
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h3 className="font-bold text-lg">Global Threat Map</h3>
            <div className="flex items-center gap-2 text-xs mt-1">
              <span className={`${getConnectionStatusColor()}`}>
                {connectionStatus === 'connected' && '● LIVE'}
                {connectionStatus === 'connecting' && '◐ CONNECTING'}
                {connectionStatus === 'disconnected' && '● OFFLINE'}
              </span>
              <span className="text-gray-400">
                Last Update: {lastUpdate.toLocaleTimeString()}
              </span>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm font-semibold">
              {threats.filter(t => t.severity === 'high').length} Critical Threats
            </div>
            <div className="text-xs text-gray-400">
              {threats.length} Total Active
            </div>
          </div>
        </div>

        {errorMessage && (
          <div className="bg-red-900 border border-red-600 p-2 rounded mb-4 text-sm">
            Connection Error: {errorMessage}
          </div>
        )}
        
        <div className="bg-gray-800 h-96 rounded mb-4 border border-cyan-500/30 overflow-hidden">
          <MapContainer 
            center={[20, 0]} 
            zoom={2} 
            style={{ height: '100%', width: '100%' }}
          >
            <TileLayer
              url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
            />
            {threats.map(threat => (
              <Marker 
                key={threat.id} 
                position={[threat.lat, threat.lng]}
              >
                <Popup>
                  <div className="p-2 bg-gray-900 text-white rounded">
                    <div className="flex items-center gap-2 mb-2">
                      <div className={`w-3 h-3 rounded-full ${getSeverityColor(threat.severity).replace('border-', 'bg-')}`}></div>
                      <h3 className="font-bold text-sm">{threat.type}</h3>
                    </div>
                    <div className="space-y-1 text-xs">
                      <div><strong>Location:</strong> {threat.location}</div>
                      <div><strong>Exchange:</strong> {threat.exchange}</div>
                      <div><strong>Severity:</strong> <span className="capitalize font-semibold">{threat.severity}</span></div>
                      <div><strong>Impact Score:</strong> {threat.impact_score?.toFixed(2)}</div>
                      <div><strong>Details:</strong> {threat.details}</div>
                      <div><strong>Coordinates:</strong> {threat.lat.toFixed(4)}, {threat.lng.toFixed(4)}</div>
                      <div><strong>Timestamp:</strong> {new Date(threat.timestamp || '').toLocaleString()}</div>
                    </div>
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </div>

        <div className="space-y-2">
          <h4 className="font-semibold glow-text">Active Threats:</h4>
          {threats.map(threat => (
            <div key={threat.id} className="flex items-center justify-between bg-gray-800 p-3 rounded border border-gray-600 hover:border-cyan-500/50 transition-all cursor-pointer"
                 onClick={() => handleThreatDetails(threat)}>
              <div className="flex items-center gap-3">
                <div className={`w-4 h-4 rounded-full border-2 ${getSeverityColor(threat.severity)} animate-pulse`}></div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold">{threat.location}</span>
                    <span className="text-xs text-cyan-400">{threat.exchange}</span>
                  </div>
                  <div className="text-xs text-gray-400">{threat.type}</div>
                  {threat.details && (
                    <div className="text-xs text-gray-500 mt-1">{threat.details}</div>
                  )}
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs capitalize font-bold">{threat.severity}</span>
                {threat.impact_score && (
                  <div className="text-xs text-gray-400">
                    Impact: {threat.impact_score.toFixed(1)}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 grid grid-cols-3 gap-2 text-xs text-center">
          <div className="bg-red-900 p-3 rounded border border-red-600">
            <div className="font-semibold text-red-400">High</div>
            <div className="text-lg font-bold">{threats.filter(t => t.severity === 'high').length}</div>
            <div className="text-xs text-gray-400">Critical</div>
          </div>
          <div className="bg-yellow-900 p-3 rounded border border-yellow-600">
            <div className="font-semibold text-yellow-400">Medium</div>
            <div className="text-lg font-bold">{threats.filter(t => t.severity === 'medium').length}</div>
            <div className="text-xs text-gray-400">Warning</div>
          </div>
          <div className="bg-green-900 p-3 rounded border border-green-600">
            <div className="font-semibold text-green-400">Low</div>
            <div className="text-lg font-bold">{threats.filter(t => t.severity === 'low').length}</div>
            <div className="text-xs text-gray-400">Info</div>
          </div>
        </div>

        <div className="mt-4 bg-gray-800 p-3 rounded border border-gray-600">
          <h4 className="font-semibold mb-2 text-cyan-400">Threat Intelligence Summary</h4>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>Active Exchanges: {new Set(threats.map(t => t.exchange)).size}</div>
            <div>Geographic Regions: {new Set(threats.map(t => t.location)).size}</div>
            <div>Avg Impact Score: {(threats.reduce((sum, t) => sum + (t.impact_score || 0), 0) / threats.length).toFixed(2)}</div>
            <div>Last Scan: {Math.floor(Math.random() * 30)} seconds ago</div>
          </div>
          <div className="mt-2 text-xs text-gray-400">
            Interactive map shows real-time threat locations. Click markers for detailed information.
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ThreatMap;
