import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface ThreatData {
  exchange: string;
  q: number;
  anomaly?: boolean;
  eventTime?: number;
  fingerprint?: string;
}

const AlertSystem = {
  processThreat: (data: ThreatData) => {
    if (data.q > 1.5 || data.anomaly) {
      const message = `Threat detected at ${data.exchange}: ${data.q} BTC @ ${new Date().toISOString()}`;
      
      const baseUrl = import.meta.env.VITE_BACKEND_URL || 'http://localhost:8000';
      const cleanUrl = baseUrl;
      
      fetch(`${cleanUrl}/api/v1/realtime/alert`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({ type: 'email', message }),
        credentials: 'omit'
      }).catch(err => console.log('Email alert failed:', err));
      
      fetch(`${cleanUrl}/api/v1/realtime/alert`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({ type: 'sms', message }),
        credentials: 'omit'
      }).catch(err => console.log('SMS alert failed:', err));
      
      console.log('THREAT ALERT:', message);
      return message;
    }
    return null;
  }
};

const AlertSystemPanel = () => {
  const [alerts, setAlerts] = useState<string[]>([]);
  const [alertCount, setAlertCount] = useState(0);

  const simulateThreat = () => {
    const mockThreat: ThreatData = {
      exchange: 'Binance',
      q: Math.random() * 3,
      anomaly: Math.random() > 0.7,
      eventTime: Date.now()
    };

    const alert = AlertSystem.processThreat(mockThreat);
    if (alert) {
      setAlerts(prev => [alert, ...prev.slice(0, 9)]);
      setAlertCount(prev => prev + 1);
    }
  };

  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.8) {
        simulateThreat();
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <Card className="bg-red-900 border border-red-700 text-white">
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Threat Alert System</h2>
          <div className="flex gap-2">
            <span className="bg-red-600 px-2 py-1 rounded text-sm">
              {alertCount} Alerts
            </span>
            <Button 
              onClick={simulateThreat}
              className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 text-sm"
            >
              Test Alert
            </Button>
          </div>
        </div>
        
        <div className="space-y-2 max-h-40 overflow-y-auto">
          {alerts.length === 0 ? (
            <p className="text-red-300 text-sm">No active threats detected</p>
          ) : (
            alerts.map((alert, index) => (
              <div key={index} className="bg-red-800 p-2 rounded text-xs font-mono">
                {alert}
              </div>
            ))
          )}
        </div>

        <div className="mt-4 grid grid-cols-3 gap-2 text-xs">
          <div className="bg-red-800 p-2 rounded text-center">
            <div className="font-semibold">Email</div>
            <div className="text-red-300">Active</div>
          </div>
          <div className="bg-red-800 p-2 rounded text-center">
            <div className="font-semibold">SMS</div>
            <div className="text-red-300">Active</div>
          </div>
          <div className="bg-red-800 p-2 rounded text-center">
            <div className="font-semibold">MQTT</div>
            <div className="text-red-300">Connected</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AlertSystemPanel;
export { AlertSystem };
