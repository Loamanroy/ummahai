import { Html } from '@react-three/drei';

interface TradingSignal {
  id: string;
  exchange: string;
  pair: string;
  action: 'buy' | 'sell';
  price: number;
  confidence: number;
  timestamp: Date;
  profit?: number;
}

interface AnalyticsXRPanelProps {
  position: [number, number, number];
  signals: TradingSignal[];
  earnings: number;
  exchange: string;
  isMobile?: boolean;
  isTablet?: boolean;
}

export default function AnalyticsXRPanel({ 
  position, 
  signals, 
  earnings, 
  exchange,
  isMobile = false,
  isTablet = false
}: AnalyticsXRPanelProps) {
  const recentSignals = signals.slice(-10);
  const buySignals = recentSignals.filter(s => s.action === 'buy').length;
  const sellSignals = recentSignals.filter(s => s.action === 'sell').length;
  const avgConfidence = recentSignals.length > 0 
    ? recentSignals.reduce((sum, s) => sum + s.confidence, 0) / recentSignals.length 
    : 0;
  const winRate = recentSignals.length > 0 
    ? (recentSignals.filter(s => (s.profit || 0) > 0).length / recentSignals.length) * 100 
    : 0;

  return (
    <Html position={position} transform occlude>
      <div className={`bg-gradient-to-br from-gray-900/95 to-black/95 rounded-xl border border-cyan-400 text-white backdrop-blur-sm ${
        isMobile ? 'p-3 w-72' : isTablet ? 'p-4 w-80' : 'p-6 w-96'
      }`}>
        <div className="flex items-center justify-between mb-4">
          <h3 className={`font-bold text-cyan-400 ${isMobile ? 'text-sm' : isTablet ? 'text-base' : 'text-lg'}`}>
            📊 {isMobile ? 'Analytics' : 'Analytics Panel'}
          </h3>
          <div className="text-xs text-gray-400">{exchange.toUpperCase()}</div>
        </div>
        
        <div className={`grid grid-cols-2 mb-4 ${isMobile ? 'gap-2' : 'gap-4'}`}>
          <div className={`bg-black/50 rounded-lg ${isMobile ? 'p-2' : 'p-3'}`}>
            <div className="text-xs text-gray-400 mb-1">
              {isMobile ? 'Earnings' : 'Total Earnings'}
            </div>
            <div className={`font-bold ${earnings >= 0 ? 'text-green-400' : 'text-red-400'} ${
              isMobile ? 'text-sm' : 'text-lg'
            }`}>
              ${isMobile ? earnings.toFixed(0) : earnings.toFixed(2)}
            </div>
          </div>
          
          <div className={`bg-black/50 rounded-lg ${isMobile ? 'p-2' : 'p-3'}`}>
            <div className="text-xs text-gray-400 mb-1">Win Rate</div>
            <div className={`font-bold text-cyan-400 ${isMobile ? 'text-sm' : 'text-lg'}`}>
              {winRate.toFixed(1)}%
            </div>
          </div>
          
          <div className={`bg-black/50 rounded-lg ${isMobile ? 'p-2' : 'p-3'}`}>
            <div className="text-xs text-gray-400 mb-1">
              {isMobile ? 'Confidence' : 'Avg Confidence'}
            </div>
            <div className={`font-bold text-yellow-400 ${isMobile ? 'text-sm' : 'text-lg'}`}>
              {(avgConfidence * 100).toFixed(1)}%
            </div>
          </div>
          
          <div className={`bg-black/50 rounded-lg ${isMobile ? 'p-2' : 'p-3'}`}>
            <div className="text-xs text-gray-400 mb-1">
              {isMobile ? 'Signals' : 'Active Signals'}
            </div>
            <div className={`font-bold text-purple-400 ${isMobile ? 'text-sm' : 'text-lg'}`}>
              {recentSignals.length}
            </div>
          </div>
        </div>

        <div className="mb-4">
          <div className="text-sm text-gray-400 mb-2">Signal Distribution</div>
          <div className="flex space-x-2">
            <div className="flex-1 bg-green-600/30 rounded-full h-2 relative">
              <div 
                className="bg-green-400 h-full rounded-full transition-all duration-300"
                style={{ width: `${recentSignals.length > 0 ? (buySignals / recentSignals.length) * 100 : 0}%` }}
              ></div>
            </div>
            <div className="flex-1 bg-red-600/30 rounded-full h-2 relative">
              <div 
                className="bg-red-400 h-full rounded-full transition-all duration-300"
                style={{ width: `${recentSignals.length > 0 ? (sellSignals / recentSignals.length) * 100 : 0}%` }}
              ></div>
            </div>
          </div>
          <div className="flex justify-between text-xs text-gray-400 mt-1">
            <span>🟢 Buy: {buySignals}</span>
            <span>🔴 Sell: {sellSignals}</span>
          </div>
        </div>

        <div className="space-y-2">
          <div className={`text-gray-400 mb-2 ${isMobile ? 'text-xs' : 'text-sm'}`}>
            Recent Signals
          </div>
          <div className={`overflow-y-auto space-y-1 ${isMobile ? 'max-h-24' : 'max-h-32'}`}>
            {recentSignals.slice(isMobile ? -3 : -5).map((signal) => (
              <div key={signal.id} className={`flex items-center justify-between text-xs bg-black/30 rounded ${
                isMobile ? 'p-1.5' : 'p-2'
              }`}>
                <div className="flex items-center space-x-2">
                  <div className={`rounded-full ${signal.action === 'buy' ? 'bg-green-400' : 'bg-red-400'} ${
                    isMobile ? 'w-1.5 h-1.5' : 'w-2 h-2'
                  }`}></div>
                  <span className="text-gray-300">
                    {isMobile && signal.pair.length > 8 ? signal.pair.substring(0, 8) : signal.pair}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-gray-400">
                    ${isMobile ? signal.price.toFixed(2) : signal.price.toFixed(4)}
                  </span>
                  <span className={`font-bold ${(signal.profit || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {signal.profit ? `${signal.profit > 0 ? '+' : ''}${signal.profit.toFixed(isMobile ? 0 : 2)}` : '—'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-gray-700">
          <div className="flex items-center justify-between text-xs">
            <span className="text-gray-400">Last Update</span>
            <span className="text-cyan-400">{new Date().toLocaleTimeString()}</span>
          </div>
        </div>
      </div>
    </Html>
  );
}
