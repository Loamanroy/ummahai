import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { FileText, CheckCircle, DollarSign, Users, Shield } from 'lucide-react';

/**
 * Props for the Step5ContractSigning component
 */
interface Step5Props {
  /** Callback function when user proceeds to next step */
  onNext: (data: any) => void;
  /** Callback function when user goes back to previous step */
  onBack: () => void;
  /** Current form data from previous steps */
  formData: any;
  /** Function to update form data */
  setFormData: (data: any) => void;
}

/**
 * Contract option configuration interface
 */
interface ContractOption {
  /** Unique identifier for the contract type */
  id: string;
  /** Display name of the contract */
  name: string;
  /** Arabic name of the contract */
  arabicName: string;
  /** Detailed description of the contract */
  description: string;
  /** Profit sharing arrangement */
  profitShare: string;
  /** Risk level assessment */
  riskLevel: 'Low' | 'Medium' | 'High';
  /** Minimum investment amount */
  minInvestment: string;
  /** List of contract features */
  features: string[];
  /** Icon component for the contract */
  icon: React.ReactNode;
  /** CSS gradient color for styling */
  color: string;
  /** Whether this contract is recommended */
  recommended?: boolean;
}

/**
 * Step5ContractSigning - Contract selection and digital signing component
 * 
 * This component handles the fifth step of the registration process where users
 * select their preferred investment partnership model (Mudarabah, Musharakah, or Wakalah)
 * and digitally sign the contract. It provides detailed contract information,
 * terms agreement, and digital signature functionality.
 * 
 * @param props - Component props
 * @param props.onNext - Callback when user proceeds to next step
 * @param props.onBack - Callback when user goes back to previous step
 * @param props.formData - Current form data from previous steps
 * @param props.setFormData - Function to update form data
 * @returns JSX.Element - Rendered contract signing step component
 */
const Step5ContractSigning = ({ onNext, onBack, formData, setFormData }: Step5Props) => {
  const [selectedContract, setSelectedContract] = useState<string>('');
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [digitalSignature, setDigitalSignature] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const contractOptions: ContractOption[] = [
    {
      id: 'mudarabah',
      name: 'Mudarabah Partnership',
      arabicName: 'شراكة المضاربة',
      description: 'Profit-sharing partnership where we manage your investment with our AI trading expertise',
      profitShare: '70% Investor / 30% Platform',
      riskLevel: 'Medium',
      minInvestment: '$10,000 USD',
      features: [
        'AI-managed trading portfolio',
        'Quarterly profit distribution',
        'Full transparency reports',
        'Sharia-compliant investments',
        'Risk management protocols',
        'Priority customer support'
      ],
      icon: <DollarSign className="w-8 h-8" />,
      color: 'from-green-600 to-emerald-600',
      recommended: true
    },
    {
      id: 'musharakah',
      name: 'Musharakah Joint Venture',
      arabicName: 'شراكة المشاركة',
      description: 'Equal partnership where both parties contribute capital and share profits and losses',
      profitShare: '60% Investor / 40% Platform',
      riskLevel: 'High',
      minInvestment: '$50,000 USD',
      features: [
        'Joint decision making',
        'Higher profit potential',
        'Shared risk and reward',
        'Advanced AI strategies',
        'Monthly performance reviews',
        'Direct communication channel'
      ],
      icon: <Users className="w-8 h-8" />,
      color: 'from-blue-600 to-indigo-600'
    },
    {
      id: 'wakalah',
      name: 'Wakalah Agency',
      arabicName: 'وكالة الوكالة',
      description: 'Agency contract where we act as your investment agent with fixed fees',
      profitShare: '85% Investor / 15% Platform',
      riskLevel: 'Low',
      minInvestment: '$5,000 USD',
      features: [
        'Fixed management fees',
        'Conservative strategies',
        'Capital preservation focus',
        'Regular reporting',
        'Flexible withdrawal terms',
        'Beginner-friendly approach'
      ],
      icon: <Shield className="w-8 h-8" />,
      color: 'from-purple-600 to-violet-600'
    }
  ];

  /**
   * Handles contract selection and updates form data
   * @param contractId - The ID of the selected contract type
   */
  const handleContractSelection = (contractId: string) => {
    setSelectedContract(contractId);
    const selectedOption = contractOptions.find(opt => opt.id === contractId);
    
    setFormData({
      ...formData,
      contract: {
        type: contractId,
        details: selectedOption,
        timestamp: new Date().toISOString()
      }
    });
  };

  const handleSignContract = async () => {
    if (!selectedContract || !agreedToTerms || !digitalSignature.trim()) {
      return;
    }

    setIsProcessing(true);
    
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const contractData = {
      ...formData,
      contract: {
        ...formData.contract,
        signed: true,
        signature: digitalSignature,
        signedAt: new Date().toISOString(),
        contractId: `UMMAH-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`
      }
    };
    
    setFormData(contractData);
    setIsProcessing(false);
    onNext(contractData);
  };

  const selectedOption = contractOptions.find(opt => opt.id === selectedContract);

  return (
    <Card className="card-enhanced pulse-border max-w-6xl mx-auto">
      <CardContent className="p-8">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <FileText className="w-8 h-8 text-blue-400" />
            <h2 className="text-2xl font-bold glow-text">Step 5: Contract Signing</h2>
          </div>
          <p className="text-gray-400 glow-text">Choose your investment partnership model and sign the digital contract</p>
        </div>

        {/* Contract Options */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-6 glow-text">Select Investment Partnership Model</h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {contractOptions.map((option) => (
              <div
                key={option.id}
                className={`p-6 rounded-lg border-2 cursor-pointer transition-all duration-300 relative ${
                  selectedContract === option.id ? 'border-green-400 bg-green-900/20' : 'border-gray-600 bg-gray-800 hover:border-gray-500'
                }`}
                onClick={() => handleContractSelection(option.id)}
              >
                {option.recommended && (
                  <div className="absolute -top-2 -right-2 bg-yellow-500 text-black text-xs font-bold px-2 py-1 rounded-full">
                    RECOMMENDED
                  </div>
                )}
                
                <div className="text-center mb-4">
                  <div className={`w-16 h-16 rounded-full bg-gradient-to-r ${option.color} flex items-center justify-center mx-auto mb-3`}>
                    {option.icon}
                  </div>
                  <h4 className="text-lg font-semibold glow-text">{option.name}</h4>
                  <p className="text-sm text-gray-400 mb-2">{option.arabicName}</p>
                  <p className="text-xs text-gray-300">{option.description}</p>
                </div>
                
                <div className="space-y-3 mb-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-400">Profit Share:</span>
                    <span className="text-sm font-semibold text-green-400">{option.profitShare}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-400">Risk Level:</span>
                    <span className={`text-sm font-semibold ${
                      option.riskLevel === 'Low' ? 'text-green-400' :
                      option.riskLevel === 'Medium' ? 'text-yellow-400' : 'text-red-400'
                    }`}>
                      {option.riskLevel}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-400">Min Investment:</span>
                    <span className="text-sm font-semibold text-blue-400">{option.minInvestment}</span>
                  </div>
                </div>
                
                <ul className="text-xs space-y-1">
                  {option.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-2">
                      <span className="text-green-400">•</span>
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Contract Details & Signing */}
        {selectedContract && (
          <div className="bg-gray-800 p-6 rounded-lg border border-gray-600 mb-8">
            <h3 className="text-xl font-semibold mb-4 glow-text">Contract Details: {selectedOption?.name}</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="space-y-4">
                <div className="bg-gray-700 p-4 rounded-lg">
                  <h4 className="font-semibold text-green-400 mb-2">Profit Distribution</h4>
                  <p className="text-sm text-gray-300">{selectedOption?.profitShare}</p>
                  <p className="text-xs text-gray-400 mt-1">Profits distributed monthly via your offshore accounts</p>
                </div>
                
                <div className="bg-gray-700 p-4 rounded-lg">
                  <h4 className="font-semibold text-blue-400 mb-2">Investment Terms</h4>
                  <p className="text-sm text-gray-300">Minimum: {selectedOption?.minInvestment}</p>
                  <p className="text-xs text-gray-400 mt-1">Risk Level: {selectedOption?.riskLevel}</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="bg-gray-700 p-4 rounded-lg">
                  <h4 className="font-semibold text-purple-400 mb-2">Contract Duration</h4>
                  <p className="text-sm text-gray-300">12 months initial term</p>
                  <p className="text-xs text-gray-400 mt-1">Auto-renewable with 30-day notice</p>
                </div>
                
                <div className="bg-gray-700 p-4 rounded-lg">
                  <h4 className="font-semibold text-yellow-400 mb-2">Withdrawal Terms</h4>
                  <p className="text-sm text-gray-300">30-day notice required</p>
                  <p className="text-xs text-gray-400 mt-1">Emergency withdrawal: 5% penalty</p>
                </div>
              </div>
            </div>
            
            {/* Terms Agreement */}
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <input
                  type="checkbox"
                  id="terms"
                  checked={agreedToTerms}
                  onChange={(e) => setAgreedToTerms(e.target.checked)}
                  className="mt-1 w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded focus:ring-blue-500"
                />
                <label htmlFor="terms" className="text-sm text-gray-300">
                  I have read and agree to the terms and conditions of this {selectedOption?.name} contract. 
                  I understand the profit-sharing arrangement, risk levels, and withdrawal terms. 
                  I confirm that this investment is made with funds I can afford to risk.
                </label>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium glow-text">Digital Signature</label>
                <input
                  type="text"
                  value={digitalSignature}
                  onChange={(e) => setDigitalSignature(e.target.value)}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-400 focus:outline-none transition-colors"
                  placeholder="Type your full legal name as digital signature"
                />
                <p className="text-xs text-gray-400">
                  By typing your name, you are providing a legally binding digital signature
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Contract Summary */}
        {selectedContract && agreedToTerms && digitalSignature && (
          <div className="bg-green-900/20 border border-green-400 p-6 rounded-lg mb-8">
            <div className="flex items-center gap-3 mb-4">
              <CheckCircle className="w-6 h-6 text-green-400" />
              <h3 className="text-lg font-semibold text-green-400">Ready to Sign Contract</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <p><strong>Contract Type:</strong> {selectedOption?.name}</p>
                <p><strong>Profit Share:</strong> {selectedOption?.profitShare}</p>
                <p><strong>Risk Level:</strong> {selectedOption?.riskLevel}</p>
              </div>
              <div>
                <p><strong>Minimum Investment:</strong> {selectedOption?.minInvestment}</p>
                <p><strong>Digital Signature:</strong> {digitalSignature}</p>
                <p><strong>Date:</strong> {new Date().toLocaleDateString()}</p>
              </div>
            </div>
          </div>
        )}

        <div className="flex justify-between pt-6">
          <Button
            onClick={onBack}
            className="px-6 py-3 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors"
          >
            ← Back to Wallet Setup
          </Button>
          
          <Button
            onClick={handleSignContract}
            disabled={!selectedContract || !agreedToTerms || !digitalSignature.trim() || isProcessing}
            className={`px-8 py-3 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105 ${
              selectedContract && agreedToTerms && digitalSignature.trim() && !isProcessing
                ? 'bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white'
                : 'bg-gray-600 text-gray-400 cursor-not-allowed'
            }`}
          >
            {isProcessing ? (
              <div className="flex items-center gap-2">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                Processing Contract...
              </div>
            ) : (
              'Sign Contract & Complete Registration'
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default Step5ContractSigning;
