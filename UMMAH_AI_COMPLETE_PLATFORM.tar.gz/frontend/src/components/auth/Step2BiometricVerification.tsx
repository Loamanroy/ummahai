import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

interface Step2Props {
  onNext: (data: any) => void;
  onBack: () => void;
  formData: any;
  setFormData: (data: any) => void;
}

interface BiometricStatus {
  face: 'pending' | 'processing' | 'success' | 'failed';
  fingerprint: 'pending' | 'processing' | 'success' | 'failed';
  voice: 'pending' | 'processing' | 'success' | 'failed';
}

const Step2BiometricVerification = ({ onNext, onBack, formData, setFormData }: Step2Props) => {
  const [biometricStatus, setBiometricStatus] = useState<BiometricStatus>({
    face: 'pending',
    fingerprint: 'pending',
    voice: 'pending'
  });
  const [currentStep, setCurrentStep] = useState<'face' | 'fingerprint' | 'voice' | 'complete'>('face');
  const [isProcessing, setIsProcessing] = useState(false);

  const simulateBiometricCapture = async (type: keyof BiometricStatus) => {
    setBiometricStatus(prev => ({ ...prev, [type]: 'processing' }));
    setIsProcessing(true);
    
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const success = Math.random() > 0.1;
    setBiometricStatus(prev => ({ 
      ...prev, 
      [type]: success ? 'success' : 'failed' 
    }));
    setIsProcessing(false);
    
    if (success) {
      setFormData({
        ...formData,
        biometrics: {
          ...formData.biometrics,
          [type]: {
            captured: true,
            timestamp: new Date().toISOString(),
            confidence: Math.random() * 0.3 + 0.7
          }
        }
      });
    }
    
    return success;
  };

  const handleFaceVerification = async () => {
    const success = await simulateBiometricCapture('face');
    if (success) {
      setCurrentStep('fingerprint');
    }
  };

  const handleFingerprintVerification = async () => {
    const success = await simulateBiometricCapture('fingerprint');
    if (success) {
      setCurrentStep('voice');
    }
  };

  const handleVoiceVerification = async () => {
    const success = await simulateBiometricCapture('voice');
    if (success) {
      setCurrentStep('complete');
    }
  };

  const allVerificationsComplete = () => {
    return biometricStatus.face === 'success' && 
           biometricStatus.fingerprint === 'success' && 
           biometricStatus.voice === 'success';
  };

  const handleContinue = () => {
    if (allVerificationsComplete()) {
      onNext(formData);
    }
  };

  const getStatusIcon = (status: BiometricStatus[keyof BiometricStatus]) => {
    switch (status) {
      case 'success':
        return <div className="w-6 h-6 bg-green-400 rounded-full"></div>;
      case 'failed':
        return <div className="w-6 h-6 bg-red-400 rounded-full"></div>;
      case 'processing':
        return <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-400"></div>;
      default:
        return <div className="w-6 h-6 border-2 border-gray-600 rounded-full"></div>;
    }
  };

  const getStatusText = (status: BiometricStatus[keyof BiometricStatus]) => {
    switch (status) {
      case 'success':
        return 'VERIFIED';
      case 'failed':
        return 'FAILED';
      case 'processing':
        return 'Processing...';
      default:
        return 'Pending';
    }
  };

  return (
    <Card className="card-enhanced pulse-border max-w-4xl mx-auto">
      <CardContent className="p-8">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold glow-text mb-4">Step 2: Biometric Verification</h2>
          <p className="text-gray-400 glow-text">Complete all three biometric verifications for maximum security</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className={`p-6 rounded-lg border-2 transition-all duration-300 ${
            currentStep === 'face' ? 'border-blue-400 bg-blue-900/20' : 
            biometricStatus.face === 'success' ? 'border-green-400 bg-green-900/20' :
            biometricStatus.face === 'failed' ? 'border-red-400 bg-red-900/20' :
            'border-gray-600 bg-gray-800'
          }`}>
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-400 rounded-full mx-auto mb-4"></div>
              <h3 className="text-lg font-semibold mb-2 glow-text">Face Recognition</h3>
              <div className="flex items-center justify-center gap-2 mb-4">
                {getStatusIcon(biometricStatus.face)}
                <span className="text-sm">{getStatusText(biometricStatus.face)}</span>
              </div>
              {currentStep === 'face' && biometricStatus.face === 'pending' && (
                <Button
                  onClick={handleFaceVerification}
                  disabled={isProcessing}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  Start Face Scan
                </Button>
              )}
              {biometricStatus.face === 'failed' && (
                <Button
                  onClick={handleFaceVerification}
                  disabled={isProcessing}
                  className="w-full bg-red-600 hover:bg-red-700"
                >
                  Retry Face Scan
                </Button>
              )}
            </div>
          </div>

          <div className={`p-6 rounded-lg border-2 transition-all duration-300 ${
            currentStep === 'fingerprint' ? 'border-blue-400 bg-blue-900/20' : 
            biometricStatus.fingerprint === 'success' ? 'border-green-400 bg-green-900/20' :
            biometricStatus.fingerprint === 'failed' ? 'border-red-400 bg-red-900/20' :
            'border-gray-600 bg-gray-800'
          }`}>
            <div className="text-center">
              <div className="w-12 h-12 bg-green-400 rounded-full mx-auto mb-4"></div>
              <h3 className="text-lg font-semibold mb-2 glow-text">Fingerprint Scan</h3>
              <div className="flex items-center justify-center gap-2 mb-4">
                {getStatusIcon(biometricStatus.fingerprint)}
                <span className="text-sm">{getStatusText(biometricStatus.fingerprint)}</span>
              </div>
              {currentStep === 'fingerprint' && biometricStatus.fingerprint === 'pending' && (
                <Button
                  onClick={handleFingerprintVerification}
                  disabled={isProcessing}
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  Scan Fingerprint
                </Button>
              )}
              {biometricStatus.fingerprint === 'failed' && (
                <Button
                  onClick={handleFingerprintVerification}
                  disabled={isProcessing}
                  className="w-full bg-red-600 hover:bg-red-700"
                >
                  Retry Fingerprint
                </Button>
              )}
              {currentStep !== 'fingerprint' && biometricStatus.fingerprint === 'pending' && (
                <p className="text-gray-500 text-sm">Complete face verification first</p>
              )}
            </div>
          </div>

          <div className={`p-6 rounded-lg border-2 transition-all duration-300 ${
            currentStep === 'voice' ? 'border-blue-400 bg-blue-900/20' : 
            biometricStatus.voice === 'success' ? 'border-green-400 bg-green-900/20' :
            biometricStatus.voice === 'failed' ? 'border-red-400 bg-red-900/20' :
            'border-gray-600 bg-gray-800'
          }`}>
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-400 rounded-full mx-auto mb-4"></div>
              <h3 className="text-lg font-semibold mb-2 glow-text">Voice Recognition</h3>
              <div className="flex items-center justify-center gap-2 mb-4">
                {getStatusIcon(biometricStatus.voice)}
                <span className="text-sm">{getStatusText(biometricStatus.voice)}</span>
              </div>
              {currentStep === 'voice' && biometricStatus.voice === 'pending' && (
                <Button
                  onClick={handleVoiceVerification}
                  disabled={isProcessing}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  Record Voice
                </Button>
              )}
              {biometricStatus.voice === 'failed' && (
                <Button
                  onClick={handleVoiceVerification}
                  disabled={isProcessing}
                  className="w-full bg-red-600 hover:bg-red-700"
                >
                  Retry Voice
                </Button>
              )}
              {currentStep !== 'voice' && biometricStatus.voice === 'pending' && (
                <p className="text-gray-500 text-sm">Complete previous steps first</p>
              )}
            </div>
          </div>
        </div>

        {currentStep === 'complete' && allVerificationsComplete() && (
          <div className="text-center mb-8 p-6 bg-green-900/20 border border-green-400 rounded-lg">
            <div className="w-16 h-16 bg-green-400 rounded-full mx-auto mb-4"></div>
            <h3 className="text-xl font-semibold text-green-400 mb-2">All Biometric Verifications Complete!</h3>
            <p className="text-gray-300">Your identity has been successfully verified using advanced biometric technology.</p>
          </div>
        )}

        <div className="flex justify-between pt-6">
          <Button
            onClick={onBack}
            className="px-6 py-3 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors"
          >
            ← Back to Documents
          </Button>
          
          <Button
            onClick={handleContinue}
            disabled={!allVerificationsComplete()}
            className={`px-8 py-3 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105 ${
              allVerificationsComplete()
                ? 'bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white'
                : 'bg-gray-600 text-gray-400 cursor-not-allowed'
            }`}
          >
            Continue to Verification →
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default Step2BiometricVerification;
