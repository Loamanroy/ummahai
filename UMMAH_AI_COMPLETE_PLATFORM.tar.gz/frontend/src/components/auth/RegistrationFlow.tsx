import React, { useState } from 'react';
import Step1DocumentUpload from './Step1DocumentUpload';
import Step2BiometricVerification from './Step2BiometricVerification';
import Step3EmailSMSConfirmation from './Step3EmailSMSConfirmation';
import Step4WalletCreation from './Step4WalletCreation';
import Step5ContractSigning from './Step5ContractSigning';

const RegistrationFlow = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({});

  const handleNext = (data: any) => {
    setFormData({ ...formData, ...data });
    setCurrentStep(currentStep + 1);
  };

  const handleBack = () => {
    setCurrentStep(currentStep - 1);
  };

  const handleComplete = (data: any) => {
    const finalData = { ...formData, ...data };
    console.log('Registration completed:', finalData);
    
    alert('Registration completed successfully! Your account is pending admin approval. You will be notified once your account is approved and you can access the UMMAH AI Platform.');
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <Step1DocumentUpload
            onNext={handleNext}
            formData={formData}
            setFormData={setFormData}
          />
        );
      case 2:
        return (
          <Step2BiometricVerification
            onNext={handleNext}
            onBack={handleBack}
            formData={formData}
            setFormData={setFormData}
          />
        );
      case 3:
        return (
          <Step3EmailSMSConfirmation
            onNext={handleNext}
            onBack={handleBack}
            formData={formData}
            setFormData={setFormData}
          />
        );
      case 4:
        return (
          <Step4WalletCreation
            onNext={handleNext}
            onBack={handleBack}
            formData={formData}
            setFormData={setFormData}
          />
        );
      case 5:
        return (
          <Step5ContractSigning
            onNext={handleComplete}
            onBack={handleBack}
            formData={formData}
            setFormData={setFormData}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-800 p-4">
      {/* Progress Indicator */}
      <div className="max-w-4xl mx-auto mb-8">
        <div className="flex items-center justify-between">
          {[1, 2, 3, 4, 5].map((step) => (
            <div key={step} className="flex items-center">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                  step <= currentStep
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-600 text-gray-300'
                }`}
              >
                {step}
              </div>
              {step < 5 && (
                <div
                  className={`w-16 h-1 mx-2 ${
                    step < currentStep ? 'bg-green-600' : 'bg-gray-600'
                  }`}
                />
              )}
            </div>
          ))}
        </div>
        <div className="flex justify-between mt-2 text-sm text-gray-400">
          <span>Documents</span>
          <span>Biometrics</span>
          <span>Verification</span>
          <span>Wallet</span>
          <span>Contract</span>
        </div>
      </div>

      {/* Current Step */}
      {renderStep()}
    </div>
  );
};

export default RegistrationFlow;
