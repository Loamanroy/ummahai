import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Upload, Camera, FileText, Mail, Phone, User } from 'lucide-react';

/**
 * Props for the Step1DocumentUpload component
 */
interface Step1Props {
  /** Callback function to proceed to next step with form data */
  onNext: (data: any) => void;
  /** Current form data object */
  formData: any;
  /** Function to update form data */
  setFormData: (data: any) => void;
}

/**
 * Step1DocumentUpload - First step of KYC process for document upload and personal information
 * 
 * This component handles the initial KYC verification step where users provide personal
 * information and upload required documents including passport scan and selfie photo.
 * It includes form validation, file upload handling, and progress to the next step.
 * 
 * @param props - Component props
 * @param props.onNext - Callback function to proceed to next step with validated data
 * @param props.formData - Current form data containing user information
 * @param props.setFormData - Function to update the form data state
 * @returns JSX.Element - Rendered document upload and personal information form
 */
const Step1DocumentUpload = ({ onNext, formData, setFormData }: Step1Props) => {
  const [errors, setErrors] = useState<{[key: string]: string}>({});
  const [uploading, setUploading] = useState(false);

  /**
   * Handles input field changes and clears related errors
   * @param e - Input change event
   */
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };

  /**
   * Handles file upload for passport and selfie images
   * @param e - File input change event
   */
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, files } = e.target;
    if (files && files[0]) {
      setFormData({
        ...formData,
        [name]: files[0]
      });
      
      if (errors[name]) {
        setErrors({
          ...errors,
          [name]: ''
        });
      }
    }
  };

  /**
   * Validates all form fields and returns validation status
   * @returns boolean - True if form is valid, false otherwise
   */
  const validateForm = () => {
    const newErrors: {[key: string]: string} = {};
    
    if (!formData.fullName?.trim()) {
      newErrors.fullName = 'Full name is required';
    }
    
    if (!formData.email?.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email is invalid';
    }
    
    if (!formData.phone?.trim()) {
      newErrors.phone = 'Phone number is required';
    }
    
    if (!formData.passportImage) {
      newErrors.passportImage = 'Passport scan is required';
    }
    
    if (!formData.selfieImage) {
      newErrors.selfieImage = 'Selfie photo is required';
    }
    
    if (!formData.dateOfBirth?.trim()) {
      newErrors.dateOfBirth = 'Date of birth is required';
    }
    
    if (!formData.nationality?.trim()) {
      newErrors.nationality = 'Nationality is required';
    }
    
    if (!formData.address?.trim()) {
      newErrors.address = 'Address is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  /**
   * Handles form submission with validation and progress to next step
   * @param e - Form submission event
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setUploading(true);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      console.log('Step 1 data:', formData);
      onNext(formData);
    } catch (error) {
      console.error('Upload failed:', error);
    } finally {
      setUploading(false);
    }
  };

  return (
    <Card className="card-enhanced pulse-border max-w-4xl mx-auto">
      <CardContent className="p-8">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <FileText className="w-8 h-8 text-blue-400" />
            <h2 className="text-2xl font-bold glow-text">Step 1: Document Upload & Personal Information</h2>
          </div>
          <p className="text-gray-400 glow-text">Please provide your personal information and upload required documents</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium glow-text">
                <User className="w-4 h-4" />
                Full Name *
              </label>
              <input
                type="text"
                name="fullName"
                value={formData.fullName || ''}
                onChange={handleInputChange}
                className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-400 focus:outline-none transition-colors"
                placeholder="Enter your full legal name"
              />
              {errors.fullName && <p className="text-red-400 text-sm">{errors.fullName}</p>}
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium glow-text">
                <Mail className="w-4 h-4" />
                Email Address *
              </label>
              <input
                type="email"
                name="email"
                value={formData.email || ''}
                onChange={handleInputChange}
                className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-400 focus:outline-none transition-colors"
                placeholder="your.email@example.com"
              />
              {errors.email && <p className="text-red-400 text-sm">{errors.email}</p>}
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium glow-text">
                <Phone className="w-4 h-4" />
                Phone Number *
              </label>
              <input
                type="tel"
                name="phone"
                value={formData.phone || ''}
                onChange={handleInputChange}
                className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-400 focus:outline-none transition-colors"
                placeholder="+1 (555) 123-4567"
              />
              {errors.phone && <p className="text-red-400 text-sm">{errors.phone}</p>}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium glow-text">Date of Birth *</label>
              <input
                type="date"
                name="dateOfBirth"
                value={formData.dateOfBirth || ''}
                onChange={handleInputChange}
                className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-400 focus:outline-none transition-colors"
              />
              {errors.dateOfBirth && <p className="text-red-400 text-sm">{errors.dateOfBirth}</p>}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium glow-text">Nationality *</label>
              <input
                type="text"
                name="nationality"
                value={formData.nationality || ''}
                onChange={handleInputChange}
                className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-400 focus:outline-none transition-colors"
                placeholder="e.g., American, Turkish, etc."
              />
              {errors.nationality && <p className="text-red-400 text-sm">{errors.nationality}</p>}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium glow-text">Address *</label>
              <input
                type="text"
                name="address"
                value={formData.address || ''}
                onChange={handleInputChange}
                className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-400 focus:outline-none transition-colors"
                placeholder="Full residential address"
              />
              {errors.address && <p className="text-red-400 text-sm">{errors.address}</p>}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
            <div className="space-y-4">
              <label className="flex items-center gap-2 text-sm font-medium glow-text">
                <FileText className="w-4 h-4" />
                Passport Scan *
              </label>
              <div className="border-2 border-dashed border-gray-600 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-400 mb-2">Upload passport scan (PDF, JPG, PNG)</p>
                <input
                  type="file"
                  name="passportImage"
                  onChange={handleFileUpload}
                  accept=".pdf,.jpg,.jpeg,.png"
                  className="hidden"
                  id="passport-upload"
                />
                <label
                  htmlFor="passport-upload"
                  className="inline-block px-4 py-2 bg-blue-600 text-white rounded-lg cursor-pointer hover:bg-blue-700 transition-colors"
                >
                  Choose File
                </label>
                {formData.passportImage && (
                  <p className="text-green-400 text-sm mt-2">{formData.passportImage.name}</p>
                )}
              </div>
              {errors.passportImage && <p className="text-red-400 text-sm">{errors.passportImage}</p>}
            </div>

            <div className="space-y-4">
              <label className="flex items-center gap-2 text-sm font-medium glow-text">
                <Camera className="w-4 h-4" />
                Selfie Photo *
              </label>
              <div className="border-2 border-dashed border-gray-600 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                <Camera className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-400 mb-2">Upload clear selfie photo (JPG, PNG)</p>
                <input
                  type="file"
                  name="selfieImage"
                  onChange={handleFileUpload}
                  accept=".jpg,.jpeg,.png"
                  className="hidden"
                  id="selfie-upload"
                />
                <label
                  htmlFor="selfie-upload"
                  className="inline-block px-4 py-2 bg-green-600 text-white rounded-lg cursor-pointer hover:bg-green-700 transition-colors"
                >
                  Take/Upload Photo
                </label>
                {formData.selfieImage && (
                  <p className="text-green-400 text-sm mt-2">{formData.selfieImage.name}</p>
                )}
              </div>
              {errors.selfieImage && <p className="text-red-400 text-sm">{errors.selfieImage}</p>}
            </div>
          </div>

          <div className="flex justify-end pt-6">
            <Button
              type="submit"
              disabled={uploading}
              className="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold rounded-lg transition-all duration-200 transform hover:scale-105"
            >
              {uploading ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Processing...
                </div>
              ) : (
                'Continue to Biometric Verification →'
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default Step1DocumentUpload;
