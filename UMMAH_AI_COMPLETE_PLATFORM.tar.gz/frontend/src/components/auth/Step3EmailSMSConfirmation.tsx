import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Mail, MessageSquare, Shield, RefreshCw } from 'lucide-react';

interface Step3Props {
  onNext: (data: any) => void;
  onBack: () => void;
  formData: any;
  setFormData: (data: any) => void;
}

const Step3EmailSMSConfirmation = ({ onNext, onBack, formData, setFormData }: Step3Props) => {
  const [emailCode, setEmailCode] = useState('');
  const [smsCode, setSmsCode] = useState('');
  const [emailSent, setEmailSent] = useState(false);
  const [smsSent, setSmsSent] = useState(false);
  const [emailVerified, setEmailVerified] = useState(false);
  const [smsVerified, setSmsVerified] = useState(false);
  const [emailCountdown, setEmailCountdown] = useState(0);
  const [smsCountdown, setSmsCountdown] = useState(0);
  const [isVerifying, setIsVerifying] = useState(false);
  const [errors, setErrors] = useState<{[key: string]: string}>({});

  const correctEmailCode = '123456';
  const correctSmsCode = '789012';

  useEffect(() => {
    if (emailCountdown > 0) {
      const timer = setTimeout(() => setEmailCountdown(emailCountdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [emailCountdown]);

  useEffect(() => {
    if (smsCountdown > 0) {
      const timer = setTimeout(() => setSmsCountdown(smsCountdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [smsCountdown]);

  const sendEmailCode = async () => {
    setEmailSent(true);
    setEmailCountdown(60);
    console.log(`Email verification code sent to: ${formData.email}`);
    console.log(`Demo code: ${correctEmailCode}`);
  };

  const sendSmsCode = async () => {
    setSmsSent(true);
    setSmsCountdown(60);
    console.log(`SMS verification code sent to: ${formData.phone}`);
    console.log(`Demo code: ${correctSmsCode}`);
  };

  const verifyEmailCode = async () => {
    setIsVerifying(true);
    setErrors({});
    
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    if (emailCode === correctEmailCode) {
      setEmailVerified(true);
      setFormData({
        ...formData,
        verification: {
          ...formData.verification,
          email: {
            verified: true,
            timestamp: new Date().toISOString(),
            code: emailCode
          }
        }
      });
    } else {
      setErrors({ email: 'Invalid verification code. Please try again.' });
    }
    
    setIsVerifying(false);
  };

  const verifySmsCode = async () => {
    setIsVerifying(true);
    setErrors({});
    
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    if (smsCode === correctSmsCode) {
      setSmsVerified(true);
      setFormData({
        ...formData,
        verification: {
          ...formData.verification,
          sms: {
            verified: true,
            timestamp: new Date().toISOString(),
            code: smsCode
          }
        }
      });
    } else {
      setErrors({ sms: 'Invalid verification code. Please try again.' });
    }
    
    setIsVerifying(false);
  };

  const handleContinue = () => {
    if (emailVerified && smsVerified) {
      onNext(formData);
    }
  };

  const bothVerified = emailVerified && smsVerified;

  return (
    <Card className="card-enhanced pulse-border max-w-4xl mx-auto">
      <CardContent className="p-8">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Shield className="w-8 h-8 text-green-400" />
            <h2 className="text-2xl font-bold glow-text">Step 3: Email & SMS Verification</h2>
          </div>
          <p className="text-gray-400 glow-text">Verify your email and phone number to secure your account</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className={`p-6 rounded-lg border-2 transition-all duration-300 ${
            emailVerified ? 'border-green-400 bg-green-900/20' : 'border-blue-400 bg-blue-900/10'
          }`}>
            <div className="text-center mb-6">
              <Mail className="w-12 h-12 text-blue-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2 glow-text">Email Verification</h3>
              <p className="text-sm text-gray-400 mb-4">
                We'll send a 6-digit code to:<br />
                <span className="text-blue-400 font-mono">{formData.email}</span>
              </p>
            </div>

            {!emailSent ? (
              <Button
                onClick={sendEmailCode}
                className="w-full bg-blue-600 hover:bg-blue-700 mb-4"
              >
                Send Email Code
              </Button>
            ) : (
              <div className="space-y-4">
                <div className="text-center">
                  <p className="text-green-400 text-sm mb-2">Email sent successfully!</p>
                  {emailCountdown > 0 && (
                    <p className="text-gray-400 text-xs">
                      Resend available in {emailCountdown}s
                    </p>
                  )}
                </div>

                {!emailVerified && (
                  <>
                    <div className="space-y-2">
                      <label className="text-sm font-medium glow-text">Enter 6-digit code:</label>
                      <input
                        type="text"
                        value={emailCode}
                        onChange={(e) => setEmailCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                        className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white text-center text-lg font-mono focus:border-blue-400 focus:outline-none transition-colors"
                        placeholder="123456"
                        maxLength={6}
                      />
                      {errors.email && <p className="text-red-400 text-sm">{errors.email}</p>}
                    </div>

                    <Button
                      onClick={verifyEmailCode}
                      disabled={emailCode.length !== 6 || isVerifying}
                      className="w-full bg-green-600 hover:bg-green-700"
                    >
                      {isVerifying ? (
                        <div className="flex items-center gap-2">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                          Verifying...
                        </div>
                      ) : (
                        'Verify Email'
                      )}
                    </Button>
                  </>
                )}

                {emailVerified && (
                  <div className="text-center p-4 bg-green-900/30 rounded-lg">
                    <p className="text-green-400 font-semibold">Email Verified!</p>
                  </div>
                )}

                {emailCountdown === 0 && !emailVerified && (
                  <Button
                    onClick={sendEmailCode}
                    className="w-full bg-gray-600 hover:bg-gray-700 text-sm"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Resend Email Code
                  </Button>
                )}
              </div>
            )}
          </div>

          <div className={`p-6 rounded-lg border-2 transition-all duration-300 ${
            smsVerified ? 'border-green-400 bg-green-900/20' : 'border-purple-400 bg-purple-900/10'
          }`}>
            <div className="text-center mb-6">
              <MessageSquare className="w-12 h-12 text-purple-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2 glow-text">SMS Verification</h3>
              <p className="text-sm text-gray-400 mb-4">
                We'll send a 6-digit code to:<br />
                <span className="text-purple-400 font-mono">{formData.phone}</span>
              </p>
            </div>

            {!smsSent ? (
              <Button
                onClick={sendSmsCode}
                className="w-full bg-purple-600 hover:bg-purple-700 mb-4"
              >
                Send SMS Code
              </Button>
            ) : (
              <div className="space-y-4">
                <div className="text-center">
                  <p className="text-green-400 text-sm mb-2">SMS sent successfully!</p>
                  {smsCountdown > 0 && (
                    <p className="text-gray-400 text-xs">
                      Resend available in {smsCountdown}s
                    </p>
                  )}
                </div>

                {!smsVerified && (
                  <>
                    <div className="space-y-2">
                      <label className="text-sm font-medium glow-text">Enter 6-digit code:</label>
                      <input
                        type="text"
                        value={smsCode}
                        onChange={(e) => setSmsCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                        className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white text-center text-lg font-mono focus:border-purple-400 focus:outline-none transition-colors"
                        placeholder="789012"
                        maxLength={6}
                      />
                      {errors.sms && <p className="text-red-400 text-sm">{errors.sms}</p>}
                    </div>

                    <Button
                      onClick={verifySmsCode}
                      disabled={smsCode.length !== 6 || isVerifying}
                      className="w-full bg-green-600 hover:bg-green-700"
                    >
                      {isVerifying ? (
                        <div className="flex items-center gap-2">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                          Verifying...
                        </div>
                      ) : (
                        'Verify SMS'
                      )}
                    </Button>
                  </>
                )}

                {smsVerified && (
                  <div className="text-center p-4 bg-green-900/30 rounded-lg">
                    <p className="text-green-400 font-semibold">SMS Verified!</p>
                  </div>
                )}

                {smsCountdown === 0 && !smsVerified && (
                  <Button
                    onClick={sendSmsCode}
                    className="w-full bg-gray-600 hover:bg-gray-700 text-sm"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Resend SMS Code
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>

        {bothVerified && (
          <div className="text-center mt-8 p-6 bg-green-900/20 border border-green-400 rounded-lg">
            <Shield className="w-16 h-16 text-green-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-green-400 mb-2">Verification Complete!</h3>
            <p className="text-gray-300">Both your email and phone number have been successfully verified.</p>
          </div>
        )}

        <div className="flex justify-between pt-8">
          <Button
            onClick={onBack}
            className="px-6 py-3 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors"
          >
            ← Back to Biometrics
          </Button>
          
          <Button
            onClick={handleContinue}
            disabled={!bothVerified}
            className={`px-8 py-3 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105 ${
              bothVerified
                ? 'bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white'
                : 'bg-gray-600 text-gray-400 cursor-not-allowed'
            }`}
          >
            Continue to Wallet Setup →
          </Button>
        </div>

        <div className="mt-6 p-4 bg-gray-800 rounded-lg">
          <p className="text-xs text-gray-400 text-center">
            <strong>Demo Codes:</strong> Email: {correctEmailCode} | SMS: {correctSmsCode}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default Step3EmailSMSConfirmation;
