import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

interface Step4Props {
  onNext: (data: any) => void;
  onBack: () => void;
  formData: any;
  setFormData: (data: any) => void;
}

interface WalletOption {
  id: string;
  name: string;
  description: string;
  features: string[];
  icon: React.ReactNode;
  color: string;
  recommended?: boolean;
}

const Step4WalletCreation = ({ onNext, onBack, formData, setFormData }: Step4Props) => {
  const [selectedWalletType, setSelectedWalletType] = useState<'connect' | 'create' | null>(null);
  const [selectedWalletOption, setSelectedWalletOption] = useState<string>('');
  const [connectedWallet, setConnectedWallet] = useState<string>('');
  const [offshoreAccounts, setOffshoreAccounts] = useState<Array<{
    bank: string;
    country: string;
    accountNumber: string;
    swift: string;
  }>>([]);
  const [newAccount, setNewAccount] = useState({
    bank: '',
    country: '',
    accountNumber: '',
    swift: ''
  });
  const [isCreating, setIsCreating] = useState(false);

  const walletOptions: WalletOption[] = [
    {
      id: 'quantum-vault',
      name: 'Quantum Vault Pro',
      description: 'Military-grade quantum encryption with AI-powered security',
      features: [
        'Quantum-resistant encryption',
        'AI threat detection',
        'Multi-signature support',
        'Hardware security module',
        'Zero-knowledge proofs',
        'Biometric authentication'
      ],
      icon: <div className="w-8 h-8 bg-blue-400 rounded-full"></div>,
      color: 'from-blue-600 to-purple-600',
      recommended: true
    },
    {
      id: 'stealth-wallet',
      name: 'Stealth Wallet Elite',
      description: 'Maximum privacy with advanced anonymization features',
      features: [
        'TOR integration',
        'Coin mixing protocols',
        'IP obfuscation',
        'Metadata encryption',
        'Anonymous transactions',
        'VPN chain routing'
      ],
      icon: <div className="w-8 h-8 bg-gray-400 rounded-full"></div>,
      color: 'from-gray-600 to-black'
    },
    {
      id: 'ai-adaptive',
      name: 'AI Adaptive Wallet',
      description: 'Self-learning wallet that adapts to your trading patterns',
      features: [
        'Machine learning optimization',
        'Predictive gas fees',
        'Smart contract analysis',
        'Risk assessment AI',
        'Automated portfolio rebalancing',
        'Pattern recognition'
      ],
      icon: <div className="w-8 h-8 bg-green-400 rounded-full"></div>,
      color: 'from-green-600 to-teal-600'
    }
  ];

  const handleConnectWallet = async (walletType: string) => {
    setIsCreating(true);
    
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const mockAddress = `0x${Math.random().toString(16).substr(2, 40)}`;
    setConnectedWallet(mockAddress);
    
    setFormData({
      ...formData,
      wallet: {
        type: 'connected',
        provider: walletType,
        address: mockAddress,
        connected: true,
        timestamp: new Date().toISOString()
      }
    });
    
    setIsCreating(false);
  };

  const handleCreateWallet = async (optionId: string) => {
    setIsCreating(true);
    
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const selectedOption = walletOptions.find(opt => opt.id === optionId);
    const mockAddress = `0x${Math.random().toString(16).substr(2, 40)}`;
    const mockSeed = Array.from({length: 12}, () => 
      ['abandon', 'ability', 'able', 'about', 'above', 'absent', 'absorb', 'abstract'][Math.floor(Math.random() * 8)]
    ).join(' ');
    
    setFormData({
      ...formData,
      wallet: {
        type: 'created',
        option: selectedOption,
        address: mockAddress,
        seedPhrase: mockSeed,
        created: true,
        timestamp: new Date().toISOString()
      }
    });
    
    setIsCreating(false);
  };

  const handleAddOffshoreAccount = () => {
    if (newAccount.bank && newAccount.country && newAccount.accountNumber && newAccount.swift) {
      setOffshoreAccounts([...offshoreAccounts, newAccount]);
      setNewAccount({ bank: '', country: '', accountNumber: '', swift: '' });
      
      setFormData({
        ...formData,
        offshoreAccounts: [...offshoreAccounts, newAccount]
      });
    }
  };

  const handleRemoveAccount = (index: number) => {
    const updatedAccounts = offshoreAccounts.filter((_, i) => i !== index);
    setOffshoreAccounts(updatedAccounts);
    setFormData({
      ...formData,
      offshoreAccounts: updatedAccounts
    });
  };

  const handleContinue = () => {
    if ((connectedWallet || selectedWalletOption) && offshoreAccounts.length > 0) {
      onNext(formData);
    }
  };

  const isComplete = (connectedWallet || selectedWalletOption) && offshoreAccounts.length > 0;

  return (
    <Card className="card-enhanced pulse-border max-w-6xl mx-auto">
      <CardContent className="p-8">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-8 h-8 bg-green-400 rounded-full"></div>
            <h2 className="text-2xl font-bold glow-text">Step 4: Wallet Setup & Offshore Accounts</h2>
          </div>
          <p className="text-gray-400 glow-text">Connect your wallet or create a new one, then add your offshore accounts</p>
        </div>

        {/* Wallet Selection */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-6 glow-text">Choose Wallet Option</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div 
              className={`p-6 rounded-lg border-2 cursor-pointer transition-all duration-300 ${
                selectedWalletType === 'connect' ? 'border-blue-400 bg-blue-900/20' : 'border-gray-600 bg-gray-800 hover:border-gray-500'
              }`}
              onClick={() => setSelectedWalletType('connect')}
            >
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-400 rounded-full mx-auto mb-4"></div>
                <h4 className="text-lg font-semibold mb-2 glow-text">Connect Existing Wallet</h4>
                <p className="text-sm text-gray-400">Connect your MetaMask, WalletConnect, or other existing wallet</p>
              </div>
            </div>

            <div 
              className={`p-6 rounded-lg border-2 cursor-pointer transition-all duration-300 ${
                selectedWalletType === 'create' ? 'border-green-400 bg-green-900/20' : 'border-gray-600 bg-gray-800 hover:border-gray-500'
              }`}
              onClick={() => setSelectedWalletType('create')}
            >
              <div className="text-center">
                <div className="w-12 h-12 bg-green-400 rounded-full mx-auto mb-4"></div>
                <h4 className="text-lg font-semibold mb-2 glow-text">Create New Wallet</h4>
                <p className="text-sm text-gray-400">Let our AI create an advanced wallet with cutting-edge features</p>
              </div>
            </div>
          </div>

          {/* Connect Existing Wallet */}
          {selectedWalletType === 'connect' && (
            <div className="bg-gray-800 p-6 rounded-lg border border-gray-600">
              <h4 className="text-lg font-semibold mb-4 glow-text">Connect Your Wallet</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {['MetaMask', 'WalletConnect', 'Coinbase Wallet', 'Trust Wallet'].map((wallet) => (
                  <Button
                    key={wallet}
                    onClick={() => handleConnectWallet(wallet)}
                    disabled={isCreating}
                    className="p-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                  >
                    {isCreating ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mx-auto"></div>
                    ) : (
                      wallet
                    )}
                  </Button>
                ))}
              </div>
              
              {connectedWallet && (
                <div className="mt-4 p-4 bg-green-900/30 rounded-lg border border-green-400">
                  <p className="text-green-400 font-semibold">Wallet Connected!</p>
                  <p className="text-sm text-gray-300 font-mono mt-1">{connectedWallet}</p>
                </div>
              )}
            </div>
          )}

          {/* Create New Wallet */}
          {selectedWalletType === 'create' && (
            <div className="bg-gray-800 p-6 rounded-lg border border-gray-600">
              <h4 className="text-lg font-semibold mb-4 glow-text">Choose Advanced Wallet Type</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {walletOptions.map((option) => (
                  <div
                    key={option.id}
                    className={`p-6 rounded-lg border-2 cursor-pointer transition-all duration-300 relative ${
                      selectedWalletOption === option.id ? 'border-green-400 bg-green-900/20' : 'border-gray-600 hover:border-gray-500'
                    }`}
                    onClick={() => setSelectedWalletOption(option.id)}
                  >
                    {option.recommended && (
                      <div className="absolute -top-2 -right-2 bg-yellow-500 text-black text-xs font-bold px-2 py-1 rounded-full">
                        RECOMMENDED
                      </div>
                    )}
                    
                    <div className="text-center mb-4">
                      <div className={`w-16 h-16 rounded-full bg-gradient-to-r ${option.color} flex items-center justify-center mx-auto mb-3`}>
                        {option.icon}
                      </div>
                      <h5 className="text-lg font-semibold glow-text">{option.name}</h5>
                      <p className="text-sm text-gray-400 mt-2">{option.description}</p>
                    </div>
                    
                    <ul className="text-xs space-y-1">
                      {option.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center gap-2">
                          <span className="text-green-400">•</span>
                          <span className="text-gray-300">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
              
              {selectedWalletOption && (
                <div className="mt-6 text-center">
                  <Button
                    onClick={() => handleCreateWallet(selectedWalletOption)}
                    disabled={isCreating}
                    className="px-8 py-3 bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white font-semibold rounded-lg transition-all duration-200 transform hover:scale-105"
                  >
                    {isCreating ? (
                      <div className="flex items-center gap-2">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        Creating Advanced Wallet...
                      </div>
                    ) : (
                      'Create Wallet'
                    )}
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Offshore Accounts Section */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-6 h-6 bg-purple-400 rounded-full"></div>
            <h3 className="text-xl font-semibold glow-text">Offshore Bank Accounts</h3>
          </div>
          
          <div className="bg-gray-800 p-6 rounded-lg border border-gray-600">
            <h4 className="text-lg font-semibold mb-4 glow-text">Add Offshore Account for Profit Withdrawal</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="space-y-2">
                <label className="text-sm font-medium glow-text">Bank Name</label>
                <input
                  type="text"
                  value={newAccount.bank}
                  onChange={(e) => setNewAccount({...newAccount, bank: e.target.value})}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-purple-400 focus:outline-none transition-colors"
                  placeholder="e.g., UBS, Credit Suisse, HSBC"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium glow-text">Country</label>
                <input
                  type="text"
                  value={newAccount.country}
                  onChange={(e) => setNewAccount({...newAccount, country: e.target.value})}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-purple-400 focus:outline-none transition-colors"
                  placeholder="e.g., Switzerland, Cayman Islands"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium glow-text">Account Number</label>
                <input
                  type="text"
                  value={newAccount.accountNumber}
                  onChange={(e) => setNewAccount({...newAccount, accountNumber: e.target.value})}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-purple-400 focus:outline-none transition-colors"
                  placeholder="Account number"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium glow-text">SWIFT Code</label>
                <input
                  type="text"
                  value={newAccount.swift}
                  onChange={(e) => setNewAccount({...newAccount, swift: e.target.value})}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-purple-400 focus:outline-none transition-colors"
                  placeholder="SWIFT/BIC code"
                />
              </div>
            </div>
            
            <Button
              onClick={handleAddOffshoreAccount}
              className="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 rounded-lg transition-colors"
            >
              Add Offshore Account
            </Button>
          </div>
          
          {/* Display Added Accounts */}
          {offshoreAccounts.length > 0 && (
            <div className="mt-6">
              <h4 className="text-lg font-semibold mb-4 glow-text">Added Offshore Accounts</h4>
              <div className="space-y-3">
                {offshoreAccounts.map((account, index) => (
                  <div key={index} className="bg-gray-700 p-4 rounded-lg border border-gray-600 flex justify-between items-center">
                    <div>
                      <p className="font-semibold text-white">{account.bank}</p>
                      <p className="text-sm text-gray-400">{account.country} • {account.swift}</p>
                      <p className="text-xs text-gray-500 font-mono">{account.accountNumber}</p>
                    </div>
                    <Button
                      onClick={() => handleRemoveAccount(index)}
                      className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 text-sm rounded"
                    >
                      Remove
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Completion Status */}
        {isComplete && (
          <div className="text-center mb-8 p-6 bg-green-900/20 border border-green-400 rounded-lg">
            <div className="w-16 h-16 bg-green-400 rounded-full mx-auto mb-4"></div>
            <h3 className="text-xl font-semibold text-green-400 mb-2">Wallet & Accounts Setup Complete!</h3>
            <p className="text-gray-300">Your wallet is connected and offshore accounts are configured for profit withdrawal.</p>
          </div>
        )}

        <div className="flex justify-between pt-6">
          <Button
            onClick={onBack}
            className="px-6 py-3 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors"
          >
            ← Back to Verification
          </Button>
          
          <Button
            onClick={handleContinue}
            disabled={!isComplete}
            className={`px-8 py-3 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105 ${
              isComplete
                ? 'bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white'
                : 'bg-gray-600 text-gray-400 cursor-not-allowed'
            }`}
          >
            Continue to Contract Signing →
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default Step4WalletCreation;
