import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent } from '../components/ui/card';
import { Button } from '../components/ui/button';

interface BiometricData {
  fingerprint?: string;
  faceId?: string;
  voiceprint?: string;
  retinalScan?: string;
}

interface BioIDModuleProps {
  onAuthSuccess?: (data: BiometricData) => void;
  onAuthFailure?: (error: string) => void;
}

export const BioIDModule: React.FC<BioIDModuleProps> = ({ 
  onAuthSuccess, 
  onAuthFailure 
}) => {
  const [isScanning, setIsScanning] = useState(false);
  const [scanType, setScanType] = useState<'fingerprint' | 'face' | 'voice' | 'retinal'>('fingerprint');
  const [authStatus, setAuthStatus] = useState<'idle' | 'scanning' | 'success' | 'failed'>('idle');
  const [biometricData, setBiometricData] = useState<BiometricData>({});
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (scanType === 'face' && videoRef.current) {
      startCamera();
    }
    return () => {
      stopCamera();
    };
  }, [scanType]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 320, height: 240 } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (error) {
      console.error('Camera access denied:', error);
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
    }
  };

  const simulateBiometricScan = async () => {
    setIsScanning(true);
    setAuthStatus('scanning');
    
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const success = Math.random() > 0.1;
    
    if (success) {
      const mockData: BiometricData = {
        [scanType]: `${scanType}_${Date.now()}_verified`
      };
      setBiometricData(prev => ({ ...prev, ...mockData }));
      setAuthStatus('success');
      onAuthSuccess?.(mockData);
    } else {
      setAuthStatus('failed');
      onAuthFailure?.(`${scanType} authentication failed`);
    }
    
    setIsScanning(false);
  };

  const getStatusColor = () => {
    switch (authStatus) {
      case 'scanning': return 'text-yellow-400';
      case 'success': return 'text-green-400';
      case 'failed': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusIcon = () => {
    switch (authStatus) {
      case 'scanning': return '🔄';
      case 'success': return '✅';
      case 'failed': return '❌';
      default: return '🔒';
    }
  };

  return (
    <Card className="bg-gray-900 border border-gray-700 text-white">
      <CardContent className="p-4">
        <h3 className="text-lg font-semibold mb-4">🧬 BioID Authentication Module</h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Biometric Type</label>
            <select
              value={scanType}
              onChange={(e) => setScanType(e.target.value as any)}
              className="w-full p-2 bg-gray-800 border border-gray-600 rounded-lg text-white"
              disabled={isScanning}
            >
              <option value="fingerprint">👆 Fingerprint Scan</option>
              <option value="face">👤 Face Recognition</option>
              <option value="voice">🎤 Voice Authentication</option>
              <option value="retinal">👁 Retinal Scan</option>
            </select>
          </div>

          {scanType === 'face' && (
            <div className="relative">
              <video
                ref={videoRef}
                autoPlay
                muted
                className="w-full rounded-lg bg-gray-800"
                style={{ maxHeight: '200px' }}
              />
              <canvas
                ref={canvasRef}
                className="absolute top-0 left-0 w-full h-full"
                style={{ display: 'none' }}
              />
            </div>
          )}

          {scanType === 'fingerprint' && (
            <div className="flex justify-center p-8 bg-gray-800 rounded-lg">
              <div className="w-24 h-24 border-2 border-dashed border-gray-600 rounded-full flex items-center justify-center">
                <span className="text-4xl">👆</span>
              </div>
            </div>
          )}

          {scanType === 'voice' && (
            <div className="flex justify-center p-8 bg-gray-800 rounded-lg">
              <div className="text-center">
                <div className="text-4xl mb-2">🎤</div>
                <div className="text-sm text-gray-400">Say: "Authenticate UMMAH AI Platform"</div>
              </div>
            </div>
          )}

          {scanType === 'retinal' && (
            <div className="flex justify-center p-8 bg-gray-800 rounded-lg">
              <div className="w-24 h-24 border-2 border-dashed border-gray-600 rounded-full flex items-center justify-center">
                <span className="text-4xl">👁</span>
              </div>
            </div>
          )}

          <div className={`text-center ${getStatusColor()}`}>
            <span className="text-2xl mr-2">{getStatusIcon()}</span>
            <span className="text-sm">
              {authStatus === 'idle' && 'Ready for authentication'}
              {authStatus === 'scanning' && `Scanning ${scanType}...`}
              {authStatus === 'success' && 'Authentication successful'}
              {authStatus === 'failed' && 'Authentication failed'}
            </span>
          </div>

          <Button
            onClick={simulateBiometricScan}
            disabled={isScanning}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            {isScanning ? '🔄 Scanning...' : `🔒 Start ${scanType} Scan`}
          </Button>

          <div className="text-xs text-gray-400 space-y-1">
            <div>🔐 AES-256 Biometric Encryption</div>
            <div>🧬 Multi-factor Bio Authentication</div>
            <div>🛡 Zero-knowledge Proof Integration</div>
            <div>📊 Behavioral Pattern Analysis</div>
            <div>🔄 Real-time Liveness Detection</div>
          </div>

          {Object.keys(biometricData).length > 0 && (
            <div className="mt-4 p-3 bg-gray-800 rounded-lg">
              <h4 className="text-sm font-medium mb-2">Verified Biometrics:</h4>
              {Object.entries(biometricData).map(([type, data]) => (
                <div key={type} className="text-xs text-green-400">
                  ✅ {type}: {data?.substring(0, 20)}...
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default BioIDModule;
