import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../../ui/button';
import { Card, CardContent } from '../../ui/card';
import { ArrowLeft, TrendingUp, TrendingDown, Activity, Brain, Shield } from 'lucide-react';

interface OrderBookEntry {
  price: number;
  amount: number;
  total: number;
}

interface Trade {
  id: string;
  price: number;
  amount: number;
  side: 'buy' | 'sell';
  timestamp: Date;
}

interface AISignal {
  symbol: string;
  prediction: 'bullish' | 'bearish' | 'neutral';
  confidence: number;
  timeframe: string;
  reasoning: string;
}

interface ExchangeConfig {
  name: string;
  logo: string;
  color: string;
  pairs: string[];
  features: string[];
}

const exchangeConfigs: Record<string, ExchangeConfig> = {
  'OKX': {
    name: 'OKX',
    logo: 'https://cryptologos.cc/logos/okb-okb-logo.png',
    color: 'blue',
    pairs: ['BTC/USDT', 'ETH/USDT', 'OKB/USDT', 'ADA/USDT'],
    features: ['Spot Trading', 'Futures', 'Options', 'DeFi']
  },
  'Bybit': {
    name: 'Bybit',
    logo: 'https://cryptologos.cc/logos/bybit-bit-logo.png',
    color: 'yellow',
    pairs: ['BTC/USDT', 'ETH/USDT', 'BIT/USDT', 'SOL/USDT'],
    features: ['Derivatives', 'Spot Trading', 'Copy Trading', 'NFT']
  },
  'Kraken': {
    name: 'Kraken',
    logo: 'https://cryptologos.cc/logos/kraken-kraken-logo.png',
    color: 'purple',
    pairs: ['BTC/USD', 'ETH/USD', 'XRP/USD', 'ADA/USD'],
    features: ['Spot Trading', 'Futures', 'Staking', 'NFT']
  },
  'Bitfinex': {
    name: 'Bitfinex',
    logo: 'https://cryptologos.cc/logos/bitfinex-leo-logo.png',
    color: 'green',
    pairs: ['BTC/USD', 'ETH/USD', 'LEO/USD', 'XRP/USD'],
    features: ['Spot Trading', 'Margin Trading', 'Lending', 'Derivatives']
  },
  'Coinbase': {
    name: 'Coinbase',
    logo: 'https://cryptologos.cc/logos/coinbase-coin-logo.png',
    color: 'blue',
    pairs: ['BTC/USD', 'ETH/USD', 'COIN/USD', 'ADA/USD'],
    features: ['Spot Trading', 'Pro Trading', 'Staking', 'NFT']
  },
  'Gemini': {
    name: 'Gemini',
    logo: 'https://cryptologos.cc/logos/gemini-dollar-gusd-logo.png',
    color: 'cyan',
    pairs: ['BTC/USD', 'ETH/USD', 'GUSD/USD', 'LTC/USD'],
    features: ['Spot Trading', 'Custody', 'Earn', 'Credit Card']
  },
  'KuCoin': {
    name: 'KuCoin',
    logo: 'https://cryptologos.cc/logos/kucoin-shares-kcs-logo.png',
    color: 'green',
    pairs: ['BTC/USDT', 'ETH/USDT', 'KCS/USDT', 'DOT/USDT'],
    features: ['Spot Trading', 'Futures', 'Pool-X', 'Bot Trading']
  },
  'Bitstamp': {
    name: 'Bitstamp',
    logo: 'https://cryptologos.cc/logos/bitstamp-logo.png',
    color: 'green',
    pairs: ['BTC/USD', 'ETH/USD', 'XRP/USD', 'LTC/USD'],
    features: ['Spot Trading', 'Institutional', 'API Trading', 'Staking']
  },
  'Poloniex': {
    name: 'Poloniex',
    logo: 'https://cryptologos.cc/logos/poloniex-logo.png',
    color: 'green',
    pairs: ['BTC/USDT', 'ETH/USDT', 'TRX/USDT', 'XRP/USDT'],
    features: ['Spot Trading', 'Margin Trading', 'Lending', 'Futures']
  },
  'Huobi': {
    name: 'Huobi',
    logo: 'https://cryptologos.cc/logos/huobi-token-ht-logo.png',
    color: 'blue',
    pairs: ['BTC/USDT', 'ETH/USDT', 'HT/USDT', 'DOT/USDT'],
    features: ['Spot Trading', 'Derivatives', 'DeFi', 'Mining Pool']
  },
  'Bittrex': {
    name: 'Bittrex',
    logo: 'https://cryptologos.cc/logos/bittrex-logo.png',
    color: 'blue',
    pairs: ['BTC/USD', 'ETH/USD', 'XRP/USD', 'ADA/USD'],
    features: ['Spot Trading', 'Global Markets', 'OTC', 'Institutional']
  },
  'Gate.io': {
    name: 'Gate.io',
    logo: 'https://cryptologos.cc/logos/gate-io-gt-logo.png',
    color: 'blue',
    pairs: ['BTC/USDT', 'ETH/USDT', 'GT/USDT', 'DOT/USDT'],
    features: ['Spot Trading', 'Margin Trading', 'Futures', 'Options']
  },
  'Deribit': {
    name: 'Deribit',
    logo: 'https://cryptologos.cc/logos/deribit-logo.png',
    color: 'yellow',
    pairs: ['BTC/USD', 'ETH/USD', 'SOL/USD', 'MATIC/USD'],
    features: ['Options', 'Futures', 'Perpetuals', 'Structured Products']
  },
  'Upbit': {
    name: 'Upbit',
    logo: 'https://cryptologos.cc/logos/upbit-logo.png',
    color: 'blue',
    pairs: ['BTC/KRW', 'ETH/KRW', 'XRP/KRW', 'ADA/KRW'],
    features: ['Spot Trading', 'KRW Markets', 'Staking', 'NFT']
  },
  'Liquid': {
    name: 'Liquid',
    logo: 'https://cryptologos.cc/logos/liquid-qash-logo.png',
    color: 'blue',
    pairs: ['BTC/USD', 'ETH/USD', 'QASH/USD', 'XRP/USD'],
    features: ['Spot Trading', 'Margin Trading', 'Lending', 'Quick Exchange']
  },
  'Coincheck': {
    name: 'Coincheck',
    logo: 'https://cryptologos.cc/logos/coincheck-logo.png',
    color: 'green',
    pairs: ['BTC/JPY', 'ETH/JPY', 'XRP/JPY', 'LTC/JPY'],
    features: ['Spot Trading', 'JPY Markets', 'Lending', 'Electricity']
  },
  'ZB.com': {
    name: 'ZB.com',
    logo: 'https://cryptologos.cc/logos/zb-token-zb-logo.png',
    color: 'blue',
    pairs: ['BTC/USDT', 'ETH/USDT', 'ZB/USDT', 'EOS/USDT'],
    features: ['Spot Trading', 'Margin Trading', 'Mining Pool', 'OTC']
  },
  'BitFlyer': {
    name: 'BitFlyer',
    logo: 'https://cryptologos.cc/logos/bitflyer-logo.png',
    color: 'blue',
    pairs: ['BTC/JPY', 'ETH/JPY', 'XRP/JPY', 'LTC/JPY'],
    features: ['Spot Trading', 'Lightning FX', 'Futures', 'Staking']
  },
  'MEXC': {
    name: 'MEXC',
    logo: 'https://cryptologos.cc/logos/mexc-token-mexc-logo.png',
    color: 'green',
    pairs: ['BTC/USDT', 'ETH/USDT', 'MEXC/USDT', 'BNB/USDT'],
    features: ['Spot Trading', 'Futures', 'Margin Trading', 'Launchpad']
  }
};

interface GenericExchangeInterfaceProps {
  exchangeName: string;
}

/**
 * GenericExchangeInterface - Universal trading interface for multiple cryptocurrency exchanges
 * 
 * Provides a unified trading interface that adapts to different exchange configurations,
 * featuring real-time order books, AI-powered trading signals from CerebellumBot vX,
 * and stealth trading capabilities across 20+ supported exchanges.
 * 
 * @param props - Component props
 * @param props.exchangeName - Name of the exchange to interface with
 * @returns JSX.Element - Rendered exchange trading interface
 */
const GenericExchangeInterface = ({ exchangeName }: GenericExchangeInterfaceProps) => {
  const navigate = useNavigate();
  const config = exchangeConfigs[exchangeName] || {
    name: exchangeName,
    logo: 'https://cryptologos.cc/logos/bitcoin-btc-logo.png',
    color: 'blue',
    pairs: ['BTC/USDT', 'ETH/USDT', 'BNB/USDT', 'ADA/USDT'],
    features: ['Spot Trading', 'Advanced Trading', 'API Access', 'Security']
  };

  const [selectedPair, setSelectedPair] = useState(config.pairs[0]);
  const [currentPrice, setCurrentPrice] = useState(67234.50);
  const [priceChange, setPriceChange] = useState(2.34);
  const [orderType, setOrderType] = useState<'market' | 'limit'>('limit');
  const [side, setSide] = useState<'buy' | 'sell'>('buy');
  const [amount, setAmount] = useState('');
  const [price, setPrice] = useState('');
  const [balance] = useState({ BTC: 0.00234567, USDT: 1234.56 });

  const [orderBook, setOrderBook] = useState<{asks: OrderBookEntry[], bids: OrderBookEntry[]}>({
    asks: [],
    bids: []
  });

  const [recentTrades, setRecentTrades] = useState<Trade[]>([]);
  const [aiSignals, setAiSignals] = useState<AISignal[]>([]);

  useEffect(() => {
    const generateOrderBook = () => {
      const basePrice = currentPrice;
      const asks: OrderBookEntry[] = [];
      const bids: OrderBookEntry[] = [];

      for (let i = 0; i < 15; i++) {
        const askPrice = basePrice + (i + 1) * (Math.random() * 10 + 5);
        const bidPrice = basePrice - (i + 1) * (Math.random() * 10 + 5);
        const askAmount = Math.random() * 2 + 0.1;
        const bidAmount = Math.random() * 2 + 0.1;

        asks.push({
          price: askPrice,
          amount: askAmount,
          total: askPrice * askAmount
        });

        bids.push({
          price: bidPrice,
          amount: bidAmount,
          total: bidPrice * bidAmount
        });
      }

      setOrderBook({ asks, bids });
    };

    const generateTrades = () => {
      const trades: Trade[] = [];
      for (let i = 0; i < 20; i++) {
        trades.push({
          id: `trade_${i}`,
          price: currentPrice + (Math.random() - 0.5) * 100,
          amount: Math.random() * 1 + 0.01,
          side: Math.random() > 0.5 ? 'buy' : 'sell',
          timestamp: new Date(Date.now() - i * 30000)
        });
      }
      setRecentTrades(trades);
    };

    const generateAISignals = () => {
      const signals: AISignal[] = [
        {
          symbol: selectedPair,
          prediction: 'bullish',
          confidence: 0.87,
          timeframe: '4H',
          reasoning: `CerebellumBot vX detected strong accumulation pattern on ${exchangeName}`
        },
        {
          symbol: config.pairs[1] || 'ETH/USDT',
          prediction: 'neutral',
          confidence: 0.62,
          timeframe: '1H',
          reasoning: `Sideways consolidation expected on ${exchangeName}, waiting for breakout`
        },
        {
          symbol: config.pairs[2] || 'BNB/USDT',
          prediction: 'bearish',
          confidence: 0.74,
          timeframe: '15M',
          reasoning: `Volume divergence suggests potential correction on ${exchangeName}`
        }
      ];
      setAiSignals(signals);
    };

    generateOrderBook();
    generateTrades();
    generateAISignals();

    const interval = setInterval(() => {
      setCurrentPrice(prev => prev + (Math.random() - 0.5) * 20);
      setPriceChange(prev => prev + (Math.random() - 0.5) * 0.5);
      generateOrderBook();
      generateTrades();
    }, 2000);

    return () => clearInterval(interval);
  }, [currentPrice, selectedPair, exchangeName, config.pairs]);

  const handlePlaceOrder = () => {
    console.log(`CerebellumBot vX ${exchangeName} Order Execution:`, {
      exchange: exchangeName,
      pair: selectedPair,
      side,
      type: orderType,
      amount,
      price: orderType === 'limit' ? price : 'market',
      stealth: 'PARANOIA_MODE_ACTIVE'
    });
    
    setAmount('');
    setPrice('');
  };

  const getColorClass = (color: string) => {
    const colorMap: Record<string, string> = {
      'blue': 'text-blue-400',
      'yellow': 'text-yellow-400',
      'purple': 'text-purple-400',
      'green': 'text-green-400',
      'cyan': 'text-cyan-400'
    };
    return colorMap[color] || 'text-blue-400';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-gray-800 text-white p-4">
      <div className="matrix-rain"></div>
      <div className="quantum-particles">
        <div className="quantum-particle"></div>
        <div className="quantum-particle"></div>
        <div className="quantum-particle"></div>
      </div>

      <div className="relative z-10 space-y-4">
        <Card className="card-enhanced">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-4">
                <Button 
                  onClick={() => navigate('/exchanges')}
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Back to Exchange Hub
                </Button>
                <div className="flex items-center gap-2">
                  <img 
                    src={config.logo} 
                    alt={config.name} 
                    className="w-8 h-8"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'https://cryptologos.cc/logos/bitcoin-btc-logo.png';
                    }}
                  />
                  <h1 className="text-2xl font-bold">{config.name} Trading Interface</h1>
                </div>
              </div>
              <div className="flex items-center gap-2 text-green-400">
                <Activity className="w-4 h-4" />
                <span className="text-sm">LIVE TRADING</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <select 
                  value={selectedPair}
                  onChange={(e) => setSelectedPair(e.target.value)}
                  className="w-full bg-gray-800 border border-gray-600 rounded px-3 py-2"
                >
                  {config.pairs.map(pair => (
                    <option key={pair} value={pair}>{pair}</option>
                  ))}
                </select>
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-bold">${currentPrice.toFixed(2)}</div>
                <div className={`text-sm flex items-center justify-center gap-1 ${priceChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {priceChange >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                  {priceChange >= 0 ? '+' : ''}{priceChange.toFixed(2)}%
                </div>
              </div>

              <div className="text-right text-sm">
                <div>24h Volume: 45,234 {selectedPair.split('/')[0]}</div>
                <div className="text-gray-400">24h High: $68,450</div>
                <div className="text-gray-400">24h Low: $66,120</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 xl:grid-cols-4 gap-4">
          <Card className="xl:col-span-1 card-enhanced">
            <CardContent className="p-4">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Brain className="w-5 h-5 text-blue-400" />
                CerebellumBot vX Signals
              </h3>
              <div className="space-y-3">
                {aiSignals.map((signal, index) => (
                  <div key={index} className="bg-gray-800 p-3 rounded border border-gray-600">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-mono text-sm">{signal.symbol}</span>
                      <span className={`text-xs px-2 py-1 rounded ${
                        signal.prediction === 'bullish' ? 'bg-green-600' :
                        signal.prediction === 'bearish' ? 'bg-red-600' : 'bg-gray-600'
                      }`}>
                        {signal.prediction.toUpperCase()}
                      </span>
                    </div>
                    <div className="text-xs text-gray-400 mb-1">
                      Confidence: {(signal.confidence * 100).toFixed(0)}% | {signal.timeframe}
                    </div>
                    <div className="text-xs text-gray-300">{signal.reasoning}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="xl:col-span-1 card-enhanced">
            <CardContent className="p-4">
              <h3 className="text-lg font-semibold mb-4">Order Book</h3>
              <div className="space-y-2">
                <div className="text-xs text-gray-400 grid grid-cols-3 gap-2 px-2">
                  <span>Price</span>
                  <span>Amount</span>
                  <span>Total</span>
                </div>
                
                <div className="max-h-32 overflow-y-auto space-y-1">
                  {orderBook.asks.slice(0, 8).reverse().map((ask, index) => (
                    <div key={index} className="text-xs grid grid-cols-3 gap-2 px-2 text-red-400">
                      <span>{ask.price.toFixed(2)}</span>
                      <span>{ask.amount.toFixed(6)}</span>
                      <span>{ask.total.toFixed(2)}</span>
                    </div>
                  ))}
                </div>

                <div className="border-t border-gray-600 pt-2">
                  <div className="text-center text-lg font-bold">${currentPrice.toFixed(2)}</div>
                </div>

                <div className="max-h-32 overflow-y-auto space-y-1">
                  {orderBook.bids.slice(0, 8).map((bid, index) => (
                    <div key={index} className="text-xs grid grid-cols-3 gap-2 px-2 text-green-400">
                      <span>{bid.price.toFixed(2)}</span>
                      <span>{bid.amount.toFixed(6)}</span>
                      <span>{bid.total.toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="xl:col-span-1 card-enhanced">
            <CardContent className="p-4">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Shield className="w-5 h-5 text-green-400" />
                Stealth Trading
              </h3>
              
              <div className="space-y-4">
                <div className="flex gap-2">
                  <Button
                    onClick={() => setSide('buy')}
                    className={`flex-1 ${side === 'buy' ? 'bg-green-600' : 'bg-gray-700'}`}
                  >
                    BUY
                  </Button>
                  <Button
                    onClick={() => setSide('sell')}
                    className={`flex-1 ${side === 'sell' ? 'bg-red-600' : 'bg-gray-700'}`}
                  >
                    SELL
                  </Button>
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => setOrderType('market')}
                    variant={orderType === 'market' ? 'default' : 'outline'}
                    size="sm"
                    className="flex-1"
                  >
                    Market
                  </Button>
                  <Button
                    onClick={() => setOrderType('limit')}
                    variant={orderType === 'limit' ? 'default' : 'outline'}
                    size="sm"
                    className="flex-1"
                  >
                    Limit
                  </Button>
                </div>

                <div className="space-y-2">
                  <div>
                    <label className="text-xs text-gray-400">Amount</label>
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0.00"
                      className="w-full bg-gray-800 border border-gray-600 rounded px-3 py-2 text-sm"
                    />
                  </div>

                  {orderType === 'limit' && (
                    <div>
                      <label className="text-xs text-gray-400">Price</label>
                      <input
                        type="number"
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        placeholder={currentPrice.toFixed(2)}
                        className="w-full bg-gray-800 border border-gray-600 rounded px-3 py-2 text-sm"
                      />
                    </div>
                  )}
                </div>

                <div className="text-xs space-y-1">
                  <div className="flex justify-between">
                    <span>Available {selectedPair.split('/')[0]}:</span>
                    <span>{balance.BTC.toFixed(8)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Available {selectedPair.split('/')[1]}:</span>
                    <span>{balance.USDT.toFixed(2)}</span>
                  </div>
                </div>

                <Button 
                  onClick={handlePlaceOrder}
                  className={`w-full ${side === 'buy' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}`}
                >
                  {side === 'buy' ? 'BUY' : 'SELL'} {selectedPair.split('/')[0]}
                </Button>

                <div className="text-xs text-gray-400 space-y-1">
                  <div>Stealth Mode: ACTIVE</div>
                  <div>Order Obfuscation: ON</div>
                  <div>IP Rotation: ENABLED</div>
                  <div className={`${getColorClass(config.color)}`}>{config.name} Connection: SECURE</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="xl:col-span-1 card-enhanced">
            <CardContent className="p-4">
              <h3 className="text-lg font-semibold mb-4">Recent Trades</h3>
              <div className="space-y-1">
                <div className="text-xs text-gray-400 grid grid-cols-3 gap-2 px-2">
                  <span>Price</span>
                  <span>Amount</span>
                  <span>Time</span>
                </div>
                <div className="max-h-64 overflow-y-auto space-y-1">
                  {recentTrades.map((trade) => (
                    <div 
                      key={trade.id} 
                      className={`text-xs grid grid-cols-3 gap-2 px-2 ${
                        trade.side === 'buy' ? 'text-green-400' : 'text-red-400'
                      }`}
                    >
                      <span>{trade.price.toFixed(2)}</span>
                      <span>{trade.amount.toFixed(6)}</span>
                      <span>{trade.timestamp.toLocaleTimeString()}</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="card-enhanced">
          <CardContent className="p-4">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Brain className="w-5 h-5 text-blue-400" />
              CerebellumBot vX {config.name} Analytics
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-gray-800 p-3 rounded">
                <div className="text-sm text-gray-400">24h PnL</div>
                <div className="text-xl font-bold text-green-400">+$2,847.32</div>
                <div className="text-xs text-gray-500">+4.23%</div>
              </div>
              <div className="bg-gray-800 p-3 rounded">
                <div className="text-sm text-gray-400">Win Rate</div>
                <div className="text-xl font-bold text-blue-400">87.3%</div>
                <div className="text-xs text-gray-500">Last 100 trades</div>
              </div>
              <div className="bg-gray-800 p-3 rounded">
                <div className="text-sm text-gray-400">Active Orders</div>
                <div className="text-xl font-bold text-yellow-400">12</div>
                <div className="text-xs text-gray-500">Stealth execution</div>
              </div>
              <div className="bg-gray-800 p-3 rounded">
                <div className="text-sm text-gray-400">Anonymity Score</div>
                <div className="text-xl font-bold text-purple-400">98.7%</div>
                <div className="text-xs text-gray-500">Maximum stealth</div>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-2">
              <div className="text-xs text-gray-400">Features:</div>
              {config.features.map((feature, index) => (
                <div key={index} className={`text-xs px-2 py-1 rounded bg-gray-700 ${getColorClass(config.color)}`}>
                  {feature}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default GenericExchangeInterface;
