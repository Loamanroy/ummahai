
import { Routes, Route, useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Activity, Brain, Shield, TrendingUp } from 'lucide-react';
import BinanceInterface from './BinanceInterface';
import GenericExchangeInterface from './interfaces/GenericExchangeInterface';

/**
 * ExchangeRouter - Main routing component for exchange interfaces
 * 
 * Provides navigation and routing for all supported cryptocurrency exchanges.
 * Displays an exchange selection grid when no specific exchange is selected,
 * and routes to specific exchange interfaces when an exchange is chosen.
 * 
 * Features:
 * - Multi-exchange selection grid with live status indicators
 * - CerebellumBot vX analytics dashboard
 * - Stealth mode status monitoring
 * - Quick action buttons for common operations
 * 
 * @returns {JSX.Element} - Exchange router with selection grid or specific exchange interface
 */
const ExchangeRouter = () => {
  const navigate = useNavigate();
  const { exchangeName } = useParams();

  const exchanges = [
    'Binance', 'OKX', 'Bybit', 'Kraken', 'Bitfinex', 'Coinbase', 
    'Gemini', 'KuCoin', 'Bitstamp', 'Poloniex', 'Huobi', 'Bittrex', 
    'Gate.io', 'Deribit', 'Upbit', 'Liquid', 'Coincheck', 'ZB.com', 
    'BitFlyer', 'MEXC'
  ];

  /**
   * Handles navigation to a specific exchange interface
   * @param {string} exchange - Name of the exchange to navigate to
   */
  const handleExchangeClick = (exchange: string) => {
    navigate(`/exchanges/${exchange}`);
  };

  /**
   * ExchangeSelectionGrid - Grid component displaying all available exchanges
   * 
   * Renders a comprehensive dashboard showing:
   * - All 20 supported exchanges with live status
   * - CerebellumBot vX analytics and performance metrics
   * - Stealth mode and security status indicators
   * - Quick action buttons for common operations
   * 
   * @returns {JSX.Element} - Exchange selection grid interface
   */
  const ExchangeSelectionGrid = () => (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-gray-800 text-white p-4">
      <div className="matrix-rain"></div>
      <div className="quantum-particles">
        <div className="quantum-particle"></div>
        <div className="quantum-particle"></div>
        <div className="quantum-particle"></div>
      </div>

      <div className="relative z-10 space-y-6">
        <Card className="card-enhanced">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <Button 
                  onClick={() => navigate('/')}
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Back to Dashboard
                </Button>
                <div className="flex items-center gap-2">
                  <Brain className="w-8 h-8 text-blue-400" />
                  <h1 className="text-3xl font-bold">CerebellumBot vX Exchange Hub</h1>
                </div>
              </div>
              <div className="flex items-center gap-2 text-green-400">
                <Activity className="w-4 h-4" />
                <span className="text-sm">ALL SYSTEMS OPERATIONAL</span>
              </div>
            </div>

            <div className="bg-gray-800 p-4 rounded border border-gray-600 mb-6">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="w-5 h-5 text-green-400" />
                <span className="font-semibold">Multi-Exchange Stealth Status</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
                <div className="flex justify-between">
                  <span>Active Connections:</span>
                  <span className="text-green-400">20/20</span>
                </div>
                <div className="flex justify-between">
                  <span>Stealth Mode:</span>
                  <span className="text-green-400">ACTIVE</span>
                </div>
                <div className="flex justify-between">
                  <span>IP Rotation:</span>
                  <span className="text-blue-400">ENABLED</span>
                </div>
                <div className="flex justify-between">
                  <span>Anonymity Score:</span>
                  <span className="text-purple-400">98.7%</span>
                </div>
              </div>
            </div>

            <div className="mb-4">
              <h2 className="text-xl font-semibold mb-2">Select Exchange Platform</h2>
              <p className="text-gray-400 text-sm">
                CerebellumBot vX operates across all major exchanges with maximum stealth and anonymity.
                Click on any exchange to access its dedicated trading interface.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="card-enhanced">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">Exchange Network Status</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-10 gap-3">
              {exchanges.map((exchange) => (
                <div 
                  key={exchange} 
                  className="bg-gray-800 p-3 rounded text-center cursor-pointer hover:bg-gray-700 transition-all duration-200 border border-gray-600 hover:border-gray-500 transform hover:scale-105"
                  onClick={() => handleExchangeClick(exchange)}
                >
                  <div className="text-sm font-mono mb-1">{exchange}</div>
                  <div className="text-green-400 text-xs flex items-center justify-center gap-1">
                    <Activity className="w-3 h-3" />
                    LIVE
                  </div>
                  <div className="text-xs text-gray-400 mt-1">
                    Full Interface
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="card-enhanced">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Brain className="w-5 h-5 text-blue-400" />
              CerebellumBot vX Multi-Exchange Analytics
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <div className="bg-gray-800 p-3 rounded border border-gray-600">
                <div className="text-sm text-gray-400">Total Volume 24h</div>
                <div className="text-xl font-bold text-green-400">$2.4M</div>
                <div className="text-xs text-gray-500 flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" />
                  +12.3%
                </div>
              </div>
              <div className="bg-gray-800 p-3 rounded border border-gray-600">
                <div className="text-sm text-gray-400">Active Trades</div>
                <div className="text-xl font-bold text-blue-400">847</div>
                <div className="text-xs text-gray-500">Across all exchanges</div>
              </div>
              <div className="bg-gray-800 p-3 rounded border border-gray-600">
                <div className="text-sm text-gray-400">Win Rate</div>
                <div className="text-xl font-bold text-purple-400">89.2%</div>
                <div className="text-xs text-gray-500">Last 1000 trades</div>
              </div>
              <div className="bg-gray-800 p-3 rounded border border-gray-600">
                <div className="text-sm text-gray-400">Profit Today</div>
                <div className="text-xl font-bold text-green-400">+$8,432</div>
                <div className="text-xs text-gray-500">+5.67%</div>
              </div>
              <div className="bg-gray-800 p-3 rounded border border-gray-600">
                <div className="text-sm text-gray-400">Stealth Score</div>
                <div className="text-xl font-bold text-yellow-400">98.7%</div>
                <div className="text-xs text-gray-500">Maximum anonymity</div>
              </div>
              <div className="bg-gray-800 p-3 rounded border border-gray-600">
                <div className="text-sm text-gray-400">Uptime</div>
                <div className="text-xl font-bold text-cyan-400">99.98%</div>
                <div className="text-xs text-gray-500">30 days</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-enhanced">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button 
                onClick={() => handleExchangeClick('Binance')}
                className="bg-yellow-600 hover:bg-yellow-700 text-black font-bold p-4 h-auto flex flex-col items-center gap-2"
              >
                <span className="text-lg">Launch Binance Interface</span>
                <span className="text-sm opacity-80">Full trading capabilities</span>
              </Button>
              <Button 
                variant="outline"
                className="border-gray-600 hover:bg-gray-800 p-4 h-auto flex flex-col items-center gap-2"
                onClick={() => navigate('/')}
              >
                <span className="text-lg">Return to Dashboard</span>
                <span className="text-sm opacity-80">Main control center</span>
              </Button>
              <Button 
                variant="outline"
                className="border-blue-600 hover:bg-blue-900 p-4 h-auto flex flex-col items-center gap-2"
                onClick={() => navigate('/exchanges/multi-view')}
              >
                <span className="text-lg">Multi-Exchange View</span>
                <span className="text-sm opacity-80">Advanced Trading</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );



  if (!exchangeName) {
    return <ExchangeSelectionGrid />;
  }

  return (
    <Routes>
      <Route path="/Binance" element={<BinanceInterface />} />
      <Route path="/OKX" element={<GenericExchangeInterface exchangeName="OKX" />} />
      <Route path="/Bybit" element={<GenericExchangeInterface exchangeName="Bybit" />} />
      <Route path="/Kraken" element={<GenericExchangeInterface exchangeName="Kraken" />} />
      <Route path="/Bitfinex" element={<GenericExchangeInterface exchangeName="Bitfinex" />} />
      <Route path="/Coinbase" element={<GenericExchangeInterface exchangeName="Coinbase" />} />
      <Route path="/Gemini" element={<GenericExchangeInterface exchangeName="Gemini" />} />
      <Route path="/KuCoin" element={<GenericExchangeInterface exchangeName="KuCoin" />} />
      <Route path="/Bitstamp" element={<GenericExchangeInterface exchangeName="Bitstamp" />} />
      <Route path="/Poloniex" element={<GenericExchangeInterface exchangeName="Poloniex" />} />
      <Route path="/Huobi" element={<GenericExchangeInterface exchangeName="Huobi" />} />
      <Route path="/Bittrex" element={<GenericExchangeInterface exchangeName="Bittrex" />} />
      <Route path="/Gate.io" element={<GenericExchangeInterface exchangeName="Gate.io" />} />
      <Route path="/Deribit" element={<GenericExchangeInterface exchangeName="Deribit" />} />
      <Route path="/Upbit" element={<GenericExchangeInterface exchangeName="Upbit" />} />
      <Route path="/Liquid" element={<GenericExchangeInterface exchangeName="Liquid" />} />
      <Route path="/Coincheck" element={<GenericExchangeInterface exchangeName="Coincheck" />} />
      <Route path="/ZB.com" element={<GenericExchangeInterface exchangeName="ZB.com" />} />
      <Route path="/BitFlyer" element={<GenericExchangeInterface exchangeName="BitFlyer" />} />
      <Route path="/MEXC" element={<GenericExchangeInterface exchangeName="MEXC" />} />
      <Route path="/:exchange" element={<GenericExchangeInterface exchangeName={exchangeName || 'Unknown'} />} />
    </Routes>
  );
};

export default ExchangeRouter;
