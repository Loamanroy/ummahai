import React, { useEffect, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Points, PointMaterial } from '@react-three/drei';
import * as THREE from 'three';

/**
 * Props for the StarField component
 */
interface StarFieldProps {
  /** Number of stars to render (default: 5000) */
  count?: number;
}

/**
 * StarField - 3D star field component using Three.js
 * 
 * Renders a field of animated stars in 3D space with rotation effects.
 * Uses React Three Fiber for WebGL rendering and performance optimization.
 * 
 * @param props - Component props
 * @param props.count - Number of stars to render
 * @returns JSX.Element - Rendered 3D star field
 */
const StarField: React.FC<StarFieldProps> = ({ count = 5000 }) => {
  const ref = useRef<THREE.Points>(null);
  
  const positions = React.useMemo(() => {
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 2000;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 2000;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 2000;
    }
    return positions;
  }, [count]);

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.x = state.clock.elapsedTime * 0.0001;
      ref.current.rotation.y = state.clock.elapsedTime * 0.0002;
    }
  });

  return (
    <Points ref={ref} positions={positions} stride={3} frustumCulled={false}>
      <PointMaterial
        transparent
        color="#4fc3f7"
        size={2}
        sizeAttenuation={true}
        depthWrite={false}
      />
    </Points>
  );
};

/**
 * Props for the Nebula component
 */
interface NebulaProps {
  /** 3D position coordinates [x, y, z] */
  position: [number, number, number];
  /** Color of the nebula effect */
  color: string;
}

/**
 * Nebula - 3D nebula effect component
 * 
 * Creates animated nebula clouds with transparency and additive blending.
 * Provides atmospheric depth to the space background scene.
 * 
 * @param props - Component props
 * @param props.position - 3D position coordinates
 * @param props.color - Nebula color
 * @returns JSX.Element - Rendered 3D nebula effect
 */
const Nebula: React.FC<NebulaProps> = ({ position, color }) => {
  const ref = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.z = state.clock.elapsedTime * 0.001;
      const material = ref.current.material as THREE.MeshBasicMaterial;
      if (material) {
        material.opacity = 0.3 + Math.sin(state.clock.elapsedTime * 0.5) * 0.1;
      }
    }
  });

  return (
    <mesh ref={ref} position={position}>
      <planeGeometry args={[500, 500]} />
      <meshBasicMaterial
        color={color}
        transparent
        opacity={0.3}
        blending={THREE.AdditiveBlending}
      />
    </mesh>
  );
};

/**
 * SpaceBackground - Immersive space-themed background component
 * 
 * Creates a multi-layered space environment with:
 * - Animated 2D star field with canvas rendering
 * - 3D WebGL star field and nebula effects
 * - Gradient backgrounds and atmospheric effects
 * - Responsive design with window resize handling
 * 
 * @returns JSX.Element - Complete space background with multiple visual layers
 */
const SpaceBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const stars: Array<{ x: number; y: number; size: number; opacity: number; speed: number }> = [];
    
    for (let i = 0; i < 200; i++) {
      stars.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 2 + 0.5,
        opacity: Math.random() * 0.8 + 0.2,
        speed: Math.random() * 0.5 + 0.1
      });
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      const gradient = ctx.createRadialGradient(
        canvas.width / 2, canvas.height / 2, 0,
        canvas.width / 2, canvas.height / 2, Math.max(canvas.width, canvas.height)
      );
      gradient.addColorStop(0, '#0a0a1a');
      gradient.addColorStop(0.5, '#1a1a2e');
      gradient.addColorStop(1, '#16213e');
      
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      stars.forEach(star => {
        ctx.save();
        ctx.globalAlpha = star.opacity;
        ctx.fillStyle = '#4fc3f7';
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#4fc3f7';
        
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.restore();

        star.y += star.speed;
        star.opacity = 0.2 + Math.sin(Date.now() * 0.001 + star.x) * 0.6;
        
        if (star.y > canvas.height) {
          star.y = -10;
          star.x = Math.random() * canvas.width;
        }
      });

      requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="fixed inset-0 z-[-2]">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ background: 'linear-gradient(45deg, #0f3460, #16537e, #1e88e5)' }}
      />
      
      <div className="absolute inset-0 z-[-1]">
        <Canvas camera={{ position: [0, 0, 1], fov: 75 }}>
          <StarField count={3000} />
          <Nebula position={[-200, 100, -500]} color="#4fc3f7" />
          <Nebula position={[300, -150, -600]} color="#2196f3" />
          <Nebula position={[0, 200, -400]} color="#64b5f6" />
        </Canvas>
      </div>

      {/* Additional space effects */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-blue-400 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute top-3/4 right-1/4 w-24 h-24 bg-cyan-300 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-1/2 left-3/4 w-16 h-16 bg-blue-300 rounded-full blur-xl animate-pulse" style={{ animationDelay: '4s' }}></div>
      </div>
    </div>
  );
};

export default SpaceBackground;
