import React, { useEffect, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface GridLinesProps {
  color?: string;
}

const GridLines: React.FC<GridLinesProps> = ({ color = '#ff0080' }) => {
  const ref = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.1) * 0.1;
      ref.current.position.z = (state.clock.elapsedTime * 10) % 100 - 50;
    }
  });

  const createLine = (key: string, positions: number[]) => {
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    
    return (
      <primitive key={key} object={new THREE.Line(geometry, new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.3 }))} />
    );
  };

  const lines = [];
  for (let i = -50; i <= 50; i += 5) {
    lines.push(createLine(`v${i}`, [i, -50, 0, i, 50, 0]));
    lines.push(createLine(`h${i}`, [-50, i, 0, 50, i, 0]));
  }

  return <group ref={ref}>{lines}</group>;
};

interface NeonCubeProps {
  position: [number, number, number];
  color: string;
}

const NeonCube: React.FC<NeonCubeProps> = ({ position, color }) => {
  const ref = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.x = state.clock.elapsedTime * 0.5;
      ref.current.rotation.y = state.clock.elapsedTime * 0.3;
      const material = ref.current.material as THREE.MeshBasicMaterial;
      if (material) {
        material.opacity = 0.5 + Math.sin(state.clock.elapsedTime * 2) * 0.3;
      }
    }
  });

  return (
    <mesh ref={ref} position={position}>
      <boxGeometry args={[2, 2, 2]} />
      <meshBasicMaterial
        color={color}
        transparent
        opacity={0.5}
        wireframe
      />
    </mesh>
  );
};

const CyberpunkBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const digitalRain: Array<{
      x: number;
      y: number;
      speed: number;
      chars: string[];
      opacity: number;
    }> = [];

    const characters = '01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン';
    
    for (let i = 0; i < 50; i++) {
      digitalRain.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        speed: Math.random() * 3 + 1,
        chars: Array.from({ length: 20 }, () => characters[Math.floor(Math.random() * characters.length)]),
        opacity: Math.random() * 0.8 + 0.2
      });
    }

    const glitchLines: Array<{
      y: number;
      width: number;
      opacity: number;
      color: string;
      duration: number;
      startTime: number;
    }> = [];

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
      gradient.addColorStop(0, '#0d0208');
      gradient.addColorStop(0.5, '#1a0e1a');
      gradient.addColorStop(1, '#2d1b2d');
      
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.strokeStyle = '#ff008020';
      ctx.lineWidth = 1;
      const gridSize = 50;
      
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      digitalRain.forEach(drop => {
        ctx.save();
        ctx.globalAlpha = drop.opacity;
        ctx.fillStyle = '#00ff41';
        ctx.font = '12px monospace';
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#00ff41';
        
        drop.chars.forEach((char, index) => {
          const charY = drop.y + index * 15;
          if (charY > 0 && charY < canvas.height + 100) {
            ctx.globalAlpha = drop.opacity * (1 - index / drop.chars.length);
            ctx.fillText(char, drop.x, charY);
          }
        });
        
        ctx.restore();

        drop.y += drop.speed;
        if (drop.y > canvas.height + 300) {
          drop.y = -300;
          drop.x = Math.random() * canvas.width;
          drop.chars = Array.from({ length: 20 }, () => characters[Math.floor(Math.random() * characters.length)]);
        }
      });

      if (Math.random() < 0.02) {
        glitchLines.push({
          y: Math.random() * canvas.height,
          width: Math.random() * canvas.width,
          opacity: Math.random() * 0.8 + 0.2,
          color: Math.random() > 0.5 ? '#ff0080' : '#00ffff',
          duration: Math.random() * 200 + 100,
          startTime: Date.now()
        });
      }

      glitchLines.forEach((line, index) => {
        const elapsed = Date.now() - line.startTime;
        if (elapsed < line.duration) {
          ctx.save();
          ctx.globalAlpha = line.opacity * (1 - elapsed / line.duration);
          ctx.fillStyle = line.color;
          ctx.fillRect(0, line.y, line.width, 2);
          ctx.restore();
        } else {
          glitchLines.splice(index, 1);
        }
      });

      requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="fixed inset-0 z-[-2]">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ background: 'linear-gradient(45deg, #0d0208, #1a0e1a, #2d1b2d)' }}
      />
      
      <div className="absolute inset-0 z-[-1]">
        <Canvas camera={{ position: [0, 0, 10], fov: 75 }}>
          <GridLines color="#ff0080" />
          <NeonCube position={[-5, 2, -10]} color="#00ff41" />
          <NeonCube position={[3, -1, -8]} color="#ff0080" />
          <NeonCube position={[0, 3, -12]} color="#00ffff" />
        </Canvas>
      </div>

      {/* Neon glow effects */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-pink-500 to-transparent animate-pulse"></div>
        <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute left-0 top-0 w-1 h-full bg-gradient-to-b from-transparent via-green-400 to-transparent animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute right-0 top-0 w-1 h-full bg-gradient-to-b from-transparent via-pink-500 to-transparent animate-pulse" style={{ animationDelay: '3s' }}></div>
      </div>

      {/* Scanning line effect */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute w-full h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent opacity-60 animate-bounce" style={{ 
          top: '0%',
          animation: 'scan-line 4s linear infinite'
        }}></div>
      </div>


    </div>
  );
};

export default CyberpunkBackground;
