import React, { useEffect, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface BuildingProps {
  position: [number, number, number];
  height: number;
  color: string;
}

const Building: React.FC<BuildingProps> = ({ position, height, color }) => {
  const ref = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (ref.current) {
      const intensity = 0.5 + Math.sin(state.clock.elapsedTime * 2 + position[0]) * 0.3;
      const material = ref.current.material as THREE.MeshBasicMaterial;
      if (material) {
        material.opacity = intensity;
      }
    }
  });

  return (
    <mesh ref={ref} position={position}>
      <boxGeometry args={[2, height, 2]} />
      <meshBasicMaterial
        color={color}
        transparent
        opacity={0.7}
      />
    </mesh>
  );
};

interface CircuitLineProps {
  start: [number, number, number];
  end: [number, number, number];
  color: string;
}

const CircuitLine: React.FC<CircuitLineProps> = ({ start, end, color }) => {
  const lineRef = useRef<THREE.Line>(null);

  useFrame((state) => {
    if (lineRef.current) {
      const material = lineRef.current.material as THREE.LineBasicMaterial;
      if (material) {
        material.opacity = 0.3 + Math.sin(state.clock.elapsedTime * 3) * 0.4;
      }
    }
  });

  const geometry = React.useMemo(() => {
    const geom = new THREE.BufferGeometry();
    geom.setAttribute('position', new THREE.Float32BufferAttribute([...start, ...end], 3));
    return geom;
  }, [start, end]);

  const material = React.useMemo(() => {
    return new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.5 });
  }, [color]);

  return <primitive ref={lineRef} object={new THREE.Line(geometry, material)} />;
};

const SmartCityBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const dataNodes: Array<{
      x: number;
      y: number;
      size: number;
      color: string;
      pulseSpeed: number;
      connections: Array<{ x: number; y: number }>;
    }> = [];

    const trafficFlow: Array<{
      x: number;
      y: number;
      targetX: number;
      targetY: number;
      speed: number;
      color: string;
    }> = [];

    for (let i = 0; i < 20; i++) {
      const node = {
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 8 + 4,
        color: Math.random() > 0.5 ? '#00e676' : '#4caf50',
        pulseSpeed: Math.random() * 2 + 1,
        connections: [] as Array<{ x: number; y: number }>
      };
      
      for (let j = 0; j < 3; j++) {
        node.connections.push({
          x: node.x + (Math.random() - 0.5) * 200,
          y: node.y + (Math.random() - 0.5) * 200
        });
      }
      
      dataNodes.push(node);
    }

    for (let i = 0; i < 15; i++) {
      trafficFlow.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        targetX: Math.random() * canvas.width,
        targetY: Math.random() * canvas.height,
        speed: Math.random() * 2 + 0.5,
        color: '#00e676'
      });
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
      gradient.addColorStop(0, '#0a1428');
      gradient.addColorStop(0.5, '#1e2a3a');
      gradient.addColorStop(1, '#2a3f5f');
      
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.strokeStyle = '#00e67620';
      ctx.lineWidth = 1;
      const circuitSize = 80;
      
      for (let x = 0; x < canvas.width; x += circuitSize) {
        for (let y = 0; y < canvas.height; y += circuitSize) {
          ctx.beginPath();
          ctx.arc(x, y, 2, 0, Math.PI * 2);
          ctx.fillStyle = '#00e676';
          ctx.fill();
          
          if (x + circuitSize < canvas.width) {
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(x + circuitSize, y);
            ctx.stroke();
          }
          
          if (y + circuitSize < canvas.height) {
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(x, y + circuitSize);
            ctx.stroke();
          }
        }
      }

      dataNodes.forEach(node => {
        ctx.strokeStyle = '#4caf5040';
        ctx.lineWidth = 1;
        node.connections.forEach(connection => {
          ctx.beginPath();
          ctx.moveTo(node.x, node.y);
          ctx.lineTo(connection.x, connection.y);
          ctx.stroke();
        });

        const pulseSize = node.size + Math.sin(Date.now() * 0.001 * node.pulseSpeed) * 3;
        ctx.save();
        ctx.fillStyle = node.color;
        ctx.shadowBlur = 15;
        ctx.shadowColor = node.color;
        
        ctx.beginPath();
        ctx.arc(node.x, node.y, pulseSize, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.restore();
      });

      trafficFlow.forEach(traffic => {
        const dx = traffic.targetX - traffic.x;
        const dy = traffic.targetY - traffic.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance > 5) {
          traffic.x += (dx / distance) * traffic.speed;
          traffic.y += (dy / distance) * traffic.speed;
        } else {
          traffic.targetX = Math.random() * canvas.width;
          traffic.targetY = Math.random() * canvas.height;
        }

        ctx.save();
        ctx.fillStyle = traffic.color;
        ctx.shadowBlur = 8;
        ctx.shadowColor = traffic.color;
        
        ctx.beginPath();
        ctx.arc(traffic.x, traffic.y, 3, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.restore();

        ctx.strokeStyle = traffic.color + '40';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(traffic.x, traffic.y);
        ctx.lineTo(traffic.x - dx * 0.1, traffic.y - dy * 0.1);
        ctx.stroke();
      });

      requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="fixed inset-0 z-[-2]">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ background: 'linear-gradient(180deg, #1e3c72, #2a5298, #4caf50)' }}
      />
      
      <div className="absolute inset-0 z-[-1]">
        <Canvas camera={{ position: [0, 5, 15], fov: 75 }}>
          {/* City skyline */}
          <Building position={[-8, 0, -5]} height={12} color="#00e676" />
          <Building position={[-4, 0, -3]} height={8} color="#4caf50" />
          <Building position={[0, 0, -4]} height={15} color="#00e676" />
          <Building position={[4, 0, -2]} height={10} color="#4caf50" />
          <Building position={[8, 0, -6]} height={6} color="#00e676" />
          
          {/* Circuit connections */}
          <CircuitLine start={[-8, 6, -5]} end={[-4, 4, -3]} color="#00e676" />
          <CircuitLine start={[-4, 4, -3]} end={[0, 7.5, -4]} color="#4caf50" />
          <CircuitLine start={[0, 7.5, -4]} end={[4, 5, -2]} color="#00e676" />
          <CircuitLine start={[4, 5, -2]} end={[8, 3, -6]} color="#4caf50" />
        </Canvas>
      </div>

      {/* Smart city UI elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-10 left-10 w-32 h-1 bg-green-400 animate-pulse"></div>
        <div className="absolute top-20 left-10 w-24 h-1 bg-green-500 animate-pulse" style={{ animationDelay: '0.5s' }}></div>
        <div className="absolute top-30 left-10 w-16 h-1 bg-green-300 animate-pulse" style={{ animationDelay: '1s' }}></div>
        
        <div className="absolute bottom-10 right-10 w-32 h-1 bg-green-400 animate-pulse" style={{ animationDelay: '1.5s' }}></div>
        <div className="absolute bottom-20 right-10 w-24 h-1 bg-green-500 animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute bottom-30 right-10 w-16 h-1 bg-green-300 animate-pulse" style={{ animationDelay: '2.5s' }}></div>
      </div>

      {/* Data flow indicators */}
      <div className="absolute top-1/2 left-4 transform -translate-y-1/2">
        <div className="flex flex-col space-y-2">
          {[...Array(8)].map((_, i) => (
            <div
              key={i}
              className="w-2 h-2 bg-green-400 rounded-full animate-ping"
              style={{ animationDelay: `${i * 0.2}s` }}
            ></div>
          ))}
        </div>
      </div>

      <div className="absolute top-1/2 right-4 transform -translate-y-1/2">
        <div className="flex flex-col space-y-2">
          {[...Array(8)].map((_, i) => (
            <div
              key={i}
              className="w-2 h-2 bg-green-500 rounded-full animate-ping"
              style={{ animationDelay: `${i * 0.3}s` }}
            ></div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SmartCityBackground;
