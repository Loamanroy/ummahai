import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Clock, MapPin, Sun, Moon } from 'lucide-react';

/**
 * Represents a prayer time entry with name, time, and Arabic text
 */
interface PrayerTime {
  /** English name of the prayer */
  name: string;
  /** Time in HH:MM format */
  time: string;
  /** Arabic name of the prayer */
  arabic: string;
}

/**
 * Weather data structure containing current conditions and location
 */
interface WeatherData {
  /** Current temperature in Celsius */
  temperature: number;
  /** Weather condition description */
  description: string;
  /** Humidity percentage */
  humidity: number;
  /** Wind speed in m/s */
  windSpeed: number;
  /** City name */
  city: string;
  /** Country name or code */
  country: string;
}

/**
 * RealTimeWidget - Displays real-time clock, weather, and prayer times
 * 
 * A comprehensive widget that shows current time with UTC, local weather conditions,
 * and Islamic prayer times based on user's geolocation. Features automatic location
 * detection with fallback to IP-based location and multiple weather API sources.
 * 
 * @returns {JSX.Element} - Rendered real-time widget with three cards
 */
const RealTimeWidget = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [prayerTimes, setPrayerTimes] = useState<PrayerTime[]>([]);
  const [location, setLocation] = useState<{ lat: number; lon: number } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lon: position.coords.longitude
          });
        },
        (error) => {
          console.error('Error getting location:', error);
          fetch('https://ipapi.co/json/')
            .then(response => response.json())
            .then(data => {
              if (data.latitude && data.longitude) {
                setLocation({
                  lat: data.latitude,
                  lon: data.longitude
                });
              } else {
                setLocation({ lat: 51.4769, lon: -0.0005 });
              }
            })
            .catch(() => {
              setLocation({ lat: 51.4769, lon: -0.0005 });
            });
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 300000
        }
      );
    } else {
      fetch('https://ipapi.co/json/')
        .then(response => response.json())
        .then(data => {
          if (data.latitude && data.longitude) {
            setLocation({
              lat: data.latitude,
              lon: data.longitude
            });
          } else {
            setLocation({ lat: 51.4769, lon: -0.0005 });
          }
        })
        .catch(() => {
          setLocation({ lat: 51.4769, lon: -0.0005 });
        });
    }
  }, []);

  useEffect(() => {
    if (location) {
      fetchWeather(location.lat, location.lon);
    }
  }, [location]);

  useEffect(() => {
    if (location) {
      fetchPrayerTimes(location.lat, location.lon);
    }
  }, [location]);

  const fetchWeather = async (lat: number, lon: number) => {
    try {
      const weatherApis = [
        `https://wttr.in/${lat},${lon}?format=j1`,
        `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&hourly=temperature_2m,relativehumidity_2m,windspeed_10m&timezone=auto`
      ];

      for (const apiUrl of weatherApis) {
        try {
          const response = await fetch(apiUrl);
          
          if (response.ok) {
            const data = await response.json();
            
            if (data.current_weather && data.hourly) {
              setWeather({
                temperature: Math.round(data.current_weather.temperature),
                description: getWeatherDescription(data.current_weather.weathercode),
                humidity: data.hourly.relativehumidity_2m ? data.hourly.relativehumidity_2m[0] : 50,
                windSpeed: data.current_weather.windspeed / 3.6,
                city: 'Location',
                country: 'Unknown'
              });
              return;
            }
            
            if (data.current_condition && data.nearest_area) {
              const current = data.current_condition[0];
              const area = data.nearest_area[0];
              setWeather({
                temperature: Math.round(parseInt(current.temp_C)),
                description: current.weatherDesc[0].value.toLowerCase(),
                humidity: parseInt(current.humidity),
                windSpeed: parseInt(current.windspeedKmph) / 3.6, // Convert to m/s
                city: area.areaName[0].value,
                country: area.country[0].value
              });
              return;
            }
          }
        } catch (apiError) {
          console.warn(`Weather API failed: ${apiUrl}`, apiError);
          continue;
        }
      }
      
      try {
        const geoResponse = await fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lon}&localityLanguage=en`);
        if (geoResponse.ok) {
          const geoData = await geoResponse.json();
          setWeather({
            temperature: 20, // Default temperature
            description: 'weather data unavailable',
            humidity: 50,
            windSpeed: 0,
            city: geoData.city || geoData.locality || 'Unknown',
            country: geoData.countryCode || 'Unknown'
          });
        } else {
          throw new Error('Geocoding failed');
        }
      } catch (geoError) {
        console.error('All weather and geocoding services failed:', geoError);
        setWeather({
          temperature: 20,
          description: 'weather data unavailable',
          humidity: 50,
          windSpeed: 0,
          city: 'Location Unknown',
          country: 'Unknown'
        });
      }
    } catch (error) {
      console.error('Weather fetch error:', error);
      setWeather({
        temperature: 20,
        description: 'weather data unavailable',
        humidity: 50,
        windSpeed: 0,
        city: 'Location Unknown',
        country: 'Unknown'
      });
    }
  };

  const fetchPrayerTimes = async (lat: number, lon: number) => {
    try {
      const today = new Date();
      const dateString = `${today.getDate()}-${today.getMonth() + 1}-${today.getFullYear()}`;
      
      const response = await fetch(
        `https://api.aladhan.com/v1/timings/${dateString}?latitude=${lat}&longitude=${lon}&method=2`
      );
      
      if (response.ok) {
        const data = await response.json();
        const timings = data.data.timings;
        
        setPrayerTimes([
          { name: 'Fajr', time: timings.Fajr, arabic: 'الفجر' },
          { name: 'Dhuhr', time: timings.Dhuhr, arabic: 'الظهر' },
          { name: 'Asr', time: timings.Asr, arabic: 'العصر' },
          { name: 'Maghrib', time: timings.Maghrib, arabic: 'المغرب' },
          { name: 'Isha', time: timings.Isha, arabic: 'العشاء' }
        ]);
      } else {
        console.log('Prayer times API failed, using fallback data');
        setPrayerTimes([
          { name: 'Fajr', time: '05:30', arabic: 'الفجر' },
          { name: 'Dhuhr', time: '12:15', arabic: 'الظهر' },
          { name: 'Asr', time: '15:45', arabic: 'العصر' },
          { name: 'Maghrib', time: '18:20', arabic: 'المغرب' },
          { name: 'Isha', time: '19:50', arabic: 'العشاء' }
        ]);
      }
    } catch (error) {
      console.error('Prayer times fetch error:', error);
      setPrayerTimes([
        { name: 'Fajr', time: '05:30', arabic: 'الفجر' },
        { name: 'Dhuhr', time: '12:15', arabic: 'الظهر' },
        { name: 'Asr', time: '15:45', arabic: 'العصر' },
        { name: 'Maghrib', time: '18:20', arabic: 'المغرب' },
        { name: 'Isha', time: '19:50', arabic: 'العشاء' }
      ]);
    }
    setLoading(false);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getWeatherDescription = (weatherCode: number): string => {
    const weatherCodes: { [key: number]: string } = {
      0: 'clear sky',
      1: 'mainly clear',
      2: 'partly cloudy',
      3: 'overcast',
      45: 'fog',
      48: 'depositing rime fog',
      51: 'light drizzle',
      53: 'moderate drizzle',
      55: 'dense drizzle',
      61: 'slight rain',
      63: 'moderate rain',
      65: 'heavy rain',
      71: 'slight snow',
      73: 'moderate snow',
      75: 'heavy snow',
      95: 'thunderstorm'
    };
    return weatherCodes[weatherCode] || 'unknown weather';
  };

  const getNextPrayer = () => {
    const now = new Date();
    const currentTime = now.getHours() * 60 + now.getMinutes();
    
    for (const prayer of prayerTimes) {
      const [hours, minutes] = prayer.time.split(':').map(Number);
      const prayerTime = hours * 60 + minutes;
      
      if (prayerTime > currentTime) {
        return prayer;
      }
    }
    
    return prayerTimes[0];
  };

  const nextPrayer = getNextPrayer();

  if (loading) {
    return (
      <Card className="card-enhanced pulse-border">
        <CardContent className="p-4">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400"></div>
            <span className="ml-2 glow-text">Loading real-time data...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {/* Real-time Clock */}
      <Card className="card-enhanced pulse-border hover:scale-105 transition-all duration-300">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Clock className="w-5 h-5 text-blue-400" />
            <h3 className="font-semibold glow-text">Real-Time Clock</h3>
          </div>
          <div className="text-center">
            <div className="text-3xl font-mono font-bold text-green-400 mb-2 glow-text-green">
              {formatTime(currentTime)}
            </div>
            <div className="text-sm text-gray-400 glow-text">
              {formatDate(currentTime)}
            </div>
            <div className="text-xs text-gray-500 mt-1">
              UTC {currentTime.toISOString().slice(11, 19)}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Weather Widget */}
      <Card className="card-enhanced pulse-border hover:scale-105 transition-all duration-300">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Sun className="w-5 h-5 text-yellow-400" />
            <h3 className="font-semibold glow-text">Weather</h3>
          </div>
          {weather && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="text-2xl font-bold text-blue-400 glow-text">
                  {weather.temperature}°C
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1 text-sm text-gray-400 glow-text">
                    <MapPin className="w-3 h-3" />
                    {weather.city}, {weather.country}
                  </div>
                </div>
              </div>
              <div className="text-sm text-gray-300 capitalize mb-2 glow-text">
                {weather.description}
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs text-gray-400">
                <div>Humidity: {weather.humidity}%</div>
                <div>Wind: {weather.windSpeed} m/s</div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Prayer Times */}
      <Card className="card-enhanced pulse-border hover:scale-105 transition-all duration-300">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Moon className="w-5 h-5 text-purple-400" />
            <h3 className="font-semibold glow-text">Prayer Times</h3>
          </div>
          <div className="space-y-2">
            {prayerTimes.map((prayer) => (
              <div 
                key={prayer.name}
                className={`flex justify-between items-center text-sm p-2 rounded transition-all duration-200 hover:bg-opacity-80 ${
                  nextPrayer?.name === prayer.name 
                    ? 'bg-green-800 border border-green-600 glow-text-green' 
                    : 'bg-gray-800 hover:bg-gray-700'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="font-medium glow-text">{prayer.name}</span>
                  <span className="text-xs text-gray-400">{prayer.arabic}</span>
                </div>
                <span className="font-mono text-green-400 glow-text-green">{prayer.time}</span>
              </div>
            ))}
          </div>
          {nextPrayer && (
            <div className="mt-3 p-2 bg-blue-900 rounded border border-blue-600 glow-text transition-all duration-200 hover:bg-blue-800">
              <div className="text-xs text-blue-300">Next Prayer:</div>
              <div className="font-semibold text-blue-200 glow-text">
                {nextPrayer.name} at {nextPrayer.time}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default RealTimeWidget;
