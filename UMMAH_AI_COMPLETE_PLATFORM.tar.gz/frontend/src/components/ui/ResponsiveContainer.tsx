import React, { ReactNode } from 'react';
import { useResponsive } from '../../hooks/useResponsive';

interface ResponsiveContainerProps {
  children: ReactNode;
  className?: string;
  mobileClassName?: string;
  tabletClassName?: string;
  desktopClassName?: string;
  hideOnMobile?: boolean;
  hideOnTablet?: boolean;
  hideOnDesktop?: boolean;
  showOnlyMobile?: boolean;
  showOnlyTablet?: boolean;
  showOnlyDesktop?: boolean;
}

export const ResponsiveContainer: React.FC<ResponsiveContainerProps> = ({
  children,
  className = '',
  mobileClassName = '',
  tabletClassName = '',
  desktopClassName = '',
  hideOnMobile = false,
  hideOnTablet = false,
  hideOnDesktop = false,
  showOnlyMobile = false,
  showOnlyTablet = false,
  showOnlyDesktop = false,
}) => {
  const { isMobile, isTablet, isDesktop } = useResponsive();

  let isVisible = true;
  
  if (hideOnMobile && isMobile) isVisible = false;
  if (hideOnTablet && isTablet) isVisible = false;
  if (hideOnDesktop && isDesktop) isVisible = false;
  
  if (showOnlyMobile && !isMobile) isVisible = false;
  if (showOnlyTablet && !isTablet) isVisible = false;
  if (showOnlyDesktop && !isDesktop) isVisible = false;

  if (!isVisible) return null;

  let responsiveClassName = className;
  
  if (isMobile && mobileClassName) {
    responsiveClassName += ` ${mobileClassName}`;
  } else if (isTablet && tabletClassName) {
    responsiveClassName += ` ${tabletClassName}`;
  } else if (isDesktop && desktopClassName) {
    responsiveClassName += ` ${desktopClassName}`;
  }

  return (
    <div className={responsiveClassName.trim()}>
      {children}
    </div>
  );
};

interface ResponsiveGridProps {
  children: ReactNode;
  className?: string;
  cols?: {
    mobile?: number;
    tablet?: number;
    desktop?: number;
  };
  gap?: {
    mobile?: string;
    tablet?: string;
    desktop?: string;
  };
}

export const ResponsiveGrid: React.FC<ResponsiveGridProps> = ({
  children,
  className = '',
  cols = { mobile: 1, tablet: 2, desktop: 3 },
  gap = { mobile: '1rem', tablet: '1.5rem', desktop: '2rem' }
}) => {
  const { isMobile, isTablet } = useResponsive();

  const gridCols = isMobile ? cols.mobile : isTablet ? cols.tablet : cols.desktop;
  const gridGap = isMobile ? gap.mobile : isTablet ? gap.tablet : gap.desktop;

  const gridStyle = {
    display: 'grid',
    gridTemplateColumns: `repeat(${gridCols}, 1fr)`,
    gap: gridGap
  };

  return (
    <div className={className} style={gridStyle}>
      {children}
    </div>
  );
};

interface ResponsiveTextProps {
  children: ReactNode;
  className?: string;
  size?: {
    mobile?: string;
    tablet?: string;
    desktop?: string;
  };
}

export const ResponsiveText: React.FC<ResponsiveTextProps> = ({
  children,
  className = '',
  size = { mobile: 'text-sm', tablet: 'text-base', desktop: 'text-lg' }
}) => {
  const { isMobile, isTablet } = useResponsive();

  const textSize = isMobile ? size.mobile : isTablet ? size.tablet : size.desktop;

  return (
    <div className={`${className} ${textSize}`.trim()}>
      {children}
    </div>
  );
};
