import React from 'react';
import { Card, CardContent } from '@/components/ui/card';

interface AIModulesPanelProps {
  paranoiaMode?: boolean;
}

const AIModulesPanel: React.FC<AIModulesPanelProps> = ({ paranoiaMode = false }) => {
  return (
    <Card className="bg-gray-900 border border-gray-700 text-white">
      <CardContent className="p-6">
        <h2 className="text-lg font-semibold mb-4">AI Modules Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          <ul className="text-xs space-y-1">
            <li className={paranoiaMode ? 'text-red-400' : ''}>Reinforcement Loop Optimizer</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Mesh Routing Intelligence</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Predictive Signal Amplifier</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Quantum Entanglement Predictor</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Liquidity Flow Analyzer</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Real-time Pattern Recognition</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Monte Carlo Risk Engine</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Market Sentiment Oracle</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Cross-Exchange Arbitrage AI</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Chaos Theory Price Predictor</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Behavioral Mimicry Engine</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Microscopic Order Analysis</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Deep Space Signal Processing</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Magnetic Field Trading AI</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Creative Strategy Generator</li>
          </ul>
          <ul className="text-xs space-y-1">
            <li className={paranoiaMode ? 'text-red-400' : ''}>Burn Rate Optimization</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Tornado Cash Integration</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Identity Masking Protocol</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Black Hole Liquidity Pools</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Sniper Bot Detection Evasion</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Rainbow Table Obfuscation</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Circus Mirror Trading</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Microscopic Profit Extraction</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Quantum Dice Roll Predictor</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Tsunami Wave Pattern AI</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Artistic Price Movement AI</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Crystal Ball Market Oracle</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Theater Performance Trading</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Vortex Liquidity Capture</li>
            <li className={paranoiaMode ? 'text-red-400' : ''}>Carnival Game Strategy AI</li>
          </ul>
        </div>
        {paranoiaMode && (
          <div className="mt-4 p-3 bg-red-900 border border-red-600 rounded">
            <p className="text-red-300 text-xs font-mono">
              PARANOIA MODE: All AI modules operating in stealth configuration. 
              Metrics encrypted, logs minimized, digital footprint obfuscated.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AIModulesPanel;
