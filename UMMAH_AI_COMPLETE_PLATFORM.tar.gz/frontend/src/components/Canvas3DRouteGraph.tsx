import React, { useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Line, Text, Sphere } from '@react-three/drei';
import * as THREE from 'three';

interface RoutePoint {
  id: string;
  position: [number, number, number];
  exchange: string;
  status: 'active' | 'warning' | 'error';
  latency: number;
}

interface Alert {
  id: string;
  position: [number, number, number];
  type: 'security' | 'performance' | 'trading';
  severity: 'low' | 'medium' | 'high';
}

interface Canvas3DRouteGraphProps {
  reroutes?: RoutePoint[];
  alerts?: Alert[];
}

const RouteNode: React.FC<{ point: RoutePoint }> = ({ point }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  
  useFrame(() => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.01;
    }
  });

  const getColor = () => {
    switch (point.status) {
      case 'active': return '#00ff00';
      case 'warning': return '#ffff00';
      case 'error': return '#ff0000';
      default: return '#ffffff';
    }
  };

  return (
    <group position={point.position}>
      <Sphere ref={meshRef} args={[0.2]} material-color={getColor()} />
      <Text
        position={[0, 0.5, 0]}
        fontSize={0.2}
        color="white"
        anchorX="center"
        anchorY="middle"
      >
        {point.exchange}
      </Text>
      <Text
        position={[0, -0.5, 0]}
        fontSize={0.15}
        color={getColor()}
        anchorX="center"
        anchorY="middle"
      >
        {point.latency}ms
      </Text>
    </group>
  );
};

const AlertIndicator: React.FC<{ alert: Alert }> = ({ alert }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (meshRef.current) {
      const scale = 1 + Math.sin(state.clock.elapsedTime * 3) * 0.3;
      meshRef.current.scale.setScalar(scale);
    }
  });

  const getColor = () => {
    switch (alert.severity) {
      case 'high': return '#ff0000';
      case 'medium': return '#ff8800';
      case 'low': return '#ffff00';
      default: return '#ffffff';
    }
  };

  return (
    <group position={alert.position}>
      <Sphere ref={meshRef} args={[0.1]} material-color={getColor()} material-transparent material-opacity={0.7} />
    </group>
  );
};

const RouteConnections: React.FC<{ points: RoutePoint[] }> = ({ points }) => {
  const lines: React.ReactElement[] = [];
  
  for (let i = 0; i < points.length - 1; i++) {
    const start = points[i].position;
    const end = points[i + 1].position;
    
    lines.push(
      <Line
        key={`line-${i}`}
        points={[start, end]}
        color="#00ffff"
        lineWidth={2}
        transparent
        opacity={0.6}
      />
    );
  }
  
  return <>{lines}</>;
};

export const Canvas3DRouteGraph: React.FC<Canvas3DRouteGraphProps> = ({ 
  reroutes = [], 
  alerts = [] 
}) => {
  const [defaultRoutes] = useState<RoutePoint[]>([
    { id: '1', position: [-3, 0, 0], exchange: 'Binance', status: 'active', latency: 45 },
    { id: '2', position: [0, 2, 0], exchange: 'Coinbase', status: 'active', latency: 67 },
    { id: '3', position: [3, 0, 0], exchange: 'Kraken', status: 'warning', latency: 123 },
    { id: '4', position: [0, -2, 0], exchange: 'Bybit', status: 'active', latency: 34 },
    { id: '5', position: [0, 0, 3], exchange: 'OKX', status: 'error', latency: 234 },
  ]);

  const [defaultAlerts] = useState<Alert[]>([
    { id: '1', position: [1, 1, 1], type: 'security', severity: 'high' },
    { id: '2', position: [-1, -1, 0], type: 'performance', severity: 'medium' },
  ]);

  const routePoints = reroutes.length > 0 ? reroutes : defaultRoutes;
  const alertPoints = alerts.length > 0 ? alerts : defaultAlerts;

  return (
    <div className="w-full h-96 bg-black rounded-lg overflow-hidden">
      <Canvas camera={{ position: [5, 5, 5], fov: 60 }}>
        <ambientLight intensity={0.3} />
        <pointLight position={[10, 10, 10]} intensity={0.8} />
        
        <OrbitControls enablePan={true} enableZoom={true} enableRotate={true} />
        
        {routePoints.map((point) => (
          <RouteNode key={point.id} point={point} />
        ))}
        
        <RouteConnections points={routePoints} />
        
        {alertPoints.map((alert) => (
          <AlertIndicator key={alert.id} alert={alert} />
        ))}
        
        <gridHelper args={[10, 10, '#333333', '#333333']} />
      </Canvas>
      
      <div className="absolute bottom-2 left-2 text-xs text-white bg-black bg-opacity-50 p-2 rounded">
        <div>🌐 3D Route Visualization</div>
        <div>⚡ Real-time Exchange Latency</div>
        <div>🚨 Security Alert Monitoring</div>
      </div>
    </div>
  );
};

export default Canvas3DRouteGraph;
