import React, { useEffect, useCallback } from 'react';

/**
 * Keyboard shortcut configuration interface
 */
interface KeyboardShortcut {
  /** Key combination (e.g., 'ctrl+k', 'alt+1') */
  key: string;
  /** Description of what the shortcut does */
  description: string;
  /** Function to execute when shortcut is triggered */
  action: () => void;
  /** Whether the shortcut is currently enabled */
  enabled?: boolean;
}

/**
 * Props for the KeyboardShortcuts component
 */
interface KeyboardShortcutsProps {
  /** Array of keyboard shortcuts to register */
  shortcuts: KeyboardShortcut[];
  /** Whether keyboard shortcuts are globally enabled */
  enabled?: boolean;
}

/**
 * KeyboardShortcuts - Global keyboard shortcut handler component
 * 
 * Provides a centralized system for managing keyboard shortcuts across the platform.
 * Supports common modifier keys (ctrl, alt, shift, meta) and handles key combinations.
 * Automatically prevents default browser behavior for registered shortcuts.
 * 
 * @param props - Component props
 * @param props.shortcuts - Array of keyboard shortcuts to register
 * @param props.enabled - Whether keyboard shortcuts are globally enabled
 * @returns JSX.Element | null - Returns null as this is a behavior-only component
 */
const KeyboardShortcuts: React.FC<KeyboardShortcutsProps> = ({ 
  shortcuts, 
  enabled = true 
}) => {
  /**
   * Parse key combination string into modifier keys and main key
   * @param keyCombo - Key combination string (e.g., 'ctrl+k')
   * @returns Object with modifier flags and main key
   */
  const parseKeyCombo = useCallback((keyCombo: string) => {
    const parts = keyCombo.toLowerCase().split('+');
    const mainKey = parts[parts.length - 1];
    
    return {
      ctrl: parts.includes('ctrl'),
      alt: parts.includes('alt'),
      shift: parts.includes('shift'),
      meta: parts.includes('meta') || parts.includes('cmd'),
      key: mainKey
    };
  }, []);

  /**
   * Check if the pressed key combination matches a shortcut
   * @param event - Keyboard event
   * @param shortcut - Shortcut configuration to check against
   * @returns Boolean indicating if the shortcut matches
   */
  const matchesShortcut = useCallback((event: KeyboardEvent, shortcut: KeyboardShortcut) => {
    const combo = parseKeyCombo(shortcut.key);
    
    return (
      event.key.toLowerCase() === combo.key &&
      event.ctrlKey === combo.ctrl &&
      event.altKey === combo.alt &&
      event.shiftKey === combo.shift &&
      event.metaKey === combo.meta
    );
  }, [parseKeyCombo]);

  /**
   * Handle keyboard events and execute matching shortcuts
   * @param event - Keyboard event
   */
  const handleKeyDown = useCallback((event: KeyboardEvent) => {
    if (!enabled) return;

    const target = event.target as HTMLElement;
    if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
      return;
    }

    const matchingShortcut = shortcuts.find(shortcut => 
      shortcut.enabled !== false && matchesShortcut(event, shortcut)
    );

    if (matchingShortcut) {
      event.preventDefault();
      event.stopPropagation();
      
      try {
        matchingShortcut.action();
      } catch (error) {
        console.error('Error executing keyboard shortcut:', error);
      }
    }
  }, [enabled, shortcuts, matchesShortcut]);

  useEffect(() => {
    if (!enabled) return;

    document.addEventListener('keydown', handleKeyDown);
    
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [handleKeyDown, enabled]);

  useEffect(() => {
    if (process.env.NODE_ENV === 'development') {
      console.log('Registered keyboard shortcuts:', shortcuts.map(s => ({
        key: s.key,
        description: s.description,
        enabled: s.enabled !== false
      })));
    }
  }, [shortcuts]);

  return null;
};

export default KeyboardShortcuts;
export type { KeyboardShortcut, KeyboardShortcutsProps };
