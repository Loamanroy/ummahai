import React, { useState, useEffect } from 'react';
import { User, Wallet, FileText, Settings, TrendingUp, Shield, Bell } from 'lucide-react';
import { LanguageSwitcher } from './LanguageSwitcher';

interface UserDashboardProps {
  userId: string;
  userEmail: string;
  onWalletConnect: () => void;
  onContractDownload: () => void;
}

interface WalletConnection {
  id: string;
  name: string;
  address: string;
  balance: number;
  currency: string;
  connected: boolean;
}

interface UserStats {
  totalBalance: number;
  totalTrades: number;
  profitLoss: number;
  riskScore: number;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  userId,
  userEmail,
  onWalletConnect,
  onContractDownload
}) => {
  const [currentLanguage, setCurrentLanguage] = useState('ru');
  const [wallets, setWallets] = useState<WalletConnection[]>([]);
  const [userStats, setUserStats] = useState<UserStats>({
    totalBalance: 0,
    totalTrades: 0,
    profitLoss: 0,
    riskScore: 5
  });

  const translations = {
    en: {
      welcome: 'Welcome to UMMAH AI',
      dashboard: 'Personal Dashboard',
      walletConnections: 'Wallet Connections',
      connectWallet: 'Connect New Wallet',
      downloadContract: 'Download Contract',
      totalBalance: 'Total Balance',
      totalTrades: 'Total Trades',
      profitLoss: 'Profit/Loss',
      riskScore: 'Risk Score',
      settings: 'Settings',
      notifications: 'Notifications',
      tradingActivity: 'Trading Activity',
      noWallets: 'No wallets connected yet',
      connectFirst: 'Connect your first wallet to start trading'
    },
    ru: {
      welcome: 'Добро пожаловать в UMMAH AI',
      dashboard: 'Личная панель',
      walletConnections: 'Подключенные кошельки',
      connectWallet: 'Подключить новый кошелек',
      downloadContract: 'Скачать контракт',
      totalBalance: 'Общий баланс',
      totalTrades: 'Всего сделок',
      profitLoss: 'Прибыль/Убыток',
      riskScore: 'Оценка риска',
      settings: 'Настройки',
      notifications: 'Уведомления',
      tradingActivity: 'Торговая активность',
      noWallets: 'Кошельки еще не подключены',
      connectFirst: 'Подключите первый кошелек для начала торговли'
    },
    ar: {
      welcome: 'مرحباً بك في UMMAH AI',
      dashboard: 'لوحة التحكم الشخصية',
      walletConnections: 'اتصالات المحفظة',
      connectWallet: 'ربط محفظة جديدة',
      downloadContract: 'تحميل العقد',
      totalBalance: 'الرصيد الإجمالي',
      totalTrades: 'إجمالي الصفقات',
      profitLoss: 'الربح/الخسارة',
      riskScore: 'نقاط المخاطرة',
      settings: 'الإعدادات',
      notifications: 'الإشعارات',
      tradingActivity: 'النشاط التجاري',
      noWallets: 'لم يتم ربط أي محافظ بعد',
      connectFirst: 'اربط محفظتك الأولى لبدء التداول'
    },
    tr: {
      welcome: 'UMMAH AI\'ye Hoş Geldiniz',
      dashboard: 'Kişisel Panel',
      walletConnections: 'Cüzdan Bağlantıları',
      connectWallet: 'Yeni Cüzdan Bağla',
      downloadContract: 'Sözleşme İndir',
      totalBalance: 'Toplam Bakiye',
      totalTrades: 'Toplam İşlem',
      profitLoss: 'Kar/Zarar',
      riskScore: 'Risk Skoru',
      settings: 'Ayarlar',
      notifications: 'Bildirimler',
      tradingActivity: 'Ticaret Aktivitesi',
      noWallets: 'Henüz cüzdan bağlanmadı',
      connectFirst: 'Ticarete başlamak için ilk cüzdanınızı bağlayın'
    }
  };

  const t = translations[currentLanguage as keyof typeof translations] || translations.en;

  useEffect(() => {
    loadUserData();
  }, [userId]);

  const loadUserData = async () => {
    try {
      const mockStats: UserStats = {
        totalBalance: 15420.50,
        totalTrades: 127,
        profitLoss: 2340.75,
        riskScore: 6
      };

      const mockWallets: WalletConnection[] = [
        {
          id: '1',
          name: 'MetaMask',
          address: '0x742d35Cc6634C0532925a3b8D4C0532925a3b8D4',
          balance: 8420.50,
          currency: 'USDT',
          connected: true
        },
        {
          id: '2',
          name: 'Binance Wallet',
          address: '0x532925a3b8D4C0532925a3b8D4C0742d35Cc6634',
          balance: 7000.00,
          currency: 'USDT',
          connected: true
        }
      ];

      setUserStats(mockStats);
      setWallets(mockWallets);
    } catch (error) {
      console.error('Failed to load user data:', error);
    }
  };

  const handleWalletConnect = () => {
    onWalletConnect();
    setTimeout(loadUserData, 1000);
  };

  const getRiskColor = (score: number) => {
    if (score <= 3) return 'text-green-400';
    if (score <= 6) return 'text-yellow-400';
    return 'text-red-400';
  };

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">{t.welcome}</h1>
            <p className="text-gray-300">{userEmail}</p>
          </div>
          <div className="flex items-center space-x-4">
            <LanguageSwitcher
              currentLanguage={currentLanguage}
              onLanguageChange={setCurrentLanguage}
            />
            <button className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors">
              <Bell className="w-5 h-5 text-gray-300" />
            </button>
            <button className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors">
              <Settings className="w-5 h-5 text-gray-300" />
            </button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">{t.totalBalance}</p>
                <p className="text-2xl font-bold text-white">${userStats.totalBalance.toLocaleString()}</p>
              </div>
              <Wallet className="w-8 h-8 text-blue-400" />
            </div>
          </div>

          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">{t.totalTrades}</p>
                <p className="text-2xl font-bold text-white">{userStats.totalTrades}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-400" />
            </div>
          </div>

          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">{t.profitLoss}</p>
                <p className={`text-2xl font-bold ${userStats.profitLoss >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  ${userStats.profitLoss.toLocaleString()}
                </p>
              </div>
              <TrendingUp className={`w-8 h-8 ${userStats.profitLoss >= 0 ? 'text-green-400' : 'text-red-400'}`} />
            </div>
          </div>

          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">{t.riskScore}</p>
                <p className={`text-2xl font-bold ${getRiskColor(userStats.riskScore)}`}>
                  {userStats.riskScore}/10
                </p>
              </div>
              <Shield className={`w-8 h-8 ${getRiskColor(userStats.riskScore)}`} />
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Wallet Connections */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-white">{t.walletConnections}</h2>
              <button
                onClick={handleWalletConnect}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors flex items-center space-x-2"
              >
                <Wallet className="w-4 h-4" />
                <span>{t.connectWallet}</span>
              </button>
            </div>

            {wallets.length > 0 ? (
              <div className="space-y-4">
                {wallets.map((wallet) => (
                  <div key={wallet.id} className="flex items-center justify-between p-4 bg-gray-700/50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${wallet.connected ? 'bg-green-400' : 'bg-red-400'}`} />
                      <div>
                        <p className="text-white font-medium">{wallet.name}</p>
                        <p className="text-gray-400 text-sm">{formatAddress(wallet.address)}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-medium">{wallet.balance.toLocaleString()} {wallet.currency}</p>
                      <p className="text-gray-400 text-sm">{wallet.connected ? 'Connected' : 'Disconnected'}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Wallet className="w-12 h-12 text-gray-500 mx-auto mb-4" />
                <p className="text-gray-400 mb-2">{t.noWallets}</p>
                <p className="text-gray-500 text-sm">{t.connectFirst}</p>
              </div>
            )}
          </div>

          {/* Contract Downloads */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-white">Legal Documents</h2>
              <button
                onClick={onContractDownload}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-lg transition-colors flex items-center space-x-2"
              >
                <FileText className="w-4 h-4" />
                <span>{t.downloadContract}</span>
              </button>
            </div>

            <div className="space-y-4">
              <div className="p-4 bg-gray-700/50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">Trading Agreement</p>
                    <p className="text-gray-400 text-sm">Updated: Dec 2024</p>
                  </div>
                  <button className="text-blue-400 hover:text-blue-300 transition-colors">
                    <FileText className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="p-4 bg-gray-700/50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">Privacy Policy</p>
                    <p className="text-gray-400 text-sm">Updated: Dec 2024</p>
                  </div>
                  <button className="text-blue-400 hover:text-blue-300 transition-colors">
                    <FileText className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="p-4 bg-gray-700/50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">Risk Disclosure</p>
                    <p className="text-gray-400 text-sm">Updated: Dec 2024</p>
                  </div>
                  <button className="text-blue-400 hover:text-blue-300 transition-colors">
                    <FileText className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
