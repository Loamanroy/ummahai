import React, { useState, useCallback } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import FilterPanel from './FilterPanel';
import QuantumSignalEmulator from './QuantumSignalEmulator';
import CognitiveSelfRewriteEngine from './CognitiveSelfRewriteEngine';

interface QuantumSignal {
  exchange: string;
  latency: number;
  impact: number;
  timestamp: number;
  type: string;
}

interface FilterState {
  exchange: string;
  type: string;
  latency: number;
}

const LatencyChart: React.FC<{ metrics: QuantumSignal[] }> = ({ metrics }) => (
  <div className="bg-gray-800 p-4 rounded">
    <h3 className="text-lg font-bold text-white mb-4">Latency Metrics</h3>
    <LineChart width={500} height={250} data={metrics.slice(-10)}>
      <CartesianGrid stroke="#ccc" />
      <XAxis 
        dataKey="timestamp" 
        tickFormatter={ts => new Date(ts).toLocaleTimeString()} 
        stroke="#fff"
      />
      <YAxis stroke="#fff" />
      <Tooltip 
        labelFormatter={ts => new Date(ts).toLocaleTimeString()}
        contentStyle={{ backgroundColor: '#374151', border: 'none' }}
      />
      <Line type="monotone" dataKey="latency" stroke="#8884d8" />
    </LineChart>
  </div>
);

const CognitiveMeshDashboard: React.FC = () => {
  const [signals, setSignals] = useState<QuantumSignal[]>([]);
  const [filtered, setFiltered] = useState<QuantumSignal[]>([]);

  const handleSignal = useCallback((sig: QuantumSignal) => {
    setSignals(prev => [...prev, sig]);
  }, []);

  const handleFilterChange = useCallback((filters: FilterState) => {
    const result = signals.filter(s =>
      (!filters.exchange || s.exchange.includes(filters.exchange)) &&
      (!filters.type || s.type.includes(filters.type)) &&
      s.latency > filters.latency
    );
    setFiltered(result);
  }, [signals]);

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">🧠 Cognitive Mesh Dashboard</h1>
        <p className="text-gray-400">Advanced quantum signal processing and latency optimization</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        <FilterPanel onFilterChange={handleFilterChange} />
        <LatencyChart metrics={filtered.length > 0 ? filtered : signals} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <CognitiveSelfRewriteEngine data={filtered.length > 0 ? filtered : signals} />
        <div className="bg-gray-800 p-4 rounded">
          <h3 className="text-lg font-bold mb-2">Signal Statistics</h3>
          <div className="space-y-2">
            <p className="text-sm">📡 Total signals: {signals.length}</p>
            <p className="text-sm">🔍 Filtered signals: {filtered.length}</p>
            <p className="text-sm">⚡ Active exchanges: {new Set(signals.map(s => s.exchange)).size}</p>
            <p className="text-sm">🎯 Quantum anomalies: {signals.filter(s => s.type === 'quantum-anomaly').length}</p>
          </div>
        </div>
      </div>

      <QuantumSignalEmulator onSignal={handleSignal} />
    </div>
  );
};

export default CognitiveMeshDashboard;
