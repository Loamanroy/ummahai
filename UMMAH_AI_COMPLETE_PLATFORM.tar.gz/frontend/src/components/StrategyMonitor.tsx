import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

/**
 * Props for the StrategyMonitor component
 */
interface StrategyMonitorProps {
  /** Optional CSS class name for styling */
  className?: string;
}

/**
 * Represents a trading strategy with performance metrics
 */
interface Strategy {
  /** Unique identifier for the strategy */
  id: string;
  /** Display name of the strategy */
  name: string;
  /** Current operational status */
  status: 'active' | 'paused' | 'stopped';
  /** Win rate percentage */
  winRate: number;
  /** Total number of trades executed */
  totalTrades: number;
  /** Current profit/loss amount */
  profitLoss: number;
  /** Maximum drawdown percentage */
  maxDrawdown: number;
  /** Sharpe ratio for risk-adjusted returns */
  sharpeRatio: number;
}

/**
 * StrategyMonitor - Real-time trading strategy monitoring dashboard
 * 
 * Displays comprehensive monitoring interface for AI trading strategies including
 * CerebellumBot vX, Quantum Arbitrage Engine, and other automated trading systems.
 * Features real-time performance tracking, stealth operations monitoring, and
 * strategy management controls.
 * 
 * @param props - Component props
 * @param props.className - Optional CSS class name for styling
 * @returns JSX.Element - Rendered strategy monitoring dashboard
 */
const StrategyMonitor: React.FC<StrategyMonitorProps> = ({ className }) => {
  const [strategies, setStrategies] = useState<Strategy[]>([
    {
      id: 'cerebellum-v1',
      name: 'CerebellumBot vX Mirror Trading',
      status: 'active',
      winRate: 73.2,
      totalTrades: 1247,
      profitLoss: 18750,
      maxDrawdown: -2.3,
      sharpeRatio: 2.8
    },
    {
      id: 'quantum-arb',
      name: 'Quantum Arbitrage Engine',
      status: 'active',
      winRate: 89.1,
      totalTrades: 892,
      profitLoss: 12340,
      maxDrawdown: -1.1,
      sharpeRatio: 3.2
    },
    {
      id: 'stealth-scalp',
      name: 'Stealth Scalping Algorithm',
      status: 'paused',
      winRate: 65.8,
      totalTrades: 2156,
      profitLoss: 8920,
      maxDrawdown: -4.2,
      sharpeRatio: 1.9
    },
    {
      id: 'mesh-liquidity',
      name: 'Mesh Liquidity Optimizer',
      status: 'active',
      winRate: 78.5,
      totalTrades: 567,
      profitLoss: 15680,
      maxDrawdown: -1.8,
      sharpeRatio: 2.5
    }
  ]);

  const [selectedStrategy, setSelectedStrategy] = useState<string>('cerebellum-v1');
  const [paranoiaMode, setParanoiaMode] = useState(false);

  const performanceData = [
    { time: '00:00', pnl: 0 },
    { time: '04:00', pnl: 1250 },
    { time: '08:00', pnl: 2100 },
    { time: '12:00', pnl: 3450 },
    { time: '16:00', pnl: 2890 },
    { time: '20:00', pnl: 4120 }
  ];

  const stealthMetrics = [
    { metric: 'IP Rotation Success', value: '99.8%', status: 'excellent' },
    { metric: 'Human Emulation Score', value: '97.2%', status: 'excellent' },
    { metric: 'Detection Probability', value: '0.1%', status: 'excellent' },
    { metric: 'Order Obfuscation', value: '94.5%', status: 'good' },
    { metric: 'Metadata Encryption', value: '100%', status: 'excellent' },
    { metric: 'ZKP Verification', value: '98.7%', status: 'excellent' }
  ];

  /**
   * Toggles strategy status between active and paused
   * @param strategyId - Unique identifier of the strategy to toggle
   */
  const toggleStrategy = (strategyId: string) => {
    setStrategies(prev => prev.map(strategy => 
      strategy.id === strategyId 
        ? { ...strategy, status: strategy.status === 'active' ? 'paused' : 'active' }
        : strategy
    ));
  };

  /**
   * Returns appropriate CSS color class for strategy status
   * @param status - Strategy status string
   * @returns CSS color class name
   */
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400';
      case 'paused': return 'text-yellow-400';
      case 'stopped': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  /**
   * Returns appropriate CSS color class for metric status
   * @param status - Metric status string
   * @returns CSS color class name
   */
  const getMetricColor = (status: string) => {
    switch (status) {
      case 'excellent': return 'text-green-400';
      case 'good': return 'text-yellow-400';
      case 'warning': return 'text-orange-400';
      case 'critical': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setStrategies(prev => prev.map(strategy => ({
        ...strategy,
        profitLoss: strategy.profitLoss + (Math.random() - 0.4) * 100
      })));
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className={`space-y-4 ${className}`}>
      <Card className="bg-gray-900 border border-gray-700 text-white">
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">Strategy Monitor</h2>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-sm">Paranoia Mode</span>
                <Button
                  onClick={() => setParanoiaMode(!paranoiaMode)}
                  className={`px-3 py-1 text-xs ${
                    paranoiaMode 
                      ? 'bg-red-600 hover:bg-red-700' 
                      : 'bg-gray-600 hover:bg-gray-700'
                  }`}
                >
                  {paranoiaMode ? 'ACTIVE' : 'INACTIVE'}
                </Button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <div className="bg-gray-800 p-4 rounded">
              <h3 className="text-lg font-semibold mb-3">Active Strategies</h3>
              <div className="space-y-3">
                {strategies.map((strategy) => (
                  <div key={strategy.id} className="bg-gray-700 p-3 rounded">
                    <div className="flex justify-between items-center mb-2">
                      <div className="font-medium">{strategy.name}</div>
                      <div className={`text-sm ${getStatusColor(strategy.status)}`}>
                        {strategy.status.toUpperCase()}
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-xs text-gray-300">
                      <div>Win Rate: {strategy.winRate}%</div>
                      <div>Trades: {strategy.totalTrades}</div>
                      <div className={strategy.profitLoss >= 0 ? 'text-green-400' : 'text-red-400'}>
                        P&L: ${strategy.profitLoss.toLocaleString()}
                      </div>
                    </div>
                    <div className="mt-2 flex gap-2">
                      <Button
                        onClick={() => toggleStrategy(strategy.id)}
                        className={`px-2 py-1 text-xs ${
                          strategy.status === 'active' 
                            ? 'bg-yellow-600 hover:bg-yellow-700' 
                            : 'bg-green-600 hover:bg-green-700'
                        }`}
                      >
                        {strategy.status === 'active' ? 'Pause' : 'Resume'}
                      </Button>
                      <Button
                        onClick={() => setSelectedStrategy(strategy.id)}
                        className="px-2 py-1 text-xs bg-blue-600 hover:bg-blue-700"
                      >
                        Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gray-800 p-4 rounded">
              <h3 className="text-lg font-semibold mb-3">Performance Chart</h3>
              <LineChart width={400} height={250} data={performanceData}>
                <CartesianGrid stroke="#374151" />
                <XAxis dataKey="time" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
                  labelStyle={{ color: '#F3F4F6' }}
                />
                <Line type="monotone" dataKey="pnl" stroke="#10B981" strokeWidth={2} />
              </LineChart>
            </div>
          </div>

          {paranoiaMode && (
            <div className="bg-red-900 border border-red-700 p-4 rounded mb-6">
              <h3 className="text-lg font-semibold mb-3 text-red-300">Stealth Operations Monitor</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {stealthMetrics.map((metric, index) => (
                  <div key={index} className="bg-gray-800 p-3 rounded">
                    <div className="text-sm text-gray-400">{metric.metric}</div>
                    <div className={`text-lg font-bold ${getMetricColor(metric.status)}`}>
                      {metric.value}
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 text-xs text-red-300">
                All stealth systems operational. CerebellumBot vX remains undetected.
              </div>
            </div>
          )}

          <div className="bg-gray-800 p-4 rounded">
            <h3 className="text-lg font-semibold mb-3">Real-time Alerts</h3>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <span className="text-green-400 font-bold">SUCCESS</span>
                <span>CerebellumBot vX executed 15 trades in last hour - All profitable</span>
                <span className="text-gray-400 text-xs">2 min ago</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-yellow-400 font-bold">WARNING</span>
                <span>High volatility detected on BTC/USDT - Adjusting position sizes</span>
                <span className="text-gray-400 text-xs">5 min ago</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-blue-400 font-bold">INFO</span>
                <span>Quantum Arbitrage Engine found new opportunity on 3 exchanges</span>
                <span className="text-gray-400 text-xs">8 min ago</span>
              </div>
            </div>
          </div>

          <div className="mt-4 flex gap-2">
            <Button className="bg-green-600 hover:bg-green-700">
              Deploy New Strategy
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700">
              Export Reports
            </Button>
            <Button className="bg-purple-600 hover:bg-purple-700">
              Configure Alerts
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StrategyMonitor;
