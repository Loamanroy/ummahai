import React, { useState } from 'react';

interface FilterPanelProps {
  onFilterChange: (filters: FilterState) => void;
}

interface FilterState {
  exchange: string;
  type: string;
  latency: number;
}

const FilterPanel: React.FC<FilterPanelProps> = ({ onFilterChange }) => {
  const [filters, setFilters] = useState<FilterState>({ 
    exchange: '', 
    type: '', 
    latency: 0 
  });

  const handleChange = (key: keyof FilterState, value: string | number) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  return (
    <div className="bg-gray-800 text-white p-4 rounded">
      <h3 className="text-lg font-bold mb-4">Threat Filter Panel</h3>
      <div className="space-y-3">
        <input 
          placeholder="Exchange" 
          className="w-full p-2 bg-gray-700 rounded border border-gray-600 text-white"
          onChange={e => handleChange('exchange', e.target.value)} 
        />
        <input 
          placeholder="Type" 
          className="w-full p-2 bg-gray-700 rounded border border-gray-600 text-white"
          onChange={e => handleChange('type', e.target.value)} 
        />
        <input 
          type="number" 
          placeholder="Latency >" 
          className="w-full p-2 bg-gray-700 rounded border border-gray-600 text-white"
          onChange={e => handleChange('latency', Number(e.target.value))} 
        />
      </div>
    </div>
  );
};

export default FilterPanel;
