import React, { useState } from 'react';
import { Globe, ChevronDown } from 'lucide-react';

interface Language {
  code: string;
  name: string;
  flag: string;
  nativeName: string;
}

const languages: Language[] = [
  { code: 'en', name: 'English', flag: '🇺🇸', nativeName: 'English' },
  { code: 'ru', name: 'Russian', flag: '🇷🇺', nativeName: 'Русский' },
  { code: 'ar', name: 'Arabic', flag: '🇦🇪', nativeName: 'العربية' },
  { code: 'tr', name: 'Turkish', flag: '🇹🇷', nativeName: 'Türkçe' }
];

interface LanguageSwitcherProps {
  currentLanguage: string;
  onLanguageChange: (language: string) => void;
  className?: string;
  showLabel?: boolean;
}

export const LanguageSwitcher: React.FC<LanguageSwitcherProps> = ({
  currentLanguage,
  onLanguageChange,
  className = '',
  showLabel = true
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const currentLang = languages.find(lang => lang.code === currentLanguage) || languages[0];

  const handleLanguageSelect = (languageCode: string) => {
    onLanguageChange(languageCode);
    setIsOpen(false);
  };

  return (
    <div className={`relative ${className}`}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 px-3 py-2 rounded-lg bg-gradient-to-r from-gray-800 to-gray-700 hover:from-gray-700 hover:to-gray-600 transition-all duration-200 border border-gray-600 hover:border-gray-500 shadow-lg"
      >
        <span className="text-xl filter drop-shadow-sm">{currentLang.flag}</span>
        {showLabel && (
          <span className="text-sm font-medium text-white">{currentLang.nativeName}</span>
        )}
        <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      
      {isOpen && (
        <>
          <div 
            className="fixed inset-0 z-40" 
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute top-full left-0 mt-2 w-56 bg-gray-800 rounded-lg shadow-xl border border-gray-600 z-50 overflow-hidden">
            <div className="py-2">
              {languages.map((language) => (
                <button
                  key={language.code}
                  onClick={() => handleLanguageSelect(language.code)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 text-left hover:bg-gray-700 transition-colors ${
                    language.code === currentLanguage 
                      ? 'bg-blue-600 hover:bg-blue-500' 
                      : 'hover:bg-gray-700'
                  }`}
                >
                  <span className="text-xl filter drop-shadow-sm">{language.flag}</span>
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-white">{language.nativeName}</span>
                    <span className="text-xs text-gray-400">{language.name}</span>
                  </div>
                  {language.code === currentLanguage && (
                    <div className="ml-auto w-2 h-2 bg-blue-400 rounded-full"></div>
                  )}
                </button>
              ))}
            </div>
            
            <div className="border-t border-gray-600 px-4 py-2">
              <div className="flex items-center space-x-2 text-xs text-gray-400">
                <Globe className="w-3 h-3" />
                <span>UMMAH AI Platform supports 4 languages</span>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
