import React, { useState } from "react"

export default function PromptToVideo() {
  const [prompt, setPrompt] = useState("")
  const [videoUrl, setVideoUrl] = useState("")
  const [loading, setLoading] = useState(false)

  const generateVideo = async () => {
    setLoading(true)
    const response = await fetch("/api/gen-video", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt }),
    })
    const data = await response.json()
    setVideoUrl(data.video_url)
    setLoading(false)
  }

  return (
    <div className="p-4 bg-black text-white rounded-xl shadow-lg">
      <h2 className="text-xl font-bold mb-2">🎥 Generate AI Video</h2>
      <input
        type="text"
        className="w-full p-2 mb-3 bg-gray-800 rounded"
        placeholder="Describe your scene (e.g. Cyberpunk alley at night)..."
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
      />
      <button
        className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded"
        onClick={generateVideo}
        disabled={loading}>
        {loading ? "Generating..." : "Generate Video"}
      </button>
      {videoUrl && (
        <div className="mt-4">
          <video src={videoUrl} controls autoPlay loop className="rounded-md w-full" />
        </div>
      )}
    </div>
  )
}
