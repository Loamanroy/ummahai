import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { 
  Grid, 
  Layout, 
  RotateCcw, 
  Save, 
  X,
  Eye,
  EyeOff
} from 'lucide-react';

/**
 * Layout component configuration interface
 */
interface LayoutComponent {
  /** Unique identifier for the component */
  id: string;
  /** Display name of the component */
  name: string;
  /** Whether the component is currently visible */
  visible: boolean;
  /** Grid position and size */
  gridArea: {
    row: number;
    column: number;
    rowSpan: number;
    columnSpan: number;
  };
  /** Minimum size constraints */
  minSize: {
    rows: number;
    columns: number;
  };
}

/**
 * Layout preset interface
 */
interface LayoutPreset {
  /** Unique identifier for the preset */
  id: string;
  /** Display name of the preset */
  name: string;
  /** Description of the preset */
  description: string;
  /** Component configuration for this preset */
  components: LayoutComponent[];
}

/**
 * Props for the LayoutCustomizer component
 */
interface LayoutCustomizerProps {
  /** Whether the layout customizer is visible */
  isOpen: boolean;
  /** Function to close the layout customizer */
  onClose: () => void;
  /** Current layout configuration */
  currentLayout: LayoutComponent[];
  /** Function to apply a new layout */
  onLayoutChange: (layout: LayoutComponent[]) => void;
  /** Available layout presets */
  presets?: LayoutPreset[];
}

/**
 * LayoutCustomizer - Dashboard layout customization interface
 * 
 * Provides a visual interface for customizing dashboard component layouts.
 * Supports drag-and-drop positioning, component visibility toggles, preset
 * layouts, and persistent layout storage. Designed for users who want to
 * optimize their dashboard for their specific workflow needs.
 * 
 * @param props - Component props
 * @param props.isOpen - Whether the layout customizer is visible
 * @param props.onClose - Function to close the layout customizer
 * @param props.currentLayout - Current layout configuration
 * @param props.onLayoutChange - Function to apply a new layout
 * @param props.presets - Available layout presets
 * @returns JSX.Element | null - Rendered layout customizer or null if closed
 */
const LayoutCustomizer: React.FC<LayoutCustomizerProps> = ({
  isOpen,
  onClose,
  currentLayout,
  onLayoutChange,
  presets = []
}) => {
  const [workingLayout, setWorkingLayout] = useState<LayoutComponent[]>(currentLayout);
  const [selectedComponent, setSelectedComponent] = useState<string | null>(null);

  useEffect(() => {
    setWorkingLayout(currentLayout);
  }, [currentLayout]);

  /**
   * Toggle component visibility
   */
  const toggleComponentVisibility = (componentId: string) => {
    setWorkingLayout(prev => 
      prev.map(comp => 
        comp.id === componentId 
          ? { ...comp, visible: !comp.visible }
          : comp
      )
    );
  };



  /**
   * Apply a preset layout
   */
  const applyPreset = (preset: LayoutPreset) => {
    setWorkingLayout(preset.components);
  };

  /**
   * Reset to default layout
   */
  const resetToDefault = () => {
    const defaultLayout: LayoutComponent[] = [
      {
        id: 'wallet-panel',
        name: 'Wallet & Signing',
        visible: true,
        gridArea: { row: 1, column: 1, rowSpan: 1, columnSpan: 2 },
        minSize: { rows: 1, columns: 2 }
      },
      {
        id: 'ai-modules',
        name: 'AI Modules Overview',
        visible: true,
        gridArea: { row: 1, column: 3, rowSpan: 1, columnSpan: 2 },
        minSize: { rows: 1, columns: 2 }
      },
      {
        id: 'fusion-visualizer',
        name: '3D Fusion Map',
        visible: true,
        gridArea: { row: 2, column: 1, rowSpan: 2, columnSpan: 2 },
        minSize: { rows: 2, columns: 2 }
      },
      {
        id: 'threat-map',
        name: 'Threat Detection',
        visible: true,
        gridArea: { row: 2, column: 3, rowSpan: 1, columnSpan: 2 },
        minSize: { rows: 1, columns: 2 }
      },
      {
        id: 'ai-agents',
        name: 'AI Agents Control',
        visible: true,
        gridArea: { row: 3, column: 3, rowSpan: 1, columnSpan: 2 },
        minSize: { rows: 1, columns: 2 }
      },
      {
        id: 'infrastructure',
        name: 'Infrastructure & Stealth',
        visible: true,
        gridArea: { row: 4, column: 1, rowSpan: 1, columnSpan: 4 },
        minSize: { rows: 1, columns: 4 }
      }
    ];
    setWorkingLayout(defaultLayout);
  };

  /**
   * Save the current working layout
   */
  const saveLayout = () => {
    onLayoutChange(workingLayout);
    
    try {
      localStorage.setItem('ummah-dashboard-layout', JSON.stringify(workingLayout));
    } catch (error) {
      console.error('Failed to save layout to localStorage:', error);
    }
    
    onClose();
  };

  /**
   * Cancel changes and revert to current layout
   */
  const cancelChanges = () => {
    setWorkingLayout(currentLayout);
    setSelectedComponent(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <Card className="bg-gray-900 border border-gray-700 text-white w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <CardContent className="p-0">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-gray-700">
            <div className="flex items-center">
              <Layout className="w-5 h-5 mr-2" />
              <h2 className="text-lg font-semibold">Customize Dashboard Layout</h2>
            </div>
            <Button
              onClick={cancelChanges}
              className="bg-transparent hover:bg-gray-800 p-1"
              size="sm"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          <div className="flex h-[70vh]">
            {/* Component List */}
            <div className="w-1/3 border-r border-gray-700 p-4 overflow-y-auto">
              <h3 className="text-sm font-semibold mb-3 text-gray-300">Components</h3>
              
              <div className="space-y-2">
                {workingLayout.map(component => (
                  <div
                    key={component.id}
                    className={`p-3 rounded border cursor-pointer transition-colors ${
                      selectedComponent === component.id
                        ? 'border-blue-500 bg-blue-900/20'
                        : 'border-gray-600 hover:border-gray-500'
                    }`}
                    onClick={() => setSelectedComponent(component.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Grid className="w-4 h-4 mr-2 text-gray-400" />
                        <span className="text-sm font-medium">{component.name}</span>
                      </div>
                      <Button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleComponentVisibility(component.id);
                        }}
                        className="bg-transparent hover:bg-gray-700 p-1"
                        size="sm"
                      >
                        {component.visible ? (
                          <Eye className="w-3 h-3" />
                        ) : (
                          <EyeOff className="w-3 h-3 text-gray-500" />
                        )}
                      </Button>
                    </div>
                    
                    <div className="mt-2 text-xs text-gray-400">
                      Position: {component.gridArea.row},{component.gridArea.column} 
                      Size: {component.gridArea.rowSpan}×{component.gridArea.columnSpan}
                    </div>
                  </div>
                ))}
              </div>

              {/* Presets */}
              {presets.length > 0 && (
                <div className="mt-6">
                  <h3 className="text-sm font-semibold mb-3 text-gray-300">Presets</h3>
                  <div className="space-y-2">
                    {presets.map(preset => (
                      <Button
                        key={preset.id}
                        onClick={() => applyPreset(preset)}
                        className="w-full bg-gray-800 hover:bg-gray-700 text-left p-3 h-auto"
                      >
                        <div>
                          <div className="font-medium text-sm">{preset.name}</div>
                          <div className="text-xs text-gray-400 mt-1">
                            {preset.description}
                          </div>
                        </div>
                      </Button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Layout Preview */}
            <div className="flex-1 p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-gray-300">Layout Preview</h3>
                <Button
                  onClick={resetToDefault}
                  className="bg-gray-800 hover:bg-gray-700 text-xs"
                  size="sm"
                >
                  <RotateCcw className="w-3 h-3 mr-1" />
                  Reset
                </Button>
              </div>

              {/* Grid Preview */}
              <div className="bg-gray-800 rounded-lg p-4 h-full min-h-96">
                <div 
                  className="grid gap-2 h-full"
                  style={{
                    gridTemplateColumns: 'repeat(4, 1fr)',
                    gridTemplateRows: 'repeat(4, 1fr)'
                  }}
                >
                  {workingLayout.map(component => (
                    <div
                      key={component.id}
                      className={`rounded border-2 border-dashed p-2 flex items-center justify-center text-xs transition-all ${
                        component.visible
                          ? selectedComponent === component.id
                            ? 'border-blue-400 bg-blue-900/30 text-blue-200'
                            : 'border-gray-500 bg-gray-700/50 text-gray-300 hover:border-gray-400'
                          : 'border-gray-600 bg-gray-800/30 text-gray-500'
                      }`}
                      style={{
                        gridRow: `${component.gridArea.row} / span ${component.gridArea.rowSpan}`,
                        gridColumn: `${component.gridArea.column} / span ${component.gridArea.columnSpan}`
                      }}
                      onClick={() => setSelectedComponent(component.id)}
                    >
                      <div className="text-center">
                        <div className="font-medium">{component.name}</div>
                        {!component.visible && (
                          <div className="text-xs mt-1 opacity-50">Hidden</div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between p-4 border-t border-gray-700">
            <div className="text-xs text-gray-400">
              Click components to select • Toggle visibility with eye icon
            </div>
            <div className="flex space-x-2">
              <Button
                onClick={cancelChanges}
                className="bg-gray-700 hover:bg-gray-600"
              >
                Cancel
              </Button>
              <Button
                onClick={saveLayout}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Save className="w-4 h-4 mr-1" />
                Save Layout
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

/**
 * Default layout presets for the UMMAH AI Platform
 */
export const defaultLayoutPresets: LayoutPreset[] = [
  {
    id: 'trading-focused',
    name: 'Trading Focused',
    description: 'Optimized for active trading with emphasis on charts and execution',
    components: [
      {
        id: 'fusion-visualizer',
        name: '3D Fusion Map',
        visible: true,
        gridArea: { row: 1, column: 1, rowSpan: 2, columnSpan: 3 },
        minSize: { rows: 2, columns: 2 }
      },
      {
        id: 'ai-agents',
        name: 'AI Agents Control',
        visible: true,
        gridArea: { row: 1, column: 4, rowSpan: 1, columnSpan: 1 },
        minSize: { rows: 1, columns: 1 }
      },
      {
        id: 'threat-map',
        name: 'Threat Detection',
        visible: true,
        gridArea: { row: 2, column: 4, rowSpan: 1, columnSpan: 1 },
        minSize: { rows: 1, columns: 1 }
      },
      {
        id: 'wallet-panel',
        name: 'Wallet & Signing',
        visible: true,
        gridArea: { row: 3, column: 1, rowSpan: 1, columnSpan: 2 },
        minSize: { rows: 1, columns: 2 }
      },
      {
        id: 'ai-modules',
        name: 'AI Modules Overview',
        visible: true,
        gridArea: { row: 3, column: 3, rowSpan: 1, columnSpan: 2 },
        minSize: { rows: 1, columns: 2 }
      },
      {
        id: 'infrastructure',
        name: 'Infrastructure & Stealth',
        visible: false,
        gridArea: { row: 4, column: 1, rowSpan: 1, columnSpan: 4 },
        minSize: { rows: 1, columns: 4 }
      }
    ]
  },
  {
    id: 'security-focused',
    name: 'Security Focused',
    description: 'Emphasizes threat detection and stealth operations',
    components: [
      {
        id: 'threat-map',
        name: 'Threat Detection',
        visible: true,
        gridArea: { row: 1, column: 1, rowSpan: 2, columnSpan: 2 },
        minSize: { rows: 1, columns: 2 }
      },
      {
        id: 'infrastructure',
        name: 'Infrastructure & Stealth',
        visible: true,
        gridArea: { row: 1, column: 3, rowSpan: 2, columnSpan: 2 },
        minSize: { rows: 1, columns: 4 }
      },
      {
        id: 'wallet-panel',
        name: 'Wallet & Signing',
        visible: true,
        gridArea: { row: 3, column: 1, rowSpan: 1, columnSpan: 2 },
        minSize: { rows: 1, columns: 2 }
      },
      {
        id: 'fusion-visualizer',
        name: '3D Fusion Map',
        visible: true,
        gridArea: { row: 3, column: 3, rowSpan: 1, columnSpan: 2 },
        minSize: { rows: 2, columns: 2 }
      },
      {
        id: 'ai-modules',
        name: 'AI Modules Overview',
        visible: false,
        gridArea: { row: 4, column: 1, rowSpan: 1, columnSpan: 2 },
        minSize: { rows: 1, columns: 2 }
      },
      {
        id: 'ai-agents',
        name: 'AI Agents Control',
        visible: false,
        gridArea: { row: 4, column: 3, rowSpan: 1, columnSpan: 2 },
        minSize: { rows: 1, columns: 2 }
      }
    ]
  },
  {
    id: 'minimal',
    name: 'Minimal',
    description: 'Clean, minimal layout with only essential components',
    components: [
      {
        id: 'fusion-visualizer',
        name: '3D Fusion Map',
        visible: true,
        gridArea: { row: 1, column: 1, rowSpan: 3, columnSpan: 4 },
        minSize: { rows: 2, columns: 2 }
      },
      {
        id: 'wallet-panel',
        name: 'Wallet & Signing',
        visible: true,
        gridArea: { row: 4, column: 1, rowSpan: 1, columnSpan: 4 },
        minSize: { rows: 1, columns: 2 }
      },
      {
        id: 'ai-modules',
        name: 'AI Modules Overview',
        visible: false,
        gridArea: { row: 5, column: 1, rowSpan: 1, columnSpan: 2 },
        minSize: { rows: 1, columns: 2 }
      },
      {
        id: 'threat-map',
        name: 'Threat Detection',
        visible: false,
        gridArea: { row: 5, column: 3, rowSpan: 1, columnSpan: 2 },
        minSize: { rows: 1, columns: 2 }
      },
      {
        id: 'ai-agents',
        name: 'AI Agents Control',
        visible: false,
        gridArea: { row: 6, column: 1, rowSpan: 1, columnSpan: 2 },
        minSize: { rows: 1, columns: 2 }
      },
      {
        id: 'infrastructure',
        name: 'Infrastructure & Stealth',
        visible: false,
        gridArea: { row: 6, column: 3, rowSpan: 1, columnSpan: 2 },
        minSize: { rows: 1, columns: 4 }
      }
    ]
  }
];

export default LayoutCustomizer;
export type { LayoutComponent, LayoutPreset, LayoutCustomizerProps };
