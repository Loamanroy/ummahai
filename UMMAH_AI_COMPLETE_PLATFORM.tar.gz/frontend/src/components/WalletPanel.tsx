import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

/**
 * Props for the WalletPanel component
 */
interface WalletPanelProps {
  /** Whether a wallet is currently connected */
  walletConnected: boolean;
  /** Function to connect a wallet with optional wallet type */
  connectWallet: (walletType?: string) => void;
  /** Whether wallet connection is in progress */
  isConnecting?: boolean;
  /** Error message if wallet connection failed */
  error?: string | null;
}

/**
 * WalletPanel - Wallet connection and security features panel
 * 
 * Provides wallet connection functionality with support for multiple wallet types
 * including MetaMask, WalletConnect, and Coinbase Wallet. Displays comprehensive
 * security features and encryption capabilities of the platform.
 * 
 * @param props - Component props
 * @param props.walletConnected - Whether a wallet is currently connected
 * @param props.connectWallet - Function to connect a wallet
 * @returns JSX.Element - Rendered wallet panel component
 */
const WalletPanel: React.FC<WalletPanelProps> = ({ walletConnected, connectWallet, isConnecting, error }) => {
  const [showWalletOptions, setShowWalletOptions] = useState(false);

  /**
   * Handles wallet selection and initiates connection
   * @param walletType - The type of wallet to connect (MetaMask, WalletConnect, etc.)
   */
  const handleWalletSelection = (walletType: string) => {
    console.log(`Connecting to ${walletType} wallet...`);
    connectWallet(walletType);
    setShowWalletOptions(false);
  };

  return (
    <Card className="bg-gray-900 border border-gray-700 text-white">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Wallet & Signing</h2>
          <Button 
            onClick={() => {
              if (!walletConnected) {
                setShowWalletOptions(!showWalletOptions);
              }
            }} 
            disabled={walletConnected || isConnecting}
            className={walletConnected ? 'bg-green-600' : isConnecting ? 'bg-gray-600' : 'bg-blue-600 hover:bg-blue-700'}
          >
            {walletConnected ? '✅ Connected' : isConnecting ? '⏳ Connecting...' : 'Connect Wallet'}
          </Button>
        </div>
        
        {error && (
          <div className="mb-4 p-3 bg-red-900/50 border border-red-500 rounded-lg">
            <div className="flex items-center">
              <div className="text-red-400 mr-2">⚠️</div>
              <div className="text-red-200 text-sm">{error}</div>
            </div>
          </div>
        )}
        
        {showWalletOptions && !walletConnected && (
          <div className="mb-4 p-4 bg-gray-800 rounded-lg border border-gray-600">
            <h3 className="text-sm font-semibold mb-3">Choose Wallet:</h3>
            <div className="grid grid-cols-1 gap-2">
              <Button
                onClick={() => handleWalletSelection('MetaMask')}
                className="bg-orange-600 hover:bg-orange-700 text-white p-3 rounded-lg flex items-center justify-center"
              >
                🦊 MetaMask
              </Button>
              <Button
                onClick={() => handleWalletSelection('WalletConnect')}
                className="bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-lg flex items-center justify-center"
              >
                🔗 WalletConnect
              </Button>
              <Button
                onClick={() => handleWalletSelection('Coinbase Wallet')}
                className="bg-blue-800 hover:bg-blue-900 text-white p-3 rounded-lg flex items-center justify-center"
              >
                💼 Coinbase Wallet
              </Button>
            </div>
          </div>
        )}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          <ul className="text-xs space-y-1">
            <li>AES-256 + TLS 1.3 Encryption Layer</li>
            <li>ZK-Signer Integrated</li>
            <li>IPFS Mirror Enabled</li>
            <li>CID Auto-Snapshot</li>
            <li>WalletConnect + MetaMask</li>
            <li>Firebase Auth Integration</li>
            <li>zkSync Signature Routing</li>
            <li>IP Rotation Detection</li>
            <li>Session Replay Protection</li>
            <li>Wallet Graph Overlay</li>
            <li>Decentralized KYC Verification</li>
            <li>Optimistic Wallet Execution</li>
            <li>Multi-chain Wallet Bridge</li>
            <li>Hidden Activity Cloaking</li>
            <li>Key Rotation Mechanism</li>
          </ul>
          <ul className="text-xs space-y-1">
            <li>BioAuth AI Linking</li>
            <li>QR-based AutoLink Wallets</li>
            <li>Wallet Behavior Learning AI</li>
            <li>De-sync Recovery Daemon</li>
            <li>Wallet Audit Trail Explorer</li>
            <li>Notification Stream Binding</li>
            <li>TX Receipt Auto-Backup</li>
            <li>Encrypted NFT Mint Log</li>
            <li>Intent Routing to Wallet Mesh</li>
            <li>On-chain Wallet Reputation Scoring</li>
            <li>TOR-Enabled Wallet Communication</li>
            <li>zkMail Integration for Wallets</li>
            <li>One-click Delegate Key</li>
            <li>Wallet Graphviz Preview</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
};

export default WalletPanel;
