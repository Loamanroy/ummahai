import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

interface UserBalance {
  user_id: number;
  email: string;
  full_name: string;
  total_balance: number;
  available_balance: number;
  locked_balance: number;
  total_deposits: number;
  total_withdrawals: number;
  profit_share_percentage: number;
  contract_type: string;
  last_activity: string;
}

interface ContractSummary {
  contract_type: string;
  user_count: number;
  total_volume: number;
  profit_distribution: {
    user_share: number;
    platform_share: number;
  };
  average_profit_share: number;
}

interface AIPerformanceMetrics {
  ai_agent_id: string;
  agent_name: string;
  total_trades: number;
  successful_trades: number;
  success_rate: number;
  total_profit: number;
  average_trade_duration: number;
  strategies_used: string[];
  last_active: string;
}

interface TradingStrategy {
  strategy_id: string;
  name: string;
  description: string;
  success_rate: number;
  total_uses: number;
  created_date: string;
  last_updated: string;
  is_active: boolean;
}

interface Transaction {
  transaction_id: string;
  user_id: number;
  user_email: string;
  transaction_type: string;
  amount: number;
  currency: string;
  status: string;
  created_at: string;
  processed_at?: string;
  fee: number;
}

interface AdminAccounts {
  admin_accounts: Array<{
    account_id: string;
    name: string;
    balance: number;
    currency: string;
    account_type: string;
  }>;
  platform_statistics: {
    total_platform_revenue: number;
    total_user_profits: number;
    platform_profit_share: number;
    active_trading_volume_24h: number;
    total_fees_collected: number;
  };
  generated_at: string;
}

interface PendingRegistration {
  id: number;
  email: string;
  full_name: string;
  registration_stage: string;
  registration_complete: boolean;
  document_verified: boolean;
  biometric_verified: boolean;
  email_verified: boolean;
  phone_verified: boolean;
  wallet_connected: boolean;
  contract_signed: boolean;
  created_at: string;
}

const AdminDashboard: React.FC = () => {
  const [userBalances, setUserBalances] = useState<UserBalance[]>([]);
  const [contractSummaries, setContractSummaries] = useState<ContractSummary[]>([]);
  const [aiPerformance, setAiPerformance] = useState<AIPerformanceMetrics[]>([]);
  const [strategies, setStrategies] = useState<TradingStrategy[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [adminAccounts, setAdminAccounts] = useState<AdminAccounts | null>(null);
  const [pendingRegistrations, setPendingRegistrations] = useState<PendingRegistration[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('overview');

  const fetchAdminData = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('admin_token') || 'demo_token';
      const headers = {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      };

      const [
        balancesRes,
        contractsRes,
        aiRes,
        strategiesRes,
        transactionsRes,
        adminAccountsRes,
        pendingRes
      ] = await Promise.all([
        fetch('/api/admin/users/balances', { headers }).catch(() => ({ ok: false })),
        fetch('/api/admin/contracts/summary', { headers }).catch(() => ({ ok: false })),
        fetch('/api/admin/ai/performance', { headers }).catch(() => ({ ok: false })),
        fetch('/api/admin/strategies/library', { headers }).catch(() => ({ ok: false })),
        fetch('/api/admin/transactions', { headers }).catch(() => ({ ok: false })),
        fetch('/api/admin/admin/accounts', { headers }).catch(() => ({ ok: false })),
        fetch('/api/admin/registrations/pending', { headers }).catch(() => ({ ok: false }))
      ]);

      if (balancesRes.ok && 'json' in balancesRes) setUserBalances(await balancesRes.json());
      if (contractsRes.ok && 'json' in contractsRes) setContractSummaries(await contractsRes.json());
      if (aiRes.ok && 'json' in aiRes) setAiPerformance(await aiRes.json());
      if (strategiesRes.ok && 'json' in strategiesRes) setStrategies(await strategiesRes.json());
      if (transactionsRes.ok && 'json' in transactionsRes) setTransactions(await transactionsRes.json());
      if (adminAccountsRes.ok && 'json' in adminAccountsRes) setAdminAccounts(await adminAccountsRes.json());
      if (pendingRes.ok && 'json' in pendingRes) setPendingRegistrations(await pendingRes.json());

      if (!balancesRes.ok && !contractsRes.ok && !aiRes.ok) {
        setUserBalances([
          {
            user_id: 1,
            email: 'user1@example.com',
            full_name: 'Ahmed Al-Rashid',
            total_balance: 15000,
            available_balance: 12000,
            locked_balance: 3000,
            total_deposits: 20000,
            total_withdrawals: 5000,
            profit_share_percentage: 70,
            contract_type: 'premium',
            last_activity: new Date().toISOString()
          },
          {
            user_id: 2,
            email: 'user2@example.com',
            full_name: 'Fatima Hassan',
            total_balance: 8500,
            available_balance: 7000,
            locked_balance: 1500,
            total_deposits: 10000,
            total_withdrawals: 1500,
            profit_share_percentage: 60,
            contract_type: 'standard',
            last_activity: new Date().toISOString()
          }
        ]);

        setContractSummaries([
          {
            contract_type: 'premium',
            user_count: 25,
            total_volume: 500000,
            profit_distribution: { user_share: 350000, platform_share: 150000 },
            average_profit_share: 70
          },
          {
            contract_type: 'standard',
            user_count: 150,
            total_volume: 1200000,
            profit_distribution: { user_share: 720000, platform_share: 480000 },
            average_profit_share: 60
          }
        ]);

        setAiPerformance([
          {
            ai_agent_id: 'quantum_ai_001',
            agent_name: 'Quantum AI Predictor',
            total_trades: 1247,
            successful_trades: 978,
            success_rate: 78.5,
            total_profit: 125000,
            average_trade_duration: 45.2,
            strategies_used: ['quantum_prediction', 'market_analysis', 'risk_management'],
            last_active: new Date().toISOString()
          },
          {
            ai_agent_id: 'stealth_executor_002',
            agent_name: 'Stealth Execution Engine',
            total_trades: 892,
            successful_trades: 734,
            success_rate: 82.3,
            total_profit: 98000,
            average_trade_duration: 32.1,
            strategies_used: ['stealth_execution', 'arbitrage', 'momentum'],
            last_active: new Date().toISOString()
          }
        ]);

        setStrategies([
          {
            strategy_id: 'quantum_momentum_v2',
            name: 'Quantum Momentum Strategy v2.0',
            description: 'Advanced quantum-based momentum trading with ML prediction',
            success_rate: 78.5,
            total_uses: 1247,
            created_date: '2024-01-15',
            last_updated: new Date().toISOString(),
            is_active: true
          },
          {
            strategy_id: 'stealth_arbitrage_pro',
            name: 'Stealth Arbitrage Pro',
            description: 'Cross-exchange arbitrage with stealth execution',
            success_rate: 82.3,
            total_uses: 892,
            created_date: '2024-02-10',
            last_updated: new Date().toISOString(),
            is_active: true
          }
        ]);

        setTransactions([
          {
            transaction_id: 'tx_001',
            user_id: 1,
            user_email: 'user1@example.com',
            transaction_type: 'deposit',
            amount: 5000,
            currency: 'USD',
            status: 'completed',
            created_at: new Date().toISOString(),
            fee: 25
          },
          {
            transaction_id: 'tx_002',
            user_id: 2,
            user_email: 'user2@example.com',
            transaction_type: 'withdrawal',
            amount: 1500,
            currency: 'USD',
            status: 'pending',
            created_at: new Date().toISOString(),
            fee: 15
          }
        ]);

        setAdminAccounts({
          admin_accounts: [
            {
              account_id: 'admin_001',
              name: 'UMMAH AI Platform',
              balance: 1250000,
              currency: 'USD',
              account_type: 'platform_reserve'
            },
            {
              account_id: 'admin_002',
              name: 'Profit Distribution Pool',
              balance: 485000,
              currency: 'USD',
              account_type: 'profit_pool'
            }
          ],
          platform_statistics: {
            total_platform_revenue: 2847500,
            total_user_profits: 1892300,
            platform_profit_share: 955200,
            active_trading_volume_24h: 15847200,
            total_fees_collected: 127800
          },
          generated_at: new Date().toISOString()
        });

        setPendingRegistrations([
          {
            id: 1,
            email: 'newuser@example.com',
            full_name: 'Omar Abdullah',
            registration_stage: 'completed',
            registration_complete: true,
            document_verified: true,
            biometric_verified: true,
            email_verified: true,
            phone_verified: true,
            wallet_connected: true,
            contract_signed: true,
            created_at: new Date().toISOString()
          }
        ]);
      }

    } catch (err) {
      setError('Failed to fetch admin data');
      console.error('Admin data fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  const approveUser = async (userId: number, action: 'approve' | 'reject', reason?: string) => {
    try {
      const token = localStorage.getItem('admin_token') || 'demo_token';
      const response = await fetch('/api/admin/registrations/approve', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          user_id: userId,
          action,
          reason
        })
      });

      if (response.ok) {
        setPendingRegistrations(prev => prev.filter(user => user.id !== userId));
        await fetchAdminData();
      }
    } catch (err) {
      console.error('Approval error:', err);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-900">
        <div className="text-white text-xl">Loading admin dashboard...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-900">
        <div className="text-red-400 text-xl">{error}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">🛡️ UMMAH AI Admin Dashboard</h1>
          <p className="text-gray-400">Comprehensive platform management and monitoring</p>
        </div>

        <div className="flex space-x-4 mb-6">
          {['overview', 'users', 'finances', 'ai', 'strategies', 'transactions', 'approvals'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                activeTab === tab
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-green-400">💰 Platform Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  ${adminAccounts?.platform_statistics.total_platform_revenue.toLocaleString() || '0'}
                </div>
                <p className="text-gray-400">Total platform revenue</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-blue-400">👥 Active Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{userBalances.length}</div>
                <p className="text-gray-400">Approved users</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-purple-400">🤖 AI Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {aiPerformance.length > 0 ? 
                    Math.round(aiPerformance.reduce((acc, ai) => acc + ai.success_rate, 0) / aiPerformance.length) : 0}%
                </div>
                <p className="text-gray-400">Average AI success rate</p>
              </CardContent>
            </Card>

            {adminAccounts?.admin_accounts.map((account) => (
              <Card key={account.account_id} className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-yellow-400">🏦 {account.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">
                    ${account.balance.toLocaleString()} {account.currency}
                  </div>
                  <p className="text-gray-400">{account.account_type}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {activeTab === 'users' && (
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle>👥 User Balances & Contracts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-700">
                      <th className="text-left p-2">User</th>
                      <th className="text-left p-2">Total Balance</th>
                      <th className="text-left p-2">Available</th>
                      <th className="text-left p-2">Contract</th>
                      <th className="text-left p-2">Profit Share</th>
                      <th className="text-left p-2">Last Activity</th>
                    </tr>
                  </thead>
                  <tbody>
                    {userBalances.map((user) => (
                      <tr key={user.user_id} className="border-b border-gray-700">
                        <td className="p-2">
                          <div>
                            <div className="font-medium">{user.full_name}</div>
                            <div className="text-gray-400 text-xs">{user.email}</div>
                          </div>
                        </td>
                        <td className="p-2 font-mono">${user.total_balance.toLocaleString()}</td>
                        <td className="p-2 font-mono text-green-400">${user.available_balance.toLocaleString()}</td>
                        <td className="p-2">
                          <span className="px-2 py-1 bg-blue-600 rounded text-xs">
                            {user.contract_type}
                          </span>
                        </td>
                        <td className="p-2">{user.profit_share_percentage}%</td>
                        <td className="p-2 text-gray-400">
                          {new Date(user.last_activity).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {activeTab === 'finances' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle>📊 Contract Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {contractSummaries.map((contract) => (
                    <div key={contract.contract_type} className="border border-gray-700 rounded p-4">
                      <div className="flex justify-between items-center mb-2">
                        <h3 className="font-medium">{contract.contract_type}</h3>
                        <span className="text-blue-400">{contract.user_count} users</span>
                      </div>
                      <div className="text-sm text-gray-400">
                        <div>Total Volume: ${contract.total_volume.toLocaleString()}</div>
                        <div>Avg Profit Share: {contract.average_profit_share}%</div>
                        <div>User Share: ${contract.profit_distribution.user_share.toLocaleString()}</div>
                        <div>Platform Share: ${contract.profit_distribution.platform_share.toLocaleString()}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle>💹 Platform Statistics</CardTitle>
              </CardHeader>
              <CardContent>
                {adminAccounts && (
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span>Total User Profits:</span>
                      <span className="text-green-400 font-mono">
                        ${adminAccounts.platform_statistics.total_user_profits.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Platform Profit Share:</span>
                      <span className="text-blue-400 font-mono">
                        ${adminAccounts.platform_statistics.platform_profit_share.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>24h Trading Volume:</span>
                      <span className="text-purple-400 font-mono">
                        ${adminAccounts.platform_statistics.active_trading_volume_24h.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Fees Collected:</span>
                      <span className="text-yellow-400 font-mono">
                        ${adminAccounts.platform_statistics.total_fees_collected.toLocaleString()}
                      </span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === 'ai' && (
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle>🤖 AI Agent Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {aiPerformance.map((ai) => (
                  <div key={ai.ai_agent_id} className="border border-gray-700 rounded p-4">
                    <h3 className="font-medium mb-2">{ai.agent_name}</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Total Trades:</span>
                        <span className="text-blue-400">{ai.total_trades}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Success Rate:</span>
                        <span className="text-green-400">{ai.success_rate}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Total Profit:</span>
                        <span className="text-yellow-400">${ai.total_profit.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Avg Duration:</span>
                        <span className="text-purple-400">{ai.average_trade_duration.toFixed(1)}min</span>
                      </div>
                      <div className="mt-2">
                        <span className="text-gray-400">Strategies:</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {ai.strategies_used.map((strategy, idx) => (
                            <span key={idx} className="px-2 py-1 bg-gray-700 rounded text-xs">
                              {strategy}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {activeTab === 'strategies' && (
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle>📚 Trading Strategies Library</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {strategies.map((strategy) => (
                  <div key={strategy.strategy_id} className="border border-gray-700 rounded p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-medium">{strategy.name}</h3>
                      <span className={`px-2 py-1 rounded text-xs ${
                        strategy.is_active ? 'bg-green-600' : 'bg-red-600'
                      }`}>
                        {strategy.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    <p className="text-gray-400 text-sm mb-3">{strategy.description}</p>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>Success Rate:</span>
                        <span className="text-green-400">{strategy.success_rate}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Total Uses:</span>
                        <span className="text-blue-400">{strategy.total_uses}</span>
                      </div>
                      <div className="text-gray-400 text-xs mt-2">
                        Updated: {new Date(strategy.last_updated).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {activeTab === 'transactions' && (
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle>💳 Recent Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-700">
                      <th className="text-left p-2">ID</th>
                      <th className="text-left p-2">User</th>
                      <th className="text-left p-2">Type</th>
                      <th className="text-left p-2">Amount</th>
                      <th className="text-left p-2">Status</th>
                      <th className="text-left p-2">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.slice(0, 20).map((txn) => (
                      <tr key={txn.transaction_id} className="border-b border-gray-700">
                        <td className="p-2 font-mono text-xs">{txn.transaction_id.slice(0, 8)}...</td>
                        <td className="p-2">{txn.user_email}</td>
                        <td className="p-2">
                          <span className={`px-2 py-1 rounded text-xs ${
                            txn.transaction_type === 'deposit' ? 'bg-green-600' : 'bg-red-600'
                          }`}>
                            {txn.transaction_type}
                          </span>
                        </td>
                        <td className="p-2 font-mono">${txn.amount.toLocaleString()} {txn.currency}</td>
                        <td className="p-2">
                          <span className={`px-2 py-1 rounded text-xs ${
                            txn.status === 'completed' ? 'bg-green-600' : 
                            txn.status === 'pending' ? 'bg-yellow-600' : 'bg-red-600'
                          }`}>
                            {txn.status}
                          </span>
                        </td>
                        <td className="p-2 text-gray-400">
                          {new Date(txn.created_at).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {activeTab === 'approvals' && (
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle>⏳ Pending User Approvals</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pendingRegistrations.map((user) => (
                  <div key={user.id} className="border border-gray-700 rounded p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="font-medium">{user.full_name}</h3>
                        <p className="text-gray-400 text-sm">{user.email}</p>
                      </div>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => approveUser(user.id, 'approve')}
                          className="px-3 py-1 bg-green-600 hover:bg-green-700 rounded text-sm"
                        >
                          ✅ Approve
                        </button>
                        <button
                          onClick={() => approveUser(user.id, 'reject', 'Manual review required')}
                          className="px-3 py-1 bg-red-600 hover:bg-red-700 rounded text-sm"
                        >
                          ❌ Reject
                        </button>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                      <div className={`p-2 rounded ${user.document_verified ? 'bg-green-600' : 'bg-red-600'}`}>
                        📄 Documents: {user.document_verified ? 'Verified' : 'Pending'}
                      </div>
                      <div className={`p-2 rounded ${user.biometric_verified ? 'bg-green-600' : 'bg-red-600'}`}>
                        🧬 Biometric: {user.biometric_verified ? 'Verified' : 'Pending'}
                      </div>
                      <div className={`p-2 rounded ${user.wallet_connected ? 'bg-green-600' : 'bg-red-600'}`}>
                        💰 Wallet: {user.wallet_connected ? 'Connected' : 'Pending'}
                      </div>
                      <div className={`p-2 rounded ${user.contract_signed ? 'bg-green-600' : 'bg-red-600'}`}>
                        📝 Contract: {user.contract_signed ? 'Signed' : 'Pending'}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
