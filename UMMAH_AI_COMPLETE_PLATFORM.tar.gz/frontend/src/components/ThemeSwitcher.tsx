import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Palette, Space, Zap, Building2, X } from 'lucide-react';

/**
 * Represents a theme configuration object
 */
interface Theme {
  /** Unique identifier for the theme */
  id: string;
  /** Display name of the theme */
  name: string;
  /** Description of the theme's visual style */
  description: string;
  /** Icon component for the theme */
  icon: React.ReactNode;
  /** CSS gradient preview for the theme */
  preview: string;
}

/**
 * Props for the ThemeSwitcher component
 */
interface ThemeSwitcherProps {
  /** Currently active theme identifier */
  currentTheme: string;
  /** Callback function when theme is changed */
  onThemeChange: (theme: string) => void;
  /** Whether the theme switcher modal is visible */
  isVisible: boolean;
  /** Callback function to close the modal */
  onClose: () => void;
}

/**
 * ThemeSwitcher - Modal component for selecting platform background themes
 * 
 * Provides a user interface for switching between different immersive background themes
 * including Space Odyssey, Cyberpunk Matrix, and Smart City. Each theme includes
 * WebGL-powered backgrounds with particle systems and visual effects.
 * 
 * @param props - Component props
 * @param props.currentTheme - Currently active theme identifier
 * @param props.onThemeChange - Callback when user selects a new theme
 * @param props.isVisible - Whether the modal should be displayed
 * @param props.onClose - Callback to close the theme switcher modal
 * @returns JSX.Element - Rendered theme switcher modal
 */
const ThemeSwitcher: React.FC<ThemeSwitcherProps> = ({
  currentTheme,
  onThemeChange,
  isVisible,
  onClose
}) => {
  const themes: Theme[] = [
    {
      id: 'space',
      name: 'Space Odyssey',
      description: 'Deep space exploration with nebulae and starfields',
      icon: <Space className="w-6 h-6" />,
      preview: 'linear-gradient(45deg, #0f3460, #16537e, #1e88e5)'
    },
    {
      id: 'cyberpunk',
      name: 'Cyberpunk Matrix',
      description: 'Neon-lit digital realm with glitch effects',
      icon: <Zap className="w-6 h-6" />,
      preview: 'linear-gradient(45deg, #0d0208, #1a0e1a, #2d1b2d)'
    },
    {
      id: 'smart-city',
      name: 'Smart City',
      description: 'Connected urban landscape with data flows',
      icon: <Building2 className="w-6 h-6" />,
      preview: 'linear-gradient(180deg, #1e3c72, #2a5298, #4caf50)'
    }
  ];

  /**
   * Handles theme selection and closes the modal
   * @param themeId - The ID of the selected theme
   */
  const handleThemeSelect = (themeId: string) => {
    onThemeChange(themeId);
    onClose();
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <Card className="bg-gradient-to-br from-gray-900 to-gray-800 border border-cyan-400 text-white max-w-2xl w-full">
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center">
              <Palette className="w-6 h-6 mr-2 text-cyan-400" />
              <h2 className="text-2xl font-bold text-cyan-400">Choose Background Theme</h2>
            </div>
            <Button
              onClick={onClose}
              className="bg-transparent hover:bg-red-600 p-2"
              size="sm"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {themes.map((theme) => (
              <Card
                key={theme.id}
                className={`cursor-pointer transition-all duration-300 ${
                  currentTheme === theme.id
                    ? 'border-cyan-400 bg-cyan-900/20 shadow-lg shadow-cyan-400/20'
                    : 'border-gray-600 bg-gray-800 hover:border-gray-500'
                }`}
                onClick={() => handleThemeSelect(theme.id)}
              >
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="text-cyan-400 mr-3">
                      {theme.icon}
                    </div>
                    <h3 className="text-lg font-semibold text-white">{theme.name}</h3>
                  </div>
                  
                  <div 
                    className="w-full h-24 rounded-lg mb-4 border border-gray-600"
                    style={{ background: theme.preview }}
                  ></div>
                  
                  <p className="text-sm text-gray-400 mb-4">{theme.description}</p>
                  
                  {currentTheme === theme.id && (
                    <div className="flex items-center text-cyan-400 text-sm">
                      <div className="w-2 h-2 bg-cyan-400 rounded-full mr-2 animate-pulse"></div>
                      Currently Active
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-6 p-4 bg-gray-800 rounded-lg border border-gray-700">
            <h4 className="text-cyan-400 font-semibold mb-2">Theme Features</h4>
            <ul className="text-sm text-gray-300 space-y-1">
              <li>• Dynamic particle systems and visual effects</li>
              <li>• Immersive WebGL-powered backgrounds</li>
              <li>• Responsive design across all devices</li>
              <li>• Smooth transitions and animations</li>
              <li>• Optimized performance for trading operations</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ThemeSwitcher;
