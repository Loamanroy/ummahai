import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bot, Activity, Settings, Plus, Zap, Shield, TrendingUp, Eye, BarChart3, Clock, Cpu, Network } from 'lucide-react';

/**
 * Represents an AI agent with its performance metrics and system information
 */
interface AIAgent {
  /** Unique identifier for the agent */
  id: number;
  /** Display name of the agent */
  name: string;
  /** Current operational status */
  status: string;
  /** Current activity description */
  activity: string;
  /** Type/category of the AI agent */
  type: string;
  /** Performance metrics for the agent */
  performance?: {
    /** Uptime in seconds */
    uptime: number;
    /** Number of completed tasks */
    tasksCompleted: number;
    /** Success rate as percentage */
    successRate: number;
    /** Average response time in milliseconds */
    avgResponseTime: number;
  };
  /** Real-time system metrics */
  metrics?: {
    /** CPU usage percentage */
    cpuUsage: number;
    /** Memory usage percentage */
    memoryUsage: number;
    /** Network activity percentage */
    networkActivity: number;
  };
  /** Timestamp of last activity */
  lastActivity?: string;
  /** Agent creation timestamp */
  createdAt?: string;
}

/**
 * Props for the AIAgentsPanel component
 */
interface AIAgentsPanelProps {
  /** Array of AI agents to display */
  agents: AIAgent[];
  /** Callback function when user creates a new agent */
  onCreateAgent?: () => void;
  /** Callback function when user monitors an agent */
  onMonitorAgent?: (agentId: number) => void;
  /** Callback function when user configures an agent */
  onConfigureAgent?: (agentId: number) => void;
  /** ID of agent currently being processed (for loading state) */
  actionLoading?: number | null;
  /** Error message for agent actions */
  actionError?: string | null;
}

/**
 * AIAgentsPanel - Control center for managing AI agents with real-time monitoring
 * 
 * This component displays a comprehensive dashboard for AI agents including their status,
 * performance metrics, real-time system monitoring, and management controls. It provides
 * an interactive interface for creating, monitoring, and configuring AI agents.
 * 
 * @param props - Component props
 * @param props.agents - Array of AI agents to display
 * @param props.onCreateAgent - Optional callback when user creates a new agent
 * @param props.onMonitorAgent - Optional callback when user monitors an agent
 * @param props.onConfigureAgent - Optional callback when user configures an agent
 * @returns JSX.Element - Rendered AI Agents Panel component
 */
const AIAgentsPanel: React.FC<AIAgentsPanelProps> = ({ 
  agents, 
  onCreateAgent, 
  onMonitorAgent, 
  onConfigureAgent,
  actionLoading,
  actionError
}) => {
  const [selectedAgent, setSelectedAgent] = useState<number | null>(null);
  const [realTimeMetrics, setRealTimeMetrics] = useState<{[key: number]: any}>({});

  /**
   * Returns the appropriate icon component for an agent type
   * @param type - The type of AI agent
   * @returns JSX.Element - Icon component for the agent type
   */
  const getAgentIcon = (type: string) => {
    switch (type) {
      case 'Trading AI': return <TrendingUp className="w-5 h-5" />;
      case 'Prediction AI': return <Zap className="w-5 h-5" />;
      case 'Execution AI': return <Activity className="w-5 h-5" />;
      case 'Security AI': return <Shield className="w-5 h-5" />;
      default: return <Bot className="w-5 h-5" />;
    }
  };

  /**
   * Returns the appropriate CSS color class for an agent status
   * @param status - The current status of the agent
   * @returns string - CSS color class name
   */
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active & breathing':
      case 'active': return 'text-green-400';
      case 'processing': return 'text-blue-400';
      case 'scanning': return 'text-yellow-400';
      case 'standby': return 'text-gray-400';
      default: return 'text-white';
    }
  };

  /**
   * Formats uptime seconds into human-readable format
   * @param seconds - Uptime in seconds
   * @returns string - Formatted uptime string (e.g., "24h 30m")
   */
  const formatUptime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };

  /**
   * Returns appropriate color class based on performance value and type
   * @param value - The performance value to evaluate
   * @param type - Type of performance metric ('percentage' or 'response_time')
   * @returns string - CSS color class name
   */
  const getPerformanceColor = (value: number, type: 'percentage' | 'response_time') => {
    if (type === 'percentage') {
      if (value >= 95) return 'text-green-400';
      if (value >= 80) return 'text-yellow-400';
      return 'text-red-400';
    } else {
      if (value <= 100) return 'text-green-400';
      if (value <= 500) return 'text-yellow-400';
      return 'text-red-400';
    }
  };

  useEffect(() => {
    const interval = setInterval(() => {
      const newMetrics: {[key: number]: any} = {};
      agents.forEach(agent => {
        newMetrics[agent.id] = {
          cpuUsage: Math.random() * 100,
          memoryUsage: Math.random() * 100,
          networkActivity: Math.random() * 100,
          timestamp: Date.now()
        };
      });
      setRealTimeMetrics(newMetrics);
    }, 2000);

    return () => clearInterval(interval);
  }, [agents]);

  /**
   * Handles the create agent button click
   */
  const handleCreateAgent = () => {
    if (onCreateAgent) onCreateAgent();
  };

  /**
   * Handles the monitor agent button click
   * @param agentId - ID of the agent to monitor
   */
  const handleMonitorAgent = (agentId: number) => {
    if (onMonitorAgent) onMonitorAgent(agentId);
  };

  /**
   * Handles the configure agent button click
   * @param agentId - ID of the agent to configure
   */
  const handleConfigureAgent = (agentId: number) => {
    if (onConfigureAgent) onConfigureAgent(agentId);
  };

  return (
    <Card className="bg-gray-900 border border-gray-700 text-white" id="ai-agents">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold flex items-center">
            <Bot className="w-6 h-6 mr-2 text-cyan-400" />
            AI Agents Control Center
          </h2>
          <Button
            onClick={handleCreateAgent}
            className="bg-green-600 hover:bg-green-700 text-white text-sm"
          >
            <Plus className="w-4 h-4 mr-1" />
            Create Agent
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {agents.map((agent) => (
            <Card
              key={agent.id}
              className={`bg-gray-800 border transition-all duration-200 cursor-pointer hover:scale-105 ${
                selectedAgent === agent.id 
                  ? 'border-cyan-400 shadow-lg shadow-cyan-400/20' 
                  : 'border-gray-600 hover:border-gray-500'
              }`}
              onClick={() => setSelectedAgent(selectedAgent === agent.id ? null : agent.id)}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center">
                    <div className="bg-gray-700 p-2 rounded-lg mr-3">
                      {getAgentIcon(agent.type)}
                    </div>
                    <div>
                      <h3 className="font-semibold text-white">{agent.name}</h3>
                      <p className="text-xs text-gray-400">{agent.type}</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <div className={`w-2 h-2 rounded-full mr-2 ${
                      agent.status.includes('Active') ? 'bg-green-400 animate-pulse' : 
                      agent.status.includes('Processing') ? 'bg-blue-400 animate-pulse' :
                      agent.status.includes('Scanning') ? 'bg-yellow-400 animate-pulse' :
                      'bg-gray-400'
                    }`} />
                    <span className={`text-sm font-medium ${getStatusColor(agent.status)}`}>
                      {agent.status}
                    </span>
                  </div>
                </div>

                <div className="bg-gray-700 p-3 rounded-lg mb-3">
                  <div className="flex items-center mb-2">
                    <Activity className="w-4 h-4 text-cyan-400 mr-2" />
                    <span className="text-sm font-medium text-cyan-400">Current Activity</span>
                  </div>
                  <p className="text-sm text-gray-300">{agent.activity}</p>
                </div>

                {selectedAgent === agent.id && (
                  <div className="space-y-2 animate-in slide-in-from-top-2">
                    <div className="flex gap-2">
                      <Button 
                        onClick={() => handleMonitorAgent(agent.id)}
                        disabled={actionLoading === agent.id}
                        className={`text-white text-xs flex-1 ${
                          actionLoading === agent.id 
                            ? 'bg-gray-600' 
                            : 'bg-blue-600 hover:bg-blue-700'
                        }`}
                      >
                        <Eye className="w-3 h-3 mr-1" />
                        {actionLoading === agent.id ? 'Loading...' : 'Monitor'}
                      </Button>
                      <Button 
                        onClick={() => handleConfigureAgent(agent.id)}
                        disabled={actionLoading === agent.id}
                        className={`text-white text-xs flex-1 ${
                          actionLoading === agent.id 
                            ? 'bg-gray-600' 
                            : 'bg-gray-600 hover:bg-gray-700'
                        }`}
                      >
                        <Settings className="w-3 h-3 mr-1" />
                        {actionLoading === agent.id ? 'Loading...' : 'Configure'}
                      </Button>
                    </div>
                    
                    {/* Performance Metrics */}
                    {agent.performance && (
                      <div className="text-xs text-gray-400 bg-gray-700 p-2 rounded mb-2">
                        <div className="grid grid-cols-2 gap-2">
                          <div className="flex items-center">
                            <Clock className="w-3 h-3 mr-1 text-cyan-400" />
                            <span className={getPerformanceColor(agent.performance.uptime, 'percentage')}>
                              {formatUptime(agent.performance.uptime)}
                            </span>
                          </div>
                          <div className="flex items-center">
                            <BarChart3 className="w-3 h-3 mr-1 text-green-400" />
                            <span className={getPerformanceColor(agent.performance.successRate, 'percentage')}>
                              {agent.performance.successRate}%
                            </span>
                          </div>
                          <div className="flex items-center">
                            <Activity className="w-3 h-3 mr-1 text-blue-400" />
                            <span>Tasks: {agent.performance.tasksCompleted}</span>
                          </div>
                          <div className="flex items-center">
                            <Zap className="w-3 h-3 mr-1 text-yellow-400" />
                            <span className={getPerformanceColor(agent.performance.avgResponseTime, 'response_time')}>
                              {agent.performance.avgResponseTime}ms
                            </span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Real-time System Metrics */}
                    {realTimeMetrics[agent.id] && (
                      <div className="text-xs text-gray-400 bg-gray-700 p-2 rounded">
                        <div className="grid grid-cols-3 gap-2">
                          <div className="flex items-center">
                            <Cpu className="w-3 h-3 mr-1 text-red-400" />
                            <span>{Math.round(realTimeMetrics[agent.id].cpuUsage)}%</span>
                          </div>
                          <div className="flex items-center">
                            <BarChart3 className="w-3 h-3 mr-1 text-blue-400" />
                            <span>{Math.round(realTimeMetrics[agent.id].memoryUsage)}%</span>
                          </div>
                          <div className="flex items-center">
                            <Network className="w-3 h-3 mr-1 text-green-400" />
                            <span>{Math.round(realTimeMetrics[agent.id].networkActivity)}%</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {actionError && (
          <div className="mt-4 p-3 bg-red-900/50 border border-red-500 rounded-lg">
            <div className="flex items-center">
              <div className="text-red-400 mr-2">⚠️</div>
              <div className="text-red-200 text-sm">{actionError}</div>
            </div>
          </div>
        )}

        <div className="mt-4 p-3 bg-gray-800 rounded-lg border border-gray-600">
          <h4 className="font-semibold text-cyan-400 mb-2">AI Mesh Network Status</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
            <div className="flex justify-between">
              <span>Active Agents:</span>
              <span className="text-green-400">{agents.filter(a => a.status.includes('Active')).length}</span>
            </div>
            <div className="flex justify-between">
              <span>Processing:</span>
              <span className="text-blue-400">{agents.filter(a => a.status.includes('Processing')).length}</span>
            </div>
            <div className="flex justify-between">
              <span>Network Load:</span>
              <span className="text-yellow-400">67%</span>
            </div>
            <div className="flex justify-between">
              <span>Sync Status:</span>
              <span className="text-green-400">Optimal</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AIAgentsPanel;
