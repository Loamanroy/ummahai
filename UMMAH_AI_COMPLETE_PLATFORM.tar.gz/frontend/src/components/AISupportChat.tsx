import React, { useState, useEffect, useRef, useCallback } from 'react';
import { MessageCircle, Send, Bot, User, X, Minimize2, Maximize2, Globe, Clock, Zap } from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'ai' | 'system';
  content: string;
  timestamp: Date;
  language: string;
  responseTime?: number;
  fromCache?: boolean;
  confidence?: number;
}

interface AISupportChatProps {
  isOpen: boolean;
  onToggle: () => void;
  currentLanguage: string;
  onLanguageChange: (language: string) => void;
  userId?: string;
  className?: string;
}

const languages = [
  { code: 'ru', name: 'Русский', flag: '🇷🇺' },
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'ar', name: 'العربية', flag: '🇦🇪' },
  { code: 'tr', name: 'Türkçe', flag: '🇹🇷' }
];

export const AISupportChat: React.FC<AISupportChatProps> = ({
  isOpen,
  onToggle,
  currentLanguage,
  onLanguageChange,
  userId = 'anonymous',
  className = ''
}) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  
  const wsRef = useRef<WebSocket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttempts = useRef(0);
  const maxReconnectAttempts = 5;

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  const addMessage = useCallback((type: 'user' | 'ai' | 'system', content: string, metadata?: Partial<Message>) => {
    const newMessage: Message = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type,
      content,
      timestamp: new Date(),
      language: currentLanguage,
      ...metadata
    };
    
    setMessages(prev => [...prev, newMessage]);
    setTimeout(scrollToBottom, 100);
  }, [currentLanguage, scrollToBottom]);

  const connectWebSocket = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      return;
    }

    setIsConnecting(true);
    setConnectionError(null);

    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/api/support/chat`;
      
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        setIsConnected(true);
        setIsConnecting(false);
        setConnectionError(null);
        reconnectAttempts.current = 0;

        ws.send(JSON.stringify({
          type: 'user_identification',
          user_id: userId,
          language: currentLanguage,
          timestamp: new Date().toISOString()
        }));
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          
          switch (data.type) {
            case 'ai_response':
              setIsTyping(false);
              addMessage('ai', data.content, {
                responseTime: data.response_time_ms,
                fromCache: data.from_cache,
                confidence: data.confidence
              });
              if (data.session_id && !sessionId) {
                setSessionId(data.session_id);
              }
              break;
              
            case 'system_message':
            case 'system_broadcast':
              addMessage('system', data.content);
              break;
              
            case 'pong':
              break;
              
            default:
              console.log('Unknown message type:', data.type);
          }
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };

      ws.onclose = (event) => {
        setIsConnected(false);
        setIsConnecting(false);
        
        if (event.code !== 1000 && reconnectAttempts.current < maxReconnectAttempts) {
          const delay = Math.min(1000 * Math.pow(2, reconnectAttempts.current), 10000);
          reconnectAttempts.current++;
          
          setConnectionError(`Переподключение через ${delay / 1000}с... (попытка ${reconnectAttempts.current})`);
          
          reconnectTimeoutRef.current = setTimeout(() => {
            connectWebSocket();
          }, delay);
        } else if (reconnectAttempts.current >= maxReconnectAttempts) {
          setConnectionError('Не удалось подключиться к службе поддержки. Попробуйте обновить страницу.');
        }
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        setConnectionError('Ошибка подключения к службе поддержки');
        setIsConnecting(false);
      };

    } catch (error) {
      console.error('Failed to create WebSocket connection:', error);
      setConnectionError('Не удалось создать подключение');
      setIsConnecting(false);
    }
  }, [userId, currentLanguage, addMessage, sessionId]);

  const disconnectWebSocket = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
    
    if (wsRef.current) {
      wsRef.current.close(1000, 'User closed chat');
      wsRef.current = null;
    }
    
    setIsConnected(false);
    setIsConnecting(false);
    reconnectAttempts.current = 0;
  }, []);

  const sendMessage = useCallback(async () => {
    const message = inputMessage.trim();
    if (!message || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      return;
    }

    addMessage('user', message);
    setInputMessage('');
    setIsTyping(true);

    try {
      wsRef.current.send(JSON.stringify({
        type: 'user_message',
        message: message,
        language: currentLanguage,
        user_id: userId,
        session_id: sessionId,
        timestamp: new Date().toISOString()
      }));
    } catch (error) {
      console.error('Error sending message:', error);
      setIsTyping(false);
      addMessage('system', 'Ошибка отправки сообщения. Попробуйте еще раз.');
    }
  }, [inputMessage, currentLanguage, userId, sessionId, addMessage]);

  const handleLanguageChange = useCallback((newLanguage: string) => {
    onLanguageChange(newLanguage);
    
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'language_change',
        language: newLanguage,
        user_id: userId,
        timestamp: new Date().toISOString()
      }));
    }
  }, [onLanguageChange, userId]);

  const handleKeyPress = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }, [sendMessage]);

  useEffect(() => {
    if (isOpen && !isConnected && !isConnecting) {
      connectWebSocket();
    } else if (!isOpen && isConnected) {
      disconnectWebSocket();
    }
  }, [isOpen, isConnected, isConnecting, connectWebSocket, disconnectWebSocket]);

  useEffect(() => {
    return () => {
      disconnectWebSocket();
    };
  }, [disconnectWebSocket]);

  useEffect(() => {
    if (isOpen && !isMinimized && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen, isMinimized]);

  const formatResponseTime = (ms?: number) => {
    if (!ms) return '';
    if (ms < 1000) return `${ms}мс`;
    return `${(ms / 1000).toFixed(1)}с`;
  };

  const currentLang = languages.find(lang => lang.code === currentLanguage) || languages[0];

  if (!isOpen) {
    return (
      <button
        onClick={onToggle}
        className={`fixed bottom-6 right-6 z-50 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white p-4 rounded-full shadow-lg transition-all duration-300 hover:scale-110 ${className}`}
        title="Открыть AI поддержку"
      >
        <MessageCircle className="w-6 h-6" />
        {!isConnected && (
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
        )}
      </button>
    );
  }

  return (
    <div className={`fixed bottom-6 right-6 z-50 bg-gray-900 border border-gray-700 rounded-lg shadow-2xl transition-all duration-300 ${isMinimized ? 'w-80 h-16' : 'w-96 h-[600px]'} ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-700 bg-gradient-to-r from-blue-600 to-purple-600 rounded-t-lg">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Bot className="w-6 h-6 text-white" />
            <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full ${isConnected ? 'bg-green-400' : 'bg-red-400'} border-2 border-white`}></div>
          </div>
          <div>
            <h3 className="text-white font-semibold">AI Поддержка UMMAH</h3>
            <p className="text-blue-100 text-xs">
              {isConnected ? 'Онлайн' : isConnecting ? 'Подключение...' : 'Офлайн'}
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          {/* Language Selector */}
          <div className="relative group">
            <button className="flex items-center space-x-1 px-2 py-1 bg-white/20 rounded text-white text-sm hover:bg-white/30 transition-colors">
              <span>{currentLang.flag}</span>
              <span className="text-xs">{currentLang.code.toUpperCase()}</span>
            </button>
            <div className="absolute top-full right-0 mt-1 bg-gray-800 rounded-lg shadow-lg border border-gray-600 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-10">
              {languages.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => handleLanguageChange(lang.code)}
                  className={`flex items-center space-x-2 px-3 py-2 text-sm hover:bg-gray-700 first:rounded-t-lg last:rounded-b-lg w-full text-left ${
                    lang.code === currentLanguage ? 'bg-blue-600 text-white' : 'text-gray-300'
                  }`}
                >
                  <span>{lang.flag}</span>
                  <span>{lang.name}</span>
                </button>
              ))}
            </div>
          </div>
          
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="text-white hover:bg-white/20 p-1 rounded transition-colors"
          >
            {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
          </button>
          
          <button
            onClick={onToggle}
            className="text-white hover:bg-white/20 p-1 rounded transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {!isMinimized && (
        <>
          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 h-[480px] bg-gray-800">
            {connectionError && (
              <div className="bg-red-900/50 border border-red-600 rounded-lg p-3 text-red-200 text-sm">
                {connectionError}
              </div>
            )}
            
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[80%] ${message.type === 'user' ? 'order-2' : 'order-1'}`}>
                  <div className={`flex items-start space-x-2 ${message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      message.type === 'user' 
                        ? 'bg-blue-600' 
                        : message.type === 'ai' 
                        ? 'bg-purple-600' 
                        : 'bg-gray-600'
                    }`}>
                      {message.type === 'user' ? (
                        <User className="w-4 h-4 text-white" />
                      ) : message.type === 'ai' ? (
                        <Bot className="w-4 h-4 text-white" />
                      ) : (
                        <Globe className="w-4 h-4 text-white" />
                      )}
                    </div>
                    
                    <div className={`rounded-lg p-3 ${
                      message.type === 'user'
                        ? 'bg-blue-600 text-white'
                        : message.type === 'ai'
                        ? 'bg-gray-700 text-gray-100'
                        : 'bg-gray-600 text-gray-200'
                    }`}>
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                      
                      <div className="flex items-center justify-between mt-2 text-xs opacity-70">
                        <span>{message.timestamp.toLocaleTimeString()}</span>
                        {message.type === 'ai' && (
                          <div className="flex items-center space-x-2">
                            {message.responseTime && (
                              <span className="flex items-center space-x-1">
                                <Clock className="w-3 h-3" />
                                <span>{formatResponseTime(message.responseTime)}</span>
                              </span>
                            )}
                            {message.fromCache && (
                              <span className="flex items-center space-x-1">
                                <Zap className="w-3 h-3" />
                                <span>Кэш</span>
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                  <div className="bg-gray-700 rounded-lg p-3">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-4 border-t border-gray-700 bg-gray-900">
            <div className="flex space-x-2">
              <input
                ref={inputRef}
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={currentLanguage === 'ru' ? 'Напишите ваш вопрос...' : 
                           currentLanguage === 'en' ? 'Type your question...' :
                           currentLanguage === 'ar' ? 'اكتب سؤالك...' :
                           'Sorunuzu yazın...'}
                className="flex-1 bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                disabled={!isConnected}
              />
              <button
                onClick={sendMessage}
                disabled={!inputMessage.trim() || !isConnected}
                className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white p-2 rounded-lg transition-colors"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
            
            {!isConnected && (
              <div className="mt-2 text-center">
                <button
                  onClick={connectWebSocket}
                  disabled={isConnecting}
                  className="text-blue-400 hover:text-blue-300 text-sm underline disabled:opacity-50"
                >
                  {isConnecting ? 'Подключение...' : 'Переподключиться'}
                </button>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default AISupportChat;
