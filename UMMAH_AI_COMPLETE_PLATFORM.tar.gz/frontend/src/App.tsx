import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { lazy, Suspense } from 'react';
import FullDashboard from './components/FullDashboard';
import ExchangeRouter from './components/exchanges/ExchangeRouter';
import XRRoom from './pages/XRRoom';
import './index.css';

const CognitiveTradeMesh = lazy(() => import('./components/CognitiveTradeMesh'));
const CognitiveMeshDashboard = lazy(() => import('./components/CognitiveMeshDashboard'));
const FilterPanel = lazy(() => import('./components/FilterPanel'));
const ThreatMap = lazy(() => import('./components/ThreatMap'));
const FusionVisualizer = lazy(() => import('./components/FusionVisualizer'));
const UmmahNova = lazy(() => import('./components/UmmahNova'));
const AdminPanel = lazy(() => import('./pages/AdminPanel'));

function App() {
  return (
    <Router>
      <div className="App">
        <Suspense fallback={
          <div className="flex items-center justify-center min-h-screen theme-transition" style={{
            background: 'var(--bg-primary)',
            color: 'var(--text-primary)'
          }}>
            <div className="quantum-particles">
              <div className="quantum-particle"></div>
              <div className="quantum-particle"></div>
              <div className="quantum-particle"></div>
            </div>
            <div className="text-xl glow-text">🧠 Loading UMMAH AI Platform...</div>
          </div>
        }>
          <Routes>
            <Route path="/" element={<FullDashboard />} />
            <Route path="/exchanges/*" element={<ExchangeRouter />} />
            <Route path="/xr-room" element={<XRRoom />} />
            <Route path="/cognitive-mesh" element={<CognitiveTradeMesh />} />
            <Route path="/cognitive-dashboard" element={<CognitiveMeshDashboard />} />
            <Route path="/threat-filter" element={<FilterPanel onFilterChange={() => {}} />} />
            <Route path="/threat-map" element={<ThreatMap />} />
            <Route path="/fusion-visualizer" element={<FusionVisualizer />} />
            <Route path="/ummah-nova" element={<UmmahNova />} />
            <Route path="/admin" element={<AdminPanel />} />
          </Routes>
        </Suspense>
      </div>
    </Router>
  );
}

export default App;
