export interface ExchangeData {
  name: string;
  status: 'live' | 'maintenance' | 'offline';
  volume24h?: number;
  lastUpdate?: Date;
  apiConnected: boolean;
  stealthMode: boolean;
}

export interface OrderBookEntry {
  price: number;
  amount: number;
  total: number;
}

export interface OrderBook {
  asks: OrderBookEntry[];
  bids: OrderBookEntry[];
  lastUpdate: Date;
}

export interface Trade {
  id: string;
  price: number;
  amount: number;
  side: 'buy' | 'sell';
  timestamp: Date;
  exchange: string;
}

export interface TradingPair {
  symbol: string;
  baseAsset: string;
  quoteAsset: string;
  currentPrice: number;
  priceChange24h: number;
  volume24h: number;
  high24h: number;
  low24h: number;
}

export interface WalletBalance {
  [asset: string]: number;
}

export interface AISignal {
  symbol: string;
  prediction: 'bullish' | 'bearish' | 'neutral';
  confidence: number;
  timeframe: string;
  reasoning: string;
  timestamp: Date;
  source: 'CerebellumBot' | 'QuantumAI' | 'PatternRecognition';
}

export interface TradingOrder {
  id: string;
  symbol: string;
  side: 'buy' | 'sell';
  type: 'market' | 'limit' | 'stop';
  amount: number;
  price?: number;
  status: 'pending' | 'filled' | 'cancelled' | 'rejected';
  timestamp: Date;
  exchange: string;
  stealthMode: boolean;
}

export interface ExchangeMetrics {
  totalVolume24h: number;
  activeTrades: number;
  winRate: number;
  profitToday: number;
  stealthScore: number;
  uptime: number;
  anonymityScore: number;
}

export interface StealthConfig {
  paranoiaMode: boolean;
  ipRotation: boolean;
  orderObfuscation: boolean;
  metadataEncryption: boolean;
  torRouting: boolean;
  vpnChain: boolean;
}
