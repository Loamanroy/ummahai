import { ExchangeData, AISignal, TradingOrder, ExchangeMetrics, StealthConfig } from './exchange.js';

export interface NavigationProps {
  onNavigate: (path: string) => void;
}

export interface ExchangeCardProps {
  exchange: ExchangeData;
  onClick: (exchangeName: string) => void;
  className?: string;
}

export interface ExchangeGridProps {
  exchanges: ExchangeData[];
  onExchangeClick: (exchangeName: string) => void;
  className?: string;
}

export interface BinanceInterfaceProps {
  initialPair?: string;
  stealthConfig?: StealthConfig;
}

export interface ExchangeRouterProps {
  defaultExchange?: string;
}

export interface AISignalsPanelProps {
  signals: AISignal[];
  isLoading?: boolean;
  onRefresh?: () => void;
}

export interface TradingPanelProps {
  symbol: string;
  currentPrice: number;
  balance: { [asset: string]: number };
  onPlaceOrder: (order: Omit<TradingOrder, 'id' | 'timestamp' | 'status'>) => void;
  stealthMode: boolean;
}

export interface OrderBookProps {
  asks: Array<{ price: number; amount: number; total: number }>;
  bids: Array<{ price: number; amount: number; total: number }>;
  currentPrice: number;
  onPriceClick?: (price: number) => void;
}

export interface RecentTradesProps {
  trades: Array<{
    id: string;
    price: number;
    amount: number;
    side: 'buy' | 'sell';
    timestamp: Date;
  }>;
  maxItems?: number;
}

export interface MetricsPanelProps {
  metrics: ExchangeMetrics;
  isLoading?: boolean;
  refreshInterval?: number;
}

export interface StealthStatusProps {
  config: StealthConfig;
  onToggleParanoia: () => void;
  onConfigChange: (config: Partial<StealthConfig>) => void;
}

export interface DashboardProps {
  initialView?: 'dashboard' | 'exchanges';
  stealthConfig?: StealthConfig;
}

export interface WalletPanelProps {
  walletConnected: boolean;
  connectWallet: () => Promise<void>;
  balance?: { [asset: string]: number };
  isLoading?: boolean;
}

export interface AIModulesPanelProps {
  paranoiaMode: boolean;
  signals?: AISignal[];
  onToggleParanoia?: () => void;
}

export interface ExchangeSelectionProps {
  exchanges: string[];
  onExchangeSelect: (exchange: string) => void;
  selectedExchange?: string;
}

export interface ComingSoonInterfaceProps {
  exchange: string;
  onBack: () => void;
  estimatedCompletion?: string;
}
