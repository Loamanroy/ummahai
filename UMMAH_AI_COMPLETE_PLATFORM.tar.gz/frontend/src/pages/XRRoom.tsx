import { useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { XR, createXRStore } from '@react-three/xr';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Sphere, Text, Html } from '@react-three/drei';
import AnalyticsXRPanel from '../components/xr/AnalyticsXRPanel';
import { routeVoiceCommand } from '../utils/voiceCommandRouter';
import { useResponsive } from '../hooks/useResponsive';
import { wsWorkerManager } from '../workers/websocketWorker';
import { ResponsiveContainer } from '../components/ui/ResponsiveContainer';

interface TradingSignal {
  id: string;
  exchange: string;
  pair: string;
  action: 'buy' | 'sell';
  price: number;
  confidence: number;
  timestamp: Date;
  profit?: number;
}

interface Trader {
  id: string;
  name: string;
  profit: number;
  trades: number;
  winRate: number;
  avatar: string;
}

interface VoiceLogEntry {
  timestamp: Date;
  command: string;
  response: string;
  type: 'user' | 'ai';
}

function TradeScene({ exchange }: { exchange: string }) {
  const [signals, setSignals] = useState<TradingSignal[]>([]);
  const [status, setStatus] = useState('Загрузка сигналов...');
  const [earnings, setEarnings] = useState(0);
  const [voiceLog, setVoiceLog] = useState<VoiceLogEntry[]>([]);
  const [traders, setTraders] = useState<Trader[]>([]);
  const [isListening, setIsListening] = useState(false);
  const [zkpStatus, setZkpStatus] = useState<'idle' | 'generating' | 'verified' | 'failed'>('idle');
  
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  
  const responsive = useResponsive();

  useEffect(() => {
    const wsUrl = `ws://localhost:8000/ws/scene?session_id=${exchange}`;
    
    wsWorkerManager.createOptimizedConnection(
      exchange,
      wsUrl,
      (data) => {
        try {
          if (Array.isArray(data)) {
            const filteredSignals = data
              .filter((signal: any) => signal.exchange === exchange)
              .map((signal: any) => ({
                ...signal,
                id: `${signal.exchange}-${Date.now()}-${Math.random()}`,
                timestamp: new Date(signal.timestamp || Date.now()),
                latency: performance.now() - (signal._receiveTime || Date.now())
              }));
            
            setSignals(prev => [...prev, ...filteredSignals].slice(-20));
            
            const totalProfit = filteredSignals.reduce((sum: number, signal: any) => 
              sum + (signal.profit || Math.random() * 50 - 25), 0
            );
            setEarnings(prev => prev + totalProfit);
            
            if (filteredSignals.length > 0) {
              generateZKP(filteredSignals);
            }
          } else if (data.type === 'trading_signal' && data.exchange === exchange) {
            const signal = {
              ...data,
              id: `${data.exchange}-${Date.now()}-${Math.random()}`,
              timestamp: new Date(data.timestamp || Date.now()),
              latency: performance.now() - (data._receiveTime || Date.now())
            };
            
            setSignals(prev => [...prev, signal].slice(-20));
            setEarnings(prev => prev + (data.profit || 0));
            
            generateZKP([signal]);
          } else if (data.type === 'session_initialized') {
            console.log('XR session initialized:', data);
            setStatus(`Подключен к ${exchange.toUpperCase()}`);
          }
          
          const avgLatency = wsWorkerManager.getAverageLatency(exchange);
          if (avgLatency > 0) {
            setStatus(`Подключен к ${exchange.toUpperCase()} (${avgLatency.toFixed(1)}ms)`);
          } else {
            setStatus(`Подключен к ${exchange.toUpperCase()}`);
          }
        } catch (error) {
          console.error('WebSocket message parsing error:', error);
        }
      },
      (error) => {
        console.error('WebSocket error:', error);
        setStatus(`Ошибка подключения к ${exchange.toUpperCase()}`);
      }
    );

    return () => {
      wsWorkerManager.disconnect(exchange);
    };
  }, [exchange]);

  useEffect(() => {
    const initializeSpeechRecognition = async () => {
      if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        try {
          await navigator.mediaDevices.getUserMedia({ audio: true });
          
          const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
          const recognition = new SpeechRecognition();
          
          recognition.continuous = true;
          recognition.interimResults = false;
          recognition.lang = 'ru-RU';
          
          recognition.onstart = () => {
            setIsListening(true);
            console.log('Voice recognition started');
          };
          
          recognition.onresult = async (event) => {
            const command = event.results[event.results.length - 1][0].transcript.toLowerCase().trim();
            console.log('Voice command:', command);
            
            const response = await routeVoiceCommand(command, exchange);
            
            setVoiceLog(prev => [
              ...prev.slice(-4),
              {
                timestamp: new Date(),
                command,
                response,
                type: 'user'
              }
            ]);
            
            speakAI(response);
          };
          
          recognition.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            setIsListening(false);
            if (event.error === 'not-allowed') {
              speakAI('Разрешите доступ к микрофону для голосовых команд');
            }
          };
          
          recognition.onend = () => {
            setIsListening(false);
            if (isListening) {
              setTimeout(() => recognition.start(), 1000);
            }
          };
          
          recognitionRef.current = recognition;
          synthRef.current = window.speechSynthesis;
          
          setTimeout(() => recognition.start(), 2000);
        } catch (error) {
          console.error('Microphone access denied:', error);
          speakAI('Доступ к микрофону не предоставлен');
        }
      } else {
        console.warn('Speech recognition not supported');
        speakAI('Голосовые команды не поддерживаются в этом браузере');
      }
    };

    initializeSpeechRecognition();

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [exchange]);

  const generateZKP = async (signalBatch: TradingSignal[]) => {
    setZkpStatus('generating');
    
    try {
      const formData = new FormData();
      formData.append('zkp_id', `zkp_${Date.now()}_${exchange}`);
      formData.append('proof_type', 'trading_signals');
      formData.append('proof_data', btoa(JSON.stringify(signalBatch)));
      
      const response = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/v1/xr/zkp/store`, {
        method: 'POST',
        body: formData
      });
      
      const result = await response.json();
      
      if (result.stored) {
        setZkpStatus('verified');
        setTimeout(() => setZkpStatus('idle'), 3000);
      } else {
        setZkpStatus('failed');
        speakAI('Ошибка верификации ZKP');
      }
    } catch (error) {
      console.error('ZKP generation error:', error);
      setZkpStatus('failed');
    }
  };

  const accessExchangeViaTOR = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/tor-proxy`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ exchange, action: 'access' })
      });
      
      const result = await response.json();
      
      if (result.proxy_url) {
        window.open(result.proxy_url, '_blank');
        speakAI('Доступ через TOR открыт');
      }
    } catch (error) {
      console.error('TOR proxy error:', error);
      speakAI('Ошибка TOR прокси');
    }
  };

  const speakAI = (text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'ru-RU';
      speechSynthesis.speak(utterance);
      setVoiceLog(prev => [...prev.slice(-5), {
        timestamp: new Date(),
        command: '',
        response: text,
        type: 'ai'
      }]);
    } else {
      console.warn('Web Speech API не поддерживается в этом браузере.');
    }
  };

  const handleAutoWithdraw = async () => {
    if (earnings >= 100) {
      try {
        const response = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/trading/withdraw`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            exchange,
            amount: earnings,
            currency: 'USDT'
          })
        });
        
        const result = await response.json();
        
        if (result.success) {
          setEarnings(0);
          speakAI(`Вывод ${earnings} USDT выполнен успешно`);
        }
      } catch (error) {
        console.error('Withdrawal error:', error);
      }
    }
  };

  useEffect(() => {
    if (earnings >= 100) {
      handleAutoWithdraw();
    }
  }, [earnings]);

  useEffect(() => {
    const mockTraders: Trader[] = [
      { id: '1', name: 'CryptoMaster', profit: 15420.50, trades: 1247, winRate: 87.3, avatar: '🚀' },
      { id: '2', name: 'BlockchainPro', profit: 8930.25, trades: 892, winRate: 82.1, avatar: '💎' },
      { id: '3', name: 'DeFiExpert', profit: 12100.75, trades: 1056, winRate: 89.7, avatar: '⚡' },
      { id: '4', name: 'TradingBot', profit: 6750.00, trades: 2341, winRate: 76.4, avatar: '🤖' },
    ];
    setTraders(mockTraders);
  }, []);

  return (
    <>
      {/* Exchange Name */}
      <Text
        position={[0, responsive.isMobile ? 3 : 4, -2]}
        fontSize={responsive.isMobile ? 0.8 : responsive.isTablet ? 1.0 : 1.2}
        color="#00ff88"
        anchorX="center"
        anchorY="middle"
      >
        {exchange.toUpperCase()} XR TRADING
      </Text>

      {/* Status Display */}
      <Text
        position={[responsive.isMobile ? -2 : -3, responsive.isMobile ? 2.5 : 3, -2]}
        fontSize={responsive.isMobile ? 0.4 : 0.6}
        color={status.includes('Подключен') ? '#00ff88' : '#ff4444'}
        anchorX="left"
        anchorY="middle"
      >
        {responsive.isMobile ? status.substring(0, 20) + (status.length > 20 ? '...' : '') : status}
      </Text>

      {/* Earnings Display */}
      <Text
        position={[responsive.isMobile ? 2 : 3, responsive.isMobile ? 2.5 : 3, -2]}
        fontSize={responsive.isMobile ? 0.5 : 0.8}
        color={earnings >= 0 ? '#00ff88' : '#ff4444'}
        anchorX="right"
        anchorY="middle"
      >
        ${earnings.toFixed(2)} USDT
      </Text>

      {/* ZKP Status */}
      <Text
        position={[0, 2.5, -2]}
        fontSize={0.4}
        color={
          zkpStatus === 'verified' ? '#00ff88' :
          zkpStatus === 'generating' ? '#ffaa00' :
          zkpStatus === 'failed' ? '#ff4444' : '#888888'
        }
        anchorX="center"
        anchorY="middle"
      >
        ZKP: {zkpStatus.toUpperCase()}
      </Text>

      {/* Trading Signals as 3D Spheres */}
      {signals.map((signal, index) => (
        <Sphere
          key={signal.id}
          position={[
            (index % 5 - 2) * 1.5,
            Math.floor(index / 5) * 0.8 - 1,
            -3
          ]}
          args={[0.2, 16, 16]}
        >
          <meshStandardMaterial
            color={signal.action === 'buy' ? '#00ff88' : '#ff4444'}
            emissive={signal.action === 'buy' ? '#004422' : '#442200'}
            emissiveIntensity={0.3}
          />
        </Sphere>
      ))}

      {/* Interactive Buttons */}
      <Html 
        position={[
          responsive.isMobile ? -2.5 : -4, 
          responsive.isMobile ? -0.5 : -1, 
          -2
        ]} 
        transform 
        occlude
      >
        <ResponsiveContainer
          className="bg-black/80 rounded-lg border border-cyan-400 text-white"
          mobileClassName="p-2 text-xs"
          tabletClassName="p-3 text-sm"
          desktopClassName="p-4 text-base"
        >
          <button
            onClick={accessExchangeViaTOR}
            className={`bg-purple-600 hover:bg-purple-700 rounded mb-2 w-full transition-colors ${
              responsive.isMobile ? 'px-2 py-1 text-xs' : 'px-4 py-2'
            }`}>
            🔐 {responsive.isMobile ? 'TOR' : 'TOR Access'}
          </button>
          <button
            onClick={handleAutoWithdraw}
            disabled={earnings < 100}
            className={`rounded w-full transition-colors ${
              responsive.isMobile ? 'px-2 py-1 text-xs' : 'px-4 py-2'
            } ${
              earnings >= 100 
                ? 'bg-green-600 hover:bg-green-700' 
                : 'bg-gray-600 cursor-not-allowed'
            }`}
          >
            💰 {responsive.isMobile ? `${earnings.toFixed(0)}` : `Withdraw (${earnings.toFixed(0)} USDT)`}
          </button>
        </ResponsiveContainer>
      </Html>

      {/* Voice Log */}
      <Html 
        position={[
          responsive.isMobile ? 2.5 : 4, 
          responsive.isMobile ? -0.5 : -1, 
          -2
        ]} 
        transform 
        occlude
      >
        <ResponsiveContainer
          className="bg-black/80 rounded-lg border border-cyan-400 text-white"
          mobileClassName="p-2 w-48"
          tabletClassName="p-3 w-64"
          desktopClassName="p-4 w-80"
        >
          <div className="flex items-center mb-2">
            <div className={`rounded-full mr-2 ${isListening ? 'bg-red-500 animate-pulse' : 'bg-gray-500'} ${
              responsive.isMobile ? 'w-2 h-2' : 'w-3 h-3'
            }`}></div>
            <span className={responsive.isMobile ? 'text-xs' : 'text-sm'}>
              {responsive.isMobile ? 'Voice' : 'Voice Commands'}
            </span>
          </div>
          <div className={`space-y-1 overflow-y-auto ${
            responsive.isMobile ? 'max-h-24' : 'max-h-32'
          }`}>
            {voiceLog.slice(responsive.isMobile ? -3 : -5).map((entry, index) => (
              <div key={index} className={responsive.isMobile ? 'text-xs' : 'text-xs'}>
                <div className="text-cyan-400 truncate">
                  👤 {responsive.isMobile && entry.command.length > 15 
                    ? entry.command.substring(0, 15) + '...' 
                    : entry.command}
                </div>
                <div className="text-green-400 truncate">
                  🤖 {responsive.isMobile && entry.response.length > 15 
                    ? entry.response.substring(0, 15) + '...' 
                    : entry.response}
                </div>
              </div>
            ))}
          </div>
        </ResponsiveContainer>
      </Html>

      {/* Trader Cards */}
      {traders.slice(0, responsive.isMobile ? 2 : 4).map((trader, index) => (
        <Html
          key={trader.id}
          position={[
            responsive.isMobile 
              ? (index % 2 - 0.5) * 4
              : (index % 2 - 0.5) * 8,
            responsive.isMobile 
              ? -2.5 + Math.floor(index / 2) * -1
              : -3 + Math.floor(index / 2) * -1.5,
            -2
          ]}
          transform
          occlude
        >
          <ResponsiveContainer
            className="bg-gradient-to-br from-gray-900 to-black rounded-lg border border-cyan-400 text-white"
            mobileClassName="p-2 w-32"
            tabletClassName="p-2.5 w-40"
            desktopClassName="p-3 w-48"
          >
            <div className="flex items-center mb-2">
              <span className={`mr-2 ${responsive.isMobile ? 'text-lg' : 'text-2xl'}`}>
                {trader.avatar}
              </span>
              <div>
                <div className={`font-bold ${responsive.isMobile ? 'text-xs' : 'text-sm'}`}>
                  {responsive.isMobile && trader.name.length > 8 
                    ? trader.name.substring(0, 8) + '...' 
                    : trader.name}
                </div>
                <div className={`text-gray-400 ${responsive.isMobile ? 'text-xs' : 'text-xs'}`}>
                  {trader.trades} trades
                </div>
              </div>
            </div>
            <div className={`text-green-400 font-bold ${responsive.isMobile ? 'text-sm' : 'text-base'}`}>
              ${responsive.isMobile ? trader.profit.toFixed(0) : trader.profit.toFixed(2)}
            </div>
            <div className={`text-gray-300 ${responsive.isMobile ? 'text-xs' : 'text-xs'}`}>
              Win: {trader.winRate}%
            </div>
          </ResponsiveContainer>
        </Html>
      ))}

      {/* Analytics Panel */}
      <AnalyticsXRPanel
        position={[0, responsive.isMobile ? -3.5 : -4, -3]}
        signals={signals}
        earnings={earnings}
        exchange={exchange}
        isMobile={responsive.isMobile}
        isTablet={responsive.isTablet}
      />

      {/* Ambient Lighting */}
      <ambientLight intensity={0.3} />
      <pointLight position={[10, 10, 10]} intensity={0.8} />
      <pointLight position={[-10, -10, -10]} intensity={0.4} color="#0088ff" />
    </>
  );
}

export default function XRRoom() {
  const [searchParams] = useSearchParams();
  const exchange = searchParams.get('exchange') || 'binance';
  const xrStore = createXRStore();
  const responsive = useResponsive();

  return (
    <div className="w-full h-screen bg-black relative">
      {!responsive.supportsWebGL && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/90 text-white z-50">
          <div className="text-center p-6">
            <h2 className="text-xl mb-4">WebGL Not Supported</h2>
            <p className="text-gray-400">Your device doesn't support WebGL required for 3D rendering.</p>
            <p className="text-gray-400 mt-2">Please try using a different browser or device.</p>
          </div>
        </div>
      )}
      
      {responsive.isMobile && (
        <div className="absolute top-4 left-4 right-4 z-40 bg-black/80 text-white p-3 rounded-lg border border-cyan-400">
          <div className="flex items-center justify-between text-sm">
            <span>📱 Mobile XR Mode</span>
            <span className="text-cyan-400">{exchange.toUpperCase()}</span>
          </div>
          <div className="text-xs text-gray-400 mt-1">
            Rotate device for better experience • Tap to interact
          </div>
        </div>
      )}

      <Canvas
        camera={{ 
          position: responsive.isMobile ? [3, 3, 3] : [5, 5, 5], 
          fov: responsive.isMobile ? 75 : 60 
        }}
        gl={{ 
          antialias: !responsive.isMobile,
          powerPreference: responsive.isMobile ? 'low-power' : 'high-performance'
        }}
        dpr={responsive.isMobile ? Math.min(responsive.devicePixelRatio, 2) : responsive.devicePixelRatio}
      >
        <XR store={xrStore}>
          <TradeScene exchange={exchange} />
          <OrbitControls 
            enablePan={true} 
            enableZoom={true} 
            enableRotate={true}
            enableDamping={true}
            dampingFactor={0.05}
            maxDistance={responsive.isMobile ? 15 : 20}
            minDistance={responsive.isMobile ? 2 : 3}
            maxPolarAngle={Math.PI * 0.75}
            minPolarAngle={Math.PI * 0.1}
          />
        </XR>
      </Canvas>
    </div>
  );
}
