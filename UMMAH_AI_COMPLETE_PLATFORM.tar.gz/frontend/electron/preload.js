const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  getAppVersion: () => ipcRenderer.invoke('get-app-version'),
  
  showSaveDialog: (options) => ipcRenderer.invoke('show-save-dialog', options),
  showOpenDialog: (options) => ipcRenderer.invoke('show-open-dialog', options),
  showMessageBox: (options) => ipcRenderer.invoke('show-message-box', options),
  openExternal: (url) => ipcRenderer.invoke('open-external', url),
  
  setBadgeCount: (count) => ipcRenderer.send('set-badge-count', count),
  
  onMenuNewSession: (callback) => ipcRenderer.on('menu-new-session', callback),
  onMenuExportData: (callback) => ipcRenderer.on('menu-export-data', callback),
  onNavigateTo: (callback) => ipcRenderer.on('navigate-to', callback),
  onTradingStartAI: (callback) => ipcRenderer.on('trading-start-ai', callback),
  onTradingEmergencyStop: (callback) => ipcRenderer.on('trading-emergency-stop', callback),
  onDownloadContract: (callback) => ipcRenderer.on('download-contract', callback),
  onChangeLanguage: (callback) => ipcRenderer.on('change-language', callback),
  onAppBeforeQuit: (callback) => ipcRenderer.on('app-before-quit', callback),
  
  removeAllListeners: (channel) => ipcRenderer.removeAllListeners(channel),
  
  notificationClick: () => ipcRenderer.send('notification-click'),
  
  platform: process.platform,
  isElectron: true
});

window.addEventListener('DOMContentLoaded', () => {
  const replaceText = (selector, text) => {
    const element = document.getElementById(selector);
    if (element) element.innerText = text;
  };

  for (const dependency of ['chrome', 'node', 'electron']) {
    replaceText(`${dependency}-version`, process.versions[dependency]);
  }
});
