import path from "path"
import react from "@vitejs/plugin-react"
import { defineConfig } from "vite"
import { VitePWA } from 'vite-plugin-pwa'

export default defineConfig({
  publicDir: 'public',
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      workbox: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,woff2}'],
        runtimeCaching: [
          {
            urlPattern: /^https:\/\/api\./,
            handler: 'NetworkFirst',
            options: {
              cacheName: 'api-cache',
              expiration: {
                maxEntries: 100,
                maxAgeSeconds: 60 * 60 * 24 // 24 hours
              }
            }
          }
        ]
      }
    })
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    host: '0.0.0.0',
    port: 3000,
    allowedHosts: ['ai-wallet-dashboard-tunnel-fl2hknk5.devinapps.com', 'ai-wallet-dashboard-tunnel-3s92b7h0.devinapps.com', 'ai-wallet-dashboard-tunnel-s2detij7.devinapps.com', 'localhost', '127.0.0.1'],
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
        secure: false
      },
      '/zkp': {
        target: 'http://localhost:8000',
        changeOrigin: true,
        secure: false
      },
      '/ws': {
        target: 'ws://localhost:8000',
        ws: true,
        changeOrigin: true
      }
    }
  },
  define: {
    global: 'globalThis',
    'process.env.FORCE_WEBGL': JSON.stringify('true'),
    'process.env.WEBGL_CONTEXT_ATTRIBUTES': JSON.stringify({
      preserveDrawingBuffer: true,
      antialias: true,
      alpha: true,
      premultipliedAlpha: false
    })
  },
  optimizeDeps: {
    include: ['buffer', 'three', 'react-dom', 'recharts'],
    exclude: ['@mediapipe/tasks-vision']
  },
  build: {
    target: 'esnext',
    minify: 'terser',
    terserOptions: {
      compress: {
        drop_console: true,
        drop_debugger: true
      }
    },
    rollupOptions: {
      output: {
        manualChunks: {
          'vendor-react': ['react', 'react-dom', 'react-router-dom'],
          'vendor-three': ['three', '@react-three/fiber', '@react-three/drei'],
          'vendor-charts': ['recharts', 'd3-force-3d'],
          'vendor-ui': ['lucide-react'],
          'vendor-utils': ['lodash', 'zustand', 'clsx']
        }
      }
    },
    chunkSizeWarningLimit: 1000
  }
})

