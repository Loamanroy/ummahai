# UMMAH AI Platform - Deployment Guide

## 🚀 Quick Start (One-Click Deployment)

### Prerequisites
- Linux/macOS/Windows with WSL2
- 4GB+ RAM, 20GB+ disk space
- Internet connection

### Installation
```bash
# 1. Extract the platform
tar -xzf UMMAH_AI_COMPLETE_PLATFORM.tar.gz
cd UMMAH_AI_vX_INFINITY_GRID

# 2. Run installation script
chmod +x install_prod.sh
./install_prod.sh

# 3. Access the platform
# Frontend: http://localhost
# Backend API: http://localhost:8000
# Admin Panel: http://localhost/admin
```

## 🏗️ Architecture Overview

### Services
- **Frontend**: React + TypeScript + Vite (Port 80)
- **Backend API**: FastAPI + Python (Port 8000)
- **Database**: PostgreSQL (Port 5432)
- **Cache**: Redis (Port 6379)
- **AI Services**: GPT-4, Claude integration
- **Monitoring**: Prometheus + Grafana
- **Security**: JWT, JA3 fingerprinting

### AI Components
- **Quantum AI Predictor**: Advanced trading predictions
- **Financial Advisor**: Real-time market analysis
- **Support Chat**: 24/7 AI assistance
- **Voice Assistant**: Multi-language support
- **Risk Management**: Automated threat detection

## 🔧 Configuration

### Environment Variables (.env.prod)
```bash
# Database
DATABASE_URL=postgresql://ummah:secure_password@postgres:5432/ummah_ai
REDIS_URL=redis://redis:6379

# JWT Security
JWT_SECRET_KEY=your-super-secret-jwt-key-here
JWT_ALGORITHM=HS256
JWT_ACCESS_TOKEN_EXPIRE_MINUTES=30

# AI Services
OPENAI_API_KEY=your-openai-api-key
ANTHROPIC_API_KEY=your-claude-api-key

# Admin Credentials
ADMIN_PASSWORD_HASH=your-hashed-admin-password
MODERATOR_PASSWORD_HASH=your-hashed-moderator-password
ADMIN_EMAIL=admin@ummah-ai.com
MODERATOR_EMAIL=moderator@ummah-ai.com

# Exchange APIs (Optional)
BINANCE_API_KEY=your-binance-key
BINANCE_SECRET_KEY=your-binance-secret
COINBASE_API_KEY=your-coinbase-key
COINBASE_SECRET_KEY=your-coinbase-secret

# Email/SMS Notifications
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your-email@gmail.com
SMTP_PASSWORD=your-app-password
SMS_API_KEY=your-sms-api-key
```

### Admin Setup
1. Generate password hashes:
```bash
python -c "from passlib.context import CryptContext; print(CryptContext(schemes=['bcrypt']).hash('your_password'))"
```

2. Update .env.prod with hashed passwords

3. Access admin panel: http://localhost/admin
   - Username: `admin` / Password: your_password
   - Username: `moderator` / Password: your_password

## 🎯 Features

### For Users
- **Real-time Trading Signals** from 20+ exchanges
- **AI-Powered Predictions** with quantum algorithms
- **3D Visualization** of market data
- **Mobile Support** with PWA capabilities
- **Multi-language Support** (Arabic, English, Turkish, etc.)
- **Voice Commands** for hands-free trading
- **Security Features** with JA3 fingerprinting

### For Admins
- **User Management** with approval workflow
- **Balance Tracking** and contract management
- **AI Agent Monitoring** and performance metrics
- **Strategy Management** and backtesting
- **Real-time Analytics** and reporting
- **System Health** monitoring

## 🔒 Security Features

### Authentication & Authorization
- JWT-based authentication
- Role-based access control (RBAC)
- Admin approval for new registrations
- Session management and timeout

### Network Security
- JA3 TLS fingerprinting
- DDoS protection
- Rate limiting
- CORS configuration
- SSL/TLS encryption

### Data Protection
- Password hashing (bcrypt)
- API key encryption
- Database encryption at rest
- Secure WebSocket connections

## 📊 Monitoring & Logging

### Health Checks
```bash
# Backend API health
curl http://localhost:8000/health

# Frontend health
curl http://localhost

# Database connection
docker-compose -f docker-compose.prod.yml exec postgres pg_isready
```

### Logs
```bash
# All services
docker-compose -f docker-compose.prod.yml logs -f

# Specific service
docker-compose -f docker-compose.prod.yml logs -f backend_api
docker-compose -f docker-compose.prod.yml logs -f frontend
```

### Monitoring Dashboard
- Grafana: http://localhost:3000
- Prometheus: http://localhost:9090
- Default credentials: admin/admin

## 🚀 Production Deployment

### Cloud Deployment (AWS/GCP/Azure)
1. Launch VM with Docker support
2. Clone repository or upload archive
3. Configure domain and SSL certificates
4. Update environment variables
5. Run installation script

### Domain Configuration
```nginx
# /etc/nginx/sites-available/ummah-ai
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
    
    location /api {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### SSL Certificate (Let's Encrypt)
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

## 🔧 Maintenance

### Updates
```bash
# Pull latest changes
git pull origin main

# Rebuild and restart
docker-compose -f docker-compose.prod.yml down
docker-compose -f docker-compose.prod.yml up -d --build
```

### Backup
```bash
# Database backup
docker-compose -f docker-compose.prod.yml exec postgres pg_dump -U ummah ummah_ai > backup.sql

# Full backup
tar -czf ummah-ai-backup-$(date +%Y%m%d).tar.gz data/ logs/ .env.prod
```

### Restore
```bash
# Database restore
docker-compose -f docker-compose.prod.yml exec -T postgres psql -U ummah ummah_ai < backup.sql
```

## 🆘 Troubleshooting

### Common Issues

#### Port Already in Use
```bash
# Check what's using the port
sudo lsof -i :80
sudo lsof -i :8000

# Kill the process
sudo kill -9 <PID>
```

#### Database Connection Issues
```bash
# Reset database
docker-compose -f docker-compose.prod.yml down -v
docker-compose -f docker-compose.prod.yml up -d postgres
sleep 10
docker-compose -f docker-compose.prod.yml run --rm backend_api alembic upgrade head
```

#### Frontend Build Issues
```bash
# Rebuild frontend
docker-compose -f docker-compose.prod.yml build --no-cache frontend
docker-compose -f docker-compose.prod.yml up -d frontend
```

### Performance Optimization

#### Database Optimization
```sql
-- Connect to database
docker-compose -f docker-compose.prod.yml exec postgres psql -U ummah ummah_ai

-- Create indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_trades_timestamp ON trades(created_at);
```

#### Redis Configuration
```bash
# Increase memory limit
echo 'maxmemory 1gb' >> redis.conf
echo 'maxmemory-policy allkeys-lru' >> redis.conf
```

## 📞 Support

### Documentation
- API Documentation: http://localhost:8000/docs
- Frontend Components: `/frontend/src/components/`
- Backend Services: `/backend/app/services/`

### Logs Location
- Application logs: `./logs/`
- Docker logs: `docker-compose logs`
- System logs: `/var/log/`

### Contact
- GitHub Issues: https://github.com/RUSTEM003/UMMAH-AI/issues
- Email: support@ummah-ai.com

---

**Created by Devin AI for @RUSTEM003**  
**Session Link**: https://app.devin.ai/sessions/7444e22f6e894eae8a6cc1ffd7873729
