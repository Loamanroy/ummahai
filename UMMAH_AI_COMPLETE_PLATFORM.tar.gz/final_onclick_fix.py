#!/usr/bin/env python3
import os
import re

def fix_final_onclick_corruption():
    """Fix the final corrupted onClick pattern in CognitiveTradeMesh.tsx"""
    file_path = "/opt/ummah-ai/UMMAH_AI_vX_INFINITY_GRID/frontend/src/components/CognitiveTradeMesh.tsx"
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        original_content = content
        
        content = re.sub(
            r'onClick=\{\(\)\s*=\s*onClick\(\(\)\s*=>\s*\{\}\}\>\s*setProtection\(!protection\)\}',
            'onClick={() => setProtection(!protection)}',
            content
        )
        
        content = re.sub(
            r'onClick=\{\(\)\s*=\s*onClick\([^}]*\}\>\s*([^}]+)\}',
            r'onClick={() => \1}',
            content
        )
        
        if content != original_content:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"✅ Fixed corrupted onClick in {file_path}")
            return True
        else:
            print(f"❌ No corrupted onClick patterns found in {file_path}")
            return False
    
    except Exception as e:
        print(f"❌ Error processing {file_path}: {e}")
        return False

if __name__ == "__main__":
    fix_final_onclick_corruption()
