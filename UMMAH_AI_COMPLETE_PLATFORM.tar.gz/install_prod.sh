#!/bin/bash
set -e

echo "Starting UMMAH AI Platform vX Infinity Grid production deployment..."

docker-compose -f docker-compose.prod.yml up -d

echo "✅ UMMAH AI Platform vX Infinity Grid успешно развернута."
echo "Platform is available at http://localhost:8000"
