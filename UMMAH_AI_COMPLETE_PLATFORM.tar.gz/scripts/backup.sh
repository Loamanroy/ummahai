#!/bin/bash

set -e

echo "💾 UMMAH AI Platform Backup Script"
echo "=================================="

BACKUP_DIR="/opt/backups/ummah-ai"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_NAME="ummah-ai-backup-$TIMESTAMP"

DB_CONTAINER="ummah-ai-postgres"
DB_NAME="ummah_ai"
DB_USER="ummah_user"

REDIS_CONTAINER="ummah-ai-redis"

echo "📋 Backup Directory: $BACKUP_DIR"
echo "📋 Backup Name: $BACKUP_NAME"

mkdir -p "$BACKUP_DIR/$BACKUP_NAME"

echo "🗄️ Backing up PostgreSQL database..."
docker exec $DB_CONTAINER pg_dump -U $DB_USER $DB_NAME > "$BACKUP_DIR/$BACKUP_NAME/database.sql"

echo "📊 Backing up Redis data..."
docker exec $REDIS_CONTAINER redis-cli BGSAVE
sleep 5
docker cp $REDIS_CONTAINER:/data/dump.rdb "$BACKUP_DIR/$BACKUP_NAME/redis-dump.rdb"

echo "📝 Backing up application logs..."
mkdir -p "$BACKUP_DIR/$BACKUP_NAME/logs"
if [ -d "logs" ]; then
    cp -r logs/* "$BACKUP_DIR/$BACKUP_NAME/logs/"
fi

echo "⚙️ Backing up configuration files..."
mkdir -p "$BACKUP_DIR/$BACKUP_NAME/config"
cp .env.prod "$BACKUP_DIR/$BACKUP_NAME/config/" 2>/dev/null || echo "No .env.prod file found"
cp docker-compose.prod.yml "$BACKUP_DIR/$BACKUP_NAME/config/"
cp -r monitoring "$BACKUP_DIR/$BACKUP_NAME/config/"

echo "🗜️ Creating compressed archive..."
cd "$BACKUP_DIR"
tar -czf "$BACKUP_NAME.tar.gz" "$BACKUP_NAME"
rm -rf "$BACKUP_NAME"

echo "🧹 Cleaning up old backups..."
find "$BACKUP_DIR" -name "ummah-ai-backup-*.tar.gz" -mtime +7 -delete

echo ""
echo "✅ Backup completed successfully!"
echo "📁 Backup file: $BACKUP_DIR/$BACKUP_NAME.tar.gz"
echo "📊 Backup size: $(du -h "$BACKUP_DIR/$BACKUP_NAME.tar.gz" | cut -f1)"
