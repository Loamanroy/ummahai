#!/bin/bash

set -e

echo "🚀 UMMAH AI Platform Deployment Script"
echo "======================================"

ENVIRONMENT=${1:-production}
DOCKER_COMPOSE_FILE="docker-compose.prod.yml"
MONITORING_COMPOSE_FILE="monitoring/docker-compose.monitoring.yml"

echo "📋 Environment: $ENVIRONMENT"
echo "📋 Docker Compose File: $DOCKER_COMPOSE_FILE"

if ! docker info > /dev/null 2>&1; then
    echo "❌ Docker is not running. Please start Docker and try again."
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install Docker Compose and try again."
    exit 1
fi

echo "📁 Creating necessary directories..."
mkdir -p logs monitoring/grafana/dashboards

export ENVIRONMENT=$ENVIRONMENT
export COMPOSE_PROJECT_NAME="ummah-ai-${ENVIRONMENT}"

echo "📥 Pulling latest Docker images..."
docker-compose -f $DOCKER_COMPOSE_FILE pull

echo "🛑 Stopping existing containers..."
docker-compose -f $DOCKER_COMPOSE_FILE down

echo "🚀 Starting UMMAH AI Platform..."
docker-compose -f $DOCKER_COMPOSE_FILE up -d

echo "⏳ Waiting for services to be ready..."
sleep 30

echo "🗄️ Running database migrations..."
docker-compose -f $DOCKER_COMPOSE_FILE exec -T backend_api alembic upgrade head

echo "📊 Starting monitoring stack..."
docker-compose -f $MONITORING_COMPOSE_FILE up -d

echo "🏥 Performing health checks..."
BACKEND_URL="http://localhost:8000"
FRONTEND_URL="http://localhost:80"
GRAFANA_URL="http://localhost:3001"

if curl -f "$BACKEND_URL/health" > /dev/null 2>&1; then
    echo "✅ Backend is healthy"
else
    echo "❌ Backend health check failed"
fi

if curl -f "$FRONTEND_URL" > /dev/null 2>&1; then
    echo "✅ Frontend is accessible"
else
    echo "❌ Frontend health check failed"
fi

if curl -f "$GRAFANA_URL" > /dev/null 2>&1; then
    echo "✅ Grafana is accessible"
else
    echo "❌ Grafana health check failed"
fi

echo ""
echo "🎉 Deployment completed!"
echo "======================================"
echo "🌐 Frontend: $FRONTEND_URL"
echo "🔧 Backend API: $BACKEND_URL"
echo "📊 Grafana: $GRAFANA_URL (admin/ummah_admin_2025)"
echo "📈 Prometheus: http://localhost:9090"
echo "🚨 AlertManager: http://localhost:9093"
echo ""
echo "📋 To view logs: docker-compose -f $DOCKER_COMPOSE_FILE logs -f"
echo "📋 To stop: docker-compose -f $DOCKER_COMPOSE_FILE down"
echo "📋 To restart: docker-compose -f $DOCKER_COMPOSE_FILE restart"
