#!/usr/bin/env python3
import os
import re

def fix_dashboard_corruption():
    """Fix the final corrupted onClick pattern in FullDashboard.tsx"""
    file_path = "/opt/ummah-ai/UMMAH_AI_vX_INFINITY_GRID/frontend/src/components/FullDashboard.tsx"
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        original_content = content
        
        content = re.sub(
            r'onClick=\{\(\)\s*=\s*onClick\(\(\)\s*=>\s*\{\}\}\>\s*setAgentActionError\(null\)\}',
            'onClick={() => setAgentActionError(null)}',
            content,
            flags=re.MULTILINE | re.DOTALL
        )
        
        content = re.sub(
            r'onClick=\{\(\)\s*=\s*onClick\(\(\)\s*=>\s*\{\}\}\>\s*([^}]+)\}',
            r'onClick={() => \1}',
            content,
            flags=re.MULTILINE | re.DOTALL
        )
        
        if content != original_content:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"✅ Fixed corrupted onClick pattern in {file_path}")
            return True
        else:
            print(f"❌ No corrupted onClick patterns found in {file_path}")
            return False
    
    except Exception as e:
        print(f"❌ Error processing {file_path}: {e}")
        return False

if __name__ == "__main__":
    fix_dashboard_corruption()
