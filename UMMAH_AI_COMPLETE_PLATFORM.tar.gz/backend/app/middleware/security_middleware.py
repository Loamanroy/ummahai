"""
Security Middleware

FastAPI middleware for implementing security enhancements including
rate limiting, request validation, and security headers.
"""

import time
from typing import Callable
from fastapi import Request, Response, HTTPException, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from app.core.security import (
    rate_limiter, 
    request_validator, 
    security_headers,
    get_client_fingerprint
)

class SecurityMiddleware(BaseHTTPMiddleware):
    """Comprehensive security middleware."""
    
    def __init__(self, app, enable_rate_limiting: bool = True, enable_validation: bool = True):
        super().__init__(app)
        self.enable_rate_limiting = enable_rate_limiting
        self.enable_validation = enable_validation
        
        self.endpoint_types = {
            "/api/v1/auth/": "auth",
            "/api/v1/trading/": "trading",
            "/api/": "api",
        }
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Process request through security checks."""
        start_time = time.time()
        
        try:
            if self.enable_rate_limiting:
                client_ip = rate_limiter.get_client_ip(request)
                endpoint_type = self._get_endpoint_type(request.url.path)
                
                if not rate_limiter.is_allowed(client_ip, endpoint_type):
                    return JSONResponse(
                        status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                        content={
                            "error": "Rate limit exceeded",
                            "message": "Too many requests. Please try again later.",
                            "retry_after": 60
                        },
                        headers={"Retry-After": "60"}
                    )
            
            if self.enable_validation:
                if not request_validator.validate_request_size(request):
                    return JSONResponse(
                        status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                        content={
                            "error": "Request too large",
                            "message": "Request size exceeds maximum allowed limit"
                        }
                    )
                
                if not request_validator.validate_headers(request):
                    return JSONResponse(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        content={
                            "error": "Invalid request",
                            "message": "Request contains invalid or suspicious headers"
                        }
                    )
            
            request.state.client_fingerprint = get_client_fingerprint(request)
            request.state.client_ip = rate_limiter.get_client_ip(request)
            request.state.request_start_time = start_time
            
            response = await call_next(request)
            
            for header_name, header_value in security_headers.get_security_headers().items():
                response.headers[header_name] = header_value
            
            process_time = time.time() - start_time
            response.headers["X-Process-Time"] = str(round(process_time, 4))
            
            return response
            
        except HTTPException as e:
            return JSONResponse(
                status_code=e.status_code,
                content={"error": e.detail}
            )
        except Exception as e:
            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content={
                    "error": "Internal server error",
                    "message": "An unexpected error occurred"
                }
            )
    
    def _get_endpoint_type(self, path: str) -> str:
        """Determine endpoint type for rate limiting."""
        for prefix, endpoint_type in self.endpoint_types.items():
            if path.startswith(prefix):
                return endpoint_type
        return "default"

class CORSSecurityMiddleware(BaseHTTPMiddleware):
    """Enhanced CORS middleware with security features."""
    
    def __init__(self, app, allowed_origins: list = None, allowed_methods: list = None):
        super().__init__(app)
        self.allowed_origins = allowed_origins or [
            "http://localhost:3000",
            "http://localhost:80",
            "https://localhost:3000",
            "https://localhost:80"
        ]
        self.allowed_methods = allowed_methods or ["GET", "POST", "PUT", "DELETE", "OPTIONS"]
        self.allowed_headers = [
            "Accept",
            "Accept-Language",
            "Content-Language",
            "Content-Type",
            "Authorization",
            "X-Requested-With",
            "X-API-Key",
            "X-Client-Version"
        ]
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Handle CORS with enhanced security."""
        origin = request.headers.get("origin")
        
        if request.method == "OPTIONS":
            if origin and self._is_origin_allowed(origin):
                response = Response()
                response.headers["Access-Control-Allow-Origin"] = origin
                response.headers["Access-Control-Allow-Methods"] = ", ".join(self.allowed_methods)
                response.headers["Access-Control-Allow-Headers"] = ", ".join(self.allowed_headers)
                response.headers["Access-Control-Allow-Credentials"] = "true"
                response.headers["Access-Control-Max-Age"] = "86400"  # 24 hours
                return response
            else:
                return JSONResponse(
                    status_code=status.HTTP_403_FORBIDDEN,
                    content={"error": "Origin not allowed"}
                )
        
        response = await call_next(request)
        
        if origin and self._is_origin_allowed(origin):
            response.headers["Access-Control-Allow-Origin"] = origin
            response.headers["Access-Control-Allow-Credentials"] = "true"
            response.headers["Vary"] = "Origin"
        
        return response
    
    def _is_origin_allowed(self, origin: str) -> bool:
        """Check if origin is allowed with enhanced validation."""
        if origin in self.allowed_origins:
            return True
        
        if origin.endswith(".devinapps.com"):
            return True
        
        if origin.startswith("http://localhost:") or origin.startswith("https://localhost:"):
            return True
        
        return False

class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Security-focused request logging middleware."""
    
    def __init__(self, app, log_sensitive_data: bool = False):
        super().__init__(app)
        self.log_sensitive_data = log_sensitive_data
        self.sensitive_headers = [
            "authorization",
            "x-api-key",
            "cookie",
            "x-auth-token"
        ]
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Log requests with security considerations."""
        start_time = time.time()
        
        log_data = {
            "method": request.method,
            "url": str(request.url),
            "client_ip": getattr(request.state, "client_ip", "unknown"),
            "user_agent": request.headers.get("user-agent", ""),
            "timestamp": start_time
        }
        
        if not self.log_sensitive_data:
            safe_headers = {
                k: v for k, v in request.headers.items()
                if k.lower() not in self.sensitive_headers
            }
            log_data["headers"] = safe_headers
        
        response = await call_next(request)
        
        process_time = time.time() - start_time
        log_data.update({
            "status_code": response.status_code,
            "process_time": round(process_time, 4),
            "response_size": response.headers.get("content-length", "unknown")
        })
        
        if response.status_code >= 400:
            print(f"⚠️  Security Alert: {log_data}")
        elif process_time > 5.0:  # Slow requests
            print(f"🐌 Slow Request: {log_data}")
        
        return response
