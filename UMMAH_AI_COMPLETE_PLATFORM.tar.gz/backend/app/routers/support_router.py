from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, HTTPException
from fastapi.security import HTTPBearer
from typing import Dict, List, Optional
import json
import asyncio
import logging
from datetime import datetime

from app.services.ai_support_service import ai_support_service
from app.middleware.security_middleware import SecurityMiddleware

logger = logging.getLogger(__name__)
security = HTTPBearer()

router = APIRouter(prefix="/api/support", tags=["support"])

class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}
        self.user_sessions: Dict[str, str] = {}
    
    async def connect(self, websocket: WebSocket, user_id: str):
        await websocket.accept()
        session_id = f"session_{user_id}_{int(datetime.now().timestamp())}"
        self.active_connections[user_id] = websocket
        self.user_sessions[user_id] = session_id
        logger.info(f"User {user_id} connected to support chat")
        return session_id
    
    def disconnect(self, user_id: str):
        if user_id in self.active_connections:
            del self.active_connections[user_id]
        if user_id in self.user_sessions:
            del self.user_sessions[user_id]
        logger.info(f"User {user_id} disconnected from support chat")
    
    async def send_personal_message(self, message: dict, user_id: str):
        if user_id in self.active_connections:
            websocket = self.active_connections[user_id]
            await websocket.send_json(message)
    
    async def broadcast_system_message(self, message: dict):
        for user_id, websocket in self.active_connections.items():
            try:
                await websocket.send_json(message)
            except Exception as e:
                logger.error(f"Error broadcasting to user {user_id}: {e}")

manager = ConnectionManager()

@router.websocket("/chat")
async def support_chat_websocket(websocket: WebSocket):
    """
    WebSocket endpoint for real-time AI support chat
    Supports multilingual responses and instant AI assistance
    """
    user_id = None
    session_id = None
    
    try:
        initial_data = await websocket.receive_json()
        user_id = initial_data.get("user_id", f"anonymous_{int(datetime.now().timestamp())}")
        language = initial_data.get("language", "ru")
        
        session_id = await manager.connect(websocket, user_id)
        
        welcome_prompts = ai_support_service.multilingual_prompts.get(language, ai_support_service.multilingual_prompts["ru"])
        welcome_message = {
            "type": "ai_response",
            "content": welcome_prompts["greeting"],
            "language": language,
            "timestamp": datetime.now().isoformat(),
            "session_id": session_id,
            "response_time_ms": 10,
            "from_cache": False
        }
        await websocket.send_json(welcome_message)
        
        while True:
            try:
                data = await websocket.receive_json()
                message_type = data.get("type", "user_message")
                
                if message_type == "user_message":
                    user_message = data.get("message", "").strip()
                    message_language = data.get("language", language)
                    
                    if not user_message:
                        continue
                    
                    start_time = datetime.now()
                    
                    try:
                        ai_response = await ai_support_service.process_support_request(
                            user_id=user_id,
                            message=user_message,
                            language=message_language,
                            session_id=session_id
                        )
                        
                        response_message = {
                            "type": "ai_response",
                            "content": ai_response["content"],
                            "language": ai_response["language"],
                            "timestamp": ai_response["timestamp"],
                            "session_id": ai_response["session_id"],
                            "response_time_ms": ai_response["response_time_ms"],
                            "from_cache": ai_response["from_cache"],
                            "confidence": ai_response.get("confidence", 0.95)
                        }
                        
                        await websocket.send_json(response_message)
                        
                        processing_time = (datetime.now() - start_time).total_seconds() * 1000
                        logger.info(f"Support request processed for user {user_id} in {processing_time:.2f}ms")
                        
                    except Exception as e:
                        logger.error(f"Error processing support request for user {user_id}: {e}")
                        
                        error_prompts = ai_support_service.multilingual_prompts.get(message_language, ai_support_service.multilingual_prompts["ru"])
                        error_response = {
                            "type": "ai_response",
                            "content": error_prompts["error"],
                            "language": message_language,
                            "timestamp": datetime.now().isoformat(),
                            "session_id": session_id,
                            "response_time_ms": 100,
                            "from_cache": False,
                            "error": True
                        }
                        await websocket.send_json(error_response)
                
                elif message_type == "ping":
                    pong_response = {
                        "type": "pong",
                        "timestamp": datetime.now().isoformat()
                    }
                    await websocket.send_json(pong_response)
                
                elif message_type == "language_change":
                    new_language = data.get("language", "ru")
                    language = new_language
                    
                    change_prompts = ai_support_service.multilingual_prompts.get(new_language, ai_support_service.multilingual_prompts["ru"])
                    language_change_response = {
                        "type": "system_message",
                        "content": change_prompts["greeting"],
                        "language": new_language,
                        "timestamp": datetime.now().isoformat()
                    }
                    await websocket.send_json(language_change_response)
                    
            except WebSocketDisconnect:
                break
            except Exception as e:
                logger.error(f"Error in chat loop for user {user_id}: {e}")
                break
                
    except WebSocketDisconnect:
        logger.info(f"WebSocket disconnected for user {user_id}")
    except Exception as e:
        logger.error(f"WebSocket error for user {user_id}: {e}")
    finally:
        if user_id:
            manager.disconnect(user_id)

@router.post("/message")
async def send_support_message(
    message: str,
    language: str = "ru",
    user_id: Optional[str] = None
):
    """
    HTTP endpoint for sending support messages (alternative to WebSocket)
    """
    try:
        if not user_id:
            user_id = f"http_user_{int(datetime.now().timestamp())}"
        
        response = await ai_support_service.process_support_request(
            user_id=user_id,
            message=message,
            language=language
        )
        
        return {
            "success": True,
            "response": response
        }
        
    except Exception as e:
        logger.error(f"Error in HTTP support message: {e}")
        raise HTTPException(status_code=500, detail="Support service temporarily unavailable")

@router.get("/analytics")
async def get_support_analytics(days: int = 7):
    """
    Get support analytics for monitoring performance
    """
    try:
        analytics = await ai_support_service.get_support_analytics(days=days)
        return {
            "success": True,
            "analytics": analytics
        }
    except Exception as e:
        logger.error(f"Error getting support analytics: {e}")
        raise HTTPException(status_code=500, detail="Analytics service unavailable")

@router.get("/health")
async def support_health_check():
    """
    Health check endpoint for support service
    """
    try:
        if not ai_support_service.redis:
            return {
                "status": "unhealthy",
                "message": "Redis connection not initialized"
            }
        
        await ai_support_service.redis.ping()
        
        return {
            "status": "healthy",
            "active_connections": len(manager.active_connections),
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Support health check failed: {e}")
        return {
            "status": "unhealthy",
            "error": str(e)
        }

@router.post("/broadcast")
async def broadcast_system_message(
    message: str,
    language: str = "ru"
):
    """
    Broadcast system message to all connected users
    """
    try:
        broadcast_message = {
            "type": "system_broadcast",
            "content": message,
            "language": language,
            "timestamp": datetime.now().isoformat()
        }
        
        await manager.broadcast_system_message(broadcast_message)
        
        return {
            "success": True,
            "message": "Broadcast sent",
            "recipients": len(manager.active_connections)
        }
        
    except Exception as e:
        logger.error(f"Error broadcasting message: {e}")
        raise HTTPException(status_code=500, detail="Broadcast failed")

@router.on_event("startup")
async def startup_support_service():
    """Initialize AI support service when router starts"""
    try:
        await ai_support_service.initialize()
        logger.info("AI Support Service initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize AI Support Service: {e}")
        raise
