from fastapi import APIRouter, HTTPException, status, Depends
from fastapi.security import HTTPBearer
from pydantic import BaseModel
from typing import Dict, Any
import os
from ..core.jwt_auth import jwt_manager, get_current_admin_user
from ..core.config import settings

router = APIRouter(prefix="/api/auth/admin", tags=["admin-auth"])
security = HTTPBearer()

def get_admin_credentials():
    """Get admin credentials from environment variables."""
    admin_password_hash = os.getenv("ADMIN_PASSWORD_HASH")
    moderator_password_hash = os.getenv("MODERATOR_PASSWORD_HASH")
    
    if not admin_password_hash or not moderator_password_hash:
        raise ValueError("Admin credentials must be set via environment variables: ADMIN_PASSWORD_HASH, MODERATOR_PASSWORD_HASH")
    
    return {
        "admin": {
            "username": "admin",
            "password_hash": admin_password_hash,
            "email": os.getenv("ADMIN_EMAIL", "admin@ummah-ai.com"),
            "role": "super_admin",
            "permissions": ["read", "write", "delete", "admin"]
        },
        "moderator": {
            "username": "moderator", 
            "password_hash": moderator_password_hash,
            "email": os.getenv("MODERATOR_EMAIL", "moderator@ummah-ai.com"),
            "role": "moderator",
            "permissions": ["read", "write", "admin"]
        }
    }

class AdminLoginRequest(BaseModel):
    username: str
    password: str

class AdminLoginResponse(BaseModel):
    access_token: str
    token_type: str
    user: Dict[str, Any]

@router.post("/login", response_model=AdminLoginResponse)
async def admin_login(login_data: AdminLoginRequest):
    """Admin login endpoint."""
    admin_credentials = get_admin_credentials()
    admin = admin_credentials.get(login_data.username)
    
    if not admin or not jwt_manager.verify_password(login_data.password, admin["password_hash"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid admin credentials"
        )
    
    token_data = {
        "sub": admin["username"],
        "user_id": 1 if login_data.username == "admin" else 2,
        "username": admin["username"],
        "email": admin["email"],
        "role": admin["role"],
        "permissions": admin["permissions"],
        "is_admin": True
    }
    
    access_token = jwt_manager.create_access_token(token_data)
    
    return AdminLoginResponse(
        access_token=access_token,
        token_type="bearer",
        user={
            "id": token_data["user_id"],
            "username": admin["username"],
            "email": admin["email"],
            "role": admin["role"],
            "permissions": admin["permissions"]
        }
    )

@router.post("/logout")
async def admin_logout(current_admin: Dict[str, Any] = Depends(get_current_admin_user)):
    """Admin logout endpoint."""
    return {"message": "Successfully logged out"}

@router.get("/me")
async def get_admin_profile(current_admin: Dict[str, Any] = Depends(get_current_admin_user)):
    """Get current admin user profile."""
    return {
        "id": current_admin.get("user_id"),
        "username": current_admin.get("username"),
        "email": current_admin.get("email"),
        "role": current_admin.get("role"),
        "permissions": current_admin.get("permissions", [])
    }

@router.get("/health")
async def admin_health_check(current_admin: Dict[str, Any] = Depends(get_current_admin_user)):
    """Health check endpoint for admin authentication."""
    return {
        "status": "healthy",
        "admin": current_admin.get("username"),
        "role": current_admin.get("role")
    }
