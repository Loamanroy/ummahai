"""
Voice Assistant Router

WebSocket and HTTP endpoints for voice command processing,
speech recognition, and text-to-speech synthesis.
"""

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, HTTPException, UploadFile, File
from fastapi.responses import StreamingResponse
from typing import Dict, List, Optional
import json
import logging
from datetime import datetime
import asyncio

from ..services.voice_assistant_service import voice_assistant
from ..core.websocket_manager import websocket_manager

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/voice", tags=["voice"])

class VoiceConnectionManager:
    """Manage voice WebSocket connections."""
    
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}
        self.user_sessions: Dict[str, Dict] = {}
    
    async def connect(self, websocket: WebSocket, user_id: str):
        """Connect user to voice WebSocket."""
        await websocket.accept()
        self.active_connections[user_id] = websocket
        self.user_sessions[user_id] = {
            "connected_at": datetime.now().isoformat(),
            "language": "ru"
        }
        logger.info(f"Voice connection established for user {user_id}")
    
    def disconnect(self, user_id: str):
        """Disconnect user from voice WebSocket."""
        if user_id in self.active_connections:
            del self.active_connections[user_id]
        if user_id in self.user_sessions:
            del self.user_sessions[user_id]
        logger.info(f"Voice connection closed for user {user_id}")
    
    async def send_personal_message(self, message: dict, user_id: str):
        """Send message to specific user."""
        if user_id in self.active_connections:
            try:
                await self.active_connections[user_id].send_text(json.dumps(message))
            except Exception as e:
                logger.error(f"Error sending message to {user_id}: {e}")
                self.disconnect(user_id)
    
    async def broadcast_to_all(self, message: dict):
        """Broadcast message to all connected users."""
        disconnected_users = []
        for user_id, websocket in self.active_connections.items():
            try:
                await websocket.send_text(json.dumps(message))
            except Exception as e:
                logger.error(f"Error broadcasting to {user_id}: {e}")
                disconnected_users.append(user_id)
        
        for user_id in disconnected_users:
            self.disconnect(user_id)

voice_manager = VoiceConnectionManager()

@router.websocket("/ws/{user_id}")
async def voice_websocket_endpoint(websocket: WebSocket, user_id: str):
    """WebSocket endpoint for real-time voice communication."""
    await voice_manager.connect(websocket, user_id)
    
    try:
        while True:
            data = await websocket.receive_text()
            message = json.loads(data)
            
            message_type = message.get("type")
            
            if message_type == "voice_command":
                await handle_voice_command(message, user_id)
                
            elif message_type == "set_language":
                language = message.get("language", "ru")
                voice_manager.user_sessions[user_id]["language"] = language
                await voice_assistant.update_voice_session(user_id, {"language": language})
                
                await voice_manager.send_personal_message({
                    "type": "language_updated",
                    "language": language,
                    "message": f"Язык изменен на {language}"
                }, user_id)
                
            elif message_type == "ping":
                await voice_manager.send_personal_message({
                    "type": "pong",
                    "timestamp": datetime.now().isoformat()
                }, user_id)
                
    except WebSocketDisconnect:
        voice_manager.disconnect(user_id)
    except Exception as e:
        logger.error(f"Voice WebSocket error for {user_id}: {e}")
        voice_manager.disconnect(user_id)

async def handle_voice_command(message: dict, user_id: str):
    """Handle voice command processing."""
    try:
        audio_data_b64 = message.get("audio_data")
        if not audio_data_b64:
            await voice_manager.send_personal_message({
                "type": "error",
                "message": "No audio data provided"
            }, user_id)
            return
        
        import base64
        audio_data = base64.b64decode(audio_data_b64)
        
        language = voice_manager.user_sessions.get(user_id, {}).get("language", "ru")
        
        await voice_manager.send_personal_message({
            "type": "processing",
            "message": "Обрабатываю голосовую команду..."
        }, user_id)
        
        result = await voice_assistant.process_voice_command(audio_data, user_id, language)
        
        await voice_manager.send_personal_message({
            "type": "voice_command_result",
            "result": result,
            "timestamp": datetime.now().isoformat()
        }, user_id)
        
        if result.get("audio_response"):
            audio_response_b64 = base64.b64encode(result["audio_response"]).decode()
            await voice_manager.send_personal_message({
                "type": "audio_response",
                "audio_data": audio_response_b64,
                "text": result.get("response_text", "")
            }, user_id)
        
    except Exception as e:
        logger.error(f"Voice command handling error: {e}")
        await voice_manager.send_personal_message({
            "type": "error",
            "message": f"Ошибка обработки команды: {str(e)}"
        }, user_id)

@router.post("/upload-audio/{user_id}")
async def upload_audio_command(user_id: str, audio_file: UploadFile = File(...), language: str = "ru"):
    """HTTP endpoint for uploading audio files for processing."""
    try:
        audio_data = await audio_file.read()
        
        result = await voice_assistant.process_voice_command(audio_data, user_id, language)
        
        return {
            "success": True,
            "result": result,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Audio upload processing error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/text-to-speech")
async def text_to_speech_endpoint(
    text: str,
    language: str = "ru",
    user_id: Optional[str] = None
):
    """Convert text to speech and return audio file."""
    try:
        audio_data = await voice_assistant._text_to_speech(text, language)
        
        if not audio_data:
            raise HTTPException(status_code=500, detail="Failed to generate speech")
        
        def generate_audio():
            yield audio_data
        
        return StreamingResponse(
            generate_audio(),
            media_type="audio/wav",
            headers={"Content-Disposition": "attachment; filename=speech.wav"}
        )
        
    except Exception as e:
        logger.error(f"Text to speech error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/session/{user_id}")
async def get_voice_session(user_id: str):
    """Get voice session information for user."""
    try:
        session = await voice_assistant.get_voice_session(user_id)
        return {
            "success": True,
            "session": session,
            "connected": user_id in voice_manager.active_connections
        }
    except Exception as e:
        logger.error(f"Get voice session error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/history/{user_id}")
async def get_command_history(user_id: str, limit: int = 10):
    """Get voice command history for user."""
    try:
        history = await voice_assistant.get_command_history(user_id, limit)
        return {
            "success": True,
            "history": history,
            "count": len(history)
        }
    except Exception as e:
        logger.error(f"Get command history error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/metrics")
async def get_voice_metrics():
    """Get voice assistant performance metrics."""
    try:
        metrics = await voice_assistant.get_performance_metrics()
        
        metrics.update({
            "active_connections": len(voice_manager.active_connections),
            "total_sessions": len(voice_manager.user_sessions)
        })
        
        return {
            "success": True,
            "metrics": metrics,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Get voice metrics error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/test-command")
async def test_voice_command(
    text: str,
    user_id: str,
    language: str = "ru"
):
    """Test voice command processing with text input."""
    try:
        intent_data = await voice_assistant._process_with_rasa(text, user_id, language)
        execution_result = await voice_assistant._execute_trading_command(intent_data, user_id)
        response_text = await voice_assistant._generate_response(intent_data, execution_result, language)
        
        return {
            "success": True,
            "input_text": text,
            "intent": intent_data,
            "execution_result": execution_result,
            "response_text": response_text,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Test voice command error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/supported-languages")
async def get_supported_languages():
    """Get list of supported languages."""
    return {
        "success": True,
        "languages": [
            {"code": "ru", "name": "Русский", "flag": "🇷🇺"},
            {"code": "en", "name": "English", "flag": "🇺🇸"},
            {"code": "ar", "name": "العربية", "flag": "🇦🇪"},
            {"code": "tr", "name": "Türkçe", "flag": "🇹🇷"}
        ]
    }

@router.post("/initialize")
async def initialize_voice_assistant():
    """Initialize voice assistant components."""
    try:
        await voice_assistant.initialize()
        return {
            "success": True,
            "message": "Voice assistant initialized successfully",
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Voice assistant initialization error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
