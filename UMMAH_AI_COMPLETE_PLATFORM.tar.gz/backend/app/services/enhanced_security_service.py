import hashlib
import hmac
import secrets
import time
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import jwt
import bcrypt
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64
import logging
from dataclasses import dataclass
import asyncio
import aioredis
from fastapi import HTTPException, Request
import geoip2.database
import re

logger = logging.getLogger(__name__)

@dataclass
class SecurityEvent:
    event_type: str
    user_id: Optional[str]
    ip_address: str
    timestamp: datetime
    severity: str
    details: Dict
    blocked: bool = False

class EnhancedSecurityService:
    def __init__(self, redis_url: str = "redis://localhost:6379"):
        self.redis_url = redis_url
        self.redis = None
        self.encryption_key = self._generate_encryption_key()
        self.cipher_suite = Fernet(self.encryption_key)
        
        self.max_login_attempts = 5
        self.lockout_duration = 900  # 15 minutes
        self.suspicious_activity_threshold = 10
        self.rate_limit_requests = 100
        self.rate_limit_window = 60  # 1 minute
        
        self.threat_patterns = {
            'sql_injection': [
                r"(\bunion\b.*\bselect\b)",
                r"(\bselect\b.*\bfrom\b.*\bwhere\b)",
                r"(\bdrop\b.*\btable\b)",
                r"(\binsert\b.*\binto\b)",
                r"(\bupdate\b.*\bset\b)",
                r"(\bdelete\b.*\bfrom\b)"
            ],
            'xss': [
                r"<script[^>]*>.*?</script>",
                r"javascript:",
                r"on\w+\s*=",
                r"<iframe[^>]*>.*?</iframe>"
            ],
            'path_traversal': [
                r"\.\./",
                r"\.\.\\",
                r"%2e%2e%2f",
                r"%2e%2e%5c"
            ]
        }
        
        self.blocked_countries = set()  # No country restrictions as per user requirement
        
    async def initialize(self):
        """Initialize Redis connection and security monitoring"""
        try:
            self.redis = await aioredis.from_url(self.redis_url)
            logger.info("Enhanced Security Service initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize security service: {e}")
            raise

    def _generate_encryption_key(self) -> bytes:
        """Generate a secure encryption key"""
        password = secrets.token_bytes(32)
        salt = secrets.token_bytes(16)
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(password))
        return key

    async def hash_password(self, password: str) -> str:
        """Hash password with bcrypt (secure hashing)"""
        salt = bcrypt.gensalt(rounds=12)
        hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
        return hashed.decode('utf-8')

    async def verify_password(self, password: str, hashed: str) -> bool:
        """Verify password against hash"""
        return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

    async def encrypt_sensitive_data(self, data: str) -> str:
        """Encrypt sensitive data"""
        encrypted = self.cipher_suite.encrypt(data.encode())
        return base64.urlsafe_b64encode(encrypted).decode()

    async def decrypt_sensitive_data(self, encrypted_data: str) -> str:
        """Decrypt sensitive data"""
        try:
            encrypted_bytes = base64.urlsafe_b64decode(encrypted_data.encode())
            decrypted = self.cipher_suite.decrypt(encrypted_bytes)
            return decrypted.decode()
        except Exception as e:
            logger.error(f"Decryption failed: {e}")
            raise

    async def detect_threats(self, request: Request) -> List[str]:
        """Advanced threat detection"""
        threats = []
        
        url = str(request.url)
        headers = dict(request.headers)
        
        for threat_type, patterns in self.threat_patterns.items():
            for pattern in patterns:
                if re.search(pattern, url, re.IGNORECASE):
                    threats.append(f"{threat_type}_in_url")
                
                for header_value in headers.values():
                    if re.search(pattern, str(header_value), re.IGNORECASE):
                        threats.append(f"{threat_type}_in_headers")
        
        user_agent = headers.get('user-agent', '').lower()
        suspicious_agents = ['sqlmap', 'nikto', 'nmap', 'burp', 'scanner']
        if any(agent in user_agent for agent in suspicious_agents):
            threats.append('suspicious_user_agent')
        
        client_ip = self._get_client_ip(request)
        if await self._check_rate_limit(client_ip):
            threats.append('rate_limit_exceeded')
        
        return threats

    async def _check_rate_limit(self, ip: str) -> bool:
        """Check if IP has exceeded rate limit"""
        if not self.redis:
            return False
            
        key = f"rate_limit:{ip}"
        current_requests = await self.redis.get(key)
        
        if current_requests is None:
            await self.redis.setex(key, self.rate_limit_window, 1)
            return False
        
        if int(current_requests) >= self.rate_limit_requests:
            return True
        
        await self.redis.incr(key)
        return False

    def _get_client_ip(self, request: Request) -> str:
        """Get real client IP address"""
        forwarded_for = request.headers.get('x-forwarded-for')
        if forwarded_for:
            return forwarded_for.split(',')[0].strip()
        
        real_ip = request.headers.get('x-real-ip')
        if real_ip:
            return real_ip
        
        return request.client.host if request.client else "unknown"

    async def log_security_event(self, event: SecurityEvent):
        """Log security events for monitoring"""
        if not self.redis:
            return
            
        event_data = {
            'event_type': event.event_type,
            'user_id': event.user_id,
            'ip_address': event.ip_address,
            'timestamp': event.timestamp.isoformat(),
            'severity': event.severity,
            'details': event.details,
            'blocked': event.blocked
        }
        
        await self.redis.lpush('security_events', str(event_data))
        await self.redis.ltrim('security_events', 0, 1000)  # Keep last 1000 events
        
        logger.warning(f"Security Event: {event.event_type} from {event.ip_address}")

    async def check_login_attempts(self, identifier: str) -> bool:
        """Check if login attempts exceed threshold"""
        if not self.redis:
            return False
            
        key = f"login_attempts:{identifier}"
        attempts = await self.redis.get(key)
        
        if attempts and int(attempts) >= self.max_login_attempts:
            return True
        return False

    async def record_failed_login(self, identifier: str, ip: str):
        """Record failed login attempt"""
        if not self.redis:
            return
            
        key = f"login_attempts:{identifier}"
        await self.redis.incr(key)
        await self.redis.expire(key, self.lockout_duration)
        
        event = SecurityEvent(
            event_type="failed_login",
            user_id=identifier,
            ip_address=ip,
            timestamp=datetime.utcnow(),
            severity="medium",
            details={"attempts": await self.redis.get(key)},
            blocked=False
        )
        await self.log_security_event(event)

    async def clear_login_attempts(self, identifier: str):
        """Clear login attempts after successful login"""
        if not self.redis:
            return
            
        key = f"login_attempts:{identifier}"
        await self.redis.delete(key)

    async def generate_secure_token(self, user_id: str, expires_in: int = 3600) -> str:
        """Generate secure JWT token"""
        payload = {
            'user_id': user_id,
            'exp': datetime.utcnow() + timedelta(seconds=expires_in),
            'iat': datetime.utcnow(),
            'jti': secrets.token_hex(16)  # Unique token ID
        }
        
        secret_key = secrets.token_urlsafe(32)
        token = jwt.encode(payload, secret_key, algorithm='HS256')
        
        if self.redis:
            await self.redis.setex(f"token:{payload['jti']}", expires_in, user_id)
        
        return token

    async def validate_token(self, token: str) -> Optional[str]:
        """Validate JWT token"""
        try:
            unverified = jwt.decode(token, options={"verify_signature": False})
            jti = unverified.get('jti')
            
            if not jti or not self.redis:
                return None
            
            user_id = await self.redis.get(f"token:{jti}")
            if not user_id:
                return None
            
            secret_key = secrets.token_urlsafe(32)  # Should match generation
            payload = jwt.decode(token, secret_key, algorithms=['HS256'])
            
            return payload.get('user_id')
            
        except jwt.ExpiredSignatureError:
            logger.warning("Token expired")
            return None
        except jwt.InvalidTokenError:
            logger.warning("Invalid token")
            return None

    async def revoke_token(self, token: str):
        """Revoke a token"""
        try:
            unverified = jwt.decode(token, options={"verify_signature": False})
            jti = unverified.get('jti')
            
            if jti and self.redis:
                await self.redis.delete(f"token:{jti}")
                
        except Exception as e:
            logger.error(f"Failed to revoke token: {e}")

    async def get_security_metrics(self) -> Dict:
        """Get security metrics for monitoring"""
        if not self.redis:
            return {}
        
        events = await self.redis.lrange('security_events', 0, 100)
        
        event_counts = {}
        blocked_count = 0
        
        for event_str in events:
            try:
                event_data = eval(event_str)  # In production, use proper JSON parsing
                event_type = event_data.get('event_type', 'unknown')
                event_counts[event_type] = event_counts.get(event_type, 0) + 1
                
                if event_data.get('blocked'):
                    blocked_count += 1
                    
            except Exception:
                continue
        
        return {
            'total_events': len(events),
            'blocked_attempts': blocked_count,
            'event_types': event_counts,
            'timestamp': datetime.utcnow().isoformat()
        }

    async def emergency_lockdown(self, reason: str):
        """Emergency security lockdown"""
        if not self.redis:
            return
            
        await self.redis.setex('emergency_lockdown', 3600, reason)
        
        event = SecurityEvent(
            event_type="emergency_lockdown",
            user_id=None,
            ip_address="system",
            timestamp=datetime.utcnow(),
            severity="critical",
            details={"reason": reason},
            blocked=True
        )
        await self.log_security_event(event)
        
        logger.critical(f"EMERGENCY LOCKDOWN ACTIVATED: {reason}")

    async def check_emergency_lockdown(self) -> Optional[str]:
        """Check if emergency lockdown is active"""
        if not self.redis:
            return None
            
        reason = await self.redis.get('emergency_lockdown')
        return reason.decode() if reason else None

security_service = EnhancedSecurityService()
