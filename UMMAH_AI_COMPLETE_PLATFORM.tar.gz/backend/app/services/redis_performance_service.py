"""
Redis Performance Service

Ultra-fast Redis operations optimized for millisecond-level performance
with connection pooling, pipelining, and advanced caching strategies.
"""

import asyncio
import redis.asyncio as redis
import json
import time
from typing import Any, Dict, List, Optional, Union
from contextlib import asynccontextmanager
from ..core.config import settings
from ..core.cache import cache

class RedisPerformanceService:
    """High-performance Redis service with advanced optimizations."""
    
    def __init__(self):
        self.pool = None
        self.pipeline_batch_size = 100
        self.pipeline_timeout = 0.01  # 10ms for ultra-low latency
        self.connection_pool_size = 20
        self.performance_metrics = {}
        
    async def initialize(self):
        """Initialize Redis connection pool with optimizations."""
        try:
            self.pool = redis.ConnectionPool.from_url(
                settings.REDIS_URL,
                max_connections=self.connection_pool_size,
                retry_on_timeout=True,
                socket_connect_timeout=1,
                socket_timeout=1,
                health_check_interval=30,
                decode_responses=True
            )
            
            async with redis.Redis(connection_pool=self.pool) as client:
                await client.ping()
                
            print("✅ Redis Performance Service initialized")
            
        except Exception as e:
            print(f"❌ Redis Performance Service initialization failed: {e}")
            self.pool = None
    
    @asynccontextmanager
    async def get_client(self):
        """Get Redis client from pool with performance tracking."""
        start_time = time.perf_counter()
        
        try:
            if not self.pool:
                await self.initialize()
            
            async with redis.Redis(connection_pool=self.pool) as client:
                yield client
                
        finally:
            duration = (time.perf_counter() - start_time) * 1000
            self._record_metric('connection_time', duration)
    
    async def pipeline_operations(self, operations: List[Dict[str, Any]]) -> List[Any]:
        """Execute multiple Redis operations in a pipeline for maximum performance."""
        start_time = time.perf_counter()
        
        try:
            async with self.get_client() as client:
                pipe = client.pipeline()
                
                for op in operations:
                    method = getattr(pipe, op['method'])
                    args = op.get('args', [])
                    kwargs = op.get('kwargs', {})
                    method(*args, **kwargs)
                
                results = await pipe.execute()
                
                duration = (time.perf_counter() - start_time) * 1000
                self._record_metric('pipeline_time', duration)
                self._record_metric('pipeline_ops', len(operations))
                
                return results
                
        except Exception as e:
            print(f"Pipeline operations error: {e}")
            return []
    
    async def batch_set_market_data(self, market_data: Dict[str, Dict[str, Any]]) -> bool:
        """Batch set market data with ultra-low latency."""
        operations = []
        
        for symbol, data in market_data.items():
            key = f"market:{symbol}"
            serialized_data = json.dumps({
                **data,
                'timestamp': time.time(),
                'latency_optimized': True
            })
            
            operations.append({
                'method': 'setex',
                'args': [key, 30, serialized_data]  # 30 second TTL
            })
        
        results = await self.pipeline_operations(operations)
        return all(results)
    
    async def batch_get_market_data(self, symbols: List[str]) -> Dict[str, Dict[str, Any]]:
        """Batch get market data with minimal latency."""
        operations = []
        
        for symbol in symbols:
            key = f"market:{symbol}"
            operations.append({
                'method': 'get',
                'args': [key]
            })
        
        results = await self.pipeline_operations(operations)
        market_data = {}
        
        for i, result in enumerate(results):
            if result:
                try:
                    data = json.loads(result)
                    market_data[symbols[i]] = data
                except json.JSONDecodeError:
                    continue
        
        return market_data
    
    async def stream_trading_signals(self, exchange: str, signals: List[Dict[str, Any]]) -> bool:
        """Stream trading signals with Redis Streams for real-time processing."""
        start_time = time.perf_counter()
        
        try:
            async with self.get_client() as client:
                stream_key = f"signals:{exchange}"
                
                pipe = client.pipeline()
                
                for signal in signals:
                    signal_data = {
                        'exchange': exchange,
                        'timestamp': str(time.time()),
                        'data': json.dumps(signal),
                        'latency_ms': '0'  # Will be updated by consumer
                    }
                    pipe.xadd(stream_key, signal_data, maxlen=1000)  # Keep last 1000 signals
                
                await pipe.execute()
                
                duration = (time.perf_counter() - start_time) * 1000
                self._record_metric('stream_time', duration)
                
                return True
                
        except Exception as e:
            print(f"Stream trading signals error: {e}")
            return False
    
    async def consume_trading_signals(self, exchange: str, count: int = 10) -> List[Dict[str, Any]]:
        """Consume trading signals from Redis Streams."""
        try:
            async with self.get_client() as client:
                stream_key = f"signals:{exchange}"
                
                streams = await client.xrevrange(stream_key, count=count)
                
                signals = []
                for stream_id, fields in streams:
                    try:
                        signal_data = json.loads(fields['data'])
                        signal_data['stream_id'] = stream_id
                        signal_data['received_at'] = time.time()
                        signals.append(signal_data)
                    except (json.JSONDecodeError, KeyError):
                        continue
                
                return signals
                
        except Exception as e:
            print(f"Consume trading signals error: {e}")
            return []
    
    async def cache_ai_prediction(self, model_id: str, input_hash: str, prediction: Dict[str, Any]) -> bool:
        """Cache AI prediction with optimized serialization."""
        try:
            async with self.get_client() as client:
                key = f"ai_pred:{model_id}:{input_hash}"
                
                cached_data = {
                    'prediction': prediction,
                    'timestamp': time.time(),
                    'model_id': model_id,
                    'ttl': 300  # 5 minutes
                }
                
                serialized = json.dumps(cached_data, separators=(',', ':'))  # Compact JSON
                await client.setex(key, 300, serialized)
                
                return True
                
        except Exception as e:
            print(f"Cache AI prediction error: {e}")
            return False
    
    async def get_cached_prediction(self, model_id: str, input_hash: str) -> Optional[Dict[str, Any]]:
        """Get cached AI prediction with performance tracking."""
        start_time = time.perf_counter()
        
        try:
            async with self.get_client() as client:
                key = f"ai_pred:{model_id}:{input_hash}"
                result = await client.get(key)
                
                if result:
                    data = json.loads(result)
                    
                    age = time.time() - data['timestamp']
                    if age < data['ttl']:
                        duration = (time.perf_counter() - start_time) * 1000
                        self._record_metric('cache_hit_time', duration)
                        return data['prediction']
                
                duration = (time.perf_counter() - start_time) * 1000
                self._record_metric('cache_miss_time', duration)
                return None
                
        except Exception as e:
            print(f"Get cached prediction error: {e}")
            return None
    
    async def increment_counter(self, key: str, amount: int = 1, ttl: int = 3600) -> int:
        """Increment counter with automatic TTL setting."""
        try:
            async with self.get_client() as client:
                pipe = client.pipeline()
                pipe.incr(key, amount)
                pipe.expire(key, ttl)
                results = await pipe.execute()
                return results[0]
                
        except Exception as e:
            print(f"Increment counter error: {e}")
            return 0
    
    async def get_performance_metrics(self) -> Dict[str, Any]:
        """Get performance metrics for monitoring."""
        try:
            async with self.get_client() as client:
                info = await client.info()
                
                metrics = {
                    'redis_info': {
                        'used_memory': info.get('used_memory_human', 'N/A'),
                        'connected_clients': info.get('connected_clients', 0),
                        'total_commands_processed': info.get('total_commands_processed', 0),
                        'keyspace_hits': info.get('keyspace_hits', 0),
                        'keyspace_misses': info.get('keyspace_misses', 0),
                    },
                    'performance_metrics': self.performance_metrics,
                    'pool_info': {
                        'max_connections': self.connection_pool_size,
                        'created_connections': getattr(self.pool, 'created_connections', 0) if self.pool else 0,
                    }
                }
                
                hits = metrics['redis_info']['keyspace_hits']
                misses = metrics['redis_info']['keyspace_misses']
                total = hits + misses
                metrics['redis_info']['hit_rate'] = round((hits / max(total, 1)) * 100, 2)
                
                return metrics
                
        except Exception as e:
            return {'error': str(e)}
    
    def _record_metric(self, metric_name: str, value: float):
        """Record performance metric."""
        if metric_name not in self.performance_metrics:
            self.performance_metrics[metric_name] = []
        
        metrics = self.performance_metrics[metric_name]
        metrics.append(value)
        
        if len(metrics) > 100:
            metrics.pop(0)
        
        if 'time' in metric_name and value > 50:  # 50ms threshold
            print(f"⚠️ High latency detected for {metric_name}: {value:.2f}ms")
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform health check with latency measurement."""
        start_time = time.perf_counter()
        
        try:
            async with self.get_client() as client:
                await client.ping()
                
                latency = (time.perf_counter() - start_time) * 1000
                
                return {
                    'status': 'healthy',
                    'latency_ms': round(latency, 2),
                    'pool_available': self.pool is not None
                }
                
        except Exception as e:
            return {
                'status': 'unhealthy',
                'error': str(e),
                'pool_available': self.pool is not None
            }

redis_performance = RedisPerformanceService()
