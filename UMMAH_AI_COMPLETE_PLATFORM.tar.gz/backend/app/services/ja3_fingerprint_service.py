import asyncio
import logging
import hashlib
import time
import json
from typing import Dict, Any, List, Set, Optional
from collections import defaultdict
import random

logger = logging.getLogger(__name__)

class JA3FingerprintService:
    """
    JA3 Fingerprint Service - Detects and analyzes TLS fingerprints for threat detection
    Сервис анализа JA3 отпечатков для обнаружения угроз
    """
    
    def __init__(self):
        self.fingerprints: Dict[str, Set[str]] = defaultdict(set)
        self.fingerprint_history: List[Dict[str, Any]] = []
        self.threat_patterns: Dict[str, float] = {}
        self.cluster_map: Dict[str, List[str]] = defaultdict(list)
        
    async def capture_fingerprint(self, data: Dict[str, Any]):
        """Capture and analyze JA3 fingerprint"""
        try:
            exchange = data.get("exchange", "unknown")
            
            ja3_fingerprint = data.get("fingerprint") or self._generate_ja3_fingerprint(data)
            
            self.fingerprints[exchange].add(ja3_fingerprint)
            
            fingerprint_entry = {
                "exchange": exchange,
                "fingerprint": ja3_fingerprint,
                "timestamp": time.time(),
                "data": data
            }
            
            self.fingerprint_history.append(fingerprint_entry)
            
            if len(self.fingerprint_history) > 1000:
                self.fingerprint_history = self.fingerprint_history[-1000:]
            
            await self._analyze_fingerprint_threats(exchange, ja3_fingerprint)
            
            logger.debug(f"🔍 JA3 fingerprint captured for {exchange}: {ja3_fingerprint[:16]}...")
            
        except Exception as e:
            logger.error(f"❌ JA3 fingerprint capture failed: {e}")
    
    def _generate_ja3_fingerprint(self, data: Dict[str, Any]) -> str:
        """Generate JA3-like fingerprint from connection data"""
        try:
            components = [
                str(data.get("tls_version", "771")),  # TLS 1.2
                str(data.get("cipher_suites", "49195,49199,49196,49200,52393,52392,49171,49172")),
                str(data.get("extensions", "0,23,65281,10,11,35,16,5,13,18,51,45,43,10")),
                str(data.get("elliptic_curves", "23,24,25")),
                str(data.get("elliptic_curve_formats", "0"))
            ]
            
            ja3_string = ",".join(components)
            ja3_hash = hashlib.md5(ja3_string.encode()).hexdigest()
            
            return ja3_hash
            
        except Exception as e:
            logger.error(f"❌ JA3 fingerprint generation failed: {e}")
            return hashlib.md5(f"{time.time()}{random.random()}".encode()).hexdigest()
    
    async def _analyze_fingerprint_threats(self, exchange: str, fingerprint: str):
        """Analyze fingerprint for potential threats"""
        try:
            threat_score = 0.0
            
            if len(self.fingerprints[exchange]) > 10:
                threat_score += 0.3
            
            recent_fingerprints = [
                entry for entry in self.fingerprint_history[-50:]
                if entry["exchange"] == exchange and time.time() - entry["timestamp"] < 300
            ]
            
            if len(set(entry["fingerprint"] for entry in recent_fingerprints)) > 5:
                threat_score += 0.5
            
            malicious_patterns = [
                "e7d705a3286e19ea42f587b344ee6865",  # Known bot fingerprint
                "a0e9f5d64349fb13191bc781f81f42e1",  # Suspicious pattern
                "b742b407517bac9536a77a7b0fee28e9"   # Automated tool
            ]
            
            if fingerprint in malicious_patterns:
                threat_score += 1.0
            
            if threat_score > 0.5:
                self.threat_patterns[f"{exchange}:{fingerprint}"] = threat_score
                logger.warning(f"⚠️ Suspicious JA3 pattern detected: {exchange} - {fingerprint[:16]}... (score: {threat_score})")
            
        except Exception as e:
            logger.error(f"❌ JA3 threat analysis failed: {e}")
    
    async def get_heatmap_data(self) -> List[Dict[str, Any]]:
        """Get JA3 fingerprint heatmap data"""
        try:
            heatmap_data = []
            
            for exchange, fingerprints in self.fingerprints.items():
                heatmap_data.append({
                    "exchange": exchange,
                    "count": len(fingerprints),
                    "unique_fingerprints": len(fingerprints),
                    "threat_level": self._calculate_exchange_threat_level(exchange)
                })
            
            heatmap_data.sort(key=lambda x: x["count"], reverse=True)
            
            return heatmap_data
            
        except Exception as e:
            logger.error(f"❌ JA3 heatmap data generation failed: {e}")
            return []
    
    def _calculate_exchange_threat_level(self, exchange: str) -> float:
        """Calculate threat level for specific exchange"""
        try:
            exchange_threats = [
                score for pattern, score in self.threat_patterns.items()
                if pattern.startswith(f"{exchange}:")
            ]
            
            if not exchange_threats:
                return 0.0
            
            return max(exchange_threats)
            
        except Exception as e:
            logger.error(f"❌ Exchange threat level calculation failed: {e}")
            return 0.0
    
    async def filter_high_impact_exchanges(self) -> List[Dict[str, Any]]:
        """Filter exchanges with high-impact threat patterns"""
        try:
            high_impact = []
            
            for exchange, fingerprints in self.fingerprints.items():
                threat_level = self._calculate_exchange_threat_level(exchange)
                fingerprint_count = len(fingerprints)
                
                if threat_level > 0.7 or fingerprint_count > 20:
                    high_impact.append({
                        "exchange": exchange,
                        "threat_level": threat_level,
                        "fingerprint_count": fingerprint_count,
                        "impact_score": threat_level * fingerprint_count
                    })
            
            high_impact.sort(key=lambda x: x["impact_score"], reverse=True)
            
            return high_impact
            
        except Exception as e:
            logger.error(f"❌ High-impact exchange filtering failed: {e}")
            return []
    
    async def add_fingerprint_to_cluster(self, exchange: str, fingerprint: str):
        """Add fingerprint to clustering analysis"""
        try:
            cluster_key = fingerprint[:8]  # Use first 8 chars as cluster key
            self.cluster_map[cluster_key].append(f"{exchange}:{fingerprint}")
            
            if len(self.cluster_map[cluster_key]) > 5:
                logger.info(f"🔍 JA3 cluster detected: {cluster_key} with {len(self.cluster_map[cluster_key])} members")
            
        except Exception as e:
            logger.error(f"❌ JA3 clustering failed: {e}")
    
    async def get_fingerprint_analytics(self) -> Dict[str, Any]:
        """Get comprehensive fingerprint analytics"""
        try:
            total_fingerprints = sum(len(fps) for fps in self.fingerprints.values())
            total_exchanges = len(self.fingerprints)
            
            avg_fingerprints_per_exchange = total_fingerprints / total_exchanges if total_exchanges > 0 else 0
            
            most_active_exchange = max(
                self.fingerprints.items(), 
                key=lambda x: len(x[1])
            ) if self.fingerprints else ("None", set())
            
            total_threats = len(self.threat_patterns)
            avg_threat_score = sum(self.threat_patterns.values()) / total_threats if total_threats > 0 else 0.0
            
            return {
                "total_fingerprints": total_fingerprints,
                "total_exchanges": total_exchanges,
                "avg_fingerprints_per_exchange": avg_fingerprints_per_exchange,
                "most_active_exchange": {
                    "name": most_active_exchange[0],
                    "fingerprint_count": len(most_active_exchange[1])
                },
                "threat_statistics": {
                    "total_threats": total_threats,
                    "avg_threat_score": avg_threat_score
                },
                "cluster_count": len(self.cluster_map),
                "history_entries": len(self.fingerprint_history)
            }
            
        except Exception as e:
            logger.error(f"❌ JA3 analytics failed: {e}")
            return {"error": str(e)}
    
    async def cleanup_old_fingerprints(self, max_age_hours: int = 24):
        """Cleanup old fingerprint data"""
        try:
            cutoff_time = time.time() - (max_age_hours * 3600)
            
            self.fingerprint_history = [
                entry for entry in self.fingerprint_history
                if entry["timestamp"] > cutoff_time
            ]
            
            for cluster_key in list(self.cluster_map.keys()):
                if len(self.cluster_map[cluster_key]) < 2:  # Remove small clusters
                    del self.cluster_map[cluster_key]
            
            logger.info(f"🧹 JA3 fingerprint cleanup completed")
            
        except Exception as e:
            logger.error(f"❌ JA3 cleanup failed: {e}")

ja3_service = JA3FingerprintService()
