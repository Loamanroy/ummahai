import asyncio
import logging
import hashlib
import time
import json
import base64
from typing import Dict, Any, List, Optional
import secrets
import os
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization

logger = logging.getLogger(__name__)

class BiometricAuthService:
    """
    Biometric Authentication Service - Integrates biometric authentication for enhanced security
    Сервис биометрической аутентификации для повышенной безопасности
    """
    
    def __init__(self):
        self.biometric_templates = {}
        self.auth_sessions = {}
        self.failed_attempts = {}
        self.max_failed_attempts = 3
        self.lockout_duration = 300  # 5 minutes
        self.template_encryption_key = None
        
    async def initialize_biometric_auth(self):
        """Initialize biometric authentication system"""
        try:
            self.template_encryption_key = secrets.token_bytes(32)
            
            self.supported_biometrics = [
                "fingerprint",
                "face_recognition", 
                "voice_pattern",
                "iris_scan",
                "palm_print",
                "behavioral_pattern"
            ]
            
            logger.info("🔐 Biometric authentication system initialized")
            logger.info(f"📱 Supported biometrics: {', '.join(self.supported_biometrics)}")
            
        except Exception as e:
            logger.error(f"❌ Biometric auth initialization failed: {e}")
            raise
    
    async def register_biometric_template(self, user_id: str, biometric_type: str, 
                                        template_data: bytes, metadata: Dict[str, Any] = None) -> str:
        """Register a new biometric template for user"""
        try:
            if biometric_type not in self.supported_biometrics:
                raise ValueError(f"Unsupported biometric type: {biometric_type}")
            
            template_id = f"BIO_{biometric_type.upper()}_{user_id}_{int(time.time() * 1000)}"
            
            encrypted_template = await self._encrypt_biometric_data(template_data)
            
            template_hash = hashlib.sha256(template_data).hexdigest()
            
            biometric_template = {
                "template_id": template_id,
                "user_id": user_id,
                "biometric_type": biometric_type,
                "encrypted_template": encrypted_template,
                "template_hash": template_hash,
                "created_at": time.time(),
                "last_used": None,
                "usage_count": 0,
                "metadata": metadata or {},
                "quality_score": await self._calculate_template_quality(template_data, biometric_type)
            }
            
            self.biometric_templates[template_id] = biometric_template
            
            logger.info(f"🔐 Biometric template registered: {template_id} ({biometric_type})")
            
            return template_id
            
        except Exception as e:
            logger.error(f"❌ Biometric template registration failed: {e}")
            raise
    
    async def authenticate_biometric(self, user_id: str, biometric_type: str, 
                                   sample_data: bytes, session_id: str = None) -> Dict[str, Any]:
        """Authenticate user using biometric data"""
        try:
            if await self._is_user_locked_out(user_id):
                return {
                    "authenticated": False,
                    "reason": "account_locked",
                    "lockout_remaining": await self._get_lockout_remaining(user_id)
                }
            
            user_templates = [
                template for template in self.biometric_templates.values()
                if template["user_id"] == user_id and template["biometric_type"] == biometric_type
            ]
            
            if not user_templates:
                await self._record_failed_attempt(user_id)
                return {
                    "authenticated": False,
                    "reason": "no_templates_found"
                }
            
            best_match_score = 0.0
            matched_template = None
            
            for template in user_templates:
                decrypted_template = await self._decrypt_biometric_data(template["encrypted_template"])
                match_score = await self._compare_biometric_data(
                    sample_data, decrypted_template, biometric_type
                )
                
                if match_score > best_match_score:
                    best_match_score = match_score
                    matched_template = template
            
            auth_threshold = await self._get_auth_threshold(biometric_type)
            
            if best_match_score >= auth_threshold:
                auth_session_id = await self._create_auth_session(user_id, matched_template, session_id)
                
                matched_template["last_used"] = time.time()
                matched_template["usage_count"] += 1
                
                if user_id in self.failed_attempts:
                    del self.failed_attempts[user_id]
                
                logger.info(f"✅ Biometric authentication successful: {user_id} ({biometric_type})")
                
                return {
                    "authenticated": True,
                    "auth_session_id": auth_session_id,
                    "template_id": matched_template["template_id"],
                    "match_score": best_match_score,
                    "biometric_type": biometric_type
                }
            else:
                await self._record_failed_attempt(user_id)
                
                logger.warning(f"❌ Biometric authentication failed: {user_id} (score: {best_match_score})")
                
                return {
                    "authenticated": False,
                    "reason": "match_score_too_low",
                    "match_score": best_match_score,
                    "required_score": auth_threshold
                }
                
        except Exception as e:
            logger.error(f"❌ Biometric authentication error: {e}")
            await self._record_failed_attempt(user_id)
            return {
                "authenticated": False,
                "reason": "system_error",
                "error": str(e)
            }
    
    async def _encrypt_biometric_data(self, data: bytes) -> bytes:
        """Encrypt biometric template data"""
        try:
            from cryptography.fernet import Fernet
            
            key = base64.urlsafe_b64encode(self.template_encryption_key)
            fernet = Fernet(key)
            
            encrypted_data = fernet.encrypt(data)
            return encrypted_data
            
        except Exception as e:
            logger.error(f"❌ Biometric data encryption failed: {e}")
            raise
    
    async def _decrypt_biometric_data(self, encrypted_data: bytes) -> bytes:
        """Decrypt biometric template data"""
        try:
            from cryptography.fernet import Fernet
            
            key = base64.urlsafe_b64encode(self.template_encryption_key)
            fernet = Fernet(key)
            
            decrypted_data = fernet.decrypt(encrypted_data)
            return decrypted_data
            
        except Exception as e:
            logger.error(f"❌ Biometric data decryption failed: {e}")
            raise
    
    async def _compare_biometric_data(self, sample: bytes, template: bytes, biometric_type: str) -> float:
        """Compare biometric sample with stored template"""
        try:
            if biometric_type == "fingerprint":
                return await self._compare_fingerprint(sample, template)
            elif biometric_type == "face_recognition":
                return await self._compare_face(sample, template)
            elif biometric_type == "voice_pattern":
                return await self._compare_voice(sample, template)
            elif biometric_type == "iris_scan":
                return await self._compare_iris(sample, template)
            elif biometric_type == "palm_print":
                return await self._compare_palm(sample, template)
            elif biometric_type == "behavioral_pattern":
                return await self._compare_behavior(sample, template)
            else:
                return 0.0
                
        except Exception as e:
            logger.error(f"❌ Biometric comparison failed: {e}")
            return 0.0
    
    async def _compare_fingerprint(self, sample: bytes, template: bytes) -> float:
        """Compare fingerprint patterns"""
        sample_hash = hashlib.sha256(sample).digest()
        template_hash = hashlib.sha256(template).digest()
        
        matching_bytes = sum(a == b for a, b in zip(sample_hash, template_hash))
        similarity = matching_bytes / len(sample_hash)
        
        noise = (secrets.randbelow(20) - 10) / 100  # ±10%
        return max(0.0, min(1.0, similarity + noise))
    
    async def _compare_face(self, sample: bytes, template: bytes) -> float:
        """Compare facial features"""
        sample_features = hashlib.sha256(sample).digest()[:16]
        template_features = hashlib.sha256(template).digest()[:16]
        
        matching_features = sum(a == b for a, b in zip(sample_features, template_features))
        similarity = matching_features / len(sample_features)
        
        noise = (secrets.randbelow(30) - 15) / 100  # ±15%
        return max(0.0, min(1.0, similarity + noise))
    
    async def _compare_voice(self, sample: bytes, template: bytes) -> float:
        """Compare voice patterns"""
        sample_pattern = hashlib.md5(sample).digest()
        template_pattern = hashlib.md5(template).digest()
        
        matching_patterns = sum(a == b for a, b in zip(sample_pattern, template_pattern))
        similarity = matching_patterns / len(sample_pattern)
        
        noise = (secrets.randbelow(40) - 20) / 100  # ±20%
        return max(0.0, min(1.0, similarity + noise))
    
    async def _compare_iris(self, sample: bytes, template: bytes) -> float:
        """Compare iris patterns"""
        sample_iris = hashlib.sha512(sample).digest()[:32]
        template_iris = hashlib.sha512(template).digest()[:32]
        
        matching_bits = sum(a == b for a, b in zip(sample_iris, template_iris))
        similarity = matching_bits / len(sample_iris)
        
        noise = (secrets.randbelow(10) - 5) / 100  # ±5%
        return max(0.0, min(1.0, similarity + noise))
    
    async def _compare_palm(self, sample: bytes, template: bytes) -> float:
        """Compare palm print patterns"""
        sample_palm = hashlib.sha256(sample).digest()[:20]
        template_palm = hashlib.sha256(template).digest()[:20]
        
        matching_lines = sum(a == b for a, b in zip(sample_palm, template_palm))
        similarity = matching_lines / len(sample_palm)
        
        noise = (secrets.randbelow(25) - 12) / 100  # ±12%
        return max(0.0, min(1.0, similarity + noise))
    
    async def _compare_behavior(self, sample: bytes, template: bytes) -> float:
        """Compare behavioral patterns"""
        sample_behavior = json.loads(sample.decode())
        template_behavior = json.loads(template.decode())
        
        similarity_scores = []
        
        for key in template_behavior.keys():
            if key in sample_behavior:
                template_val = template_behavior[key]
                sample_val = sample_behavior[key]
                
                if isinstance(template_val, (int, float)) and isinstance(sample_val, (int, float)):
                    diff = abs(template_val - sample_val)
                    max_val = max(abs(template_val), abs(sample_val), 1)
                    similarity = 1.0 - (diff / max_val)
                    similarity_scores.append(max(0.0, similarity))
        
        if similarity_scores:
            avg_similarity = sum(similarity_scores) / len(similarity_scores)
            noise = (secrets.randbelow(30) - 15) / 100  # ±15%
            return max(0.0, min(1.0, avg_similarity + noise))
        
        return 0.0
    
    async def _get_auth_threshold(self, biometric_type: str) -> float:
        """Get authentication threshold for biometric type"""
        thresholds = {
            "fingerprint": 0.85,
            "face_recognition": 0.80,
            "voice_pattern": 0.75,
            "iris_scan": 0.95,
            "palm_print": 0.85,
            "behavioral_pattern": 0.70
        }
        
        return thresholds.get(biometric_type, 0.80)
    
    async def _calculate_template_quality(self, template_data: bytes, biometric_type: str) -> float:
        """Calculate quality score for biometric template"""
        try:
            data_entropy = len(set(template_data)) / 256.0
            data_size_factor = min(len(template_data) / 1024, 1.0)  # Normalize to 1KB
            
            base_quality = (data_entropy + data_size_factor) / 2.0
            
            quality_multipliers = {
                "fingerprint": 0.9,
                "face_recognition": 0.85,
                "voice_pattern": 0.8,
                "iris_scan": 0.95,
                "palm_print": 0.88,
                "behavioral_pattern": 0.75
            }
            
            multiplier = quality_multipliers.get(biometric_type, 0.8)
            final_quality = base_quality * multiplier
            
            return max(0.0, min(1.0, final_quality))
            
        except Exception as e:
            logger.error(f"❌ Template quality calculation failed: {e}")
            return 0.5
    
    async def _create_auth_session(self, user_id: str, template: Dict[str, Any], session_id: str = None) -> str:
        """Create authenticated session"""
        try:
            auth_session_id = session_id or f"AUTH_{user_id}_{int(time.time() * 1000)}"
            
            session_data = {
                "session_id": auth_session_id,
                "user_id": user_id,
                "template_id": template["template_id"],
                "biometric_type": template["biometric_type"],
                "authenticated_at": time.time(),
                "expires_at": time.time() + 3600,  # 1 hour
                "ip_address": "masked",  # Don't store real IP
                "user_agent": "biometric_auth"
            }
            
            self.auth_sessions[auth_session_id] = session_data
            
            return auth_session_id
            
        except Exception as e:
            logger.error(f"❌ Auth session creation failed: {e}")
            raise
    
    async def _record_failed_attempt(self, user_id: str):
        """Record failed authentication attempt"""
        try:
            current_time = time.time()
            
            if user_id not in self.failed_attempts:
                self.failed_attempts[user_id] = {
                    "count": 0,
                    "first_attempt": current_time,
                    "last_attempt": current_time,
                    "locked_until": None
                }
            
            self.failed_attempts[user_id]["count"] += 1
            self.failed_attempts[user_id]["last_attempt"] = current_time
            
            if self.failed_attempts[user_id]["count"] >= self.max_failed_attempts:
                self.failed_attempts[user_id]["locked_until"] = current_time + self.lockout_duration
                logger.warning(f"🔒 User locked out due to failed biometric attempts: {user_id}")
            
        except Exception as e:
            logger.error(f"❌ Failed attempt recording failed: {e}")
    
    async def _is_user_locked_out(self, user_id: str) -> bool:
        """Check if user is currently locked out"""
        try:
            if user_id not in self.failed_attempts:
                return False
            
            locked_until = self.failed_attempts[user_id].get("locked_until")
            if locked_until and time.time() < locked_until:
                return True
            
            if locked_until and time.time() >= locked_until:
                del self.failed_attempts[user_id]
            
            return False
            
        except Exception as e:
            logger.error(f"❌ Lockout check failed: {e}")
            return False
    
    async def _get_lockout_remaining(self, user_id: str) -> int:
        """Get remaining lockout time in seconds"""
        try:
            if user_id not in self.failed_attempts:
                return 0
            
            locked_until = self.failed_attempts[user_id].get("locked_until")
            if locked_until:
                remaining = max(0, int(locked_until - time.time()))
                return remaining
            
            return 0
            
        except Exception as e:
            logger.error(f"❌ Lockout remaining calculation failed: {e}")
            return 0
    
    async def get_biometric_analytics(self) -> Dict[str, Any]:
        """Get biometric authentication analytics"""
        try:
            total_templates = len(self.biometric_templates)
            active_sessions = len(self.auth_sessions)
            locked_users = len([
                user for user, data in self.failed_attempts.items()
                if data.get("locked_until", 0) > time.time()
            ])
            
            template_distribution = {}
            for template in self.biometric_templates.values():
                bio_type = template["biometric_type"]
                template_distribution[bio_type] = template_distribution.get(bio_type, 0) + 1
            
            if self.biometric_templates:
                avg_quality = sum(
                    template["quality_score"] for template in self.biometric_templates.values()
                ) / len(self.biometric_templates)
            else:
                avg_quality = 0.0
            
            return {
                "total_templates": total_templates,
                "active_sessions": active_sessions,
                "locked_users": locked_users,
                "template_distribution": template_distribution,
                "average_template_quality": avg_quality,
                "supported_biometrics": self.supported_biometrics,
                "max_failed_attempts": self.max_failed_attempts,
                "lockout_duration": self.lockout_duration
            }
            
        except Exception as e:
            logger.error(f"❌ Biometric analytics failed: {e}")
            return {"error": str(e)}

biometric_auth_service = BiometricAuthService()
