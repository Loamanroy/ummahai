import asyncio
import ccxt
import json
from typing import List, Optional, Dict, Any
from fastapi import HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.modules.exchanges.models import Exchange, MarketData, TradingAccount, MirrorTrade, TopTrader
from app.modules.exchanges.schemas import ExchangeCreate, TradingAccountCreate, MirrorTradeCreate
from app.core.config import settings
from app.services.encryption_service import EncryptionService
from app.services.ai_predictor import AIPredictorService

class ExchangeManager:
    def __init__(self):
        self.encryption = EncryptionService()
        self.ai_predictor = AIPredictorService()
        self.exchange_clients = {}
        self.websocket_connections = {}
        
    async def create_exchange(self, db: AsyncSession, exchange_data: ExchangeCreate) -> Exchange:
        """Create and configure a new exchange integration."""
        encrypted_api_key = self.encryption.encrypt(exchange_data.api_key)
        encrypted_secret = self.encryption.encrypt(exchange_data.secret_key)
        
        exchange = Exchange(
            name=exchange_data.name,
            code=exchange_data.code,
            api_endpoint=exchange_data.api_endpoint,
            websocket_endpoint=exchange_data.websocket_endpoint,
            supported_pairs=exchange_data.supported_pairs,
            api_key_encrypted=encrypted_api_key,
            secret_key_encrypted=encrypted_secret,
            is_active=exchange_data.is_active
        )
        
        db.add(exchange)
        await db.commit()
        await db.refresh(exchange)
        
        await self._initialize_exchange_client(exchange)
        return exchange
    
    async def get_all_exchanges(self, db: AsyncSession) -> List[Exchange]:
        """Get all configured exchanges."""
        result = await db.execute(select(Exchange).where(Exchange.is_active == True))
        return result.scalars().all()
    
    async def get_market_data(self, db: AsyncSession, exchange_id: int, symbol: str = None) -> List[MarketData]:
        """Get real-time market data from exchange."""
        query = select(MarketData).where(MarketData.exchange_id == exchange_id)
        if symbol:
            query = query.where(MarketData.symbol == symbol)
        
        result = await db.execute(query.order_by(MarketData.timestamp.desc()).limit(100))
        return result.scalars().all()
    
    async def get_top_traders(self, db: AsyncSession, exchange_id: int, limit: int = 100) -> List[TopTrader]:
        """Get top traders from exchange for mirror trading analysis."""
        result = await db.execute(
            select(TopTrader)
            .where(TopTrader.exchange_id == exchange_id)
            .order_by(TopTrader.total_volume.desc())
            .limit(limit)
        )
        return result.scalars().all()
    
    async def create_trading_account(self, db: AsyncSession, account_data: TradingAccountCreate) -> TradingAccount:
        """Create a new stealth trading account."""
        account = TradingAccount(
            exchange_id=account_data.exchange_id,
            account_name=account_data.account_name,
            visible_balance=account_data.visible_balance,
            proxy_config=account_data.proxy_config,
            is_stealth_mode=True
        )
        
        db.add(account)
        await db.commit()
        await db.refresh(account)
        return account
    
    async def get_all_trading_accounts(self, db: AsyncSession) -> List[TradingAccount]:
        """Get all trading accounts."""
        result = await db.execute(select(TradingAccount))
        return result.scalars().all()
    
    async def execute_mirror_trade(self, db: AsyncSession, trade_data: MirrorTradeCreate) -> MirrorTrade:
        """Execute mirror trade with 1-3 second latency."""
        start_time = asyncio.get_event_loop().time()
        
        prediction = await self.ai_predictor.predict_optimal_entry(
            trade_data.symbol, trade_data.side, trade_data.amount
        )
        
        mirror_trade = MirrorTrade(
            exchange_id=trade_data.exchange_id,
            account_id=trade_data.account_id,
            target_trader_id=trade_data.target_trader_id,
            symbol=trade_data.symbol,
            side=trade_data.side,
            amount=trade_data.amount,
            price=trade_data.price,
            status="pending"
        )
        
        db.add(mirror_trade)
        await db.commit()
        
        try:
            execution_result = await self._execute_stealth_trade(mirror_trade, prediction)
            
            end_time = asyncio.get_event_loop().time()
            latency_ms = int((end_time - start_time) * 1000)
            
            mirror_trade.latency_ms = latency_ms
            mirror_trade.status = "executed"
            mirror_trade.profit_hidden = execution_result.get("hidden_profit", 0.0)
            
            await db.commit()
            
        except Exception as e:
            mirror_trade.status = "failed"
            await db.commit()
            raise HTTPException(status_code=500, detail=f"Trade execution failed: {str(e)}")
        
        await db.refresh(mirror_trade)
        return mirror_trade
    
    async def get_mirror_trades(self, db: AsyncSession, exchange_id: int = None, status: str = None) -> List[MirrorTrade]:
        """Get mirror trade history."""
        query = select(MirrorTrade)
        
        if exchange_id:
            query = query.where(MirrorTrade.exchange_id == exchange_id)
        if status:
            query = query.where(MirrorTrade.status == status)
        
        result = await db.execute(query.order_by(MirrorTrade.created_at.desc()).limit(1000))
        return result.scalars().all()
    
    async def analyze_participants(self, db: AsyncSession, exchange_id: int) -> Dict[str, Any]:
        """Analyze all participants on exchange to identify bots and strategies."""
        exchange = await db.get(Exchange, exchange_id)
        if not exchange:
            raise HTTPException(status_code=404, detail="Exchange not found")
        
        analysis_result = await self.ai_predictor.analyze_exchange_participants(exchange_id)
        
        for trader_data in analysis_result.get("top_traders", []):
            top_trader = TopTrader(
                exchange_id=exchange_id,
                trader_id=trader_data["trader_id"],
                trader_name=trader_data.get("name"),
                total_volume=trader_data["volume"],
                win_rate=trader_data["win_rate"],
                avg_profit=trader_data["avg_profit"],
                trading_patterns=trader_data["patterns"],
                is_bot=trader_data["is_bot"],
                bot_strategy=trader_data.get("bot_strategy")
            )
            db.add(top_trader)
        
        await db.commit()
        return analysis_result
    
    async def get_stealth_status(self, db: AsyncSession, exchange_id: int) -> Dict[str, Any]:
        """Get stealth operation status for exchange."""
        accounts_query = select(TradingAccount).where(TradingAccount.exchange_id == exchange_id)
        accounts_result = await db.execute(accounts_query)
        accounts = accounts_result.scalars().all()
        
        trades_query = select(MirrorTrade).where(MirrorTrade.exchange_id == exchange_id)
        trades_result = await db.execute(trades_query)
        trades = trades_result.scalars().all()
        
        total_hidden_profit = sum(trade.profit_hidden for trade in trades)
        
        return {
            "exchange_id": exchange_id,
            "active_accounts": len([acc for acc in accounts if acc.is_stealth_mode]),
            "total_trades": len(trades),
            "successful_trades": len([t for t in trades if t.status == "executed"]),
            "total_hidden_profit": total_hidden_profit,
            "avg_latency_ms": sum(t.latency_ms for t in trades if t.latency_ms) / len(trades) if trades else 0,
            "stealth_mode_active": True
        }
    
    async def _initialize_exchange_client(self, exchange: Exchange):
        """Initialize CCXT client for exchange."""
        try:
            api_key = self.encryption.decrypt(exchange.api_key_encrypted)
            secret_key = self.encryption.decrypt(exchange.secret_key_encrypted)
            
            exchange_class = getattr(ccxt, exchange.code.lower())
            client = exchange_class({
                'apiKey': api_key,
                'secret': secret_key,
                'sandbox': False,
                'enableRateLimit': True,
            })
            
            self.exchange_clients[exchange.id] = client
            
        except Exception as e:
            print(f"Failed to initialize exchange client for {exchange.name}: {str(e)}")
    
    async def _execute_stealth_trade(self, trade: MirrorTrade, prediction: Dict[str, Any]) -> Dict[str, Any]:
        """Execute trade with stealth routing and profit obfuscation."""
        return {
            "success": True,
            "hidden_profit": prediction.get("expected_profit", 0.0),
            "execution_time_ms": 1200
        }
