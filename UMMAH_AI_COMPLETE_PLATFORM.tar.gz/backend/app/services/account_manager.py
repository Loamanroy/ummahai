import asyncio
from typing import List, Optional, Dict, Any
from fastapi import HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from datetime import datetime, timedelta
from app.modules.accounts.models import Account, ExchangeAccount, TradingSession, AccountActivity, AccountPermissions
from app.modules.accounts.schemas import AccountCreate, ExchangeAccountCreate, TradingSessionCreate, AccountPermissionsCreate, AccountBalanceUpdate, AccountConfigUpdate
from app.services.encryption_service import EncryptionService
from app.services.stealth_service import StealthService

class AccountManager:
    def __init__(self):
        self.encryption = EncryptionService()
        self.stealth_service = StealthService()
        
    async def create_account(self, db: AsyncSession, account_data: AccountCreate) -> Account:
        """Create a new trading account."""
        account = Account(
            account_name=account_data.account_name,
            account_type=account_data.account_type,
            owner_id=account_data.owner_id,
            max_daily_volume=account_data.max_daily_volume,
            risk_tolerance=account_data.risk_tolerance,
            auto_trading_enabled=account_data.auto_trading_enabled,
            stealth_mode_enabled=account_data.stealth_mode_enabled,
            configuration=account_data.configuration,
            visible_balance_usd=1000.0,  # Always show max $1000
            last_activity=datetime.utcnow()
        )
        
        db.add(account)
        await db.commit()
        await db.refresh(account)
        
        default_permissions = AccountPermissionsCreate(
            account_id=account.id,
            can_withdraw=False  # Stealth accounts can't withdraw by default
        )
        await self.create_permissions(db, default_permissions)
        
        await self._log_activity(db, account.id, "account_created", "New account created")
        
        return account
    
    async def get_accounts(self, db: AsyncSession, owner_id: str = None, account_type: str = None, status: str = None) -> List[Account]:
        """Get accounts with filtering."""
        query = select(Account)
        
        if owner_id:
            query = query.where(Account.owner_id == owner_id)
        if account_type:
            query = query.where(Account.account_type == account_type)
        if status:
            query = query.where(Account.status == status)
        
        result = await db.execute(query.order_by(Account.created_at.desc()))
        return result.scalars().all()
    
    async def get_account(self, db: AsyncSession, account_id: int) -> Account:
        """Get account by ID."""
        account = await db.get(Account, account_id)
        if not account:
            raise HTTPException(status_code=404, detail="Account not found")
        
        account.last_activity = datetime.utcnow()
        await db.commit()
        
        return account
    
    async def update_balance(self, db: AsyncSession, account_id: int, balance_update: AccountBalanceUpdate) -> Dict[str, Any]:
        """Update account balance."""
        account = await self.get_account(db, account_id)
        
        if balance_update.total_balance_usd is not None:
            account.total_balance_usd = balance_update.total_balance_usd
        if balance_update.visible_balance_usd is not None:
            account.visible_balance_usd = min(1000.0, balance_update.visible_balance_usd)
        if balance_update.hidden_balance_usd is not None:
            account.hidden_balance_usd = balance_update.hidden_balance_usd
        
        account.updated_at = datetime.utcnow()
        await db.commit()
        
        await self._log_activity(db, account_id, "balance_updated", f"Balance updated: visible=${account.visible_balance_usd}, hidden=${account.hidden_balance_usd}")
        
        return {
            "account_id": account_id,
            "total_balance_usd": account.total_balance_usd,
            "visible_balance_usd": account.visible_balance_usd,
            "hidden_balance_usd": account.hidden_balance_usd,
            "updated_at": account.updated_at
        }
    
    async def update_config(self, db: AsyncSession, account_id: int, config_update: AccountConfigUpdate) -> Dict[str, Any]:
        """Update account configuration."""
        account = await self.get_account(db, account_id)
        
        if config_update.max_daily_volume is not None:
            account.max_daily_volume = config_update.max_daily_volume
        if config_update.risk_tolerance is not None:
            account.risk_tolerance = config_update.risk_tolerance
        if config_update.auto_trading_enabled is not None:
            account.auto_trading_enabled = config_update.auto_trading_enabled
        if config_update.stealth_mode_enabled is not None:
            account.stealth_mode_enabled = config_update.stealth_mode_enabled
        if config_update.encryption_level is not None:
            account.encryption_level = config_update.encryption_level
        if config_update.proxy_rotation_enabled is not None:
            account.proxy_rotation_enabled = config_update.proxy_rotation_enabled
        if config_update.tor_routing_enabled is not None:
            account.tor_routing_enabled = config_update.tor_routing_enabled
        if config_update.configuration is not None:
            account.configuration = config_update.configuration
        
        account.updated_at = datetime.utcnow()
        await db.commit()
        
        await self._log_activity(db, account_id, "config_updated", "Account configuration updated")
        
        return {"account_id": account_id, "message": "Configuration updated successfully"}
    
    async def create_exchange_account(self, db: AsyncSession, exchange_account_data: ExchangeAccountCreate) -> ExchangeAccount:
        """Create exchange account integration."""
        encrypted_api_key = self.encryption.encrypt(exchange_account_data.api_key)
        encrypted_secret_key = self.encryption.encrypt(exchange_account_data.secret_key)
        encrypted_passphrase = None
        if exchange_account_data.passphrase:
            encrypted_passphrase = self.encryption.encrypt(exchange_account_data.passphrase)
        
        exchange_account = ExchangeAccount(
            account_id=exchange_account_data.account_id,
            exchange_id=exchange_account_data.exchange_id,
            api_key_encrypted=encrypted_api_key,
            secret_key_encrypted=encrypted_secret_key,
            passphrase_encrypted=encrypted_passphrase,
            account_type_on_exchange=exchange_account_data.account_type_on_exchange,
            max_position_size=exchange_account_data.max_position_size,
            proxy_config=exchange_account_data.proxy_config,
            visible_balance_override=1000.0  # Always show $1000 max
        )
        
        db.add(exchange_account)
        await db.commit()
        await db.refresh(exchange_account)
        
        await self._log_activity(db, exchange_account_data.account_id, "exchange_account_created", f"Exchange account created for exchange {exchange_account_data.exchange_id}")
        
        return exchange_account
    
    async def get_exchange_accounts(self, db: AsyncSession, account_id: int) -> List[ExchangeAccount]:
        """Get exchange accounts for account."""
        result = await db.execute(select(ExchangeAccount).where(ExchangeAccount.account_id == account_id))
        return result.scalars().all()
    
    async def create_trading_session(self, db: AsyncSession, session_data: TradingSessionCreate) -> TradingSession:
        """Create a new trading session."""
        session = TradingSession(
            account_id=session_data.account_id,
            session_name=session_data.session_name,
            session_type=session_data.session_type,
            target_exchanges=session_data.target_exchanges,
            trading_pairs=session_data.trading_pairs,
            strategy_parameters=session_data.strategy_parameters,
            stop_loss_percentage=session_data.stop_loss_percentage,
            take_profit_percentage=session_data.take_profit_percentage,
            max_concurrent_trades=session_data.max_concurrent_trades
        )
        
        db.add(session)
        await db.commit()
        await db.refresh(session)
        
        await self._log_activity(db, session_data.account_id, "trading_session_created", f"Trading session '{session_data.session_name}' created")
        
        return session
    
    async def get_trading_sessions(self, db: AsyncSession, account_id: int, status: str = None) -> List[TradingSession]:
        """Get trading sessions for account."""
        query = select(TradingSession).where(TradingSession.account_id == account_id)
        
        if status:
            query = query.where(TradingSession.status == status)
        
        result = await db.execute(query.order_by(TradingSession.created_at.desc()))
        return result.scalars().all()
    
    async def start_trading_session(self, db: AsyncSession, session_id: int) -> Dict[str, Any]:
        """Start a trading session."""
        session = await db.get(TradingSession, session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Trading session not found")
        
        session.status = "running"
        session.started_at = datetime.utcnow()
        await db.commit()
        
        await self._log_activity(db, session.account_id, "trading_session_started", f"Trading session '{session.session_name}' started")
        
        return {"session_id": session_id, "status": "running", "started_at": session.started_at}
    
    async def stop_trading_session(self, db: AsyncSession, session_id: int) -> Dict[str, Any]:
        """Stop a trading session."""
        session = await db.get(TradingSession, session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Trading session not found")
        
        session.status = "stopped"
        session.ended_at = datetime.utcnow()
        await db.commit()
        
        await self._log_activity(db, session.account_id, "trading_session_stopped", f"Trading session '{session.session_name}' stopped")
        
        return {"session_id": session_id, "status": "stopped", "ended_at": session.ended_at}
    
    async def get_account_activities(self, db: AsyncSession, account_id: int, activity_type: str = None, limit: int = 100) -> List[AccountActivity]:
        """Get account activity history."""
        query = select(AccountActivity).where(AccountActivity.account_id == account_id)
        
        if activity_type:
            query = query.where(AccountActivity.activity_type == activity_type)
        
        result = await db.execute(query.order_by(AccountActivity.created_at.desc()).limit(limit))
        return result.scalars().all()
    
    async def create_permissions(self, db: AsyncSession, permissions_data: AccountPermissionsCreate) -> AccountPermissions:
        """Create account permissions."""
        permissions = AccountPermissions(**permissions_data.dict())
        
        db.add(permissions)
        await db.commit()
        await db.refresh(permissions)
        return permissions
    
    async def get_permissions(self, db: AsyncSession, account_id: int) -> AccountPermissions:
        """Get account permissions."""
        result = await db.execute(select(AccountPermissions).where(AccountPermissions.account_id == account_id))
        permissions = result.scalar_one_or_none()
        
        if not permissions:
            raise HTTPException(status_code=404, detail="Account permissions not found")
        
        return permissions
    
    async def get_account_dashboard(self, db: AsyncSession, account_id: int) -> Dict[str, Any]:
        """Get comprehensive account dashboard data."""
        account = await self.get_account(db, account_id)
        exchange_accounts = await self.get_exchange_accounts(db, account_id)
        trading_sessions = await self.get_trading_sessions(db, account_id)
        recent_activities = await self.get_account_activities(db, account_id, limit=10)
        
        active_sessions = [s for s in trading_sessions if s.status == "running"]
        total_profit = sum(s.total_profit for s in trading_sessions)
        total_trades = sum(s.total_trades for s in trading_sessions)
        
        return {
            "account": {
                "id": account.id,
                "name": account.account_name,
                "type": account.account_type,
                "status": account.status,
                "visible_balance_usd": account.visible_balance_usd,
                "stealth_mode": account.stealth_mode_enabled
            },
            "balances": {
                "total_balance_usd": account.total_balance_usd,
                "visible_balance_usd": account.visible_balance_usd,
                "hidden_balance_usd": account.hidden_balance_usd
            },
            "exchanges": {
                "connected_exchanges": len(exchange_accounts),
                "active_exchanges": len([ea for ea in exchange_accounts if ea.is_active])
            },
            "trading": {
                "active_sessions": len(active_sessions),
                "total_sessions": len(trading_sessions),
                "total_trades": total_trades,
                "total_profit": total_profit
            },
            "security": {
                "encryption_level": account.encryption_level,
                "proxy_rotation": account.proxy_rotation_enabled,
                "tor_routing": account.tor_routing_enabled,
                "stealth_mode": account.stealth_mode_enabled
            },
            "recent_activities": [
                {
                    "type": activity.activity_type,
                    "description": activity.description,
                    "timestamp": activity.created_at
                }
                for activity in recent_activities
            ]
        }
    
    async def get_stealth_status(self, db: AsyncSession, account_id: int) -> Dict[str, Any]:
        """Get stealth operation status for account."""
        account = await self.get_account(db, account_id)
        
        stealth_operations = await self.stealth_service.get_operations(db)
        account_operations = [op for op in stealth_operations if op.source_account_id == account_id]
        
        anonymity_metrics = await self.stealth_service.get_anonymity_metrics(db, account_id)
        
        return {
            "account_id": account_id,
            "stealth_mode_enabled": account.stealth_mode_enabled,
            "anonymity_score": anonymity_metrics.anonymity_score,
            "risk_level": anonymity_metrics.risk_level,
            "active_operations": len([op for op in account_operations if op.status == "active"]),
            "completed_operations": len([op for op in account_operations if op.status == "completed"]),
            "proxy_rotation": account.proxy_rotation_enabled,
            "tor_routing": account.tor_routing_enabled,
            "encryption_level": account.encryption_level,
            "visible_balance_limit": 1000.0,
            "status": "operational" if account.stealth_mode_enabled else "disabled"
        }
    
    async def _log_activity(self, db: AsyncSession, account_id: int, activity_type: str, description: str, **kwargs):
        """Log account activity."""
        activity = AccountActivity(
            account_id=account_id,
            activity_type=activity_type,
            description=description,
            exchange_id=kwargs.get("exchange_id"),
            amount=kwargs.get("amount"),
            currency=kwargs.get("currency"),
            ip_address=kwargs.get("ip_address", "127.0.0.1"),
            user_agent=kwargs.get("user_agent", "UMMAH-AI-Platform/1.0"),
            proxy_used=kwargs.get("proxy_used", True),
            tor_used=kwargs.get("tor_used", True),
            vpn_used=kwargs.get("vpn_used", True),
            metadata=kwargs.get("metadata")
        )
        
        db.add(activity)
        await db.commit()
