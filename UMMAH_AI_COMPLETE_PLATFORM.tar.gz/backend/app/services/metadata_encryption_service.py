import asyncio
import hashlib
import time
import json
import os
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from enum import Enum
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64
import secrets
import threading

class MetadataType(Enum):
    AI_DECISION = "ai_decision"
    TRADING_LOG = "trading_log"
    PREDICTION_DATA = "prediction_data"
    EXECUTION_LOG = "execution_log"
    PATTERN_ANALYSIS = "pattern_analysis"
    MIRROR_ACTIVITY = "mirror_activity"
    STEALTH_METRICS = "stealth_metrics"
    TEMPORARY_TOKEN = "temporary_token"

class EncryptionLevel(Enum):
    STANDARD = "standard"
    HIGH = "high"
    PARANOIA = "paranoia"

@dataclass
class EncryptedMetadata:
    metadata_id: str
    metadata_type: MetadataType
    encrypted_data: bytes
    encryption_key_id: str
    created_at: datetime
    expires_at: datetime
    access_count: int
    max_access_count: int
    is_ephemeral: bool

@dataclass
class EncryptionKey:
    key_id: str
    key_data: bytes
    salt: bytes
    created_at: datetime
    expires_at: datetime
    usage_count: int
    max_usage: int
    encryption_level: EncryptionLevel

@dataclass
class EphemeralContainer:
    container_id: str
    container_type: str
    encrypted_strategy_data: bytes
    encryption_key_id: str
    created_at: datetime
    expires_at: datetime
    execution_count: int
    max_executions: int
    auto_destruct_triggers: List[str]

class MetadataEncryptionService:
    """
    Advanced Metadata Encryption Service for CerebellumBot vX
    Encrypts AI decision logs with auto-deletion after 5 minutes
    """
    
    def __init__(self):
        self.service_version = "MetaEncrypt_v6.0"
        
        self.encryption_keys = {}
        self.active_key_rotation = True
        
        self.encrypted_metadata = {}
        self.metadata_access_log = {}
        
        self.ephemeral_containers = {}
        
        self.temporary_tokens = {}
        
        self.auto_destruction_enabled = True
        self.default_expiry_minutes = 5
        self.paranoia_expiry_minutes = 2
        
        self.performance_metrics = {
            'total_metadata_encrypted': 0,
            'metadata_auto_destructed': 0,
            'keys_rotated': 0,
            'ephemeral_containers_created': 0,
            'temporary_tokens_generated': 0,
            'encryption_operations_per_second': 0.0
        }
        
        self._lock = threading.Lock()
    
    async def initialize_metadata_encryption(self):
        """Initialize metadata encryption service."""
        
        print("🔐 Initializing Metadata Encryption Service...")
        
        await self._generate_initial_encryption_keys()
        
        await self._start_key_rotation()
        
        await self._start_auto_destruction_daemon()
        
        await self._start_performance_monitoring()
        
        print("✅ Metadata Encryption Service initialized")
        print(f"🔑 Encryption keys: {len(self.encryption_keys)}")
        print(f"⏰ Auto-destruction: {self.default_expiry_minutes} minutes")
    
    async def _generate_initial_encryption_keys(self):
        """Generate initial set of encryption keys."""
        
        encryption_levels = [
            (EncryptionLevel.STANDARD, 3),
            (EncryptionLevel.HIGH, 2),
            (EncryptionLevel.PARANOIA, 1)
        ]
        
        for encryption_level, key_count in encryption_levels:
            for i in range(key_count):
                await self._generate_encryption_key(encryption_level)
        
        print(f"🔑 Generated {len(self.encryption_keys)} initial encryption keys")
    
    async def _generate_encryption_key(self, encryption_level: EncryptionLevel) -> str:
        """Generate a new encryption key."""
        
        key_id = f"KEY_{encryption_level.value.upper()}_{int(time.time() * 1000)}_{secrets.randbelow(9999):04d}"
        
        salt = os.urandom(16)
        
        if encryption_level == EncryptionLevel.PARANOIA:
            password = secrets.token_bytes(64)  # 512-bit password
            iterations = 500000
            expiry_minutes = self.paranoia_expiry_minutes
            max_usage = secrets.randbelow(10) + 5  # 5-15 uses
        elif encryption_level == EncryptionLevel.HIGH:
            password = secrets.token_bytes(32)  # 256-bit password
            iterations = 200000
            expiry_minutes = 3
            max_usage = secrets.randbelow(20) + 10  # 10-30 uses
        else:  # STANDARD
            password = secrets.token_bytes(32)  # 256-bit password
            iterations = 100000
            expiry_minutes = self.default_expiry_minutes
            max_usage = secrets.randbelow(30) + 20  # 20-50 uses
        
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=iterations,
        )
        key_data = base64.urlsafe_b64encode(kdf.derive(password))
        
        encryption_key = EncryptionKey(
            key_id=key_id,
            key_data=key_data,
            salt=salt,
            created_at=datetime.utcnow(),
            expires_at=datetime.utcnow() + timedelta(minutes=expiry_minutes),
            usage_count=0,
            max_usage=max_usage,
            encryption_level=encryption_level
        )
        
        with self._lock:
            self.encryption_keys[key_id] = encryption_key
        
        return key_id
    
    async def _start_key_rotation(self):
        """Start automatic key rotation."""
        
        asyncio.create_task(self._key_rotation_daemon())
        print("🔄 Key rotation daemon started")
    
    async def _key_rotation_daemon(self):
        """Daemon for automatic key rotation."""
        
        while self.active_key_rotation:
            try:
                current_time = datetime.utcnow()
                keys_to_rotate = []
                
                with self._lock:
                    for key_id, key_data in self.encryption_keys.items():
                        if (current_time > key_data.expires_at or 
                            key_data.usage_count >= key_data.max_usage):
                            keys_to_rotate.append((key_id, key_data.encryption_level))
                
                for key_id, encryption_level in keys_to_rotate:
                    await self._rotate_encryption_key(key_id, encryption_level)
                
                await self._ensure_minimum_key_count()
                
                await asyncio.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                print(f"🔑 Key rotation error: {str(e)}")
                await asyncio.sleep(60)
    
    async def _rotate_encryption_key(self, old_key_id: str, encryption_level: EncryptionLevel):
        """Rotate an encryption key."""
        
        new_key_id = await self._generate_encryption_key(encryption_level)
        
        with self._lock:
            if old_key_id in self.encryption_keys:
                del self.encryption_keys[old_key_id]
        
        self.performance_metrics['keys_rotated'] += 1
        print(f"🔄 Rotated key {old_key_id} -> {new_key_id}")
    
    async def _ensure_minimum_key_count(self):
        """Ensure minimum number of keys per encryption level."""
        
        min_keys_per_level = {
            EncryptionLevel.STANDARD: 2,
            EncryptionLevel.HIGH: 1,
            EncryptionLevel.PARANOIA: 1
        }
        
        key_counts = {level: 0 for level in EncryptionLevel}
        
        with self._lock:
            for key_data in self.encryption_keys.values():
                key_counts[key_data.encryption_level] += 1
        
        for encryption_level, min_count in min_keys_per_level.items():
            current_count = key_counts[encryption_level]
            if current_count < min_count:
                for _ in range(min_count - current_count):
                    await self._generate_encryption_key(encryption_level)
    
    async def _start_auto_destruction_daemon(self):
        """Start auto-destruction daemon."""
        
        asyncio.create_task(self._auto_destruction_daemon())
        print("🔥 Auto-destruction daemon started")
    
    async def _auto_destruction_daemon(self):
        """Daemon for automatic metadata destruction."""
        
        while self.auto_destruction_enabled:
            try:
                current_time = datetime.utcnow()
                
                await self._auto_destruct_metadata(current_time)
                
                await self._auto_destruct_ephemeral_containers(current_time)
                
                await self._auto_destruct_temporary_tokens(current_time)
                
                await asyncio.sleep(10)  # Check every 10 seconds
                
            except Exception as e:
                print(f"🔥 Auto-destruction error: {str(e)}")
                await asyncio.sleep(30)
    
    async def _auto_destruct_metadata(self, current_time: datetime):
        """Auto-destruct expired metadata."""
        
        metadata_to_destruct = []
        
        with self._lock:
            for metadata_id, metadata in self.encrypted_metadata.items():
                if (current_time > metadata.expires_at or 
                    metadata.access_count >= metadata.max_access_count):
                    metadata_to_destruct.append(metadata_id)
        
        for metadata_id in metadata_to_destruct:
            await self._secure_delete_metadata(metadata_id)
    
    async def _auto_destruct_ephemeral_containers(self, current_time: datetime):
        """Auto-destruct expired ephemeral containers."""
        
        containers_to_destruct = []
        
        with self._lock:
            for container_id, container in self.ephemeral_containers.items():
                if (current_time > container.expires_at or 
                    container.execution_count >= container.max_executions):
                    containers_to_destruct.append(container_id)
        
        for container_id in containers_to_destruct:
            await self._secure_delete_container(container_id)
    
    async def _auto_destruct_temporary_tokens(self, current_time: datetime):
        """Auto-destruct expired temporary tokens."""
        
        tokens_to_destruct = []
        
        with self._lock:
            for token_id, token_data in self.temporary_tokens.items():
                if current_time > token_data['expires_at']:
                    tokens_to_destruct.append(token_id)
        
        for token_id in tokens_to_destruct:
            with self._lock:
                if token_id in self.temporary_tokens:
                    del self.temporary_tokens[token_id]
    
    async def _start_performance_monitoring(self):
        """Start performance monitoring."""
        
        asyncio.create_task(self._performance_monitoring_daemon())
        print("📊 Performance monitoring started")
    
    async def _performance_monitoring_daemon(self):
        """Monitor encryption performance."""
        
        last_encryption_count = 0
        
        while True:
            try:
                current_encryption_count = self.performance_metrics['total_metadata_encrypted']
                encryption_ops_per_second = (current_encryption_count - last_encryption_count) / 60
                
                self.performance_metrics['encryption_operations_per_second'] = encryption_ops_per_second
                last_encryption_count = current_encryption_count
                
                await asyncio.sleep(60)  # Update every minute
                
            except Exception as e:
                print(f"📊 Performance monitoring error: {str(e)}")
                await asyncio.sleep(60)
    
    async def encrypt_metadata(self, data: Dict[str, Any], metadata_type: MetadataType,
                             encryption_level: EncryptionLevel = EncryptionLevel.STANDARD,
                             expiry_minutes: Optional[int] = None,
                             is_ephemeral: bool = False) -> str:
        """Encrypt metadata with auto-destruction."""
        
        encryption_key = await self._select_encryption_key(encryption_level)
        if not encryption_key:
            raise Exception(f"No available encryption key for level {encryption_level.value}")
        
        fernet = Fernet(encryption_key.key_data)
        
        json_data = json.dumps(data, default=str).encode('utf-8')
        encrypted_data = fernet.encrypt(json_data)
        
        metadata_id = f"META_{metadata_type.value.upper()}_{int(time.time() * 1000)}_{secrets.randbelow(9999):04d}"
        
        if expiry_minutes is None:
            if encryption_level == EncryptionLevel.PARANOIA:
                expiry_minutes = self.paranoia_expiry_minutes
            else:
                expiry_minutes = self.default_expiry_minutes
        
        expires_at = datetime.utcnow() + timedelta(minutes=expiry_minutes)
        
        if encryption_level == EncryptionLevel.PARANOIA:
            max_access_count = secrets.randbelow(3) + 1  # 1-3 accesses
        elif encryption_level == EncryptionLevel.HIGH:
            max_access_count = secrets.randbelow(5) + 3  # 3-7 accesses
        else:
            max_access_count = secrets.randbelow(10) + 5  # 5-14 accesses
        
        encrypted_metadata = EncryptedMetadata(
            metadata_id=metadata_id,
            metadata_type=metadata_type,
            encrypted_data=encrypted_data,
            encryption_key_id=encryption_key.key_id,
            created_at=datetime.utcnow(),
            expires_at=expires_at,
            access_count=0,
            max_access_count=max_access_count,
            is_ephemeral=is_ephemeral
        )
        
        with self._lock:
            self.encrypted_metadata[metadata_id] = encrypted_metadata
            encryption_key.usage_count += 1
        
        self.performance_metrics['total_metadata_encrypted'] += 1
        
        return metadata_id
    
    async def _select_encryption_key(self, encryption_level: EncryptionLevel) -> Optional[EncryptionKey]:
        """Select an available encryption key."""
        
        current_time = datetime.utcnow()
        available_keys = []
        
        with self._lock:
            for key_data in self.encryption_keys.values():
                if (key_data.encryption_level == encryption_level and
                    current_time < key_data.expires_at and
                    key_data.usage_count < key_data.max_usage):
                    available_keys.append(key_data)
        
        if not available_keys:
            return None
        
        return min(available_keys, key=lambda k: k.usage_count)
    
    async def decrypt_metadata(self, metadata_id: str) -> Optional[Dict[str, Any]]:
        """Decrypt metadata (with access counting)."""
        
        with self._lock:
            if metadata_id not in self.encrypted_metadata:
                return None
            
            metadata = self.encrypted_metadata[metadata_id]
            
            current_time = datetime.utcnow()
            if (current_time > metadata.expires_at or 
                metadata.access_count >= metadata.max_access_count):
                asyncio.create_task(self._secure_delete_metadata(metadata_id))
                return None
            
            if metadata.encryption_key_id not in self.encryption_keys:
                return None
            
            encryption_key = self.encryption_keys[metadata.encryption_key_id]
            
            metadata.access_count += 1
        
        try:
            fernet = Fernet(encryption_key.key_data)
            decrypted_data = fernet.decrypt(metadata.encrypted_data)
            
            json_data = json.loads(decrypted_data.decode('utf-8'))
            
            self.metadata_access_log[metadata_id] = {
                'accessed_at': datetime.utcnow(),
                'access_count': metadata.access_count
            }
            
            return json_data
            
        except Exception as e:
            print(f"🔐 Decryption error for {metadata_id}: {str(e)}")
            return None
    
    async def _secure_delete_metadata(self, metadata_id: str):
        """Securely delete metadata."""
        
        with self._lock:
            if metadata_id in self.encrypted_metadata:
                metadata = self.encrypted_metadata[metadata_id]
                random_data = os.urandom(len(metadata.encrypted_data))
                metadata.encrypted_data = random_data
                
                del self.encrypted_metadata[metadata_id]
                
                self.performance_metrics['metadata_auto_destructed'] += 1
                print(f"🔥 Metadata {metadata_id} securely deleted")
    
    async def create_ephemeral_container(self, strategy_data: Dict[str, Any], 
                                       container_type: str,
                                       max_executions: int = 1,
                                       expiry_minutes: int = 5) -> str:
        """Create ephemeral container for short-lived strategies."""
        
        encryption_key = await self._select_encryption_key(EncryptionLevel.HIGH)
        if not encryption_key:
            raise Exception("No available encryption key for ephemeral container")
        
        fernet = Fernet(encryption_key.key_data)
        json_data = json.dumps(strategy_data, default=str).encode('utf-8')
        encrypted_strategy_data = fernet.encrypt(json_data)
        
        container_id = f"EPHEMERAL_{container_type.upper()}_{int(time.time() * 1000)}_{secrets.randbelow(9999):04d}"
        
        ephemeral_container = EphemeralContainer(
            container_id=container_id,
            container_type=container_type,
            encrypted_strategy_data=encrypted_strategy_data,
            encryption_key_id=encryption_key.key_id,
            created_at=datetime.utcnow(),
            expires_at=datetime.utcnow() + timedelta(minutes=expiry_minutes),
            execution_count=0,
            max_executions=max_executions,
            auto_destruct_triggers=['time_expiry', 'execution_limit', 'error_threshold']
        )
        
        with self._lock:
            self.ephemeral_containers[container_id] = ephemeral_container
            encryption_key.usage_count += 1
        
        self.performance_metrics['ephemeral_containers_created'] += 1
        
        return container_id
    
    async def execute_ephemeral_container(self, container_id: str) -> Optional[Dict[str, Any]]:
        """Execute ephemeral container strategy."""
        
        with self._lock:
            if container_id not in self.ephemeral_containers:
                return None
            
            container = self.ephemeral_containers[container_id]
            
            current_time = datetime.utcnow()
            if (current_time > container.expires_at or 
                container.execution_count >= container.max_executions):
                asyncio.create_task(self._secure_delete_container(container_id))
                return None
            
            if container.encryption_key_id not in self.encryption_keys:
                return None
            
            encryption_key = self.encryption_keys[container.encryption_key_id]
            
            container.execution_count += 1
        
        try:
            fernet = Fernet(encryption_key.key_data)
            decrypted_data = fernet.decrypt(container.encrypted_strategy_data)
            strategy_data = json.loads(decrypted_data.decode('utf-8'))
            
            return strategy_data
            
        except Exception as e:
            print(f"🔐 Ephemeral container execution error for {container_id}: {str(e)}")
            return None
    
    async def _secure_delete_container(self, container_id: str):
        """Securely delete ephemeral container."""
        
        with self._lock:
            if container_id in self.ephemeral_containers:
                container = self.ephemeral_containers[container_id]
                random_data = os.urandom(len(container.encrypted_strategy_data))
                container.encrypted_strategy_data = random_data
                
                del self.ephemeral_containers[container_id]
                
                print(f"🔥 Ephemeral container {container_id} securely deleted")
    
    async def generate_temporary_token(self, purpose: str, expiry_minutes: int = 5) -> str:
        """Generate temporary token with auto-destruction."""
        
        token = secrets.token_urlsafe(32)
        token_id = f"TOKEN_{purpose.upper()}_{int(time.time() * 1000)}_{secrets.randbelow(9999):04d}"
        
        token_data = {
            'token': token,
            'purpose': purpose,
            'created_at': datetime.utcnow(),
            'expires_at': datetime.utcnow() + timedelta(minutes=expiry_minutes),
            'usage_count': 0,
            'max_usage': 1  # Single use by default
        }
        
        with self._lock:
            self.temporary_tokens[token_id] = token_data
        
        self.performance_metrics['temporary_tokens_generated'] += 1
        
        return token
    
    async def validate_temporary_token(self, token: str) -> bool:
        """Validate and consume temporary token."""
        
        current_time = datetime.utcnow()
        
        with self._lock:
            for token_id, token_data in self.temporary_tokens.items():
                if (token_data['token'] == token and 
                    current_time <= token_data['expires_at'] and
                    token_data['usage_count'] < token_data['max_usage']):
                    
                    token_data['usage_count'] += 1
                    
                    if token_data['usage_count'] >= token_data['max_usage']:
                        del self.temporary_tokens[token_id]
                    
                    return True
        
        return False
    
    async def get_encryption_metrics(self) -> Dict[str, Any]:
        """Get encryption service metrics."""
        
        with self._lock:
            active_metadata_count = len(self.encrypted_metadata)
            active_containers_count = len(self.ephemeral_containers)
            active_tokens_count = len(self.temporary_tokens)
            active_keys_count = len(self.encryption_keys)
        
        return {
            'service_version': self.service_version,
            'total_metadata_encrypted': self.performance_metrics['total_metadata_encrypted'],
            'metadata_auto_destructed': self.performance_metrics['metadata_auto_destructed'],
            'keys_rotated': self.performance_metrics['keys_rotated'],
            'ephemeral_containers_created': self.performance_metrics['ephemeral_containers_created'],
            'temporary_tokens_generated': self.performance_metrics['temporary_tokens_generated'],
            'active_metadata_count': active_metadata_count,
            'active_containers_count': active_containers_count,
            'active_tokens_count': active_tokens_count,
            'active_keys_count': active_keys_count,
            'encryption_operations_per_second': self.performance_metrics['encryption_operations_per_second'],
            'auto_destruction_enabled': self.auto_destruction_enabled,
            'default_expiry_minutes': self.default_expiry_minutes,
            'last_updated': datetime.utcnow().isoformat()
        }
    
    async def activate_paranoia_encryption(self) -> Dict[str, Any]:
        """Activate maximum paranoia mode for encryption."""
        
        print("🔒 Activating Paranoia Mode - Maximum Metadata Encryption")
        
        self.default_expiry_minutes = 2
        self.paranoia_expiry_minutes = 1
        
        for _ in range(3):
            await self._generate_encryption_key(EncryptionLevel.PARANOIA)
        
        keys_to_rotate = list(self.encryption_keys.keys())
        for key_id in keys_to_rotate:
            key_data = self.encryption_keys[key_id]
            await self._rotate_encryption_key(key_id, key_data.encryption_level)
        
        return {
            'status': 'Paranoia Mode Metadata Encryption Activated',
            'default_expiry_minutes': self.default_expiry_minutes,
            'paranoia_expiry_minutes': self.paranoia_expiry_minutes,
            'encryption_keys': len(self.encryption_keys),
            'auto_destruction_interval': '10 seconds',
            'key_rotation_interval': '30 seconds',
            'max_access_count': '1-3 accesses',
            'secure_deletion': 'Enabled with random overwrite',
            'encryption_level': 'AES-256 with PBKDF2 (500k iterations)'
        }

metadata_encryption_service = MetadataEncryptionService()
