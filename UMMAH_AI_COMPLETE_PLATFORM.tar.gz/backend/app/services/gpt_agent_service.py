"""
GPT Agent Service - Custom AI Agent Management System

This module provides a comprehensive service for creating, managing, and
interacting with custom GPT-powered AI agents. It supports multiple agent
templates and allows for dynamic agent creation with customizable parameters.

The service includes:
- Predefined agent templates for different use cases
- Custom agent creation and management
- OpenAI GPT API integration for agent queries
- Agent performance tracking and monitoring
- Template-based agent configuration system
"""

import openai
import json
from typing import Dict, List, Optional, Any
from datetime import datetime
from pydantic import BaseModel
from app.core.config import settings

class AgentTemplate(BaseModel):
    """
    Template model for creating standardized AI agents.
    
    Attributes:
        name (str): Display name of the agent template
        type (str): Category/type of the agent (e.g., 'Trading AI', 'Security AI')
        description (str): Detailed description of agent capabilities
        system_prompt (str): System prompt that defines agent behavior
        capabilities (List[str]): List of agent capabilities/functions
        parameters (Dict[str, Any]): Configuration parameters for the agent
    """
    name: str
    type: str
    description: str
    system_prompt: str
    capabilities: List[str]
    parameters: Dict[str, Any]

class CustomAgent(BaseModel):
    """
    Custom AI agent instance with performance tracking.
    
    Attributes:
        id (str): Unique identifier for the agent
        name (str): Custom name assigned to the agent
        type (str): Agent type/category
        description (str): Agent description
        system_prompt (str): System prompt defining agent behavior
        capabilities (List[str]): List of agent capabilities
        parameters (Dict[str, Any]): Agent configuration parameters
        created_at (datetime): Timestamp when agent was created
        status (str): Current agent status ('active', 'inactive', etc.)
        performance (Dict[str, float]): Performance metrics and statistics
    """
    id: str
    name: str
    type: str
    description: str
    system_prompt: str
    capabilities: List[str]
    parameters: Dict[str, Any]
    created_at: datetime
    status: str = "inactive"
    performance: Dict[str, float] = {}

class GPTAgentService:
    """
    Service for managing custom GPT-powered AI agents.
    
    This service provides comprehensive functionality for creating, managing,
    and interacting with custom AI agents powered by OpenAI's GPT models.
    It supports template-based agent creation and real-time agent querying.
    
    Attributes:
        client (openai.OpenAI): OpenAI API client instance
        agents (Dict[str, CustomAgent]): Dictionary of active custom agents
        agent_templates (List[AgentTemplate]): Available agent templates
    """
    
    def __init__(self):
        """
        Initialize the GPT Agent Service.
        
        Sets up OpenAI client, initializes agent storage, and loads
        predefined agent templates for quick agent creation.
        """
        self.client = openai.OpenAI(api_key=settings.OPENAI_API_KEY if hasattr(settings, 'OPENAI_API_KEY') else None)
        self.agents: Dict[str, CustomAgent] = {}
        self.agent_templates = self._load_agent_templates()
    
    def _load_agent_templates(self) -> List[AgentTemplate]:
        """
        Load predefined agent templates for quick agent creation.
        
        Creates a set of standardized agent templates including Trading Analyst,
        Security Monitor, Market Predictor, and Execution Optimizer agents.
        Each template includes optimized system prompts and capabilities.
        
        Returns:
            List[AgentTemplate]: List of available agent templates
        """
        return [
            AgentTemplate(
                name="Trading Analyst",
                type="Trading AI",
                description="Analyzes market trends and provides trading insights",
                system_prompt="You are a professional trading analyst AI. Analyze market data, identify trends, and provide actionable trading insights. Focus on risk management and data-driven decisions.",
                capabilities=["market_analysis", "trend_detection", "risk_assessment", "signal_generation"],
                parameters={"model": "gpt-4", "temperature": 0.3, "max_tokens": 1000}
            ),
            AgentTemplate(
                name="Security Monitor",
                type="Security AI",
                description="Monitors system security and detects threats",
                system_prompt="You are a cybersecurity AI specialist. Monitor network traffic, detect anomalies, and identify potential security threats. Provide detailed security assessments and recommendations.",
                capabilities=["threat_detection", "anomaly_analysis", "security_assessment", "incident_response"],
                parameters={"model": "gpt-4", "temperature": 0.2, "max_tokens": 800}
            ),
            AgentTemplate(
                name="Market Predictor",
                type="Prediction AI",
                description="Predicts market movements using AI analysis",
                system_prompt="You are a market prediction AI. Use historical data, technical indicators, and market sentiment to predict future price movements. Provide probability-based forecasts.",
                capabilities=["price_prediction", "sentiment_analysis", "technical_analysis", "probability_modeling"],
                parameters={"model": "gpt-4", "temperature": 0.4, "max_tokens": 1200}
            ),
            AgentTemplate(
                name="Execution Optimizer",
                type="Execution AI",
                description="Optimizes trade execution strategies",
                system_prompt="You are a trade execution optimization AI. Analyze market conditions, liquidity, and timing to optimize trade execution. Minimize slippage and market impact.",
                capabilities=["execution_optimization", "liquidity_analysis", "timing_optimization", "slippage_reduction"],
                parameters={"model": "gpt-4", "temperature": 0.1, "max_tokens": 600}
            )
        ]
    
    def get_agent_templates(self) -> List[Dict[str, Any]]:
        """
        Get all available agent templates.
        
        Returns:
            List[Dict[str, Any]]: List of agent templates as dictionaries
        """
        return [template.dict() for template in self.agent_templates]
    
    async def create_custom_agent(self, template_name: str, custom_name: str, custom_parameters: Optional[Dict[str, Any]] = None) -> CustomAgent:
        """
        Create a custom agent from a predefined template.
        
        Args:
            template_name (str): Name of the template to use
            custom_name (str): Custom name for the new agent
            custom_parameters (Optional[Dict[str, Any]]): Custom parameters to override template defaults
            
        Returns:
            CustomAgent: The newly created custom agent instance
            
        Raises:
            ValueError: If the specified template is not found
        """
        template = next((t for t in self.agent_templates if t.name == template_name), None)
        if not template:
            raise ValueError(f"Template '{template_name}' not found")
        
        agent_id = f"agent_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{len(self.agents)}"
        
        parameters = template.parameters.copy()
        if custom_parameters:
            parameters.update(custom_parameters)
        
        agent = CustomAgent(
            id=agent_id,
            name=custom_name,
            type=template.type,
            description=template.description,
            system_prompt=template.system_prompt,
            capabilities=template.capabilities,
            parameters=parameters,
            created_at=datetime.now(),
            status="active",
            performance={
                "uptime": 0,
                "tasks_completed": 0,
                "success_rate": 100.0,
                "avg_response_time": 0
            }
        )
        
        self.agents[agent_id] = agent
        return agent
    
    async def query_agent(self, agent_id: str, query: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Query a custom agent using the OpenAI GPT API.
        
        Sends a query to the specified agent and returns the AI-generated response.
        Includes context handling and performance tracking.
        
        Args:
            agent_id (str): Unique identifier of the agent to query
            query (str): The query/question to send to the agent
            context (Optional[Dict[str, Any]]): Additional context for the query
            
        Returns:
            Dict[str, Any]: Response containing:
                - response: The AI-generated response text
                - agent_id: ID of the responding agent
                - timestamp: Response timestamp
                - tokens_used: Number of tokens consumed
                - model: GPT model used for the response
                
        Raises:
            ValueError: If the specified agent is not found
        """
        if agent_id not in self.agents:
            raise ValueError(f"Agent '{agent_id}' not found")
        
        agent = self.agents[agent_id]
        
        if not self.client.api_key:
            return {
                "response": f"Mock response from {agent.name}: This is a simulated response for query '{query[:50]}...'",
                "agent_id": agent_id,
                "timestamp": datetime.now().isoformat(),
                "tokens_used": 150,
                "model": agent.parameters.get("model", "gpt-4")
            }
        
        try:
            messages = [
                {"role": "system", "content": agent.system_prompt}
            ]
            
            if context:
                context_str = json.dumps(context, indent=2)
                messages.append({"role": "user", "content": f"Context: {context_str}"})
            
            messages.append({"role": "user", "content": query})
            
            response = await self.client.chat.completions.create(
                model=agent.parameters.get("model", "gpt-4"),
                messages=messages,
                temperature=agent.parameters.get("temperature", 0.3),
                max_tokens=agent.parameters.get("max_tokens", 1000)
            )
            
            self.agents[agent_id].performance["tasks_completed"] += 1
            
            return {
                "response": response.choices[0].message.content,
                "agent_id": agent_id,
                "timestamp": datetime.now().isoformat(),
                "tokens_used": response.usage.total_tokens,
                "model": response.model
            }
            
        except Exception as e:
            return {
                "error": str(e),
                "agent_id": agent_id,
                "timestamp": datetime.now().isoformat()
            }
    
    def get_agent(self, agent_id: str) -> Optional[CustomAgent]:
        """Get agent by ID"""
        return self.agents.get(agent_id)
    
    def list_agents(self) -> List[CustomAgent]:
        """List all custom agents"""
        return list(self.agents.values())
    
    def delete_agent(self, agent_id: str) -> bool:
        """Delete a custom agent"""
        if agent_id in self.agents:
            del self.agents[agent_id]
            return True
        return False
    
    def update_agent_status(self, agent_id: str, status: str) -> bool:
        """Update agent status"""
        if agent_id in self.agents:
            self.agents[agent_id].status = status
            return True
        return False

gpt_agent_service = GPTAgentService()
