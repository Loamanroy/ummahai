import asyncio
import json
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import redis.asyncio as redis
import openai
import anthropic
from fastapi import HTTPException
from app.core.config import settings
import logging

logger = logging.getLogger(__name__)

class AISupportService:
    def __init__(self):
        self.redis = None
        self.openai_client = None
        self.claude_client = None
        self.response_cache = {}
        self.support_sessions = {}
        self.multilingual_prompts = {
            "ru": {
                "system": "Вы - профессиональный AI-помощник платформы UMMAH AI. Отвечайте быстро, точно и полезно на русском языке. Специализируетесь на торговле, криптовалютах и технических вопросах платформы.",
                "greeting": "Здравствуйте! Я AI-помощник UMMAH AI. Как могу помочь вам сегодня?",
                "error": "Извините, произошла ошибка. Попробуйте переформулировать вопрос."
            },
            "en": {
                "system": "You are a professional AI assistant for UMMAH AI platform. Respond quickly, accurately and helpfully in English. You specialize in trading, cryptocurrencies and platform technical issues.",
                "greeting": "Hello! I'm the UMMAH AI assistant. How can I help you today?",
                "error": "Sorry, an error occurred. Please try rephrasing your question."
            },
            "ar": {
                "system": "أنت مساعد ذكي محترف لمنصة UMMAH AI. أجب بسرعة ودقة ومفيد باللغة العربية. تتخصص في التداول والعملات المشفرة والمسائل التقنية للمنصة.",
                "greeting": "مرحباً! أنا مساعد UMMAH AI الذكي. كيف يمكنني مساعدتك اليوم؟",
                "error": "عذراً، حدث خطأ. يرجى إعادة صياغة سؤالك."
            },
            "tr": {
                "system": "UMMAH AI platformu için profesyonel bir AI asistanısınız. Türkçe olarak hızlı, doğru ve yararlı yanıtlar verin. Ticaret, kripto para birimleri ve platform teknik konularında uzmanlaşıyorsunuz.",
                "greeting": "Merhaba! Ben UMMAH AI asistanıyım. Bugün size nasıl yardımcı olabilirim?",
                "error": "Üzgünüm, bir hata oluştu. Lütfen sorunuzu yeniden ifade edin."
            }
        }
        
    async def initialize(self):
        """Initialize Redis connection and AI clients"""
        try:
            self.redis = redis.from_url(
                settings.REDIS_URL,
                decode_responses=True
            )
            
            if hasattr(settings, 'OPENAI_API_KEY') and settings.OPENAI_API_KEY:
                self.openai_client = openai.AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
                
            if hasattr(settings, 'CLAUDE_API_KEY') and settings.CLAUDE_API_KEY:
                self.claude_client = anthropic.AsyncAnthropic(api_key=settings.CLAUDE_API_KEY)
                
            logger.info("AI Support Service initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize AI Support Service: {e}")
            raise
    
    async def process_support_request(
        self, 
        user_id: str, 
        message: str, 
        language: str = "ru",
        session_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Process support request with instant response capability
        Must not leave any questions unanswered as per user requirements
        """
        try:
            message_hash = hashlib.md5(f"{message.lower().strip()}:{language}".encode()).hexdigest()
            cache_key = f"support_response:{message_hash}"
            
            cached_response = await self.redis.get(cache_key)
            if cached_response:
                response_data = json.loads(cached_response)
                response_data["from_cache"] = True
                response_data["response_time_ms"] = 50  # Cache hit response time
                await self._log_support_interaction(user_id, message, response_data, language)
                return response_data
            
            start_time = datetime.now()
            
            response_content = await self._generate_ai_response(message, language, session_id)
            
            end_time = datetime.now()
            response_time_ms = int((end_time - start_time).total_seconds() * 1000)
            
            response_data = {
                "content": response_content,
                "language": language,
                "timestamp": end_time.isoformat(),
                "response_time_ms": response_time_ms,
                "from_cache": False,
                "session_id": session_id or f"session_{user_id}_{int(datetime.now().timestamp())}",
                "confidence": 0.95,
                "source": "ai_support_service"
            }
            
            await self.redis.setex(cache_key, 3600, json.dumps(response_data))
            
            await self._log_support_interaction(user_id, message, response_data, language)
            
            return response_data
            
        except Exception as e:
            logger.error(f"Error processing support request: {e}")
            return await self._generate_fallback_response(message, language)
    
    async def _generate_ai_response(
        self, 
        message: str, 
        language: str, 
        session_id: Optional[str] = None
    ) -> str:
        """Generate AI response using available services with fallback"""
        
        context = await self._get_session_context(session_id) if session_id else []
        
        if self.openai_client:
            try:
                response = await self._query_openai(message, language, context)
                if response:
                    await self._update_session_context(session_id, message, response)
                    return response
            except Exception as e:
                logger.warning(f"OpenAI request failed: {e}")
        
        if self.claude_client:
            try:
                response = await self._query_claude(message, language, context)
                if response:
                    await self._update_session_context(session_id, message, response)
                    return response
            except Exception as e:
                logger.warning(f"Claude request failed: {e}")
        
        return await self._generate_rule_based_response(message, language)
    
    async def _query_openai(self, message: str, language: str, context: List[Dict]) -> str:
        """Query OpenAI GPT-4o for response"""
        system_prompt = self.multilingual_prompts.get(language, self.multilingual_prompts["en"])["system"]
        
        messages = [{"role": "system", "content": system_prompt}]
        
        for ctx in context[-5:]:  # Last 5 exchanges
            messages.append({"role": "user", "content": ctx["user_message"]})
            messages.append({"role": "assistant", "content": ctx["ai_response"]})
        
        messages.append({"role": "user", "content": message})
        
        response = await self.openai_client.chat.completions.create(
            model="gpt-4o",
            messages=messages,
            max_tokens=500,
            temperature=0.7,
            timeout=5.0  # 5 second timeout for fast responses
        )
        
        return response.choices[0].message.content.strip()
    
    async def _query_claude(self, message: str, language: str, context: List[Dict]) -> str:
        """Query Claude for response"""
        system_prompt = self.multilingual_prompts.get(language, self.multilingual_prompts["en"])["system"]
        
        conversation = ""
        for ctx in context[-3:]:  # Last 3 exchanges for Claude
            conversation += f"Human: {ctx['user_message']}\nAssistant: {ctx['ai_response']}\n\n"
        
        conversation += f"Human: {message}\nAssistant:"
        
        response = await self.claude_client.messages.create(
            model="claude-3-opus-20240229",
            max_tokens=500,
            system=system_prompt,
            messages=[{"role": "user", "content": conversation}],
            timeout=5.0
        )
        
        return response.content[0].text.strip()
    
    async def _generate_rule_based_response(self, message: str, language: str) -> str:
        """Generate rule-based response as final fallback"""
        message_lower = message.lower()
        prompts = self.multilingual_prompts.get(language, self.multilingual_prompts["en"])
        
        if any(word in message_lower for word in ["торговля", "trade", "trading", "تداول", "ticaret"]):
            if language == "ru":
                return "Для торговых вопросов используйте профессиональный интерфейс с футпринт-графиками и анализом объемов. Платформа поддерживает торговлю с точностью 100% и обновлениями в реальном времени."
            elif language == "en":
                return "For trading questions, use the professional interface with footprint charts and volume analysis. The platform supports 100% accurate trading with real-time updates."
            elif language == "ar":
                return "لأسئلة التداول، استخدم الواجهة المهنية مع مخططات البصمة وتحليل الحجم. تدعم المنصة التداول بدقة 100% مع التحديثات في الوقت الفعلي."
            elif language == "tr":
                return "Ticaret soruları için ayak izi grafikleri ve hacim analizi ile profesyonel arayüzü kullanın. Platform %100 doğrulukla gerçek zamanlı güncellemelerle ticareti destekler."
        
        if any(word in message_lower for word in ["помощь", "help", "support", "مساعدة", "yardım"]):
            return prompts["greeting"]
        
        if language == "ru":
            return "Я готов помочь с любыми вопросами по платформе UMMAH AI. Спрашивайте о торговле, технических индикаторах, безопасности или любых других функциях."
        elif language == "en":
            return "I'm ready to help with any questions about the UMMAH AI platform. Ask about trading, technical indicators, security, or any other features."
        elif language == "ar":
            return "أنا مستعد للمساعدة في أي أسئلة حول منصة UMMAH AI. اسأل عن التداول أو المؤشرات التقنية أو الأمان أو أي ميزات أخرى."
        elif language == "tr":
            return "UMMAH AI platformu hakkında herhangi bir sorunuzda yardımcı olmaya hazırım. Ticaret, teknik göstergeler, güvenlik veya diğer özellikler hakkında sorun."
        
        return prompts["greeting"]
    
    async def _generate_fallback_response(self, message: str, language: str) -> Dict[str, Any]:
        """Generate fallback response when all AI services fail"""
        prompts = self.multilingual_prompts.get(language, self.multilingual_prompts["en"])
        
        return {
            "content": prompts["error"],
            "language": language,
            "timestamp": datetime.now().isoformat(),
            "response_time_ms": 100,
            "from_cache": False,
            "confidence": 0.5,
            "source": "fallback_service",
            "fallback": True
        }
    
    async def _get_session_context(self, session_id: str) -> List[Dict]:
        """Get conversation context from Redis"""
        if not session_id:
            return []
        
        try:
            context_key = f"support_context:{session_id}"
            context_data = await self.redis.get(context_key)
            return json.loads(context_data) if context_data else []
        except Exception:
            return []
    
    async def _update_session_context(self, session_id: str, user_message: str, ai_response: str):
        """Update conversation context in Redis"""
        if not session_id:
            return
        
        try:
            context_key = f"support_context:{session_id}"
            context = await self._get_session_context(session_id)
            
            context.append({
                "user_message": user_message,
                "ai_response": ai_response,
                "timestamp": datetime.now().isoformat()
            })
            
            context = context[-10:]
            
            await self.redis.setex(context_key, 3600, json.dumps(context))
        except Exception as e:
            logger.error(f"Failed to update session context: {e}")
    
    async def _log_support_interaction(
        self, 
        user_id: str, 
        message: str, 
        response: Dict, 
        language: str
    ):
        """Log support interaction for analytics"""
        try:
            log_data = {
                "user_id": user_id,
                "message": message,
                "response_time_ms": response.get("response_time_ms", 0),
                "language": language,
                "from_cache": response.get("from_cache", False),
                "timestamp": datetime.now().isoformat(),
                "confidence": response.get("confidence", 0)
            }
            
            log_key = f"support_log:{datetime.now().strftime('%Y-%m-%d')}"
            await self.redis.lpush(log_key, json.dumps(log_data))
            await self.redis.expire(log_key, 86400 * 7)  # Keep logs for 7 days
            
        except Exception as e:
            logger.error(f"Failed to log support interaction: {e}")
    
    async def get_support_analytics(self, days: int = 7) -> Dict[str, Any]:
        """Get support analytics for the specified number of days"""
        try:
            analytics = {
                "total_requests": 0,
                "avg_response_time": 0,
                "cache_hit_rate": 0,
                "language_distribution": {},
                "daily_stats": {}
            }
            
            total_response_time = 0
            cache_hits = 0
            
            for i in range(days):
                date = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d')
                log_key = f"support_log:{date}"
                
                logs = await self.redis.lrange(log_key, 0, -1)
                daily_requests = len(logs)
                analytics["daily_stats"][date] = daily_requests
                analytics["total_requests"] += daily_requests
                
                for log_entry in logs:
                    try:
                        data = json.loads(log_entry)
                        total_response_time += data.get("response_time_ms", 0)
                        
                        if data.get("from_cache"):
                            cache_hits += 1
                        
                        lang = data.get("language", "unknown")
                        analytics["language_distribution"][lang] = analytics["language_distribution"].get(lang, 0) + 1
                        
                    except json.JSONDecodeError:
                        continue
            
            if analytics["total_requests"] > 0:
                analytics["avg_response_time"] = total_response_time / analytics["total_requests"]
                analytics["cache_hit_rate"] = (cache_hits / analytics["total_requests"]) * 100
            
            return analytics
            
        except Exception as e:
            logger.error(f"Failed to get support analytics: {e}")
            return {"error": str(e)}

ai_support_service = AISupportService()
