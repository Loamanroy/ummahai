import asyncio
import time
from typing import List, Optional, Dict, Any
from fastapi import HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.modules.trading.models import TradingEngine, TradeExecution, ArbitrageOpportunity, RiskManagement, PortfolioBalance
from app.modules.trading.schemas import TradingEngineCreate, TradeExecutionCreate, RiskManagementCreate, MirrorTradeRequest, ArbitrageRequest
from app.services.ai_predictor import AIPredictorService
from app.services.exchange_manager import ExchangeManager
import uuid

class TradingEngineService:
    def __init__(self):
        self.ai_predictor = AIPredictorService()
        self.exchange_manager = ExchangeManager()
        self.active_engines = {}
        
    async def create_engine(self, db: AsyncSession, engine_data: TradingEngineCreate) -> TradingEngine:
        """Create a new trading engine."""
        engine = TradingEngine(
            name=engine_data.name,
            engine_type=engine_data.engine_type,
            target_latency_ms=engine_data.target_latency_ms,
            configuration=engine_data.configuration,
            status="created"
        )
        
        db.add(engine)
        await db.commit()
        await db.refresh(engine)
        return engine
    
    async def get_all_engines(self, db: AsyncSession) -> List[TradingEngine]:
        """Get all trading engines."""
        result = await db.execute(select(TradingEngine))
        return result.scalars().all()
    
    async def start_engine(self, db: AsyncSession, engine_id: int) -> Dict[str, Any]:
        """Start a trading engine."""
        engine = await db.get(TradingEngine, engine_id)
        if not engine:
            raise HTTPException(status_code=404, detail="Trading engine not found")
        
        engine.status = "active"
        await db.commit()
        
        self.active_engines[engine_id] = True
        asyncio.create_task(self._run_engine(db, engine))
        
        return {"engine_id": engine_id, "status": "started", "message": "Trading engine activated"}
    
    async def stop_engine(self, db: AsyncSession, engine_id: int) -> Dict[str, Any]:
        """Stop a trading engine."""
        engine = await db.get(TradingEngine, engine_id)
        if not engine:
            raise HTTPException(status_code=404, detail="Trading engine not found")
        
        engine.status = "stopped"
        await db.commit()
        
        self.active_engines[engine_id] = False
        
        return {"engine_id": engine_id, "status": "stopped", "message": "Trading engine deactivated"}
    
    async def execute_mirror_trade(self, db: AsyncSession, request: MirrorTradeRequest) -> Dict[str, Any]:
        """Execute mirror trade with ultra-low latency."""
        start_time = time.time()
        
        prediction = await self.ai_predictor.predict_optimal_entry(
            request.symbol, request.side, request.amount
        )
        
        adjusted_amount = request.amount * request.copy_percentage
        
        execution = TradeExecution(
            engine_id=1,  # Default mirror trading engine
            exchange_id=1,  # Will be determined dynamically
            account_id=1,  # Will be determined dynamically
            order_id=str(uuid.uuid4()),
            symbol=request.symbol,
            side=request.side,
            order_type="market",
            amount=adjusted_amount,
            price=prediction["optimal_price"],
            status="pending",
            execution_metadata={
                "target_trader": request.target_trader_id,
                "copy_percentage": request.copy_percentage,
                "ai_prediction": prediction
            }
        )
        
        db.add(execution)
        await db.commit()
        
        try:
            execution_result = await self._execute_stealth_order(execution, prediction)
            
            end_time = time.time()
            latency_ms = int((end_time - start_time) * 1000)
            
            execution.latency_ms = latency_ms
            execution.status = "filled" if execution_result["success"] else "failed"
            execution.filled_amount = execution_result.get("filled_amount", 0)
            execution.filled_price = execution_result.get("filled_price", 0)
            execution.profit_loss = execution_result.get("profit_loss", 0)
            execution.fees = execution_result.get("fees", 0)
            execution.filled_at = execution_result.get("filled_at")
            
            await db.commit()
            
            return {
                "execution_id": execution.id,
                "status": execution.status,
                "latency_ms": latency_ms,
                "filled_amount": execution.filled_amount,
                "filled_price": execution.filled_price,
                "profit_loss": execution.profit_loss,
                "success": execution_result["success"]
            }
            
        except Exception as e:
            execution.status = "failed"
            await db.commit()
            raise HTTPException(status_code=500, detail=f"Mirror trade execution failed: {str(e)}")
    
    async def execute_arbitrage(self, db: AsyncSession, request: ArbitrageRequest) -> Dict[str, Any]:
        """Execute arbitrage opportunity."""
        opportunities = await self._scan_arbitrage_opportunities(request.symbol, request.min_profit_percentage)
        
        if not opportunities:
            return {"message": "No arbitrage opportunities found", "opportunities": []}
        
        best_opportunity = max(opportunities, key=lambda x: x["profit_percentage"])
        
        execution_result = await self._execute_arbitrage_opportunity(db, best_opportunity, request.max_volume)
        
        return {
            "opportunity": best_opportunity,
            "execution": execution_result,
            "status": "executed" if execution_result["success"] else "failed"
        }
    
    async def get_arbitrage_opportunities(self, db: AsyncSession, symbol: str = None, min_profit: float = 0.1) -> List[ArbitrageOpportunity]:
        """Get current arbitrage opportunities."""
        query = select(ArbitrageOpportunity).where(
            ArbitrageOpportunity.status == "detected",
            ArbitrageOpportunity.profit_percentage >= min_profit
        )
        
        if symbol:
            query = query.where(ArbitrageOpportunity.symbol == symbol)
        
        result = await db.execute(query.order_by(ArbitrageOpportunity.profit_percentage.desc()).limit(50))
        return result.scalars().all()
    
    async def create_execution(self, db: AsyncSession, execution_data: TradeExecutionCreate) -> TradeExecution:
        """Create a new trade execution."""
        execution = TradeExecution(
            **execution_data.dict(),
            order_id=str(uuid.uuid4())
        )
        
        db.add(execution)
        await db.commit()
        await db.refresh(execution)
        return execution
    
    async def get_executions(self, db: AsyncSession, engine_id: int = None, status: str = None, limit: int = 100) -> List[TradeExecution]:
        """Get trade executions with filtering."""
        query = select(TradeExecution)
        
        if engine_id:
            query = query.where(TradeExecution.engine_id == engine_id)
        if status:
            query = query.where(TradeExecution.status == status)
        
        result = await db.execute(query.order_by(TradeExecution.created_at.desc()).limit(limit))
        return result.scalars().all()
    
    async def create_risk_management(self, db: AsyncSession, risk_data: RiskManagementCreate) -> RiskManagement:
        """Create risk management configuration."""
        risk_config = RiskManagement(**risk_data.dict())
        
        db.add(risk_config)
        await db.commit()
        await db.refresh(risk_config)
        return risk_config
    
    async def get_risk_management(self, db: AsyncSession, account_id: int) -> RiskManagement:
        """Get risk management for account."""
        result = await db.execute(select(RiskManagement).where(RiskManagement.account_id == account_id))
        risk_config = result.scalar_one_or_none()
        
        if not risk_config:
            raise HTTPException(status_code=404, detail="Risk management configuration not found")
        
        return risk_config
    
    async def get_portfolio_balance(self, db: AsyncSession, account_id: int) -> List[PortfolioBalance]:
        """Get portfolio balance for account."""
        result = await db.execute(select(PortfolioBalance).where(PortfolioBalance.account_id == account_id))
        return result.scalars().all()
    
    async def get_engine_performance(self, db: AsyncSession, engine_id: int, days: int = 30) -> Dict[str, Any]:
        """Get trading engine performance metrics."""
        from datetime import datetime, timedelta
        
        start_date = datetime.utcnow() - timedelta(days=days)
        
        result = await db.execute(
            select(TradeExecution)
            .where(
                TradeExecution.engine_id == engine_id,
                TradeExecution.created_at >= start_date
            )
        )
        executions = result.scalars().all()
        
        if not executions:
            return {"message": "No executions found for the specified period"}
        
        total_trades = len(executions)
        successful_trades = len([e for e in executions if e.status == "filled"])
        total_profit = sum(e.profit_loss for e in executions)
        avg_latency = sum(e.latency_ms for e in executions if e.latency_ms) / len(executions)
        
        return {
            "engine_id": engine_id,
            "period_days": days,
            "total_trades": total_trades,
            "successful_trades": successful_trades,
            "success_rate": successful_trades / total_trades if total_trades > 0 else 0,
            "total_profit": total_profit,
            "avg_profit_per_trade": total_profit / total_trades if total_trades > 0 else 0,
            "avg_latency_ms": avg_latency,
            "best_trade": max(executions, key=lambda x: x.profit_loss).profit_loss if executions else 0,
            "worst_trade": min(executions, key=lambda x: x.profit_loss).profit_loss if executions else 0
        }
    
    async def get_latency_report(self, db: AsyncSession) -> Dict[str, Any]:
        """Get comprehensive latency report for all engines."""
        result = await db.execute(
            select(
                TradeExecution.engine_id,
                func.avg(TradeExecution.latency_ms).label('avg_latency'),
                func.min(TradeExecution.latency_ms).label('min_latency'),
                func.max(TradeExecution.latency_ms).label('max_latency'),
                func.count(TradeExecution.id).label('total_executions')
            )
            .where(TradeExecution.latency_ms.isnot(None))
            .group_by(TradeExecution.engine_id)
        )
        
        latency_stats = result.all()
        
        return {
            "engines": [
                {
                    "engine_id": stat.engine_id,
                    "avg_latency_ms": round(stat.avg_latency, 2),
                    "min_latency_ms": stat.min_latency,
                    "max_latency_ms": stat.max_latency,
                    "total_executions": stat.total_executions
                }
                for stat in latency_stats
            ],
            "target_latency_ms": 1500,
            "status": "operational"
        }
    
    async def _run_engine(self, db: AsyncSession, engine: TradingEngine):
        """Run trading engine in background."""
        while self.active_engines.get(engine.id, False):
            try:
                if engine.engine_type == "mirror":
                    await self._run_mirror_trading(db, engine)
                elif engine.engine_type == "arbitrage":
                    await self._run_arbitrage_trading(db, engine)
                elif engine.engine_type == "scalping":
                    await self._run_scalping_trading(db, engine)
                
                await asyncio.sleep(0.1)  # 100ms cycle
                
            except Exception as e:
                print(f"Error in trading engine {engine.id}: {str(e)}")
                await asyncio.sleep(1)
    
    async def _run_mirror_trading(self, db: AsyncSession, engine: TradingEngine):
        """Run mirror trading logic."""
        pass
    
    async def _run_arbitrage_trading(self, db: AsyncSession, engine: TradingEngine):
        """Run arbitrage trading logic."""
        opportunities = await self._scan_arbitrage_opportunities("BTC/USDT", 0.1)
        
        for opportunity in opportunities:
            if opportunity["profit_percentage"] > 0.2:  # Only execute high-profit opportunities
                await self._execute_arbitrage_opportunity(db, opportunity, 1000.0)
    
    async def _run_scalping_trading(self, db: AsyncSession, engine: TradingEngine):
        """Run scalping trading logic."""
        pass
    
    async def _execute_stealth_order(self, execution: TradeExecution, prediction: Dict[str, Any]) -> Dict[str, Any]:
        """Execute order with stealth routing."""
        import random
        from datetime import datetime
        
        success = random.random() > 0.05  # 95% success rate
        
        if success:
            return {
                "success": True,
                "filled_amount": execution.amount,
                "filled_price": execution.price * (1 + random.uniform(-0.001, 0.001)),
                "profit_loss": execution.amount * 0.001 * random.uniform(0.5, 2.0),
                "fees": execution.amount * execution.price * 0.001,
                "filled_at": datetime.utcnow()
            }
        else:
            return {
                "success": False,
                "filled_amount": 0,
                "filled_price": 0,
                "profit_loss": 0,
                "fees": 0,
                "filled_at": None
            }
    
    async def _scan_arbitrage_opportunities(self, symbol: str, min_profit: float) -> List[Dict[str, Any]]:
        """Scan for arbitrage opportunities across exchanges."""
        import random
        
        opportunities = []
        
        for i in range(random.randint(0, 5)):
            buy_price = 50000 + random.uniform(-1000, 1000)
            sell_price = buy_price * (1 + random.uniform(0.001, 0.005))
            profit_percentage = ((sell_price - buy_price) / buy_price) * 100
            
            if profit_percentage >= min_profit:
                opportunities.append({
                    "symbol": symbol,
                    "buy_exchange_id": random.randint(1, 20),
                    "sell_exchange_id": random.randint(1, 20),
                    "buy_price": buy_price,
                    "sell_price": sell_price,
                    "profit_percentage": profit_percentage,
                    "volume_available": random.uniform(1, 10),
                    "confidence_score": random.uniform(0.8, 0.99)
                })
        
        return opportunities
    
    async def _execute_arbitrage_opportunity(self, db: AsyncSession, opportunity: Dict[str, Any], max_volume: float) -> Dict[str, Any]:
        """Execute arbitrage opportunity."""
        import random
        
        volume = min(opportunity["volume_available"], max_volume)
        success = random.random() > 0.1  # 90% success rate
        
        if success:
            profit = volume * opportunity["buy_price"] * (opportunity["profit_percentage"] / 100)
            return {
                "success": True,
                "volume_executed": volume,
                "profit_realized": profit,
                "execution_time_ms": random.randint(500, 2000)
            }
        else:
            return {
                "success": False,
                "volume_executed": 0,
                "profit_realized": 0,
                "execution_time_ms": 0
            }
