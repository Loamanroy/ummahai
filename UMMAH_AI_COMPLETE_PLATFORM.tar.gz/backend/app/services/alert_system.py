import asyncio
import logging
import os
import json
from typing import Dict, Any, List, Optional
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import httpx
import paho.mqtt.client as mqtt

logger = logging.getLogger(__name__)

class AlertSystem:
    """
    Alert System - Handles email, SMS, and MQTT notifications for threat detection
    Система оповещений для обнаружения угроз и аномалий
    """
    
    def __init__(self):
        self.email_config = {
            "smtp_server": os.getenv("SMTP_SERVER", "smtp.gmail.com"),
            "smtp_port": int(os.getenv("SMTP_PORT", "587")),
            "email_user": os.getenv("EMAIL_USER", ""),
            "email_password": os.getenv("EMAIL_PASSWORD", ""),
            "from_email": os.getenv("FROM_EMAIL", "alerts@ummah-ai.com")
        }
        
        self.sms_config = {
            "provider": os.getenv("SMS_PROVIDER", "twilio"),
            "api_key": os.getenv("SMS_API_KEY", ""),
            "api_secret": os.getenv("SMS_API_SECRET", ""),
            "from_number": os.getenv("SMS_FROM_NUMBER", "")
        }
        
        self.mqtt_config = {
            "broker": os.getenv("MQTT_BROKER", "localhost"),
            "port": int(os.getenv("MQTT_PORT", "1883")),
            "username": os.getenv("MQTT_USERNAME", ""),
            "password": os.getenv("MQTT_PASSWORD", ""),
            "topic_prefix": os.getenv("MQTT_TOPIC_PREFIX", "ummah")
        }
        
        self.mqtt_client = None
        self.alert_history = []
        self.threat_threshold = float(os.getenv("THREAT_THRESHOLD", "1.5"))
        
    async def initialize_mqtt(self):
        """Initialize MQTT client for real-time alerts"""
        try:
            self.mqtt_client = mqtt.Client()
            
            if self.mqtt_config["username"]:
                self.mqtt_client.username_pw_set(
                    self.mqtt_config["username"], 
                    self.mqtt_config["password"]
                )
            
            self.mqtt_client.on_connect = self._on_mqtt_connect
            self.mqtt_client.on_disconnect = self._on_mqtt_disconnect
            
            self.mqtt_client.connect(
                self.mqtt_config["broker"], 
                self.mqtt_config["port"], 
                60
            )
            
            self.mqtt_client.loop_start()
            logger.info("📡 MQTT client initialized")
            
        except Exception as e:
            logger.error(f"❌ MQTT initialization failed: {e}")
    
    def _on_mqtt_connect(self, client, userdata, flags, rc):
        """MQTT connection callback"""
        if rc == 0:
            logger.info("📡 MQTT connected successfully")
        else:
            logger.error(f"❌ MQTT connection failed with code {rc}")
    
    def _on_mqtt_disconnect(self, client, userdata, rc):
        """MQTT disconnection callback"""
        logger.warning("📡 MQTT disconnected")
    
    async def process_threat(self, data: Dict[str, Any]):
        """Process threat data and trigger appropriate alerts"""
        try:
            threat_level = self._calculate_threat_level(data)
            
            if threat_level >= self.threat_threshold:
                alert_message = self._format_alert_message(data, threat_level)
                
                await self._send_email_alert(alert_message, data)
                await self._send_sms_alert(alert_message, data)
                await self._send_mqtt_alert(alert_message, data)
                
                self.alert_history.append({
                    "timestamp": asyncio.get_event_loop().time(),
                    "threat_level": threat_level,
                    "data": data,
                    "message": alert_message
                })
                
                if len(self.alert_history) > 100:
                    self.alert_history = self.alert_history[-100:]
                
                logger.warning(f"🚨 Threat alert sent: {alert_message}")
            
        except Exception as e:
            logger.error(f"❌ Threat processing failed: {e}")
    
    def _calculate_threat_level(self, data: Dict[str, Any]) -> float:
        """Calculate threat level based on data characteristics"""
        try:
            threat_level = 0.0
            
            quantity = float(data.get("q", 0))
            if quantity > 2.0:
                threat_level += 2.0
            elif quantity > 1.5:
                threat_level += 1.5
            elif quantity > 1.0:
                threat_level += 1.0
            
            if data.get("anomaly", False):
                threat_level += 1.0
            
            exchange = data.get("exchange", "").lower()
            high_risk_exchanges = ["unknown", "suspicious", "unverified"]
            if exchange in high_risk_exchanges:
                threat_level += 0.5
            
            latency = float(data.get("latency", 0))
            if latency > 1000:  # High latency might indicate proxy/VPN
                threat_level += 0.3
            
            return threat_level
            
        except Exception as e:
            logger.error(f"❌ Threat level calculation failed: {e}")
            return 0.0
    
    def _format_alert_message(self, data: Dict[str, Any], threat_level: float) -> str:
        """Format alert message for notifications"""
        try:
            exchange = data.get("exchange", "Unknown")
            quantity = data.get("q", 0)
            timestamp = data.get("timestamp", "Unknown")
            
            message = f"🚨 THREAT DETECTED 🚨\n"
            message += f"Exchange: {exchange}\n"
            message += f"Quantity: {quantity} BTC\n"
            message += f"Threat Level: {threat_level:.2f}\n"
            message += f"Time: {timestamp}\n"
            
            if data.get("anomaly"):
                message += f"⚠️ Anomaly detected\n"
            
            if data.get("latency"):
                message += f"Latency: {data['latency']}ms\n"
            
            return message
            
        except Exception as e:
            logger.error(f"❌ Alert message formatting failed: {e}")
            return f"🚨 Threat detected at {data.get('exchange', 'Unknown')}"
    
    async def _send_email_alert(self, message: str, data: Dict[str, Any]):
        """Send email alert"""
        try:
            if not self.email_config["email_user"] or not self.email_config["email_password"]:
                logger.debug("📧 Email credentials not configured, skipping email alert")
                return
            
            recipients = os.getenv("ALERT_EMAIL_RECIPIENTS", "").split(",")
            if not recipients or recipients == [""]:
                logger.debug("📧 No email recipients configured")
                return
            
            msg = MIMEMultipart()
            msg["From"] = self.email_config["from_email"]
            msg["To"] = ", ".join(recipients)
            msg["Subject"] = f"UMMAH AI Threat Alert - {data.get('exchange', 'Unknown')}"
            
            msg.attach(MIMEText(message, "plain"))
            
            server = smtplib.SMTP(self.email_config["smtp_server"], self.email_config["smtp_port"])
            server.starttls()
            server.login(self.email_config["email_user"], self.email_config["email_password"])
            
            text = msg.as_string()
            server.sendmail(self.email_config["from_email"], recipients, text)
            server.quit()
            
            logger.info(f"📧 Email alert sent to {len(recipients)} recipients")
            
        except Exception as e:
            logger.error(f"❌ Email alert failed: {e}")
    
    async def _send_sms_alert(self, message: str, data: Dict[str, Any]):
        """Send SMS alert"""
        try:
            if not self.sms_config["api_key"]:
                logger.debug("📱 SMS credentials not configured, skipping SMS alert")
                return
            
            recipients = os.getenv("ALERT_SMS_RECIPIENTS", "").split(",")
            if not recipients or recipients == [""]:
                logger.debug("📱 No SMS recipients configured")
                return
            
            sms_message = message[:160] if len(message) > 160 else message
            
            if self.sms_config["provider"] == "twilio":
                await self._send_twilio_sms(sms_message, recipients)
            else:
                logger.warning(f"⚠️ Unsupported SMS provider: {self.sms_config['provider']}")
            
        except Exception as e:
            logger.error(f"❌ SMS alert failed: {e}")
    
    async def _send_twilio_sms(self, message: str, recipients: List[str]):
        """Send SMS via Twilio"""
        try:
            from twilio.rest import Client
            
            client = Client(self.sms_config["api_key"], self.sms_config["api_secret"])
            
            for recipient in recipients:
                if recipient.strip():
                    client.messages.create(
                        body=message,
                        from_=self.sms_config["from_number"],
                        to=recipient.strip()
                    )
            
            logger.info(f"📱 SMS alerts sent to {len(recipients)} recipients")
            
        except ImportError:
            logger.error("❌ Twilio library not installed")
        except Exception as e:
            logger.error(f"❌ Twilio SMS failed: {e}")
    
    async def _send_mqtt_alert(self, message: str, data: Dict[str, Any]):
        """Send MQTT alert"""
        try:
            if not self.mqtt_client:
                await self.initialize_mqtt()
            
            if not self.mqtt_client:
                logger.debug("📡 MQTT client not available")
                return
            
            topic = f"{self.mqtt_config['topic_prefix']}/alerts"
            
            mqtt_payload = {
                "message": message,
                "data": data,
                "timestamp": asyncio.get_event_loop().time(),
                "threat_level": self._calculate_threat_level(data)
            }
            
            self.mqtt_client.publish(topic, json.dumps(mqtt_payload))
            logger.info(f"📡 MQTT alert published to {topic}")
            
        except Exception as e:
            logger.error(f"❌ MQTT alert failed: {e}")
    
    async def get_alert_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get recent alert history"""
        try:
            return self.alert_history[-limit:] if self.alert_history else []
        except Exception as e:
            logger.error(f"❌ Alert history retrieval failed: {e}")
            return []
    
    async def get_alert_statistics(self) -> Dict[str, Any]:
        """Get alert system statistics"""
        try:
            total_alerts = len(self.alert_history)
            
            if total_alerts == 0:
                return {
                    "total_alerts": 0,
                    "average_threat_level": 0.0,
                    "most_common_exchange": "None",
                    "alert_frequency": 0.0
                }
            
            avg_threat_level = sum(alert["threat_level"] for alert in self.alert_history) / total_alerts
            
            exchange_counts = {}
            for alert in self.alert_history:
                exchange = alert["data"].get("exchange", "Unknown")
                exchange_counts[exchange] = exchange_counts.get(exchange, 0) + 1
            
            most_common_exchange = max(exchange_counts, key=exchange_counts.get) if exchange_counts else "None"
            
            if total_alerts > 1:
                time_span = self.alert_history[-1]["timestamp"] - self.alert_history[0]["timestamp"]
                alert_frequency = (total_alerts / time_span) * 3600 if time_span > 0 else 0.0
            else:
                alert_frequency = 0.0
            
            return {
                "total_alerts": total_alerts,
                "average_threat_level": avg_threat_level,
                "most_common_exchange": most_common_exchange,
                "alert_frequency": alert_frequency,
                "exchange_distribution": exchange_counts
            }
            
        except Exception as e:
            logger.error(f"❌ Alert statistics failed: {e}")
            return {"error": str(e)}

alert_system = AlertSystem()
