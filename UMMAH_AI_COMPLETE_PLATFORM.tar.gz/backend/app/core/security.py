"""
Security Enhancements Module

Advanced security middleware and utilities for the UMMAH AI Platform
including rate limiting, data encryption, request validation, and sanitization.
"""

import time
import hashlib
import hmac
import secrets
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
from collections import defaultdict, deque
from fastapi import Request, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64
import re
import bleach
from pydantic import BaseModel, validator
from .config import settings

class RateLimiter:
    """Advanced rate limiting with multiple strategies."""
    
    def __init__(self):
        self.requests = defaultdict(deque)
        self.blocked_ips = {}
        
        self.rules = {
            "default": {"requests": 100, "window": 60},  # 100 requests per minute
            "auth": {"requests": 10, "window": 60},      # 10 auth attempts per minute
            "trading": {"requests": 50, "window": 60},   # 50 trading requests per minute
            "api": {"requests": 1000, "window": 3600},   # 1000 API calls per hour
        }
    
    def is_allowed(self, client_ip: str, endpoint_type: str = "default") -> bool:
        """Check if request is allowed based on rate limiting rules."""
        current_time = time.time()
        
        if client_ip in self.blocked_ips:
            if current_time < self.blocked_ips[client_ip]:
                return False
            else:
                del self.blocked_ips[client_ip]
        
        rule = self.rules.get(endpoint_type, self.rules["default"])
        window_start = current_time - rule["window"]
        
        client_requests = self.requests[client_ip]
        while client_requests and client_requests[0] < window_start:
            client_requests.popleft()
        
        if len(client_requests) >= rule["requests"]:
            self.blocked_ips[client_ip] = current_time + 300
            return False
        
        client_requests.append(current_time)
        return True
    
    def get_client_ip(self, request: Request) -> str:
        """Extract client IP from request headers."""
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()
        
        real_ip = request.headers.get("X-Real-IP")
        if real_ip:
            return real_ip
        
        return request.client.host if request.client else "unknown"

class DataEncryption:
    """Data encryption and decryption utilities."""
    
    def __init__(self, password: str = None):
        if not password:
            password = settings.SECRET_KEY
        
        password_bytes = password.encode()
        salt = b'ummah_ai_salt_2025'  # In production, use random salt per encryption
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(password_bytes))
        self.cipher = Fernet(key)
    
    def encrypt(self, data: str) -> str:
        """Encrypt sensitive data."""
        if not data:
            return ""
        return self.cipher.encrypt(data.encode()).decode()
    
    def decrypt(self, encrypted_data: str) -> str:
        """Decrypt sensitive data."""
        if not encrypted_data:
            return ""
        try:
            return self.cipher.decrypt(encrypted_data.encode()).decode()
        except Exception:
            return ""
    
    def encrypt_dict(self, data: Dict[str, Any], sensitive_fields: List[str]) -> Dict[str, Any]:
        """Encrypt sensitive fields in a dictionary."""
        encrypted_data = data.copy()
        for field in sensitive_fields:
            if field in encrypted_data and encrypted_data[field]:
                encrypted_data[field] = self.encrypt(str(encrypted_data[field]))
        return encrypted_data
    
    def decrypt_dict(self, data: Dict[str, Any], sensitive_fields: List[str]) -> Dict[str, Any]:
        """Decrypt sensitive fields in a dictionary."""
        decrypted_data = data.copy()
        for field in sensitive_fields:
            if field in decrypted_data and decrypted_data[field]:
                decrypted_data[field] = self.decrypt(decrypted_data[field])
        return decrypted_data

class RequestValidator:
    """Request validation and sanitization."""
    
    DANGEROUS_PATTERNS = [
        r'<script[^>]*>.*?</script>',  # Script tags
        r'javascript:',                # JavaScript URLs
        r'on\w+\s*=',                 # Event handlers
        r'<iframe[^>]*>.*?</iframe>',  # Iframes
        r'<object[^>]*>.*?</object>',  # Objects
        r'<embed[^>]*>.*?</embed>',    # Embeds
        r'<link[^>]*>',               # Link tags
        r'<meta[^>]*>',               # Meta tags
        r'<style[^>]*>.*?</style>',   # Style tags
        r'expression\s*\(',           # CSS expressions
        r'url\s*\(',                  # CSS URLs
        r'@import',                   # CSS imports
    ]
    
    SQL_PATTERNS = [
        r'(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION)\b)',
        r'(\b(OR|AND)\s+\d+\s*=\s*\d+)',
        r'(\b(OR|AND)\s+[\'"][^\'"]*[\'"])',
        r'(--|#|/\*|\*/)',
        r'(\bxp_cmdshell\b)',
    ]
    
    @classmethod
    def sanitize_string(cls, value: str) -> str:
        """Sanitize string input to prevent XSS and injection attacks."""
        if not isinstance(value, str):
            return str(value)
        
        for pattern in cls.DANGEROUS_PATTERNS:
            value = re.sub(pattern, '', value, flags=re.IGNORECASE)
        
        allowed_tags = ['b', 'i', 'u', 'em', 'strong', 'p', 'br']
        allowed_attributes = {}
        
        value = bleach.clean(value, tags=allowed_tags, attributes=allowed_attributes)
        
        value = value.replace('<', '&lt;').replace('>', '&gt;')
        
        return value.strip()
    
    @classmethod
    def validate_sql_injection(cls, value: str) -> bool:
        """Check for SQL injection patterns."""
        if not isinstance(value, str):
            return True
        
        for pattern in cls.SQL_PATTERNS:
            if re.search(pattern, value, re.IGNORECASE):
                return False
        
        return True
    
    @classmethod
    def validate_request_size(cls, request: Request, max_size: int = 10 * 1024 * 1024) -> bool:
        """Validate request size to prevent DoS attacks."""
        content_length = request.headers.get("content-length")
        if content_length and int(content_length) > max_size:
            return False
        return True
    
    @classmethod
    def validate_headers(cls, request: Request) -> bool:
        """Validate request headers for security."""
        suspicious_headers = [
            'x-forwarded-host',
            'x-forwarded-server',
            'x-forwarded-proto'
        ]
        
        for header in suspicious_headers:
            if header in request.headers:
                value = request.headers[header]
                if not cls.validate_sql_injection(value):
                    return False
        
        return True

class SecurityHeaders:
    """Security headers for responses."""
    
    @staticmethod
    def get_security_headers() -> Dict[str, str]:
        """Get recommended security headers."""
        return {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "X-XSS-Protection": "1; mode=block",
            "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
            "Content-Security-Policy": (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline' 'unsafe-eval'; "
                "style-src 'self' 'unsafe-inline'; "
                "img-src 'self' data: https:; "
                "font-src 'self' https:; "
                "connect-src 'self' https: wss:; "
                "frame-ancestors 'none';"
            ),
            "Referrer-Policy": "strict-origin-when-cross-origin",
            "Permissions-Policy": (
                "geolocation=(), "
                "microphone=(), "
                "camera=(), "
                "payment=(), "
                "usb=(), "
                "magnetometer=(), "
                "gyroscope=(), "
                "speaker=()"
            )
        }

class SecureRequest(BaseModel):
    """Base model for secure request validation."""
    
    @validator('*', pre=True)
    def sanitize_fields(cls, v):
        """Sanitize all string fields."""
        if isinstance(v, str):
            return RequestValidator.sanitize_string(v)
        return v

class APIKeyValidator:
    """API key validation and management."""
    
    def __init__(self):
        self.valid_keys = set()
        self.key_usage = defaultdict(int)
        self.key_limits = {}
    
    def generate_api_key(self, user_id: str) -> str:
        """Generate a new API key for a user."""
        timestamp = str(int(time.time()))
        data = f"{user_id}:{timestamp}:{secrets.token_hex(16)}"
        api_key = base64.urlsafe_b64encode(data.encode()).decode()
        
        self.valid_keys.add(api_key)
        self.key_limits[api_key] = {"daily_limit": 10000, "used_today": 0}
        
        return api_key
    
    def validate_api_key(self, api_key: str) -> bool:
        """Validate API key and check usage limits."""
        if api_key not in self.valid_keys:
            return False
        
        key_info = self.key_limits.get(api_key, {})
        if key_info.get("used_today", 0) >= key_info.get("daily_limit", 10000):
            return False
        
        self.key_usage[api_key] += 1
        if api_key in self.key_limits:
            self.key_limits[api_key]["used_today"] += 1
        
        return True

rate_limiter = RateLimiter()
data_encryption = DataEncryption()
request_validator = RequestValidator()
security_headers = SecurityHeaders()
api_key_validator = APIKeyValidator()

def get_client_fingerprint(request: Request) -> str:
    """Generate client fingerprint for additional security."""
    user_agent = request.headers.get("user-agent", "")
    accept_language = request.headers.get("accept-language", "")
    accept_encoding = request.headers.get("accept-encoding", "")
    
    fingerprint_data = f"{user_agent}:{accept_language}:{accept_encoding}"
    return hashlib.sha256(fingerprint_data.encode()).hexdigest()[:16]

def verify_request_signature(request: Request, secret_key: str) -> bool:
    """Verify request signature for API integrity."""
    signature = request.headers.get("X-Signature")
    if not signature:
        return False
    
    timestamp = request.headers.get("X-Timestamp", "")
    if not timestamp:
        return False
    
    try:
        request_time = int(timestamp)
        current_time = int(time.time())
        if abs(current_time - request_time) > 300:  # 5 minutes tolerance
            return False
    except ValueError:
        return False
    
    return True
