"""
Enhanced JWT Authentication System

This module provides advanced JWT authentication with refresh tokens,
role-based access control (RBAC), and token blacklisting functionality.
"""

from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
import jwt
from passlib.context import CryptContext
from fastapi import HTTPException, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import redis
import json
from .config import settings

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

security = HTTPBearer()

redis_client = None
try:
    redis_client = redis.from_url(settings.REDIS_URL, decode_responses=True)
except Exception:
    print("Warning: Redis not available for JWT blacklisting")

class JWTManager:
    """Enhanced JWT Manager with refresh tokens and RBAC."""
    
    def __init__(self):
        self.secret_key = settings.SECRET_KEY
        self.refresh_secret_key = settings.JWT_REFRESH_SECRET_KEY
        self.algorithm = settings.ALGORITHM
        self.access_token_expire_minutes = settings.ACCESS_TOKEN_EXPIRE_MINUTES
        self.refresh_token_expire_days = settings.REFRESH_TOKEN_EXPIRE_DAYS
    
    def create_access_token(self, data: Dict[str, Any]) -> str:
        """Create JWT access token with user data and role."""
        to_encode = data.copy()
        expire = datetime.utcnow() + timedelta(minutes=self.access_token_expire_minutes)
        
        to_encode.update({
            "exp": expire,
            "iat": datetime.utcnow(),
            "type": "access"
        })
        
        if "role" not in to_encode:
            to_encode["role"] = settings.DEFAULT_USER_ROLE
        
        return jwt.encode(to_encode, self.secret_key, algorithm=self.algorithm)
    
    def create_refresh_token(self, data: Dict[str, Any]) -> str:
        """Create JWT refresh token for token renewal."""
        to_encode = data.copy()
        expire = datetime.utcnow() + timedelta(days=self.refresh_token_expire_days)
        
        to_encode.update({
            "exp": expire,
            "iat": datetime.utcnow(),
            "type": "refresh"
        })
        
        return jwt.encode(to_encode, self.refresh_secret_key, algorithm=self.algorithm)
    
    def verify_token(self, token: str, token_type: str = "access") -> Dict[str, Any]:
        """Verify JWT token and return payload."""
        try:
            if self.is_token_blacklisted(token):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Token has been revoked"
                )
            
            secret_key = self.secret_key if token_type == "access" else self.refresh_secret_key
            
            payload = jwt.decode(
                token, 
                secret_key, 
                algorithms=[self.algorithm],
                options={
                    "verify_exp": settings.JWT_VERIFY_EXPIRATION,
                    "verify_signature": settings.JWT_VERIFY_SIGNATURE
                },
                leeway=timedelta(seconds=settings.JWT_LEEWAY_SECONDS)
            )
            
            if payload.get("type") != token_type:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=f"Invalid token type. Expected {token_type}"
                )
            
            for claim in settings.JWT_REQUIRE_CLAIMS:
                if claim not in payload:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail=f"Missing required claim: {claim}"
                    )
            
            return payload
            
        except jwt.ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired"
            )
        except jwt.JWTError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Could not validate credentials"
            )
    
    def refresh_access_token(self, refresh_token: str) -> Dict[str, str]:
        """Generate new access token using refresh token."""
        payload = self.verify_token(refresh_token, "refresh")
        
        new_access_token = self.create_access_token({
            "sub": payload["sub"],
            "role": payload.get("role", settings.DEFAULT_USER_ROLE),
            "user_id": payload.get("user_id"),
            "username": payload.get("username")
        })
        
        return {
            "access_token": new_access_token,
            "token_type": "bearer"
        }
    
    def blacklist_token(self, token: str) -> bool:
        """Add token to blacklist (logout functionality)."""
        if not redis_client or not settings.JWT_BLACKLIST_ENABLED:
            return False
        
        try:
            payload = jwt.decode(token, options={"verify_signature": False})
            exp = payload.get("exp")
            
            if exp:
                exp_datetime = datetime.fromtimestamp(exp)
                ttl = int((exp_datetime - datetime.utcnow()).total_seconds())
                
                if ttl > 0:
                    redis_client.setex(f"blacklist:{token}", ttl, "1")
                    return True
            
        except Exception as e:
            print(f"Error blacklisting token: {e}")
        
        return False
    
    def is_token_blacklisted(self, token: str) -> bool:
        """Check if token is blacklisted."""
        if not redis_client or not settings.JWT_BLACKLIST_ENABLED:
            return False
        
        try:
            return redis_client.exists(f"blacklist:{token}") > 0
        except Exception:
            return False
    
    def has_role(self, user_role: str, required_roles: List[str]) -> bool:
        """Check if user has required role."""
        if not settings.RBAC_ENABLED:
            return True
        
        return user_role in required_roles
    
    def hash_password(self, password: str) -> str:
        """Hash password using bcrypt."""
        return pwd_context.hash(password)
    
    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """Verify password against hash."""
        return pwd_context.verify(plain_password, hashed_password)

jwt_manager = JWTManager()

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> Dict[str, Any]:
    """Get current authenticated user from JWT token."""
    token = credentials.credentials
    return jwt_manager.verify_token(token)

async def get_current_admin_user(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    """Get current user and verify admin role."""
    user_role = current_user.get("role", settings.DEFAULT_USER_ROLE)
    
    if not jwt_manager.has_role(user_role, settings.ADMIN_ROLES):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin access required"
        )
    
    return current_user

async def get_current_trader_user(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    """Get current user and verify trader role."""
    user_role = current_user.get("role", settings.DEFAULT_USER_ROLE)
    
    if not jwt_manager.has_role(user_role, settings.TRADER_ROLES):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Trader access required"
        )
    
    return current_user

def require_roles(required_roles: List[str]):
    """Decorator factory for role-based access control."""
    async def role_checker(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
        user_role = current_user.get("role", settings.DEFAULT_USER_ROLE)
        
        if not jwt_manager.has_role(user_role, required_roles):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access denied. Required roles: {required_roles}"
            )
        
        return current_user
    
    return role_checker
