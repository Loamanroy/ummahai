"""
Redis Caching Service

Advanced Redis caching implementation with cache invalidation strategies,
TTL management, and optimized caching for market data and AI predictions.
"""

import redis
import json
import hashlib
from typing import Any, Optional, Dict, List, Union
from datetime import datetime, timedelta
import asyncio
import pickle
from functools import wraps
from .config import settings

class RedisCache:
    """Enhanced Redis cache manager with advanced features."""
    
    def __init__(self):
        self.redis_client = None
        self.connect()
        
        self.ttl_settings = {
            "market_data": 30,          # 30 seconds for real-time market data
            "predictions": 300,         # 5 minutes for AI predictions
            "user_data": 3600,          # 1 hour for user data
            "exchange_data": 60,        # 1 minute for exchange data
            "trading_signals": 15,      # 15 seconds for trading signals
            "historical_data": 86400,   # 24 hours for historical data
            "default": 600              # 10 minutes default
        }
        
        self.prefixes = {
            "market": "market:",
            "prediction": "pred:",
            "user": "user:",
            "exchange": "exch:",
            "signal": "signal:",
            "historical": "hist:",
            "session": "session:"
        }
    
    def connect(self):
        """Initialize Redis connection with error handling."""
        try:
            self.redis_client = redis.from_url(
                settings.REDIS_URL,
                decode_responses=True,
                socket_connect_timeout=5,
                socket_timeout=5,
                retry_on_timeout=True,
                health_check_interval=30
            )
            self.redis_client.ping()
            print("✅ Redis cache connected successfully")
        except Exception as e:
            print(f"❌ Redis connection failed: {e}")
            self.redis_client = None
    
    def _generate_key(self, prefix: str, identifier: str, **kwargs) -> str:
        """Generate cache key with optional parameters."""
        key_parts = [prefix, identifier]
        
        if kwargs:
            sorted_kwargs = sorted(kwargs.items())
            params_str = "_".join([f"{k}:{v}" for k, v in sorted_kwargs])
            key_parts.append(params_str)
        
        return "".join(key_parts)
    
    def _serialize_data(self, data: Any) -> str:
        """Serialize data for Redis storage."""
        if isinstance(data, (dict, list)):
            return json.dumps(data, default=str)
        elif isinstance(data, (int, float, str, bool)):
            return str(data)
        else:
            return pickle.dumps(data).hex()
    
    def _deserialize_data(self, data: str, use_pickle: bool = False) -> Any:
        """Deserialize data from Redis."""
        if not data:
            return None
        
        if use_pickle:
            try:
                return pickle.loads(bytes.fromhex(data))
            except:
                pass
        
        try:
            return json.loads(data)
        except json.JSONDecodeError:
            return data
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None, category: str = "default") -> bool:
        """Set cache value with TTL."""
        if not self.redis_client:
            return False
        
        try:
            serialized_value = self._serialize_data(value)
            ttl = ttl or self.ttl_settings.get(category, self.ttl_settings["default"])
            
            cache_entry = {
                "data": serialized_value,
                "timestamp": datetime.utcnow().isoformat(),
                "category": category,
                "ttl": ttl
            }
            
            result = self.redis_client.setex(
                key,
                ttl,
                json.dumps(cache_entry)
            )
            
            return result
        except Exception as e:
            print(f"Cache set error: {e}")
            return False
    
    async def get(self, key: str) -> Optional[Any]:
        """Get cache value with metadata."""
        if not self.redis_client:
            return None
        
        try:
            cached_data = self.redis_client.get(key)
            if not cached_data:
                return None
            
            cache_entry = json.loads(cached_data)
            return self._deserialize_data(cache_entry["data"])
            
        except Exception as e:
            print(f"Cache get error: {e}")
            return None
    
    async def delete(self, key: str) -> bool:
        """Delete cache entry."""
        if not self.redis_client:
            return False
        
        try:
            return bool(self.redis_client.delete(key))
        except Exception as e:
            print(f"Cache delete error: {e}")
            return False
    
    async def delete_pattern(self, pattern: str) -> int:
        """Delete all keys matching pattern."""
        if not self.redis_client:
            return 0
        
        try:
            keys = self.redis_client.keys(pattern)
            if keys:
                return self.redis_client.delete(*keys)
            return 0
        except Exception as e:
            print(f"Cache pattern delete error: {e}")
            return 0
    
    async def exists(self, key: str) -> bool:
        """Check if key exists in cache."""
        if not self.redis_client:
            return False
        
        try:
            return bool(self.redis_client.exists(key))
        except Exception as e:
            print(f"Cache exists error: {e}")
            return False
    
    async def increment(self, key: str, amount: int = 1) -> Optional[int]:
        """Increment counter in cache."""
        if not self.redis_client:
            return None
        
        try:
            return self.redis_client.incr(key, amount)
        except Exception as e:
            print(f"Cache increment error: {e}")
            return None
    
    async def set_hash(self, key: str, mapping: Dict[str, Any], ttl: Optional[int] = None) -> bool:
        """Set hash data in cache."""
        if not self.redis_client:
            return False
        
        try:
            serialized_mapping = {
                k: self._serialize_data(v) for k, v in mapping.items()
            }
            
            result = self.redis_client.hset(key, mapping=serialized_mapping)
            
            if ttl:
                self.redis_client.expire(key, ttl)
            
            return bool(result)
        except Exception as e:
            print(f"Cache hash set error: {e}")
            return False
    
    async def get_hash(self, key: str, field: Optional[str] = None) -> Optional[Union[Dict, Any]]:
        """Get hash data from cache."""
        if not self.redis_client:
            return None
        
        try:
            if field:
                data = self.redis_client.hget(key, field)
                return self._deserialize_data(data) if data else None
            else:
                data = self.redis_client.hgetall(key)
                return {k: self._deserialize_data(v) for k, v in data.items()} if data else None
        except Exception as e:
            print(f"Cache hash get error: {e}")
            return None
    
    async def cache_market_data(self, symbol: str, data: Dict[str, Any]) -> bool:
        """Cache market data with symbol-specific key."""
        key = self._generate_key(self.prefixes["market"], symbol)
        return await self.set(key, data, category="market_data")
    
    async def get_market_data(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Get cached market data for symbol."""
        key = self._generate_key(self.prefixes["market"], symbol)
        return await self.get(key)
    
    async def cache_prediction(self, model_id: str, input_hash: str, prediction: Dict[str, Any]) -> bool:
        """Cache AI prediction with model and input hash."""
        key = self._generate_key(self.prefixes["prediction"], f"{model_id}:{input_hash}")
        return await self.set(key, prediction, category="predictions")
    
    async def get_prediction(self, model_id: str, input_hash: str) -> Optional[Dict[str, Any]]:
        """Get cached prediction."""
        key = self._generate_key(self.prefixes["prediction"], f"{model_id}:{input_hash}")
        return await self.get(key)
    
    async def cache_trading_signal(self, exchange: str, symbol: str, signal: Dict[str, Any]) -> bool:
        """Cache trading signal."""
        key = self._generate_key(self.prefixes["signal"], f"{exchange}:{symbol}")
        return await self.set(key, signal, category="trading_signals")
    
    async def get_trading_signal(self, exchange: str, symbol: str) -> Optional[Dict[str, Any]]:
        """Get cached trading signal."""
        key = self._generate_key(self.prefixes["signal"], f"{exchange}:{symbol}")
        return await self.get(key)
    
    async def invalidate_market_data(self, symbol: Optional[str] = None) -> int:
        """Invalidate market data cache."""
        if symbol:
            key = self._generate_key(self.prefixes["market"], symbol)
            return 1 if await self.delete(key) else 0
        else:
            pattern = f"{self.prefixes['market']}*"
            return await self.delete_pattern(pattern)
    
    async def invalidate_predictions(self, model_id: Optional[str] = None) -> int:
        """Invalidate prediction cache."""
        if model_id:
            pattern = f"{self.prefixes['prediction']}{model_id}:*"
        else:
            pattern = f"{self.prefixes['prediction']}*"
        return await self.delete_pattern(pattern)
    
    async def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        if not self.redis_client:
            return {"status": "disconnected"}
        
        try:
            info = self.redis_client.info()
            return {
                "status": "connected",
                "used_memory": info.get("used_memory_human", "N/A"),
                "connected_clients": info.get("connected_clients", 0),
                "total_commands_processed": info.get("total_commands_processed", 0),
                "keyspace_hits": info.get("keyspace_hits", 0),
                "keyspace_misses": info.get("keyspace_misses", 0),
                "hit_rate": round(
                    info.get("keyspace_hits", 0) / 
                    max(info.get("keyspace_hits", 0) + info.get("keyspace_misses", 0), 1) * 100, 2
                )
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}

cache = RedisCache()

def cached(ttl: Optional[int] = None, category: str = "default", key_prefix: str = "func"):
    """Decorator for caching function results."""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            key_data = f"{func.__name__}:{str(args)}:{str(sorted(kwargs.items()))}"
            key_hash = hashlib.md5(key_data.encode()).hexdigest()
            cache_key = f"{key_prefix}:{key_hash}"
            
            cached_result = await cache.get(cache_key)
            if cached_result is not None:
                return cached_result
            
            result = await func(*args, **kwargs) if asyncio.iscoroutinefunction(func) else func(*args, **kwargs)
            await cache.set(cache_key, result, ttl=ttl, category=category)
            
            return result
        return wrapper
    return decorator
