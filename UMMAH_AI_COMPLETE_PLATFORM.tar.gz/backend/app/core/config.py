from pydantic_settings import BaseSettings
from typing import List

class Settings(BaseSettings):
    DATABASE_URL: str = "postgresql+asyncpg://ummah_user:ummah_secure_pass@postgres:5432/ummah_ai"
    REDIS_URL: str = "redis://localhost:6379"
    
    CACHE_ENABLED: bool = True
    CACHE_DEFAULT_TTL: int = 600  # 10 minutes
    CACHE_MAX_CONNECTIONS: int = 20
    CACHE_RETRY_ON_TIMEOUT: bool = True
    
    SECURITY_ENABLED: bool = True
    RATE_LIMITING_ENABLED: bool = True
    REQUEST_VALIDATION_ENABLED: bool = True
    CORS_SECURITY_ENABLED: bool = True
    REQUEST_LOGGING_ENABLED: bool = True
    
    DEFAULT_RATE_LIMIT: int = 100  # requests per minute
    AUTH_RATE_LIMIT: int = 10      # auth attempts per minute
    TRADING_RATE_LIMIT: int = 50   # trading requests per minute
    API_RATE_LIMIT: int = 1000     # API calls per hour
    
    SECURITY_HEADERS_ENABLED: bool = True
    CONTENT_SECURITY_POLICY_ENABLED: bool = True
    
    CORS_ALLOW_CREDENTIALS: bool = True
    CORS_MAX_AGE: int = 86400
    
    SECRET_KEY: str = "ummah-ai-quantum-secret-key-2025"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    
    JWT_REFRESH_SECRET_KEY: str = "ummah-ai-refresh-secret-key-2025"
    JWT_BLACKLIST_ENABLED: bool = True
    JWT_BLACKLIST_TOKEN_CHECKS: List[str] = ["access", "refresh"]
    
    RBAC_ENABLED: bool = True
    DEFAULT_USER_ROLE: str = "user"
    ADMIN_ROLES: List[str] = ["admin", "super_admin"]
    TRADER_ROLES: List[str] = ["trader", "pro_trader", "admin", "super_admin"]
    VIEWER_ROLES: List[str] = ["viewer", "user", "trader", "pro_trader", "admin", "super_admin"]
    
    JWT_REQUIRE_CLAIMS: List[str] = ["exp", "iat", "sub", "role"]
    JWT_VERIFY_EXPIRATION: bool = True
    JWT_VERIFY_SIGNATURE: bool = True
    JWT_LEEWAY_SECONDS: int = 10
    
    paranoia: bool = False
    allowed_origins: str = "http://localhost:80,http://localhost:3000"
    
    @property
    def ALLOWED_ORIGINS(self) -> List[str]:
        return [origin.strip() for origin in self.allowed_origins.split(",")]
    log_level: str = "INFO"
    metrics_enabled: bool = True
    
    BINANCE_API_KEY: str = ""
    BINANCE_SECRET_KEY: str = ""
    
    OPENAI_API_KEY: str = ""
    OPENAI_MODEL: str = "gpt-4"
    OPENAI_MAX_TOKENS: int = 2000
    OPENAI_TEMPERATURE: float = 0.3
    COINBASE_API_KEY: str = ""
    COINBASE_SECRET_KEY: str = ""
    COINBASE_PASSPHRASE: str = ""
    KRAKEN_API_KEY: str = ""
    KRAKEN_SECRET_KEY: str = ""
    BYBIT_API_KEY: str = ""
    BYBIT_SECRET_KEY: str = ""
    OKX_API_KEY: str = ""
    OKX_SECRET_KEY: str = ""
    HUOBI_API_KEY: str = ""
    HUOBI_SECRET_KEY: str = ""
    
    OPENAI_API_KEY: str = ""
    
    AI_MODEL_PATH: str = "./models"
    PREDICTION_ACCURACY_TARGET: float = 1.0
    MIRROR_TRADE_LATENCY_MS: int = 1500
    
    MAX_VISIBLE_BALANCE: float = 1000.0
    PROFIT_OBFUSCATION_ENABLED: bool = True
    TOR_PROXY_ENABLED: bool = True
    
    SUPPORTED_EXCHANGES: List[str] = [
        "binance", "coinbase", "kraken", "bybit", "okx", "huobi",
        "kucoin", "gate", "bitfinex", "bitstamp", "gemini", "ftx",
        "mexc", "bitget", "bingx", "phemex", "deribit", "bitmart",
        "lbank", "probit"
    ]
    
    class Config:
        env_file = ".env"

settings = Settings()
