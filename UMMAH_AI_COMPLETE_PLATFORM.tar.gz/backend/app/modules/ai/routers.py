from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List
from app.database import get_db
from app.modules.ai.models import AIModel, AIPrediction, MarketSignal, TradingStrategy
from app.modules.ai.schemas import (
    AIModelCreate, AIModelResponse, AIPredictionCreate, AIPredictionResponse,
    MarketSignalCreate, MarketSignalResponse, TradingStrategyCreate, TradingStrategyResponse,
    PredictionRequest, PredictionResponse
)
from app.services.ai_predictor import AIPredictorService

router = APIRouter(prefix="/api/ai", tags=["ai"])
ai_predictor = AIPredictorService()

@router.post("/predict", response_model=PredictionResponse)
async def predict_optimal_entry(
    request: PredictionRequest,
    db: AsyncSession = Depends(get_db)
):
    """Get AI prediction for optimal trade entry with 100% accuracy target."""
    try:
        prediction = await ai_predictor.predict_optimal_entry(
            request.symbol, request.side, request.amount
        )
        return prediction
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")

@router.get("/market-prediction/{symbol}")
async def get_market_prediction(
    symbol: str,
    timeframe: str = "1m",
    db: AsyncSession = Depends(get_db)
):
    """Get comprehensive market movement prediction."""
    try:
        prediction = await ai_predictor.predict_market_movement(symbol, timeframe)
        return prediction
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Market prediction failed: {str(e)}")

@router.post("/analyze-exchange/{exchange_id}")
async def analyze_exchange_participants(
    exchange_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Analyze all participants on exchange to identify bots and strategies."""
    try:
        analysis = await ai_predictor.analyze_exchange_participants(exchange_id)
        return analysis
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")

@router.post("/models", response_model=AIModelResponse)
async def create_ai_model(
    model: AIModelCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new AI model configuration."""
    db_model = AIModel(**model.dict())
    db.add(db_model)
    await db.commit()
    await db.refresh(db_model)
    return db_model

@router.get("/models", response_model=List[AIModelResponse])
async def get_ai_models(db: AsyncSession = Depends(get_db)):
    """Get all AI models."""
    from sqlalchemy import select
    result = await db.execute(select(AIModel).where(AIModel.is_active == True))
    return result.scalars().all()

@router.post("/predictions", response_model=AIPredictionResponse)
async def create_prediction(
    prediction: AIPredictionCreate,
    db: AsyncSession = Depends(get_db)
):
    """Store AI prediction for tracking accuracy."""
    db_prediction = AIPrediction(**prediction.dict())
    db.add(db_prediction)
    await db.commit()
    await db.refresh(db_prediction)
    return db_prediction

@router.get("/predictions", response_model=List[AIPredictionResponse])
async def get_predictions(
    symbol: str = None,
    exchange_id: int = None,
    limit: int = 100,
    db: AsyncSession = Depends(get_db)
):
    """Get AI predictions with optional filtering."""
    from sqlalchemy import select
    query = select(AIPrediction)
    
    if symbol:
        query = query.where(AIPrediction.symbol == symbol)
    if exchange_id:
        query = query.where(AIPrediction.exchange_id == exchange_id)
    
    result = await db.execute(query.order_by(AIPrediction.created_at.desc()).limit(limit))
    return result.scalars().all()

@router.post("/signals", response_model=MarketSignalResponse)
async def create_market_signal(
    signal: MarketSignalCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new market signal."""
    db_signal = MarketSignal(**signal.dict())
    db.add(db_signal)
    await db.commit()
    await db.refresh(db_signal)
    return db_signal

@router.get("/signals", response_model=List[MarketSignalResponse])
async def get_market_signals(
    symbol: str = None,
    exchange_id: int = None,
    signal_type: str = None,
    active_only: bool = True,
    db: AsyncSession = Depends(get_db)
):
    """Get market signals with filtering."""
    from sqlalchemy import select
    query = select(MarketSignal)
    
    if symbol:
        query = query.where(MarketSignal.symbol == symbol)
    if exchange_id:
        query = query.where(MarketSignal.exchange_id == exchange_id)
    if signal_type:
        query = query.where(MarketSignal.signal_type == signal_type)
    if active_only:
        query = query.where(MarketSignal.is_active == True)
    
    result = await db.execute(query.order_by(MarketSignal.created_at.desc()).limit(100))
    return result.scalars().all()

@router.post("/strategies", response_model=TradingStrategyResponse)
async def create_trading_strategy(
    strategy: TradingStrategyCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new trading strategy."""
    db_strategy = TradingStrategy(**strategy.dict())
    db.add(db_strategy)
    await db.commit()
    await db.refresh(db_strategy)
    return db_strategy

@router.get("/strategies", response_model=List[TradingStrategyResponse])
async def get_trading_strategies(db: AsyncSession = Depends(get_db)):
    """Get all trading strategies."""
    from sqlalchemy import select
    result = await db.execute(select(TradingStrategy).where(TradingStrategy.is_active == True))
    return result.scalars().all()

@router.get("/accuracy-report")
async def get_accuracy_report(db: AsyncSession = Depends(get_db)):
    """Get comprehensive accuracy report for all AI models."""
    from sqlalchemy import select, func
    
    model_query = select(AIModel.name, AIModel.accuracy).where(AIModel.is_active == True)
    model_result = await db.execute(model_query)
    models = model_result.all()
    
    pred_query = select(
        func.avg(AIPrediction.accuracy).label('avg_accuracy'),
        func.count(AIPrediction.id).label('total_predictions')
    ).where(AIPrediction.accuracy.isnot(None))
    pred_result = await db.execute(pred_query)
    pred_stats = pred_result.first()
    
    return {
        "models": [{"name": name, "accuracy": accuracy} for name, accuracy in models],
        "overall_accuracy": pred_stats.avg_accuracy if pred_stats.avg_accuracy else 0.0,
        "total_predictions": pred_stats.total_predictions if pred_stats.total_predictions else 0,
        "target_accuracy": 1.0,
        "status": "operational"
    }
