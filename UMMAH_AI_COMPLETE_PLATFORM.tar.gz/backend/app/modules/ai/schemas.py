from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime

class AIModelBase(BaseModel):
    name: str
    model_type: str
    version: str
    hyperparameters: Optional[Dict[str, Any]] = None

class AIModelCreate(AIModelBase):
    pass

class AIModelResponse(AIModelBase):
    id: int
    accuracy: float
    training_data_size: int
    model_path: Optional[str] = None
    is_active: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class AIPredictionCreate(BaseModel):
    model_id: int
    exchange_id: int
    symbol: str
    prediction_type: str
    predicted_value: float
    confidence: float
    features_used: Optional[Dict[str, Any]] = None
    prediction_horizon: str = "1m"

class AIPredictionResponse(BaseModel):
    id: int
    model_id: int
    exchange_id: int
    symbol: str
    prediction_type: str
    predicted_value: float
    confidence: float
    actual_value: Optional[float] = None
    accuracy: Optional[float] = None
    features_used: Optional[Dict[str, Any]] = None
    prediction_horizon: str
    created_at: datetime
    verified_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class MarketSignalCreate(BaseModel):
    exchange_id: int
    symbol: str
    signal_type: str
    strength: float
    source: str
    metadata: Optional[Dict[str, Any]] = None
    expires_at: Optional[datetime] = None

class MarketSignalResponse(BaseModel):
    id: int
    exchange_id: int
    symbol: str
    signal_type: str
    strength: float
    source: str
    metadata: Optional[Dict[str, Any]] = None
    is_active: bool
    expires_at: Optional[datetime] = None
    created_at: datetime
    
    class Config:
        from_attributes = True

class TradingStrategyCreate(BaseModel):
    name: str
    strategy_type: str
    parameters: Dict[str, Any]
    target_accuracy: float = 1.0

class TradingStrategyResponse(BaseModel):
    id: int
    name: str
    strategy_type: str
    parameters: Dict[str, Any]
    target_accuracy: float
    current_accuracy: float
    total_trades: int
    successful_trades: int
    total_profit: float
    is_active: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class PredictionRequest(BaseModel):
    symbol: str
    side: str
    amount: float
    timeframe: str = "1m"

class PredictionResponse(BaseModel):
    symbol: str
    side: str
    amount: float
    optimal_price: float
    confidence: float
    expected_profit: float
    execution_window_ms: int
    market_sentiment: str
    participant_behavior: Dict[str, Any]
    prediction_accuracy: float
