from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, JSON, Text, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base

class AIModel(Base):
    __tablename__ = "ai_models"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True)
    name = Column(String, nullable=False)
    model_type = Column(String, nullable=False)  # "neural_network", "ensemble", "quantum"
    version = Column(String, nullable=False)
    accuracy = Column(Float, default=0.0)
    training_data_size = Column(Integer, default=0)
    model_path = Column(String)
    hyperparameters = Column(JSON)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    predictions = relationship("AIPrediction", back_populates="model")

class AIPrediction(Base):
    __tablename__ = "ai_predictions"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True)
    model_id = Column(Integer, ForeignKey("ai_models.id"), nullable=False)
    exchange_id = Column(Integer, nullable=False)
    symbol = Column(String, nullable=False)
    prediction_type = Column(String, nullable=False)  # "price", "direction", "volume"
    predicted_value = Column(Float, nullable=False)
    confidence = Column(Float, nullable=False)
    actual_value = Column(Float)
    accuracy = Column(Float)
    features_used = Column(JSON)
    prediction_horizon = Column(String)  # "1m", "5m", "1h", "1d"
    created_at = Column(DateTime, default=datetime.utcnow)
    verified_at = Column(DateTime)
    
    model = relationship("AIModel", back_populates="predictions")

class MarketSignal(Base):
    __tablename__ = "market_signals"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True)
    exchange_id = Column(Integer, nullable=False)
    symbol = Column(String, nullable=False)
    signal_type = Column(String, nullable=False)  # "buy", "sell", "hold"
    strength = Column(Float, nullable=False)  # 0.0 to 1.0
    source = Column(String, nullable=False)  # "technical", "sentiment", "whale", "ai"
    signal_metadata = Column(JSON)
    is_active = Column(Boolean, default=True)
    expires_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)

class TradingStrategy(Base):
    __tablename__ = "trading_strategies"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True)
    name = Column(String, nullable=False)
    strategy_type = Column(String, nullable=False)  # "mirror", "arbitrage", "trend", "mean_reversion"
    parameters = Column(JSON)
    target_accuracy = Column(Float, default=1.0)
    current_accuracy = Column(Float, default=0.0)
    total_trades = Column(Integer, default=0)
    successful_trades = Column(Integer, default=0)
    total_profit = Column(Float, default=0.0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
