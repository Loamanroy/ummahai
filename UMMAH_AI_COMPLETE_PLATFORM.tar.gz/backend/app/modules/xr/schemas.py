"""
XR Module Schemas - Pydantic Models for XR API

This module defines the Pydantic schemas for XR functionality including
request/response models for scene management, ZKP verification, and
quantum-enhanced trading operations.
"""

from pydantic import BaseModel, Field
from typing import Optional, Dict, List, Any
from datetime import datetime

class XRSceneBase(BaseModel):
    """Base schema for XR Scene operations."""
    scene_id: str = Field(..., description="Unique scene identifier")
    name: str = Field(..., description="Human-readable scene name")
    description: Optional[str] = Field(None, description="Scene description")
    background_type: str = Field("cyberpunk_city_night", description="Background environment type")
    agents_config: Optional[Dict[str, Any]] = Field(None, description="AI agents configuration")
    audio_config: Optional[Dict[str, Any]] = Field(None, description="Audio settings")
    quantum_params: Optional[Dict[str, Any]] = Field(None, description="Quantum enhancement parameters")

class XRSceneCreate(XRSceneBase):
    """Schema for creating new XR scenes."""
    pass

class XRSceneResponse(XRSceneBase):
    """Schema for XR scene responses."""
    id: int
    created_at: datetime
    updated_at: Optional[datetime]
    is_active: bool
    
    class Config:
        from_attributes = True

class XRSessionBase(BaseModel):
    """Base schema for XR Session operations."""
    session_id: str = Field(..., description="Unique session identifier")
    user_id: str = Field(..., description="User identifier")
    scene_id: str = Field(..., description="Associated scene identifier")

class XRSessionCreate(XRSessionBase):
    """Schema for creating new XR sessions."""
    pass

class XRSessionResponse(XRSessionBase):
    """Schema for XR session responses."""
    id: int
    start_time: datetime
    end_time: Optional[datetime]
    performance_metrics: Optional[Dict[str, Any]]
    quantum_coherence: float
    trades_executed: int
    profit_loss: float
    is_active: bool
    
    class Config:
        from_attributes = True

class ZKPProofBase(BaseModel):
    """Base schema for Zero-Knowledge Proof operations."""
    proof_type: str = Field(..., description="Type of ZKP proof")
    proof_data: Dict[str, Any] = Field(..., description="Cryptographic proof data")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional proof metadata")

class ZKPProofCreate(ZKPProofBase):
    """Schema for creating new ZKP proofs."""
    pass

class ZKPProofResponse(ZKPProofBase):
    """Schema for ZKP proof responses."""
    id: int
    zkp_id: str
    verification_status: bool
    confidence_score: float
    created_at: datetime
    expires_at: Optional[datetime]
    
    class Config:
        from_attributes = True

class ZKPVerificationRequest(BaseModel):
    """Schema for ZKP verification requests."""
    zkp_id: str = Field(..., description="ZKP identifier to verify")
    challenge_data: Optional[str] = Field(None, description="Challenge data for verification")

class ZKPVerificationResponse(BaseModel):
    """Schema for ZKP verification responses."""
    zkp_id: str
    verified: bool
    confidence: float
    verification_time: float
    quantum_signature: Optional[str] = Field(None, description="Quantum-enhanced signature")

class QuantumTradingStateBase(BaseModel):
    """Base schema for Quantum Trading State operations."""
    state_id: str = Field(..., description="Unique quantum state identifier")
    session_id: str = Field(..., description="Associated session identifier")
    quantum_vector: Dict[str, Any] = Field(..., description="Quantum state vector")
    entanglement_map: Optional[Dict[str, Any]] = Field(None, description="Entanglement correlations")
    probability_matrix: Optional[Dict[str, Any]] = Field(None, description="Probability distributions")

class QuantumTradingStateCreate(QuantumTradingStateBase):
    """Schema for creating new quantum trading states."""
    pass

class QuantumTradingStateResponse(QuantumTradingStateBase):
    """Schema for quantum trading state responses."""
    id: int
    coherence_time: Optional[float]
    decoherence_rate: Optional[float]
    measurement_results: Optional[Dict[str, Any]]
    created_at: datetime
    is_collapsed: bool
    
    class Config:
        from_attributes = True

class WebSocketMessage(BaseModel):
    """Schema for WebSocket messages in XR environments."""
    message_type: str = Field(..., description="Type of WebSocket message")
    session_id: Optional[str] = Field(None, description="Session identifier")
    data: Dict[str, Any] = Field(..., description="Message payload")
    timestamp: Optional[datetime] = Field(None, description="Message timestamp")
    quantum_signature: Optional[str] = Field(None, description="Quantum authentication signature")

class SceneGenerationRequest(BaseModel):
    """Schema for AI scene generation requests."""
    prompt: str = Field(..., description="Natural language scene description")
    style: str = Field("cyberpunk", description="Visual style preference")
    complexity: int = Field(5, ge=1, le=10, description="Scene complexity level")
    ai_agents: Optional[List[str]] = Field(None, description="Requested AI agent types")
    quantum_enhancement: bool = Field(True, description="Enable quantum-enhanced generation")

class SceneGenerationResponse(BaseModel):
    """Schema for AI scene generation responses."""
    scene_id: str
    generation_time: float
    complexity_achieved: int
    ai_agents_created: List[str]
    quantum_coherence: float
    scene_config: Dict[str, Any]
    preview_url: Optional[str] = Field(None, description="Scene preview URL")
