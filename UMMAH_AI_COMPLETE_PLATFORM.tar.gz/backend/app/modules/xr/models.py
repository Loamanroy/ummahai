"""
XR Module Models - Advanced Extended Reality Trading Models

This module defines the database models for XR (Extended Reality) functionality
including scene management, ZKP verification, and quantum-enhanced trading sessions.
"""

from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, Text, JSON
from sqlalchemy.sql import func
from app.database import Base

class XRScene(Base):
    """
    XR Scene model for managing virtual trading environments.
    
    Stores scene configurations, AI agent placements, and quantum-enhanced
    market visualization parameters for immersive trading experiences.
    """
    __tablename__ = "xr_scenes"
    
    id = Column(Integer, primary_key=True, index=True)
    scene_id = Column(String(100), unique=True, index=True)
    name = Column(String(200), nullable=False)
    description = Column(Text)
    background_type = Column(String(50), default="cyberpunk_city_night")
    agents_config = Column(JSON)
    audio_config = Column(JSON)
    quantum_params = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    is_active = Column(Boolean, default=True)

class XRSession(Base):
    """
    XR Session model for tracking user interactions in virtual environments.
    
    Manages session state, performance metrics, and quantum coherence levels
    for optimal trading experience in extended reality.
    """
    __tablename__ = "xr_sessions"
    
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String(100), unique=True, index=True)
    user_id = Column(String(100), index=True)
    scene_id = Column(String(100), index=True)
    start_time = Column(DateTime(timezone=True), server_default=func.now())
    end_time = Column(DateTime(timezone=True))
    performance_metrics = Column(JSON)
    quantum_coherence = Column(Float, default=0.0)
    trades_executed = Column(Integer, default=0)
    profit_loss = Column(Float, default=0.0)
    is_active = Column(Boolean, default=True)

class ZKPProof(Base):
    """
    Zero-Knowledge Proof model for privacy-preserving trading verification.
    
    Stores cryptographic proofs that enable trade verification without
    revealing sensitive trading strategies or positions.
    """
    __tablename__ = "zkp_proofs"
    
    id = Column(Integer, primary_key=True, index=True)
    zkp_id = Column(String(100), unique=True, index=True)
    proof_type = Column(String(50), nullable=False)
    proof_data = Column(JSON, nullable=False)
    verification_status = Column(Boolean, default=False)
    confidence_score = Column(Float, default=0.0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    expires_at = Column(DateTime(timezone=True))
    proof_metadata = Column(JSON)

class QuantumTradingState(Base):
    """
    Quantum Trading State model for managing quantum-enhanced predictions.
    
    Tracks quantum superposition states, entanglement correlations, and
    probability distributions for advanced market prediction algorithms.
    """
    __tablename__ = "quantum_trading_states"
    
    id = Column(Integer, primary_key=True, index=True)
    state_id = Column(String(100), unique=True, index=True)
    session_id = Column(String(100), index=True)
    quantum_vector = Column(JSON)
    entanglement_map = Column(JSON)
    probability_matrix = Column(JSON)
    coherence_time = Column(Float)
    decoherence_rate = Column(Float)
    measurement_results = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    is_collapsed = Column(Boolean, default=False)
