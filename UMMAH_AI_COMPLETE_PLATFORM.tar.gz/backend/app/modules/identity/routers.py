from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List
import random
import string
import hashlib
from datetime import datetime, timedelta

from app.database import get_db
from app.modules.identity.models import UserRegistration, KYCVerification, BiometricData
from app.modules.identity.schemas import (
    DocumentUploadRequest, DocumentUploadResponse,
    BiometricVerificationRequest, BiometricVerificationResponse,
    SendVerificationCodeRequest, VerifyCodeRequest, VerificationResponse,
    WalletCreationRequest, WalletCreationResponse,
    ContractSigningRequest, ContractSigningResponse,
    RegistrationStatusResponse, UserRegistrationResponse,
    KYCVerificationRequest, KYCVerificationResponse
)

router = APIRouter(prefix="/api/identity", tags=["identity"])

@router.post("/register/step1", response_model=DocumentUploadResponse)
async def register_step1(
    user_data: DocumentUploadRequest,
    db: AsyncSession = Depends(get_db)
):
    """Step 1: Document upload and personal information collection."""
    try:
        existing_user = await db.execute(
            "SELECT * FROM user_registrations WHERE email = :email",
            {"email": user_data.email}
        )
        if existing_user.fetchone():
            raise HTTPException(status_code=400, detail="Email already registered")
        
        new_user = UserRegistration(
            email=user_data.email,
            phone=user_data.phone,
            full_name=user_data.full_name,
            date_of_birth=user_data.date_of_birth,
            nationality=user_data.nationality,
            address=user_data.address,
            registration_stage=1
        )
        
        db.add(new_user)
        await db.commit()
        await db.refresh(new_user)
        
        return DocumentUploadResponse(
            user_id=new_user.id,
            message="Personal information saved successfully",
            next_step="biometric_verification"
        )
    except Exception as e:
        await db.rollback()
        raise HTTPException(status_code=500, detail=f"Registration failed: {str(e)}")

@router.post("/register/step1/upload-documents")
async def upload_documents(
    user_id: int,
    passport_image: UploadFile = File(...),
    selfie_image: UploadFile = File(...),
    db: AsyncSession = Depends(get_db)
):
    """Upload passport and selfie documents."""
    try:
        
        user = await db.get(UserRegistration, user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        user.passport_image_path = f"/uploads/passport_{user_id}_{passport_image.filename}"
        user.selfie_image_path = f"/uploads/selfie_{user_id}_{selfie_image.filename}"
        user.document_verified = True
        
        await db.commit()
        
        return {"message": "Documents uploaded and verified successfully"}
    except Exception as e:
        await db.rollback()
        raise HTTPException(status_code=500, detail=f"Document upload failed: {str(e)}")

@router.post("/register/step2/biometric", response_model=BiometricVerificationResponse)
async def biometric_verification(
    biometric_data: BiometricVerificationRequest,
    db: AsyncSession = Depends(get_db)
):
    """Step 2: Biometric verification (face, fingerprint, voice)."""
    try:
        user = await db.get(UserRegistration, biometric_data.user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        verification_score = random.uniform(0.85, 0.99)
        biometric_hash = hashlib.sha256(biometric_data.biometric_data.encode()).hexdigest()
        
        biometric_record = BiometricData(
            user_id=biometric_data.user_id,
            biometric_type=biometric_data.biometric_type,
            biometric_hash=biometric_hash,
            verification_score=str(verification_score)
        )
        db.add(biometric_record)
        
        if biometric_data.biometric_type == "face":
            user.face_verified = True
        elif biometric_data.biometric_type == "fingerprint":
            user.fingerprint_verified = True
        elif biometric_data.biometric_type == "voice":
            user.voice_verified = True
        
        if user.face_verified and user.fingerprint_verified and user.voice_verified:
            user.registration_stage = 2
        
        await db.commit()
        
        return BiometricVerificationResponse(
            user_id=biometric_data.user_id,
            biometric_type=biometric_data.biometric_type,
            verification_status="verified",
            verification_score=verification_score,
            message=f"{biometric_data.biometric_type.title()} verification successful"
        )
    except Exception as e:
        await db.rollback()
        raise HTTPException(status_code=500, detail=f"Biometric verification failed: {str(e)}")

@router.post("/register/step3/send-code", response_model=VerificationResponse)
async def send_verification_code(
    request: SendVerificationCodeRequest,
    db: AsyncSession = Depends(get_db)
):
    """Step 3: Send verification code via email or SMS."""
    try:
        user = await db.get(UserRegistration, request.user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        verification_code = ''.join(random.choices(string.digits, k=6))
        
        if request.verification_type == "email":
            user.email_verification_code = verification_code
            message = f"Email verification code sent to {user.email}"
        elif request.verification_type == "sms":
            user.phone_verification_code = verification_code
            message = f"SMS verification code sent to {user.phone}"
        else:
            raise HTTPException(status_code=400, detail="Invalid verification type")
        
        await db.commit()
        
        return VerificationResponse(
            user_id=request.user_id,
            verification_type=request.verification_type,
            verified=False,
            message=message
        )
    except Exception as e:
        await db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to send verification code: {str(e)}")

@router.post("/register/step3/verify-code", response_model=VerificationResponse)
async def verify_code(
    request: VerifyCodeRequest,
    db: AsyncSession = Depends(get_db)
):
    """Step 3: Verify email or SMS code."""
    try:
        user = await db.get(UserRegistration, request.user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        verified = False
        if request.verification_type == "email":
            if user.email_verification_code == request.verification_code:
                user.email_verified = True
                user.email_verification_code = None
                verified = True
        elif request.verification_type == "sms":
            if user.phone_verification_code == request.verification_code:
                user.phone_verified = True
                user.phone_verification_code = None
                verified = True
        
        if not verified:
            raise HTTPException(status_code=400, detail="Invalid verification code")
        
        if user.email_verified and user.phone_verified:
            user.registration_stage = 3
        
        await db.commit()
        
        return VerificationResponse(
            user_id=request.user_id,
            verification_type=request.verification_type,
            verified=True,
            message=f"{request.verification_type.title()} verified successfully"
        )
    except Exception as e:
        await db.rollback()
        raise HTTPException(status_code=500, detail=f"Code verification failed: {str(e)}")

@router.post("/register/step4/wallet", response_model=WalletCreationResponse)
async def create_or_connect_wallet(
    wallet_data: WalletCreationRequest,
    db: AsyncSession = Depends(get_db)
):
    """Step 4: Create new wallet or connect existing wallet."""
    try:
        user = await db.get(UserRegistration, wallet_data.user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        wallet_address = ""
        seed_phrase = None
        
        if wallet_data.wallet_type == "create":
            wallet_address = "0x" + ''.join(random.choices(string.hexdigits.lower(), k=40))
            seed_phrase = ' '.join([
                ''.join(random.choices(string.ascii_lowercase, k=random.randint(4, 8)))
                for _ in range(12)
            ])
        elif wallet_data.wallet_type == "connect":
            wallet_address = wallet_data.existing_wallet_address
        
        user.wallet_address = wallet_address
        user.wallet_type = wallet_data.wallet_type
        user.offshore_accounts = [account.dict() for account in wallet_data.offshore_accounts]
        user.registration_stage = 4
        
        await db.commit()
        
        return WalletCreationResponse(
            user_id=wallet_data.user_id,
            wallet_address=wallet_address,
            wallet_type=wallet_data.wallet_type,
            seed_phrase=seed_phrase,
            offshore_accounts_count=len(wallet_data.offshore_accounts),
            message="Wallet setup completed successfully"
        )
    except Exception as e:
        await db.rollback()
        raise HTTPException(status_code=500, detail=f"Wallet creation failed: {str(e)}")

@router.post("/register/step5/contract", response_model=ContractSigningResponse)
async def sign_contract(
    contract_data: ContractSigningRequest,
    db: AsyncSession = Depends(get_db)
):
    """Step 5: Sign investment contract."""
    try:
        user = await db.get(UserRegistration, contract_data.user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        if not contract_data.agreed_to_terms:
            raise HTTPException(status_code=400, detail="Must agree to terms to proceed")
        
        contract_id = f"UMMAH-{datetime.now().strftime('%Y%m%d')}-{random.randint(10000, 99999)}"
        
        user.contract_type = contract_data.contract_type
        user.contract_signed = True
        user.digital_signature = contract_data.digital_signature
        user.contract_id = contract_id
        user.registration_stage = 5
        user.registration_complete = True
        user.approval_status = "pending"  # Set to pending approval
        user.is_approved = False  # Requires admin approval
        
        await db.commit()
        
        return ContractSigningResponse(
            user_id=contract_data.user_id,
            contract_id=contract_id,
            contract_type=contract_data.contract_type,
            signed_at=datetime.utcnow(),
            registration_complete=True,
            message="Contract signed successfully. Registration complete!"
        )
    except Exception as e:
        await db.rollback()
        raise HTTPException(status_code=500, detail=f"Contract signing failed: {str(e)}")

@router.get("/register/status/{user_id}", response_model=RegistrationStatusResponse)
async def get_registration_status(
    user_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Get current registration status for a user."""
    user = await db.get(UserRegistration, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    stages_completed = []
    if user.document_verified:
        stages_completed.append("document_upload")
    if user.face_verified and user.fingerprint_verified and user.voice_verified:
        stages_completed.append("biometric_verification")
    if user.email_verified and user.phone_verified:
        stages_completed.append("email_sms_confirmation")
    if user.wallet_address:
        stages_completed.append("wallet_creation")
    if user.contract_signed:
        stages_completed.append("contract_signing")
    
    return RegistrationStatusResponse(
        user_id=user.id,
        current_stage=user.registration_stage,
        stages_completed=stages_completed,
        registration_complete=user.registration_complete,
        created_at=user.created_at,
        updated_at=user.updated_at
    )

@router.get("/users", response_model=List[UserRegistrationResponse])
async def get_all_registrations(
    db: AsyncSession = Depends(get_db)
):
    """Get all user registrations (admin endpoint)."""
    result = await db.execute("SELECT * FROM user_registrations ORDER BY created_at DESC")
    users = result.fetchall()
    
    return [
        UserRegistrationResponse(
            id=user.id,
            email=user.email,
            full_name=user.full_name,
            registration_stage=user.registration_stage,
            registration_complete=user.registration_complete,
            document_verified=user.document_verified,
            biometric_verified=user.face_verified and user.fingerprint_verified and user.voice_verified,
            email_verified=user.email_verified,
            phone_verified=user.phone_verified,
            wallet_connected=bool(user.wallet_address),
            contract_signed=user.contract_signed,
            created_at=user.created_at
        )
        for user in users
    ]

@router.post("/kyc/verify", response_model=KYCVerificationResponse)
async def verify_kyc(
    kyc_data: KYCVerificationRequest,
    db: AsyncSession = Depends(get_db)
):
    """Process KYC/AML verification."""
    try:
        kyc_verification = KYCVerification(
            user_id=kyc_data.user_id,
            verification_type=kyc_data.verification_type,
            verification_status="approved",  # Simulate approval
            verification_data=kyc_data.verification_data,
            verification_notes="Automated verification passed",
            verified_at=datetime.utcnow()
        )
        
        db.add(kyc_verification)
        await db.commit()
        await db.refresh(kyc_verification)
        
        return KYCVerificationResponse(
            id=kyc_verification.id,
            user_id=kyc_verification.user_id,
            verification_type=kyc_verification.verification_type,
            verification_status=kyc_verification.verification_status,
            verification_notes=kyc_verification.verification_notes,
            verified_at=kyc_verification.verified_at
        )
    except Exception as e:
        await db.rollback()
        raise HTTPException(status_code=500, detail=f"KYC verification failed: {str(e)}")
