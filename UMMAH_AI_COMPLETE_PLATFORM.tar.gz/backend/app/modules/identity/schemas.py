from pydantic import BaseModel, EmailStr
from typing import Optional, List, Dict, Any
from datetime import datetime

class DocumentUploadRequest(BaseModel):
    full_name: str
    email: EmailStr
    phone: str
    date_of_birth: str
    nationality: str
    address: str

class DocumentUploadResponse(BaseModel):
    user_id: int
    message: str
    next_step: str

class BiometricVerificationRequest(BaseModel):
    user_id: int
    biometric_type: str  # face, fingerprint, voice
    biometric_data: str  # base64 encoded biometric data

class BiometricVerificationResponse(BaseModel):
    user_id: int
    biometric_type: str
    verification_status: str
    verification_score: Optional[float]
    message: str

class SendVerificationCodeRequest(BaseModel):
    user_id: int
    verification_type: str  # email or sms

class VerifyCodeRequest(BaseModel):
    user_id: int
    verification_type: str  # email or sms
    verification_code: str

class VerificationResponse(BaseModel):
    user_id: int
    verification_type: str
    verified: bool
    message: str

class OffshoreAccount(BaseModel):
    bank: str
    country: str
    account_number: str
    swift: str

class WalletCreationRequest(BaseModel):
    user_id: int
    wallet_type: str  # connect or create
    wallet_option: Optional[str]  # for create: quantum-vault, stealth-elite, ai-adaptive
    existing_wallet_address: Optional[str]  # for connect
    offshore_accounts: List[OffshoreAccount]

class WalletCreationResponse(BaseModel):
    user_id: int
    wallet_address: str
    wallet_type: str
    seed_phrase: Optional[str]  # only for created wallets
    offshore_accounts_count: int
    message: str

class ContractSigningRequest(BaseModel):
    user_id: int
    contract_type: str  # mudarabah, musharakah, wakalah
    digital_signature: str
    agreed_to_terms: bool

class ContractSigningResponse(BaseModel):
    user_id: int
    contract_id: str
    contract_type: str
    signed_at: datetime
    registration_complete: bool
    message: str

class RegistrationStatusResponse(BaseModel):
    user_id: int
    current_stage: int
    stages_completed: List[str]
    registration_complete: bool
    created_at: datetime
    updated_at: datetime

class UserRegistrationResponse(BaseModel):
    id: int
    email: str
    full_name: str
    registration_stage: int
    registration_complete: bool
    document_verified: bool
    biometric_verified: bool
    email_verified: bool
    phone_verified: bool
    wallet_connected: bool
    contract_signed: bool
    created_at: datetime

class KYCVerificationRequest(BaseModel):
    user_id: int
    verification_type: str
    verification_data: Dict[str, Any]

class KYCVerificationResponse(BaseModel):
    id: int
    user_id: int
    verification_type: str
    verification_status: str
    verification_notes: Optional[str]
    verified_at: Optional[datetime]
