from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey, JSON, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base

class UserRegistration(Base):
    """
    User registration model for managing the 5-step registration process
    with admin approval functionality
    """
    __tablename__ = "user_registrations"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True, default="default")
    
    email = Column(String(255), unique=True, nullable=False, index=True)
    phone = Column(String(50), nullable=False)
    full_name = Column(String(255), nullable=False)
    date_of_birth = Column(String(50), nullable=False)
    nationality = Column(String(100), nullable=False)
    address = Column(Text, nullable=False)
    
    passport_image_path = Column(String(500))
    selfie_image_path = Column(String(500))
    document_verified = Column(Boolean, default=False)
    
    face_verified = Column(Boolean, default=False)
    fingerprint_verified = Column(Boolean, default=False)
    voice_verified = Column(Boolean, default=False)
    
    email_verified = Column(Boolean, default=False)
    phone_verified = Column(Boolean, default=False)
    email_verification_code = Column(String(10))
    phone_verification_code = Column(String(10))
    
    wallet_address = Column(String(255))
    wallet_type = Column(String(50))  # "create" or "connect"
    offshore_accounts = Column(JSON)
    
    contract_signed = Column(Boolean, default=False)
    contract_type = Column(String(50))  # "mudarabah", "musharakah", "wakalah"
    contract_id = Column(String(100))
    digital_signature = Column(Text)
    
    registration_stage = Column(Integer, default=1)
    registration_complete = Column(Boolean, default=False)
    
    is_approved = Column(Boolean, default=False)
    approval_status = Column(String(20), default="pending")  # "pending", "approved", "rejected"
    approved_by = Column(String(100))  # Admin user ID who approved
    approved_at = Column(DateTime)
    rejection_reason = Column(Text)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class KYCVerification(Base):
    """KYC/AML verification records"""
    __tablename__ = "kyc_verifications"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("user_registrations.id"), nullable=False)
    verification_type = Column(String(50), nullable=False)
    verification_status = Column(String(20), default="pending")
    verification_data = Column(JSON)
    verification_notes = Column(Text)
    verified_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)

class BiometricData(Base):
    """Biometric verification data storage"""
    __tablename__ = "biometric_data"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("user_registrations.id"), nullable=False)
    biometric_type = Column(String(20), nullable=False)  # "face", "fingerprint", "voice"
    biometric_hash = Column(String(255), nullable=False)
    verification_score = Column(String(10))
    created_at = Column(DateTime, default=datetime.utcnow)
