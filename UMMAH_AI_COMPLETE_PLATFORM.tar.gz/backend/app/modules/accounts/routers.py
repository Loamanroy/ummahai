from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List, Optional
from datetime import datetime, timedelta
import jwt
import bcrypt
from app.database import get_db
from app.modules.accounts.models import Account, ExchangeAccount, TradingSession, AccountActivity, AccountPermissions
from app.modules.accounts.schemas import (
    AccountCreate, AccountResponse, ExchangeAccountCreate, ExchangeAccountResponse,
    TradingSessionCreate, TradingSessionResponse, AccountActivityResponse,
    AccountPermissionsCreate, AccountPermissionsResponse, AccountBalanceUpdate, AccountConfigUpdate
)
from app.services.account_manager import AccountManager
from app.services.wallet_service import wallet_service

router = APIRouter(prefix="/api/accounts", tags=["accounts"])
account_manager = AccountManager()
security = HTTPBearer()

SECRET_KEY = "ummah-ai-platform-secret-key-2024"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

@router.post("/", response_model=AccountResponse)
async def create_account(
    account: AccountCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new trading account."""
    return await account_manager.create_account(db, account)

@router.get("/", response_model=List[AccountResponse])
async def get_accounts(
    owner_id: str = None,
    account_type: str = None,
    status: str = None,
    db: AsyncSession = Depends(get_db)
):
    """Get accounts with filtering."""
    return await account_manager.get_accounts(db, owner_id, account_type, status)

@router.get("/{account_id}", response_model=AccountResponse)
async def get_account(
    account_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Get account by ID."""
    return await account_manager.get_account(db, account_id)

@router.put("/{account_id}/balance")
async def update_account_balance(
    account_id: int,
    balance_update: AccountBalanceUpdate,
    db: AsyncSession = Depends(get_db)
):
    """Update account balance."""
    return await account_manager.update_balance(db, account_id, balance_update)

@router.put("/{account_id}/config")
async def update_account_config(
    account_id: int,
    config_update: AccountConfigUpdate,
    db: AsyncSession = Depends(get_db)
):
    """Update account configuration."""
    return await account_manager.update_config(db, account_id, config_update)

@router.post("/exchange-accounts", response_model=ExchangeAccountResponse)
async def create_exchange_account(
    exchange_account: ExchangeAccountCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create exchange account integration."""
    return await account_manager.create_exchange_account(db, exchange_account)

@router.get("/{account_id}/exchange-accounts", response_model=List[ExchangeAccountResponse])
async def get_exchange_accounts(
    account_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Get exchange accounts for account."""
    return await account_manager.get_exchange_accounts(db, account_id)

@router.post("/trading-sessions", response_model=TradingSessionResponse)
async def create_trading_session(
    session: TradingSessionCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new trading session."""
    return await account_manager.create_trading_session(db, session)

@router.get("/{account_id}/trading-sessions", response_model=List[TradingSessionResponse])
async def get_trading_sessions(
    account_id: int,
    status: str = None,
    db: AsyncSession = Depends(get_db)
):
    """Get trading sessions for account."""
    return await account_manager.get_trading_sessions(db, account_id, status)

@router.post("/trading-sessions/{session_id}/start")
async def start_trading_session(
    session_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Start a trading session."""
    return await account_manager.start_trading_session(db, session_id)

@router.post("/trading-sessions/{session_id}/stop")
async def stop_trading_session(
    session_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Stop a trading session."""
    return await account_manager.stop_trading_session(db, session_id)

@router.get("/{account_id}/activities", response_model=List[AccountActivityResponse])
async def get_account_activities(
    account_id: int,
    activity_type: str = None,
    limit: int = 100,
    db: AsyncSession = Depends(get_db)
):
    """Get account activity history."""
    return await account_manager.get_account_activities(db, account_id, activity_type, limit)

@router.post("/permissions", response_model=AccountPermissionsResponse)
async def create_account_permissions(
    permissions: AccountPermissionsCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create account permissions."""
    return await account_manager.create_permissions(db, permissions)

@router.get("/{account_id}/permissions", response_model=AccountPermissionsResponse)
async def get_account_permissions(
    account_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Get account permissions."""
    return await account_manager.get_permissions(db, account_id)

@router.get("/{account_id}/dashboard")
async def get_account_dashboard(
    account_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Get comprehensive account dashboard data."""
    return await account_manager.get_account_dashboard(db, account_id)

@router.get("/{account_id}/stealth-status")
async def get_stealth_status(
    account_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Get stealth operation status for account."""
    return await account_manager.get_stealth_status(db, account_id)

@router.post("/auth/register")
async def register_user(
    email: str,
    password: str,
    full_name: str,
    db: AsyncSession = Depends(get_db)
):
    """Register a new user account."""
    try:
        existing_user = await db.execute(
            "SELECT * FROM accounts WHERE email = :email",
            {"email": email}
        )
        if existing_user.fetchone():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email already registered"
            )
        
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        
        new_account = Account(
            email=email,
            password_hash=hashed_password.decode('utf-8'),
            full_name=full_name,
            account_type="investor",
            status="pending_verification",
            created_at=datetime.utcnow()
        )
        
        db.add(new_account)
        await db.commit()
        await db.refresh(new_account)
        
        return {
            "message": "User registered successfully",
            "user_id": new_account.id,
            "email": new_account.email,
            "status": "pending_verification"
        }
    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Registration failed: {str(e)}"
        )

@router.post("/auth/login")
async def login_user(
    email: str,
    password: str,
    db: AsyncSession = Depends(get_db)
):
    """Authenticate user and return access token."""
    try:
        result = await db.execute(
            "SELECT * FROM accounts WHERE email = :email",
            {"email": email}
        )
        user = result.fetchone()
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password"
            )
        
        if not bcrypt.checkpw(password.encode('utf-8'), user.password_hash.encode('utf-8')):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password"
            )
        
        access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        access_token = create_access_token(
            data={"sub": user.email, "user_id": user.id},
            expires_delta=access_token_expires
        )
        
        return {
            "access_token": access_token,
            "token_type": "bearer",
            "expires_in": ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            "user": {
                "id": user.id,
                "email": user.email,
                "full_name": user.full_name,
                "account_type": user.account_type,
                "status": user.status
            }
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Login failed: {str(e)}"
        )

@router.post("/auth/refresh")
async def refresh_token(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """Refresh access token."""
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        user_id: int = payload.get("user_id")
        
        if email is None or user_id is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
        
        access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        access_token = create_access_token(
            data={"sub": email, "user_id": user_id},
            expires_delta=access_token_expires
        )
        
        return {
            "access_token": access_token,
            "token_type": "bearer",
            "expires_in": ACCESS_TOKEN_EXPIRE_MINUTES * 60
        }
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token expired"
        )
    except jwt.JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )

@router.post("/kyc/submit-documents")
async def submit_kyc_documents(
    user_id: int,
    document_type: str,
    document_data: dict,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """Submit KYC documents for verification."""
    try:
        current_user = await get_current_user(credentials, db)
        
        if current_user.id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied"
            )
        
        kyc_result = await process_kyc_documents(user_id, document_type, document_data, db)
        
        return {
            "message": "KYC documents submitted successfully",
            "verification_id": kyc_result["verification_id"],
            "status": kyc_result["status"],
            "estimated_processing_time": "24-48 hours"
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"KYC submission failed: {str(e)}"
        )

@router.get("/kyc/status/{user_id}")
async def get_kyc_status(
    user_id: int,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """Get KYC verification status for user."""
    try:
        current_user = await get_current_user(credentials, db)
        
        if current_user.id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied"
            )
        
        kyc_status = await get_user_kyc_status(user_id, db)
        
        return kyc_status
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get KYC status: {str(e)}"
        )

@router.post("/wallet/create")
async def create_wallet(
    wallet_type: str,
    wallet_option: Optional[str] = None,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """Create a new wallet for authenticated user."""
    try:
        current_user = await get_current_user(credentials, db)
        
        if wallet_type == "create":
            if wallet_option == "quantum-vault":
                wallet_data = wallet_service.create_quantum_vault_wallet()
            elif wallet_option == "stealth-elite":
                wallet_data = wallet_service.create_stealth_elite_wallet()
            elif wallet_option == "ai-adaptive":
                wallet_data = wallet_service.create_ai_adaptive_wallet()
            else:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid wallet option"
                )
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid wallet type"
            )
        
        await store_user_wallet(current_user.id, wallet_data, db)
        
        return {
            "message": "Wallet created successfully",
            "wallet_address": wallet_data["wallet_address"],
            "wallet_type": wallet_data["wallet_type"],
            "features": wallet_data["features"],
            "security_level": wallet_data["security_level"]
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Wallet creation failed: {str(e)}"
        )

@router.post("/wallet/connect")
async def connect_wallet(
    wallet_address: str,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """Connect an existing wallet to user account."""
    try:
        current_user = await get_current_user(credentials, db)
        
        wallet_data = wallet_service.connect_existing_wallet(wallet_address)
        
        await store_user_wallet(current_user.id, wallet_data, db)
        
        return {
            "message": "Wallet connected successfully",
            "wallet_address": wallet_data["wallet_address"],
            "wallet_type": wallet_data["wallet_type"],
            "features": wallet_data["features"]
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Wallet connection failed: {str(e)}"
        )

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """Create JWT access token."""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(credentials: HTTPAuthorizationCredentials, db: AsyncSession):
    """Get current authenticated user."""
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        user_id: int = payload.get("user_id")
        
        if email is None or user_id is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
        
        result = await db.execute(
            "SELECT * FROM accounts WHERE email = :email AND id = :user_id",
            {"email": email, "user_id": user_id}
        )
        user = result.fetchone()
        
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User not found"
            )
        
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token expired"
        )
    except jwt.JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )

async def process_kyc_documents(user_id: int, document_type: str, document_data: dict, db: AsyncSession):
    """Process KYC documents and return verification result."""
    verification_id = f"KYC-{user_id}-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    return {
        "verification_id": verification_id,
        "status": "pending",
        "document_type": document_type,
        "submitted_at": datetime.utcnow().isoformat()
    }

async def get_user_kyc_status(user_id: int, db: AsyncSession):
    """Get KYC verification status for user."""
    return {
        "user_id": user_id,
        "kyc_status": "pending",
        "documents_submitted": ["passport", "selfie"],
        "verification_level": "basic",
        "last_updated": datetime.utcnow().isoformat()
    }

async def store_user_wallet(user_id: int, wallet_data: dict, db: AsyncSession):
    """Store wallet information in database."""
    await db.execute(
        "UPDATE accounts SET wallet_address = :wallet_address, wallet_type = :wallet_type WHERE id = :user_id",
        {
            "wallet_address": wallet_data["wallet_address"],
            "wallet_type": wallet_data["wallet_type"],
            "user_id": user_id
        }
    )
    await db.commit()
