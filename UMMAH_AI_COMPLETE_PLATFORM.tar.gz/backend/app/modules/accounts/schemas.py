from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime

class AccountBase(BaseModel):
    account_name: str
    account_type: str
    owner_id: str
    max_daily_volume: float = 100000.0
    risk_tolerance: str = "medium"
    auto_trading_enabled: bool = True
    stealth_mode_enabled: bool = True
    configuration: Optional[Dict[str, Any]] = None

class AccountCreate(AccountBase):
    pass

class AccountResponse(AccountBase):
    id: int
    status: str
    total_balance_usd: float
    visible_balance_usd: float
    hidden_balance_usd: float
    encryption_level: int
    proxy_rotation_enabled: bool
    tor_routing_enabled: bool
    created_at: datetime
    updated_at: datetime
    last_activity: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class ExchangeAccountCreate(BaseModel):
    account_id: int
    exchange_id: int
    api_key: str
    secret_key: str
    passphrase: Optional[str] = None
    account_type_on_exchange: str = "spot"
    max_position_size: float = 10000.0
    proxy_config: Optional[Dict[str, Any]] = None

class ExchangeAccountResponse(BaseModel):
    id: int
    account_id: int
    exchange_id: int
    exchange_account_id: Optional[str] = None
    account_name_on_exchange: Optional[str] = None
    account_type_on_exchange: str
    balances: Optional[Dict[str, float]] = None
    last_balance_update: Optional[datetime] = None
    trading_enabled: bool
    withdrawal_enabled: bool
    max_position_size: float
    visible_balance_override: float
    proxy_config: Optional[Dict[str, Any]] = None
    user_agent_rotation: bool
    is_active: bool
    last_used: Optional[datetime] = None
    created_at: datetime
    
    class Config:
        from_attributes = True

class TradingSessionCreate(BaseModel):
    account_id: int
    session_name: str
    session_type: str
    target_exchanges: List[int]
    trading_pairs: List[str]
    strategy_parameters: Dict[str, Any]
    stop_loss_percentage: float = 5.0
    take_profit_percentage: float = 10.0
    max_concurrent_trades: int = 10

class TradingSessionResponse(BaseModel):
    id: int
    account_id: int
    session_name: str
    session_type: str
    target_exchanges: List[int]
    trading_pairs: List[str]
    strategy_parameters: Dict[str, Any]
    total_trades: int
    successful_trades: int
    total_volume: float
    total_profit: float
    max_drawdown: float
    stop_loss_percentage: float
    take_profit_percentage: float
    max_concurrent_trades: int
    status: str
    started_at: Optional[datetime] = None
    ended_at: Optional[datetime] = None
    created_at: datetime
    
    class Config:
        from_attributes = True

class AccountActivityResponse(BaseModel):
    id: int
    account_id: int
    activity_type: str
    description: Optional[str] = None
    exchange_id: Optional[int] = None
    amount: Optional[float] = None
    currency: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    proxy_used: bool
    tor_used: bool
    vpn_used: bool
    metadata: Optional[Dict[str, Any]] = None
    created_at: datetime
    
    class Config:
        from_attributes = True

class AccountPermissionsCreate(BaseModel):
    account_id: int
    can_trade: bool = True
    can_withdraw: bool = False
    can_deposit: bool = True
    can_view_balances: bool = True
    can_modify_settings: bool = True
    can_use_stealth_mode: bool = True
    can_mirror_trade: bool = True
    can_arbitrage: bool = True
    can_access_ai_predictions: bool = True
    daily_trading_limit: float = 100000.0
    monthly_trading_limit: float = 1000000.0
    max_open_positions: int = 50
    expires_at: Optional[datetime] = None

class AccountPermissionsResponse(BaseModel):
    id: int
    account_id: int
    can_trade: bool
    can_withdraw: bool
    can_deposit: bool
    can_view_balances: bool
    can_modify_settings: bool
    can_use_stealth_mode: bool
    can_mirror_trade: bool
    can_arbitrage: bool
    can_access_ai_predictions: bool
    daily_trading_limit: float
    monthly_trading_limit: float
    max_open_positions: int
    granted_by: Optional[str] = None
    granted_at: datetime
    expires_at: Optional[datetime] = None
    is_active: bool
    
    class Config:
        from_attributes = True

class AccountBalanceUpdate(BaseModel):
    total_balance_usd: Optional[float] = None
    visible_balance_usd: Optional[float] = None
    hidden_balance_usd: Optional[float] = None

class AccountConfigUpdate(BaseModel):
    max_daily_volume: Optional[float] = None
    risk_tolerance: Optional[str] = None
    auto_trading_enabled: Optional[bool] = None
    stealth_mode_enabled: Optional[bool] = None
    encryption_level: Optional[int] = None
    proxy_rotation_enabled: Optional[bool] = None
    tor_routing_enabled: Optional[bool] = None
    configuration: Optional[Dict[str, Any]] = None
