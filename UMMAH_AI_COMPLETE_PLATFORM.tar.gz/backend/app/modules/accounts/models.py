from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey, JSON, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base
import enum

class AccountType(enum.Enum):
    MASTER = "master"
    STEALTH = "stealth"
    MIRROR = "mirror"
    ARBITRAGE = "arbitrage"
    SCALPING = "scalping"
    INSTITUTIONAL = "institutional"
    CEREBELLUM_ENTITY = "cerebellum_entity"

class AccountStatus(enum.Enum):
    ACTIVE = "active"
    SUSPENDED = "suspended"
    CLOSED = "closed"
    MAINTENANCE = "maintenance"
    PARANOIA = "paranoia"

class RiskTolerance(enum.Enum):
    ULTRA_LOW = "ultra_low"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    EXTREME = "extreme"

class Account(Base):
    """
    Master account model for CerebellumBot vX multi-account management
    Manages stealth operations across 20 exchanges with $1000 visibility limits
    """
    __tablename__ = "accounts"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True)
    account_name = Column(String(100), nullable=False)
    account_type = Column(String(20), nullable=False)  # AccountType enum
    owner_id = Column(String(100), nullable=False)  # CerebellumBot entity identifier
    status = Column(String(20), default="active")  # AccountStatus enum
    
    total_balance_usd = Column(Float, default=0.0)
    visible_balance_usd = Column(Float, default=1000.0)  # Always show max $1000
    hidden_balance_usd = Column(Float, default=0.0)
    stealth_balance_pools = Column(JSON)  # Multiple hidden balance pools
    
    max_daily_volume = Column(Float, default=100000.0)
    max_position_size = Column(Float, default=50000.0)
    risk_tolerance = Column(String(20), default="medium")  # RiskTolerance enum
    auto_trading_enabled = Column(Boolean, default=True)
    mirror_trading_enabled = Column(Boolean, default=True)
    arbitrage_enabled = Column(Boolean, default=True)
    
    stealth_mode_enabled = Column(Boolean, default=True)
    paranoia_mode_enabled = Column(Boolean, default=False)
    encryption_level = Column(Integer, default=5)  # 1-10 scale
    proxy_rotation_enabled = Column(Boolean, default=True)
    tor_routing_enabled = Column(Boolean, default=True)
    ip_masking_enabled = Column(Boolean, default=True)
    
    ai_strategy_enabled = Column(Boolean, default=True)
    quantum_prediction_enabled = Column(Boolean, default=True)
    pattern_recognition_enabled = Column(Boolean, default=True)
    sentiment_analysis_enabled = Column(Boolean, default=True)
    participant_analysis_enabled = Column(Boolean, default=True)  # Analyze top 100 participants
    
    total_profit_usd = Column(Float, default=0.0)
    total_trades = Column(Integer, default=0)
    win_rate = Column(Float, default=0.0)
    sharpe_ratio = Column(Float, default=0.0)
    max_drawdown = Column(Float, default=0.0)
    monthly_target_usd = Column(Float, default=1000000000.0)  # $1B/month target
    
    is_cerebellum_entity = Column(Boolean, default=False)
    entity_breathing_enabled = Column(Boolean, default=True)  # "breathes in the background"
    invisible_mode_enabled = Column(Boolean, default=True)
    market_side_entry_enabled = Column(Boolean, default=True)  # "side entry to market"
    
    configuration = Column(JSON)
    stealth_configuration = Column(JSON)
    ai_configuration = Column(JSON)
    participant_analysis_config = Column(JSON)  # Config for analyzing top participants
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_activity = Column(DateTime)
    last_stealth_rotation = Column(DateTime)
    last_participant_analysis = Column(DateTime)
    
    exchange_accounts = relationship("ExchangeAccount", back_populates="account", cascade="all, delete-orphan")
    trading_sessions = relationship("TradingSession", back_populates="account", cascade="all, delete-orphan")
    account_activities = relationship("AccountActivity", back_populates="account", cascade="all, delete-orphan")
    stealth_operations = relationship("StealthOperation", foreign_keys="StealthOperation.source_account_id", cascade="all, delete-orphan")
    balance_pools = relationship("BalancePool", back_populates="account", cascade="all, delete-orphan")
    participant_analyses = relationship("ParticipantAnalysis", back_populates="account", cascade="all, delete-orphan")

class ExchangeAccount(Base):
    """
    Exchange-specific account model for managing accounts across 20 exchanges
    Stores encrypted API credentials and exchange-specific configurations
    """
    __tablename__ = "exchange_accounts"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    exchange_name = Column(String(50), nullable=False)  # Binance, Coinbase, etc.
    exchange_account_id = Column(String(100))  # Exchange-specific account ID
    
    encrypted_api_key = Column(Text, nullable=False)
    encrypted_api_secret = Column(Text, nullable=False)
    encrypted_passphrase = Column(Text)  # For exchanges that require it
    encryption_key_id = Column(String(100), nullable=False)
    
    status = Column(String(20), default="active")
    is_verified = Column(Boolean, default=False)
    kyc_level = Column(Integer, default=0)  # 0-3 KYC levels
    
    daily_withdrawal_limit = Column(Float, default=0.0)
    daily_trading_limit = Column(Float, default=0.0)
    max_order_size = Column(Float, default=0.0)
    
    total_balance_usd = Column(Float, default=0.0)
    available_balance_usd = Column(Float, default=0.0)
    locked_balance_usd = Column(Float, default=0.0)
    visible_balance_override = Column(Float, default=1000.0)  # Always show max $1000
    
    balances = Column(JSON)  # {"BTC": 0.5, "USDT": 1000.0, ...}
    hidden_balances = Column(JSON)  # Hidden balance pools
    
    stealth_enabled = Column(Boolean, default=True)
    human_emulation_profile = Column(String(50))  # Profile from HumanEmulationService
    ip_rotation_enabled = Column(Boolean, default=True)
    api_call_obfuscation = Column(Boolean, default=True)
    user_agent_rotation = Column(Boolean, default=True)
    
    participant_monitoring_enabled = Column(Boolean, default=True)  # Monitor top participants
    bot_detection_enabled = Column(Boolean, default=True)  # Detect other bots
    strategy_analysis_enabled = Column(Boolean, default=True)  # Analyze participant strategies
    
    total_trades_count = Column(Integer, default=0)
    successful_trades_count = Column(Integer, default=0)
    total_volume_usd = Column(Float, default=0.0)
    total_fees_paid = Column(Float, default=0.0)
    profit_generated_usd = Column(Float, default=0.0)
    
    exchange_configuration = Column(JSON)
    trading_pairs = Column(JSON)  # Supported trading pairs
    proxy_config = Column(JSON)
    stealth_config = Column(JSON)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_api_call = Column(DateTime)
    last_balance_update = Column(DateTime)
    credentials_last_rotated = Column(DateTime)
    last_participant_scan = Column(DateTime)
    
    account = relationship("Account", back_populates="exchange_accounts")
    trading_sessions = relationship("TradingSession", back_populates="exchange_account")
    participant_analyses = relationship("ParticipantAnalysis", back_populates="exchange_account")

class TradingSession(Base):
    """
    Trading session model for tracking active trading sessions
    Manages session state, performance, and stealth operations
    """
    __tablename__ = "trading_sessions"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    exchange_account_id = Column(Integer, ForeignKey("exchange_accounts.id"), nullable=False)
    
    session_id = Column(String(100), unique=True, nullable=False)
    session_name = Column(String(100), nullable=False)
    session_type = Column(String(30), nullable=False)  # "mirror", "arbitrage", "scalping", "ai_strategy", "participant_analysis"
    status = Column(String(20), default="active")  # "active", "paused", "completed", "error"
    
    strategy_name = Column(String(100))
    strategy_parameters = Column(JSON)
    risk_parameters = Column(JSON)
    target_exchanges = Column(JSON)  # List of exchange names
    trading_pairs = Column(JSON)  # List of trading pairs
    
    start_balance_usd = Column(Float, default=0.0)
    current_balance_usd = Column(Float, default=0.0)
    realized_pnl_usd = Column(Float, default=0.0)
    unrealized_pnl_usd = Column(Float, default=0.0)
    
    total_orders = Column(Integer, default=0)
    successful_orders = Column(Integer, default=0)
    failed_orders = Column(Integer, default=0)
    total_volume_usd = Column(Float, default=0.0)
    
    stop_loss_percentage = Column(Float, default=5.0)
    take_profit_percentage = Column(Float, default=10.0)
    max_concurrent_trades = Column(Integer, default=10)
    max_drawdown_percentage = Column(Float, default=15.0)
    
    stealth_score = Column(Float, default=0.95)  # 0.0-1.0 stealth effectiveness
    detection_incidents = Column(Integer, default=0)
    ip_rotations = Column(Integer, default=0)
    human_emulation_score = Column(Float, default=0.98)
    
    ai_predictions_made = Column(Integer, default=0)
    ai_predictions_correct = Column(Integer, default=0)
    quantum_enhancements_used = Column(Integer, default=0)
    participants_analyzed = Column(Integer, default=0)  # Number of participants analyzed
    
    market_side_entries = Column(Integer, default=0)  # Side entries to market
    invisible_operations = Column(Integer, default=0)  # Invisible operations performed
    breathing_cycles = Column(Integer, default=0)  # Background breathing cycles
    
    started_at = Column(DateTime, default=datetime.utcnow)
    ended_at = Column(DateTime)
    last_activity = Column(DateTime, default=datetime.utcnow)
    last_stealth_rotation = Column(DateTime)
    
    account = relationship("Account", back_populates="trading_sessions")
    exchange_account = relationship("ExchangeAccount", back_populates="trading_sessions")

class AccountActivity(Base):
    """
    Account activity tracking for audit trails and performance analysis
    Records all significant account operations and stealth activities
    """
    __tablename__ = "account_activities"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    
    activity_type = Column(String(50), nullable=False)  # "trade", "deposit", "withdrawal", "stealth_rotation", "participant_analysis"
    activity_category = Column(String(30), nullable=False)  # "trading", "security", "maintenance", "stealth", "ai_analysis"
    description = Column(Text)
    
    exchange_name = Column(String(50))
    trading_pair = Column(String(20))
    amount_usd = Column(Float)
    currency = Column(String(10))
    
    ip_address_hash = Column(String(64))  # Hashed IP for privacy
    user_agent_hash = Column(String(64))  # Hashed user agent
    stealth_level = Column(Integer)  # 1-10 stealth level used
    proxy_used = Column(Boolean, default=False)
    tor_used = Column(Boolean, default=False)
    vpn_used = Column(Boolean, default=False)
    
    profit_impact_usd = Column(Float, default=0.0)
    risk_impact = Column(Float, default=0.0)
    
    participants_affected = Column(Integer, default=0)  # Number of participants affected by this activity
    bots_detected = Column(Integer, default=0)  # Number of bots detected during this activity
    strategies_analyzed = Column(Integer, default=0)  # Number of strategies analyzed
    
    activity_metadata = Column(JSON)
    stealth_metadata = Column(JSON)
    ai_metadata = Column(JSON)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    account = relationship("Account", back_populates="account_activities")

class AccountPermissions(Base):
    """
    Account permissions and access control for different account types
    Manages what operations each account type can perform
    """
    __tablename__ = "account_permissions"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    
    can_trade = Column(Boolean, default=True)
    can_withdraw = Column(Boolean, default=False)
    can_deposit = Column(Boolean, default=True)
    can_view_balances = Column(Boolean, default=True)
    can_modify_settings = Column(Boolean, default=True)
    
    can_use_stealth_mode = Column(Boolean, default=True)
    can_mirror_trade = Column(Boolean, default=True)
    can_arbitrage = Column(Boolean, default=True)
    can_access_ai_predictions = Column(Boolean, default=True)
    can_use_quantum_predictions = Column(Boolean, default=True)
    
    can_analyze_participants = Column(Boolean, default=True)
    can_detect_bots = Column(Boolean, default=True)
    can_use_paranoia_mode = Column(Boolean, default=True)
    can_access_hidden_balances = Column(Boolean, default=True)
    can_perform_side_entry = Column(Boolean, default=True)
    
    daily_trading_limit = Column(Float, default=100000.0)
    monthly_trading_limit = Column(Float, default=1000000000.0)  # $1B monthly target
    max_open_positions = Column(Integer, default=50)
    max_exchanges_access = Column(Integer, default=20)  # Access to all 20 exchanges
    
    max_risk_level = Column(Integer, default=8)  # 1-10 risk level
    requires_approval_above_usd = Column(Float, default=1000000.0)  # $1M approval threshold
    
    permission_config = Column(JSON)
    
    granted_by = Column(String(100))
    granted_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime)
    is_active = Column(Boolean, default=True)
    last_modified = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)



class BalancePool(Base):
    """
    Stealth balance pool management for hiding true account balances
    Implements $1000 visibility limit with multiple hidden pools
    """
    __tablename__ = "balance_pools"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    
    pool_id = Column(String(100), unique=True, nullable=False)
    pool_name = Column(String(100), nullable=False)
    pool_type = Column(String(30), nullable=False)  # "visible", "hidden", "reserve", "emergency"
    
    balance_usd = Column(Float, default=0.0)
    allocated_balance_usd = Column(Float, default=0.0)
    reserved_balance_usd = Column(Float, default=0.0)
    
    is_visible = Column(Boolean, default=False)
    visibility_limit_usd = Column(Float, default=1000.0)
    stealth_fragmentation = Column(JSON)  # How balance is fragmented across exchanges
    
    requires_stealth_access = Column(Boolean, default=True)
    access_frequency_limit = Column(Integer, default=10)  # Max accesses per day
    
    total_inflows_usd = Column(Float, default=0.0)
    total_outflows_usd = Column(Float, default=0.0)
    profit_generated_usd = Column(Float, default=0.0)
    
    pool_configuration = Column(JSON)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_accessed = Column(DateTime)
    
    account = relationship("Account", back_populates="balance_pools")

class ParticipantAnalysis(Base):
    """
    Participant analysis tracking for CerebellumBot vX market intelligence
    Analyzes top 100 participants on each exchange to understand market dynamics
    """
    __tablename__ = "participant_analyses"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    exchange_account_id = Column(Integer, ForeignKey("exchange_accounts.id"), nullable=False)
    
    analysis_id = Column(String(100), unique=True, nullable=False)
    exchange_name = Column(String(50), nullable=False)
    
    participant_id = Column(String(100), nullable=False)  # Anonymized participant ID
    participant_rank = Column(Integer)  # Rank among top participants (1-100)
    participant_type = Column(String(30))  # "whale", "institution", "bot", "retail", "market_maker"
    
    trading_volume_24h = Column(Float, default=0.0)
    trading_frequency = Column(Float, default=0.0)  # Trades per hour
    average_order_size = Column(Float, default=0.0)
    preferred_trading_pairs = Column(JSON)
    
    detected_strategy = Column(String(100))  # "scalping", "arbitrage", "market_making", "trend_following"
    strategy_confidence = Column(Float, default=0.0)  # 0.0-1.0 confidence in strategy detection
    bot_probability = Column(Float, default=0.0)  # 0.0-1.0 probability of being a bot
    
    timing_patterns = Column(JSON)  # When they trade
    order_patterns = Column(JSON)  # How they place orders
    reaction_patterns = Column(JSON)  # How they react to market events
    
    market_impact_score = Column(Float, default=0.0)  # How much they affect market
    influence_on_price = Column(Float, default=0.0)  # Price influence percentage
    liquidity_provision = Column(Float, default=0.0)  # Liquidity they provide
    
    profit_estimation = Column(Float, default=0.0)  # Estimated daily profit
    risk_level = Column(Integer, default=5)  # 1-10 risk level
    success_rate = Column(Float, default=0.0)  # Estimated success rate
    
    mirror_worthiness_score = Column(Float, default=0.0)  # 0.0-1.0 worth mirroring
    mirror_risk_assessment = Column(String(20), default="medium")  # "low", "medium", "high"
    
    analysis_confidence = Column(Float, default=0.0)  # Overall analysis confidence
    data_quality_score = Column(Float, default=0.0)  # Quality of data used
    analysis_method = Column(String(50))  # Method used for analysis
    
    analyzed_at = Column(DateTime, default=datetime.utcnow)
    data_period_start = Column(DateTime)  # Period of data analyzed
    data_period_end = Column(DateTime)
    next_analysis_due = Column(DateTime)
    
    account = relationship("Account", back_populates="participant_analyses")
    exchange_account = relationship("ExchangeAccount", back_populates="participant_analyses")

class ExchangeIntegration(Base):
    """
    Exchange integration configuration and status tracking
    Manages connections to all 20 supported exchanges
    """
    __tablename__ = "exchange_integrations"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True)
    exchange_name = Column(String(50), nullable=False)
    exchange_display_name = Column(String(100), nullable=False)
    
    is_active = Column(Boolean, default=True)
    is_available = Column(Boolean, default=True)
    maintenance_mode = Column(Boolean, default=False)
    
    api_base_url = Column(String(200), nullable=False)
    api_version = Column(String(20))
    websocket_url = Column(String(200))
    
    supports_spot_trading = Column(Boolean, default=True)
    supports_futures_trading = Column(Boolean, default=False)
    supports_margin_trading = Column(Boolean, default=False)
    supports_options_trading = Column(Boolean, default=False)
    
    api_rate_limit_per_minute = Column(Integer, default=1200)
    websocket_connection_limit = Column(Integer, default=5)
    max_orders_per_second = Column(Integer, default=10)
    
    supports_stealth_mode = Column(Boolean, default=True)
    human_emulation_compatible = Column(Boolean, default=True)
    ip_rotation_compatible = Column(Boolean, default=True)
    participant_analysis_compatible = Column(Boolean, default=True)
    
    average_response_time_ms = Column(Float, default=0.0)
    uptime_percentage = Column(Float, default=99.9)
    error_rate_percentage = Column(Float, default=0.1)
    
    integration_config = Column(JSON)
    stealth_config = Column(JSON)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_health_check = Column(DateTime)
