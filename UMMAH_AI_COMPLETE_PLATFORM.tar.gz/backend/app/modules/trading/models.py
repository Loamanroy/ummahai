from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey, JSON, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base

class TradingEngine(Base):
    __tablename__ = "trading_engines"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True)
    name = Column(String, nullable=False)
    engine_type = Column(String, nullable=False)  # "mirror", "arbitrage", "scalping", "grid"
    status = Column(String, default="active")  # "active", "paused", "stopped"
    target_latency_ms = Column(Integer, default=1500)
    current_latency_ms = Column(Integer, default=0)
    success_rate = Column(Float, default=0.0)
    total_trades = Column(Integer, default=0)
    profitable_trades = Column(Integer, default=0)
    total_profit = Column(Float, default=0.0)
    configuration = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    executions = relationship("TradeExecution", back_populates="engine")

class TradeExecution(Base):
    __tablename__ = "trade_executions"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True)
    engine_id = Column(Integer, ForeignKey("trading_engines.id"))
    exchange_id = Column(Integer, nullable=False)
    account_id = Column(Integer, nullable=False)
    order_id = Column(String, nullable=False)
    symbol = Column(String, nullable=False)
    side = Column(String, nullable=False)  # "buy", "sell"
    order_type = Column(String, nullable=False)  # "market", "limit", "stop"
    amount = Column(Float, nullable=False)
    price = Column(Float, nullable=False)
    filled_amount = Column(Float, default=0.0)
    filled_price = Column(Float, default=0.0)
    status = Column(String, default="pending")  # "pending", "filled", "cancelled", "failed"
    latency_ms = Column(Integer)
    profit_loss = Column(Float, default=0.0)
    fees = Column(Float, default=0.0)
    execution_metadata = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    filled_at = Column(DateTime)
    
    engine = relationship("TradingEngine", back_populates="executions")

class ArbitrageOpportunity(Base):
    __tablename__ = "arbitrage_opportunities"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True)
    symbol = Column(String, nullable=False)
    buy_exchange_id = Column(Integer, nullable=False)
    sell_exchange_id = Column(Integer, nullable=False)
    buy_price = Column(Float, nullable=False)
    sell_price = Column(Float, nullable=False)
    profit_percentage = Column(Float, nullable=False)
    profit_amount = Column(Float, nullable=False)
    volume_available = Column(Float, nullable=False)
    confidence_score = Column(Float, nullable=False)
    execution_window_ms = Column(Integer, nullable=False)
    status = Column(String, default="detected")  # "detected", "executing", "executed", "expired"
    executed_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime)

class RiskManagement(Base):
    __tablename__ = "risk_management"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True)
    account_id = Column(Integer, nullable=False)
    max_position_size = Column(Float, nullable=False)
    max_daily_loss = Column(Float, nullable=False)
    max_drawdown = Column(Float, nullable=False)
    current_exposure = Column(Float, default=0.0)
    daily_pnl = Column(Float, default=0.0)
    current_drawdown = Column(Float, default=0.0)
    risk_score = Column(Float, default=0.0)  # 0.0 to 1.0
    is_trading_allowed = Column(Boolean, default=True)
    risk_parameters = Column(JSON)
    last_updated = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class PortfolioBalance(Base):
    __tablename__ = "portfolio_balances"
    
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String(100), nullable=False, index=True)
    account_id = Column(Integer, nullable=False)
    exchange_id = Column(Integer, nullable=False)
    currency = Column(String, nullable=False)
    total_balance = Column(Float, nullable=False)
    available_balance = Column(Float, nullable=False)
    locked_balance = Column(Float, default=0.0)
    usd_value = Column(Float, nullable=False)
    last_updated = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
