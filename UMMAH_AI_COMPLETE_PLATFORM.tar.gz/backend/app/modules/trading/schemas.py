from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime

class TradingEngineBase(BaseModel):
    name: str
    engine_type: str
    target_latency_ms: int = 1500
    configuration: Optional[Dict[str, Any]] = None

class TradingEngineCreate(TradingEngineBase):
    pass

class TradingEngineResponse(TradingEngineBase):
    id: int
    status: str
    current_latency_ms: int
    success_rate: float
    total_trades: int
    profitable_trades: int
    total_profit: float
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class TradeExecutionCreate(BaseModel):
    engine_id: int
    exchange_id: int
    account_id: int
    symbol: str
    side: str
    order_type: str
    amount: float
    price: float
    execution_metadata: Optional[Dict[str, Any]] = None

class TradeExecutionResponse(BaseModel):
    id: int
    engine_id: int
    exchange_id: int
    account_id: int
    order_id: str
    symbol: str
    side: str
    order_type: str
    amount: float
    price: float
    filled_amount: float
    filled_price: float
    status: str
    latency_ms: Optional[int] = None
    profit_loss: float
    fees: float
    execution_metadata: Optional[Dict[str, Any]] = None
    created_at: datetime
    filled_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class ArbitrageOpportunityResponse(BaseModel):
    id: int
    symbol: str
    buy_exchange_id: int
    sell_exchange_id: int
    buy_price: float
    sell_price: float
    profit_percentage: float
    profit_amount: float
    volume_available: float
    confidence_score: float
    execution_window_ms: int
    status: str
    executed_at: Optional[datetime] = None
    created_at: datetime
    expires_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class RiskManagementCreate(BaseModel):
    account_id: int
    max_position_size: float
    max_daily_loss: float
    max_drawdown: float
    risk_parameters: Optional[Dict[str, Any]] = None

class RiskManagementResponse(BaseModel):
    id: int
    account_id: int
    max_position_size: float
    max_daily_loss: float
    max_drawdown: float
    current_exposure: float
    daily_pnl: float
    current_drawdown: float
    risk_score: float
    is_trading_allowed: bool
    risk_parameters: Optional[Dict[str, Any]] = None
    last_updated: datetime
    
    class Config:
        from_attributes = True

class PortfolioBalanceResponse(BaseModel):
    id: int
    account_id: int
    exchange_id: int
    currency: str
    total_balance: float
    available_balance: float
    locked_balance: float
    usd_value: float
    last_updated: datetime
    
    class Config:
        from_attributes = True

class MirrorTradeRequest(BaseModel):
    target_trader_id: str
    symbol: str
    side: str
    amount: float
    max_latency_ms: int = 3000
    copy_percentage: float = 1.0

class ArbitrageRequest(BaseModel):
    symbol: str
    min_profit_percentage: float = 0.1
    max_execution_time_ms: int = 5000
    max_volume: float = 10000.0
