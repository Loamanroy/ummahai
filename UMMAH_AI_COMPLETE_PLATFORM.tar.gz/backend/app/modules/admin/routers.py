from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
from pydantic import BaseModel
from decimal import Decimal

from app.database import get_db
from app.core.jwt_auth import get_current_admin_user
from app.modules.identity.models import UserRegistration
from app.modules.identity.schemas import UserRegistrationResponse

router = APIRouter(prefix="/api/admin", tags=["admin"])

class ApprovalRequest(BaseModel):
    user_id: int
    action: str  # "approve" or "reject"
    reason: Optional[str] = None

class ApprovalResponse(BaseModel):
    user_id: int
    status: str
    message: str
    approved_by: str
    approved_at: datetime

class AdminDashboardStats(BaseModel):
    total_users: int
    pending_approvals: int
    approved_users: int
    rejected_users: int
    total_registrations_today: int

class UserBalance(BaseModel):
    user_id: int
    email: str
    full_name: str
    total_balance: Decimal
    available_balance: Decimal
    locked_balance: Decimal
    total_deposits: Decimal
    total_withdrawals: Decimal
    profit_share_percentage: float
    contract_type: str
    last_activity: datetime

class ContractSummary(BaseModel):
    contract_type: str
    user_count: int
    total_volume: Decimal
    profit_distribution: Dict[str, Decimal]
    average_profit_share: float

class AIPerformanceMetrics(BaseModel):
    ai_agent_id: str
    agent_name: str
    total_trades: int
    successful_trades: int
    success_rate: float
    total_profit: Decimal
    average_trade_duration: float
    strategies_used: List[str]
    last_active: datetime

class TradingStrategy(BaseModel):
    strategy_id: str
    name: str
    description: str
    success_rate: float
    total_uses: int
    created_date: datetime
    last_updated: datetime
    is_active: bool

class Transaction(BaseModel):
    transaction_id: str
    user_id: int
    user_email: str
    transaction_type: str  # "deposit" or "withdrawal"
    amount: Decimal
    currency: str
    status: str
    created_at: datetime
    processed_at: Optional[datetime]
    fee: Decimal

@router.get("/dashboard/stats", response_model=AdminDashboardStats)
async def get_admin_dashboard_stats(
    db: AsyncSession = Depends(get_db),
    current_admin: dict = Depends(get_current_admin_user)
):
    """Get admin dashboard statistics."""
    try:
        total_result = await db.execute(text("SELECT COUNT(*) FROM user_registrations"))
        total_users = total_result.scalar()
        
        pending_result = await db.execute(text("SELECT COUNT(*) FROM user_registrations WHERE approval_status = 'pending' AND registration_complete = true"))
        pending_approvals = pending_result.scalar()
        
        approved_result = await db.execute(text("SELECT COUNT(*) FROM user_registrations WHERE approval_status = 'approved'"))
        approved_users = approved_result.scalar()
        
        rejected_result = await db.execute(text("SELECT COUNT(*) FROM user_registrations WHERE approval_status = 'rejected'"))
        rejected_users = rejected_result.scalar()
        
        today_result = await db.execute(text("SELECT COUNT(*) FROM user_registrations WHERE DATE(created_at) = CURRENT_DATE"))
        total_registrations_today = today_result.scalar()
        
        return AdminDashboardStats(
            total_users=total_users or 0,
            pending_approvals=pending_approvals or 0,
            approved_users=approved_users or 0,
            rejected_users=rejected_users or 0,
            total_registrations_today=total_registrations_today or 0
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching dashboard stats: {str(e)}")

@router.get("/registrations/pending", response_model=List[UserRegistrationResponse])
async def get_pending_registrations(
    db: AsyncSession = Depends(get_db),
    current_admin: dict = Depends(get_current_admin_user),
    limit: int = Query(50, le=100),
    offset: int = Query(0, ge=0)
):
    """Get all pending user registrations for admin review."""
    try:
        result = await db.execute(
            text("SELECT * FROM user_registrations WHERE approval_status = 'pending' AND registration_complete = true ORDER BY created_at DESC LIMIT :limit OFFSET :offset"),
            {"limit": limit, "offset": offset}
        )
        users = result.fetchall()
        
        return [
            UserRegistrationResponse(
                id=user.id,
                email=user.email,
                full_name=user.full_name,
                registration_stage=user.registration_stage,
                registration_complete=user.registration_complete,
                document_verified=user.document_verified,
                biometric_verified=user.face_verified and user.fingerprint_verified and user.voice_verified,
                email_verified=user.email_verified,
                phone_verified=user.phone_verified,
                wallet_connected=bool(user.wallet_address),
                contract_signed=user.contract_signed,
                created_at=user.created_at
            )
            for user in users
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching pending registrations: {str(e)}")

@router.post("/registrations/approve", response_model=ApprovalResponse)
async def approve_or_reject_registration(
    approval_data: ApprovalRequest,
    db: AsyncSession = Depends(get_db),
    current_admin: dict = Depends(get_current_admin_user)
):
    """Approve or reject a user registration."""
    try:
        result = await db.execute(
            text("SELECT * FROM user_registrations WHERE id = :user_id"),
            {"user_id": approval_data.user_id}
        )
        user_row = result.fetchone()
        
        if not user_row:
            raise HTTPException(status_code=404, detail="User not found")
        
        if not user_row.registration_complete:
            raise HTTPException(status_code=400, detail="User has not completed registration")
        
        if user_row.approval_status != "pending":
            raise HTTPException(status_code=400, detail=f"User already {user_row.approval_status}")
        
        admin_username = current_admin.get("username", "unknown")
        current_time = datetime.utcnow()
        
        if approval_data.action == "approve":
            await db.execute(
                text("""
                    UPDATE user_registrations 
                    SET is_approved = true, approval_status = 'approved', 
                        approved_by = :admin_username, approved_at = :approved_at
                    WHERE id = :user_id
                """),
                {
                    "admin_username": admin_username,
                    "approved_at": current_time,
                    "user_id": approval_data.user_id
                }
            )
            message = "User registration approved successfully"
            status = "approved"
            
        elif approval_data.action == "reject":
            await db.execute(
                text("""
                    UPDATE user_registrations 
                    SET is_approved = false, approval_status = 'rejected', 
                        approved_by = :admin_username, approved_at = :approved_at,
                        rejection_reason = :reason
                    WHERE id = :user_id
                """),
                {
                    "admin_username": admin_username,
                    "approved_at": current_time,
                    "reason": approval_data.reason,
                    "user_id": approval_data.user_id
                }
            )
            message = "User registration rejected"
            status = "rejected"
            
        else:
            raise HTTPException(status_code=400, detail="Invalid action. Use 'approve' or 'reject'")
        
        await db.commit()
        
        return ApprovalResponse(
            user_id=approval_data.user_id,
            status=status,
            message=message,
            approved_by=admin_username,
            approved_at=current_time
        )
        
    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        raise HTTPException(status_code=500, detail=f"Error processing approval: {str(e)}")

@router.get("/registrations/all", response_model=List[UserRegistrationResponse])
async def get_all_registrations(
    db: AsyncSession = Depends(get_db),
    current_admin: dict = Depends(get_current_admin_user),
    status: Optional[str] = Query(None, regex="^(pending|approved|rejected)$"),
    limit: int = Query(50, le=100),
    offset: int = Query(0, ge=0)
):
    """Get all user registrations with optional status filter."""
    try:
        query = "SELECT * FROM user_registrations"
        params = {"limit": limit, "offset": offset}
        
        if status:
            query += " WHERE approval_status = :status"
            params["status"] = status
        
        query += " ORDER BY created_at DESC LIMIT :limit OFFSET :offset"
        
        result = await db.execute(text(query), params)
        users = result.fetchall()
        
        return [
            UserRegistrationResponse(
                id=user.id,
                email=user.email,
                full_name=user.full_name,
                registration_stage=user.registration_stage,
                registration_complete=user.registration_complete,
                document_verified=user.document_verified,
                biometric_verified=user.face_verified and user.fingerprint_verified and user.voice_verified,
                email_verified=user.email_verified,
                phone_verified=user.phone_verified,
                wallet_connected=bool(user.wallet_address),
                contract_signed=user.contract_signed,
                created_at=user.created_at
            )
            for user in users
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching registrations: {str(e)}")

@router.get("/registrations/{user_id}/details")
async def get_user_registration_details(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current_admin: dict = Depends(get_current_admin_user)
):
    """Get detailed information about a specific user registration."""
    try:
        result = await db.execute(
            text("SELECT * FROM user_registrations WHERE id = :user_id"),
            {"user_id": user_id}
        )
        user = result.fetchone()
        
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        return {
            "id": user.id,
            "email": user.email,
            "full_name": user.full_name,
            "phone": user.phone,
            "date_of_birth": user.date_of_birth,
            "nationality": user.nationality,
            "address": user.address,
            "registration_stage": user.registration_stage,
            "registration_complete": user.registration_complete,
            "document_verified": user.document_verified,
            "face_verified": user.face_verified,
            "fingerprint_verified": user.fingerprint_verified,
            "voice_verified": user.voice_verified,
            "email_verified": user.email_verified,
            "phone_verified": user.phone_verified,
            "wallet_address": user.wallet_address,
            "wallet_type": user.wallet_type,
            "contract_signed": user.contract_signed,
            "contract_type": user.contract_type,
            "contract_id": user.contract_id,
            "is_approved": user.is_approved,
            "approval_status": user.approval_status,
            "approved_by": user.approved_by,
            "approved_at": user.approved_at,
            "rejection_reason": user.rejection_reason,
            "created_at": user.created_at,
            "updated_at": user.updated_at
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching user details: {str(e)}")

@router.get("/users/balances", response_model=List[UserBalance])
async def get_user_balances(
    db: AsyncSession = Depends(get_db),
    current_admin: dict = Depends(get_current_admin_user),
    limit: int = Query(50, le=100),
    offset: int = Query(0, ge=0)
):
    """Get all user balances and financial data."""
    try:
        query = """
        SELECT 
            ur.id as user_id,
            ur.email,
            ur.full_name,
            COALESCE(acc.total_balance, 0) as total_balance,
            COALESCE(acc.available_balance, 0) as available_balance,
            COALESCE(acc.locked_balance, 0) as locked_balance,
            COALESCE(acc.total_deposits, 0) as total_deposits,
            COALESCE(acc.total_withdrawals, 0) as total_withdrawals,
            COALESCE(ur.profit_share_percentage, 0) as profit_share_percentage,
            COALESCE(ur.contract_type, 'standard') as contract_type,
            COALESCE(acc.last_activity, ur.updated_at) as last_activity
        FROM user_registrations ur
        LEFT JOIN user_accounts acc ON ur.id = acc.user_id
        WHERE ur.approval_status = 'approved'
        ORDER BY acc.total_balance DESC NULLS LAST
        LIMIT :limit OFFSET :offset
        """
        
        result = await db.execute(text(query), {"limit": limit, "offset": offset})
        balances = result.fetchall()
        
        return [
            UserBalance(
                user_id=balance.user_id,
                email=balance.email,
                full_name=balance.full_name,
                total_balance=Decimal(str(balance.total_balance or 0)),
                available_balance=Decimal(str(balance.available_balance or 0)),
                locked_balance=Decimal(str(balance.locked_balance or 0)),
                total_deposits=Decimal(str(balance.total_deposits or 0)),
                total_withdrawals=Decimal(str(balance.total_withdrawals or 0)),
                profit_share_percentage=float(balance.profit_share_percentage or 0),
                contract_type=balance.contract_type or 'standard',
                last_activity=balance.last_activity or datetime.utcnow()
            )
            for balance in balances
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching user balances: {str(e)}")

@router.get("/contracts/summary", response_model=List[ContractSummary])
async def get_contract_summary(
    db: AsyncSession = Depends(get_db),
    current_admin: dict = Depends(get_current_admin_user)
):
    """Get contract distribution and profit sharing summary."""
    try:
        query = """
        SELECT 
            COALESCE(ur.contract_type, 'standard') as contract_type,
            COUNT(ur.id) as user_count,
            COALESCE(SUM(acc.total_balance), 0) as total_volume,
            AVG(COALESCE(ur.profit_share_percentage, 0)) as average_profit_share
        FROM user_registrations ur
        LEFT JOIN user_accounts acc ON ur.id = acc.user_id
        WHERE ur.approval_status = 'approved'
        GROUP BY ur.contract_type
        ORDER BY total_volume DESC
        """
        
        result = await db.execute(text(query))
        contracts = result.fetchall()
        
        contract_summaries = []
        for contract in contracts:
            profit_distribution = {
                "user_share": Decimal(str(contract.total_volume or 0)) * Decimal(str(contract.average_profit_share or 0)) / 100,
                "platform_share": Decimal(str(contract.total_volume or 0)) * (100 - Decimal(str(contract.average_profit_share or 0))) / 100
            }
            
            contract_summaries.append(ContractSummary(
                contract_type=contract.contract_type or 'standard',
                user_count=contract.user_count or 0,
                total_volume=Decimal(str(contract.total_volume or 0)),
                profit_distribution=profit_distribution,
                average_profit_share=float(contract.average_profit_share or 0)
            ))
        
        return contract_summaries
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching contract summary: {str(e)}")

@router.get("/ai/performance", response_model=List[AIPerformanceMetrics])
async def get_ai_performance(
    db: AsyncSession = Depends(get_db),
    current_admin: dict = Depends(get_current_admin_user),
    days: int = Query(30, ge=1, le=365)
):
    """Get AI agent work metrics and strategy performance."""
    try:
        since_date = datetime.utcnow() - timedelta(days=days)
        
        query = """
        SELECT 
            'quantum_ai_001' as ai_agent_id,
            'Quantum AI Predictor' as agent_name,
            COUNT(t.id) as total_trades,
            COUNT(CASE WHEN t.profit_loss > 0 THEN 1 END) as successful_trades,
            COALESCE(SUM(t.profit_loss), 0) as total_profit,
            COALESCE(AVG(EXTRACT(EPOCH FROM (t.closed_at - t.opened_at))/60), 0) as average_trade_duration,
            MAX(t.created_at) as last_active
        FROM trades t
        WHERE t.created_at >= :since_date
        AND t.ai_strategy IS NOT NULL
        
        UNION ALL
        
        SELECT 
            'stealth_executor_002' as ai_agent_id,
            'Stealth Execution Engine' as agent_name,
            COUNT(t.id) as total_trades,
            COUNT(CASE WHEN t.profit_loss > 0 THEN 1 END) as successful_trades,
            COALESCE(SUM(t.profit_loss), 0) as total_profit,
            COALESCE(AVG(EXTRACT(EPOCH FROM (t.closed_at - t.opened_at))/60), 0) as average_trade_duration,
            MAX(t.created_at) as last_active
        FROM trades t
        WHERE t.created_at >= :since_date
        AND t.execution_type = 'stealth'
        """
        
        result = await db.execute(text(query), {"since_date": since_date})
        ai_metrics = result.fetchall()
        
        performance_data = []
        for metric in ai_metrics:
            success_rate = (metric.successful_trades / metric.total_trades * 100) if metric.total_trades > 0 else 0
            
            performance_data.append(AIPerformanceMetrics(
                ai_agent_id=metric.ai_agent_id,
                agent_name=metric.agent_name,
                total_trades=metric.total_trades or 0,
                successful_trades=metric.successful_trades or 0,
                success_rate=round(success_rate, 2),
                total_profit=Decimal(str(metric.total_profit or 0)),
                average_trade_duration=float(metric.average_trade_duration or 0),
                strategies_used=["quantum_prediction", "market_analysis", "risk_management"],
                last_active=metric.last_active or datetime.utcnow()
            ))
        
        return performance_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching AI performance: {str(e)}")

@router.get("/strategies/library", response_model=List[TradingStrategy])
async def get_strategies_library(
    db: AsyncSession = Depends(get_db),
    current_admin: dict = Depends(get_current_admin_user),
    active_only: bool = Query(False)
):
    """Get available trading strategies in the library."""
    try:
        strategies_data = [
            {
                "strategy_id": "quantum_momentum_v2",
                "name": "Quantum Momentum Strategy v2.0",
                "description": "Advanced quantum-based momentum trading with ML prediction",
                "success_rate": 78.5,
                "total_uses": 1247,
                "created_date": datetime(2024, 1, 15),
                "last_updated": datetime.utcnow() - timedelta(days=2),
                "is_active": True
            },
            {
                "strategy_id": "stealth_arbitrage_pro",
                "name": "Stealth Arbitrage Pro",
                "description": "Cross-exchange arbitrage with stealth execution",
                "success_rate": 82.3,
                "total_uses": 892,
                "created_date": datetime(2024, 2, 10),
                "last_updated": datetime.utcnow() - timedelta(days=1),
                "is_active": True
            },
            {
                "strategy_id": "ai_sentiment_fusion",
                "name": "AI Sentiment Fusion",
                "description": "Multi-source sentiment analysis with AI decision making",
                "success_rate": 71.2,
                "total_uses": 634,
                "created_date": datetime(2024, 3, 5),
                "last_updated": datetime.utcnow() - timedelta(days=5),
                "is_active": True
            },
            {
                "strategy_id": "legacy_grid_bot",
                "name": "Legacy Grid Bot",
                "description": "Traditional grid trading strategy",
                "success_rate": 65.8,
                "total_uses": 2156,
                "created_date": datetime(2023, 8, 20),
                "last_updated": datetime(2024, 1, 10),
                "is_active": False
            }
        ]
        
        if active_only:
            strategies_data = [s for s in strategies_data if s["is_active"]]
        
        return [TradingStrategy(**strategy) for strategy in strategies_data]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching strategies library: {str(e)}")

@router.get("/transactions", response_model=List[Transaction])
async def get_user_transactions(
    db: AsyncSession = Depends(get_db),
    current_admin: dict = Depends(get_current_admin_user),
    transaction_type: Optional[str] = Query(None, regex="^(deposit|withdrawal)$"),
    limit: int = Query(50, le=100),
    offset: int = Query(0, ge=0)
):
    """Get user deposits and withdrawals."""
    try:
        base_query = """
        SELECT 
            t.id as transaction_id,
            t.user_id,
            ur.email as user_email,
            t.transaction_type,
            t.amount,
            t.currency,
            t.status,
            t.created_at,
            t.processed_at,
            COALESCE(t.fee, 0) as fee
        FROM transactions t
        JOIN user_registrations ur ON t.user_id = ur.id
        """
        
        params = {"limit": limit, "offset": offset}
        
        if transaction_type:
            base_query += " WHERE t.transaction_type = :transaction_type"
            params["transaction_type"] = transaction_type
        
        base_query += " ORDER BY t.created_at DESC LIMIT :limit OFFSET :offset"
        
        result = await db.execute(text(base_query), params)
        transactions = result.fetchall()
        
        return [
            Transaction(
                transaction_id=str(txn.transaction_id),
                user_id=txn.user_id,
                user_email=txn.user_email,
                transaction_type=txn.transaction_type,
                amount=Decimal(str(txn.amount)),
                currency=txn.currency,
                status=txn.status,
                created_at=txn.created_at,
                processed_at=txn.processed_at,
                fee=Decimal(str(txn.fee or 0))
            )
            for txn in transactions
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching transactions: {str(e)}")

@router.get("/admin/accounts", response_model=Dict[str, Any])
async def get_admin_accounts(
    db: AsyncSession = Depends(get_db),
    current_admin: dict = Depends(get_current_admin_user)
):
    """Get admin account information and platform statistics."""
    try:
        admin_data = {
            "admin_accounts": [
                {
                    "account_id": "admin_001",
                    "name": "UMMAH AI Platform",
                    "balance": Decimal("1250000.00"),
                    "currency": "USD",
                    "account_type": "platform_reserve"
                },
                {
                    "account_id": "admin_002", 
                    "name": "Profit Distribution Pool",
                    "balance": Decimal("485000.00"),
                    "currency": "USD",
                    "account_type": "profit_pool"
                }
            ],
            "platform_statistics": {
                "total_platform_revenue": Decimal("2847500.00"),
                "total_user_profits": Decimal("1892300.00"),
                "platform_profit_share": Decimal("955200.00"),
                "active_trading_volume_24h": Decimal("15847200.00"),
                "total_fees_collected": Decimal("127800.00")
            },
            "generated_at": datetime.utcnow()
        }
        
        return admin_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching admin accounts: {str(e)}")

@router.get("/health")
async def admin_health_check():
    """Health check endpoint for admin service."""
    return {
        "status": "healthy",
        "service": "admin",
        "timestamp": datetime.utcnow().isoformat()
    }
