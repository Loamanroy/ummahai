"""
Authentication Router

Enhanced authentication endpoints with JWT refresh tokens,
role-based access control, and logout functionality.
"""

from fastapi import APIRouter, HTTPException, status, Depends
from fastapi.security import HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from app.core.jwt_auth import jwt_manager, get_current_user, security

router = APIRouter(prefix="/api/v1/auth", tags=["authentication"])

class LoginRequest(BaseModel):
    username: str
    password: str

class LoginResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str
    expires_in: int
    user_role: str

class RefreshTokenRequest(BaseModel):
    refresh_token: str

class RefreshTokenResponse(BaseModel):
    access_token: str
    token_type: str

class LogoutResponse(BaseModel):
    message: str
    success: bool

class UserRegistration(BaseModel):
    username: str
    email: str
    password: str
    role: Optional[str] = "user"

@router.post("/login", response_model=LoginResponse)
async def login(login_data: LoginRequest):
    """
    Enhanced login endpoint with JWT access and refresh tokens.
    
    Returns both access token (short-lived) and refresh token (long-lived)
    for secure authentication flow.
    """
    demo_users = {
        "admin": {"password": "admin123", "role": "admin", "user_id": 1},
        "trader": {"password": "trader123", "role": "trader", "user_id": 2},
        "user": {"password": "user123", "role": "user", "user_id": 3}
    }
    
    user = demo_users.get(login_data.username)
    if not user or not jwt_manager.verify_password(login_data.password, jwt_manager.hash_password(user["password"])):
        if not user or user["password"] != login_data.password:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid username or password"
            )
    
    token_data = {
        "sub": login_data.username,
        "user_id": user["user_id"],
        "username": login_data.username,
        "role": user["role"]
    }
    
    access_token = jwt_manager.create_access_token(token_data)
    refresh_token = jwt_manager.create_refresh_token(token_data)
    
    return LoginResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",
        expires_in=jwt_manager.access_token_expire_minutes * 60,
        user_role=user["role"]
    )

@router.post("/refresh", response_model=RefreshTokenResponse)
async def refresh_token(refresh_data: RefreshTokenRequest):
    """
    Refresh access token using refresh token.
    
    Allows clients to get new access tokens without re-authentication
    when the access token expires.
    """
    try:
        result = jwt_manager.refresh_access_token(refresh_data.refresh_token)
        return RefreshTokenResponse(**result)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not refresh token"
        )

@router.post("/logout", response_model=LogoutResponse)
async def logout(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """
    Logout endpoint with token blacklisting.
    
    Adds the current access token to blacklist to prevent further use.
    In a complete implementation, would also blacklist the refresh token.
    """
    token = credentials.credentials
    
    try:
        jwt_manager.verify_token(token)
        
        success = jwt_manager.blacklist_token(token)
        
        return LogoutResponse(
            message="Successfully logged out" if success else "Logged out (blacklisting unavailable)",
            success=True
        )
    except HTTPException:
        return LogoutResponse(
            message="Logged out",
            success=True
        )

@router.get("/me")
async def get_current_user_info(current_user: dict = Depends(get_current_user)):
    """
    Get current authenticated user information.
    
    Protected endpoint that requires valid JWT access token.
    Returns user information from token payload.
    """
    return {
        "username": current_user.get("username"),
        "user_id": current_user.get("user_id"),
        "role": current_user.get("role"),
        "token_type": current_user.get("type"),
        "issued_at": datetime.fromtimestamp(current_user.get("iat", 0)).isoformat(),
        "expires_at": datetime.fromtimestamp(current_user.get("exp", 0)).isoformat()
    }

@router.post("/register", response_model=dict)
async def register_user(user_data: UserRegistration):
    """
    User registration endpoint.
    
    In a real implementation, this would:
    1. Validate user data
    2. Check if username/email already exists
    3. Hash password securely
    4. Store user in database
    5. Send verification email
    """
    hashed_password = jwt_manager.hash_password(user_data.password)
    
    return {
        "message": "User registered successfully",
        "username": user_data.username,
        "role": user_data.role,
        "success": True
    }

@router.get("/validate-token")
async def validate_token(current_user: dict = Depends(get_current_user)):
    """
    Token validation endpoint.
    
    Returns token validity status and user information.
    Useful for frontend applications to check token status.
    """
    return {
        "valid": True,
        "user": current_user,
        "message": "Token is valid"
    }
