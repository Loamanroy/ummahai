from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List
from app.database import get_db
from app.modules.stealth.models import StealthOperation, ProxyConfiguration, WalletMixer, TransactionObfuscation, AnonymityMetrics
from app.modules.stealth.schemas import (
    StealthOperationCreate, StealthOperationResponse, ProxyConfigurationCreate, ProxyConfigurationResponse,
    WalletMixerCreate, WalletMixerResponse, TransactionObfuscationResponse, AnonymityMetricsResponse,
    ProfitRoutingRequest, WalletMixingRequest
)
from app.services.stealth_service import StealthService

router = APIRouter(prefix="/api/stealth", tags=["stealth"])
stealth_service = StealthService()

@router.post("/operations", response_model=StealthOperationResponse)
async def create_stealth_operation(
    operation: StealthOperationCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new stealth operation."""
    return await stealth_service.create_operation(db, operation)

@router.get("/operations", response_model=List[StealthOperationResponse])
async def get_stealth_operations(
    status: str = None,
    operation_type: str = None,
    db: AsyncSession = Depends(get_db)
):
    """Get stealth operations with filtering."""
    return await stealth_service.get_operations(db, status, operation_type)

@router.post("/profit-routing")
async def route_profits(
    request: ProfitRoutingRequest,
    db: AsyncSession = Depends(get_db)
):
    """Route profits through obfuscated channels."""
    return await stealth_service.route_profits(db, request)

@router.post("/wallet-mixing")
async def mix_wallet_funds(
    request: WalletMixingRequest,
    db: AsyncSession = Depends(get_db)
):
    """Mix wallet funds for anonymity."""
    return await stealth_service.mix_wallet_funds(db, request)

@router.post("/proxies", response_model=ProxyConfigurationResponse)
async def create_proxy_configuration(
    proxy: ProxyConfigurationCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new proxy configuration."""
    return await stealth_service.create_proxy_config(db, proxy)

@router.get("/proxies", response_model=List[ProxyConfigurationResponse])
async def get_proxy_configurations(
    account_id: int = None,
    active_only: bool = True,
    db: AsyncSession = Depends(get_db)
):
    """Get proxy configurations."""
    return await stealth_service.get_proxy_configs(db, account_id, active_only)

@router.post("/proxies/{proxy_id}/rotate")
async def rotate_proxy(
    proxy_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Rotate proxy configuration to new endpoint."""
    return await stealth_service.rotate_proxy(db, proxy_id)

@router.post("/proxies/{proxy_id}/test")
async def test_proxy(
    proxy_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Test proxy connection and performance."""
    return await stealth_service.test_proxy_connection(db, proxy_id)

@router.get("/wallet-mixers", response_model=List[WalletMixerResponse])
async def get_wallet_mixers(
    account_id: int = None,
    status: str = None,
    db: AsyncSession = Depends(get_db)
):
    """Get wallet mixers with filtering."""
    return await stealth_service.get_wallet_mixers(db, account_id, status)

@router.post("/wallet-mixers", response_model=WalletMixerResponse)
async def create_wallet_mixer(
    mixer: WalletMixerCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new wallet mixer."""
    return await stealth_service.create_wallet_mixer(db, mixer)

@router.get("/transactions/obfuscated", response_model=List[TransactionObfuscationResponse])
async def get_obfuscated_transactions(
    account_id: int = None,
    limit: int = 100,
    db: AsyncSession = Depends(get_db)
):
    """Get obfuscated transactions."""
    return await stealth_service.get_obfuscated_transactions(db, account_id, limit)

@router.get("/anonymity-metrics/{account_id}", response_model=AnonymityMetricsResponse)
async def get_anonymity_metrics(
    account_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Get anonymity metrics for account."""
    return await stealth_service.get_anonymity_metrics(db, account_id)

@router.post("/paranoia-mode/activate")
async def activate_paranoia_mode(
    account_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Activate Paranoia Mode for maximum stealth."""
    return await stealth_service.activate_paranoia_mode(db, account_id)

@router.post("/paranoia-mode/deactivate")
async def deactivate_paranoia_mode(
    account_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Deactivate Paranoia Mode."""
    return await stealth_service.deactivate_paranoia_mode(db, account_id)

@router.get("/cerebellum-status")
async def get_cerebellum_status():
    """Get CerebellumBot vX entity status."""
    from app.services.cerebellum_bot import cerebellum_bot
    return await cerebellum_bot.get_entity_status()

@router.post("/cerebellum/awaken")
async def awaken_cerebellum():
    """Awaken CerebellumBot vX entity."""
    from app.services.cerebellum_bot import cerebellum_bot
    await cerebellum_bot.awaken()
    return {"status": "CerebellumBot vX awakened", "entity_id": cerebellum_bot.entity_id}

@router.get("/stealth-score/{account_id}")
async def calculate_stealth_score(
    account_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Calculate comprehensive stealth score for account."""
    return await stealth_service.calculate_stealth_score(db, account_id)

@router.post("/ip-rotation/enable")
async def enable_ip_rotation(
    account_id: int,
    rotation_interval_minutes: int = 15,
    db: AsyncSession = Depends(get_db)
):
    """Enable automatic IP rotation for account."""
    return await stealth_service.enable_ip_rotation(db, account_id, rotation_interval_minutes)

@router.post("/tor-routing/enable")
async def enable_tor_routing(
    account_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Enable TOR routing for account."""
    return await stealth_service.enable_tor_routing(db, account_id)

@router.get("/detection-risk/{account_id}")
async def get_detection_risk(
    account_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Get detection risk assessment for account."""
    return await stealth_service.assess_detection_risk(db, account_id)

@router.post("/biometric/register")
async def register_biometric_template(
    user_id: str,
    biometric_type: str,
    template_data: str,  # Base64 encoded biometric data
    db: AsyncSession = Depends(get_db)
):
    """Register biometric template for user."""
    from app.services.biometric_auth_service import biometric_auth_service
    import base64
    
    try:
        decoded_data = base64.b64decode(template_data)
        template_id = await biometric_auth_service.register_biometric_template(
            user_id, biometric_type, decoded_data
        )
        return {"template_id": template_id, "status": "registered"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/biometric/authenticate")
async def authenticate_biometric(
    user_id: str,
    biometric_type: str,
    sample_data: str,  # Base64 encoded biometric sample
    session_id: str = None,
    db: AsyncSession = Depends(get_db)
):
    """Authenticate user using biometric data."""
    from app.services.biometric_auth_service import biometric_auth_service
    import base64
    
    try:
        decoded_sample = base64.b64decode(sample_data)
        result = await biometric_auth_service.authenticate_biometric(
            user_id, biometric_type, decoded_sample, session_id
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/biometric/analytics")
async def get_biometric_analytics():
    """Get biometric authentication analytics."""
    from app.services.biometric_auth_service import biometric_auth_service
    return await biometric_auth_service.get_biometric_analytics()

@router.get("/status")
async def get_stealth_status():
    """Get overall stealth system status."""
    import os
    from datetime import datetime
    
    paranoia_enabled = os.getenv('PARANOIA', 'false').lower() == 'true'
    ephemeral_mode = os.getenv('EPHEMERAL_MODE', 'false').lower() == 'true'
    tor_enabled = os.getenv('TOR_ENABLED', 'false').lower() == 'true'
    vpn_chain_enabled = os.getenv('VPN_CHAIN_ENABLED', 'false').lower() == 'true'
    
    return {
        "stealth_system": "operational",
        "paranoia_mode": {
            "paranoia_enabled": paranoia_enabled,
            "ephemeral_mode": ephemeral_mode,
            "session_id": "static_session",
            "uptime_seconds": 300,
            "remaining_seconds": 300 if ephemeral_mode else None,
            "tor_enabled": tor_enabled,
            "vpn_chain_enabled": vpn_chain_enabled,
            "metadata_encryption": True,
            "ephemeral_data_count": 0,
            "encrypted_logs_count": 0
        },
        "services": {
            "ip_masking": "active",
            "geo_routing": "active", 
            "human_emulation": "active",
            "order_obfuscation": "active",
            "metadata_encryption": "active",
            "biometric_auth": "active",
            "zkp_integration": "standby"
        },
        "threat_level": "low",
        "active_operations": 0,
        "anonymity_score": 0.95,
        "timestamp": datetime.utcnow().isoformat()
    }
