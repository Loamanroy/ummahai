from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey, JSON, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base

class StealthOperation(Base):
    __tablename__ = "stealth_operations"
    
    id = Column(Integer, primary_key=True, index=True)
    operation_type = Column(String, nullable=False)  # "profit_routing", "wallet_mixing", "ip_rotation"
    status = Column(String, default="active")  # "active", "paused", "completed"
    source_account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    target_account_id = Column(Integer, ForeignKey("accounts.id"))
    amount = Column(Float, nullable=False)
    obfuscation_level = Column(Integer, default=5)  # 1-10 scale
    routing_path = Column(JSON)  # Array of intermediate wallets/exchanges
    completion_percentage = Column(Float, default=0.0)
    estimated_completion = Column(DateTime)
    operation_metadata = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)
    
    source_account = relationship("Account", foreign_keys=[source_account_id])
    target_account = relationship("Account", foreign_keys=[target_account_id])

class ProxyConfiguration(Base):
    __tablename__ = "proxy_configurations"
    
    id = Column(Integer, primary_key=True, index=True)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    proxy_type = Column(String, nullable=False)  # "tor", "vpn", "residential", "datacenter"
    proxy_address = Column(String, nullable=False)
    proxy_port = Column(Integer, nullable=False)
    username = Column(String)
    password_encrypted = Column(Text)
    country = Column(String)
    is_active = Column(Boolean, default=True)
    rotation_interval_minutes = Column(Integer, default=30)
    last_rotation = Column(DateTime)
    success_rate = Column(Float, default=1.0)
    latency_ms = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

class WalletMixer(Base):
    __tablename__ = "wallet_mixers"
    
    id = Column(Integer, primary_key=True, index=True)
    mixer_name = Column(String, nullable=False)
    mixer_type = Column(String, nullable=False)  # "tornado_cash", "custom", "coin_join"
    supported_currencies = Column(JSON)
    mixing_fee_percentage = Column(Float, default=0.1)
    min_amount = Column(Float, default=0.01)
    max_amount = Column(Float, default=1000.0)
    anonymity_score = Column(Float, default=0.9)  # 0.0 to 1.0
    is_active = Column(Boolean, default=True)
    api_endpoint = Column(String)
    configuration = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)

class TransactionObfuscation(Base):
    __tablename__ = "transaction_obfuscations"
    
    id = Column(Integer, primary_key=True, index=True)
    original_transaction_id = Column(String, nullable=False)
    obfuscated_transaction_id = Column(String, nullable=False)
    obfuscation_method = Column(String, nullable=False)  # "splitting", "timing", "routing", "mixing"
    original_amount = Column(Float, nullable=False)
    visible_amount = Column(Float, nullable=False)
    hidden_amount = Column(Float, nullable=False)
    split_count = Column(Integer, default=1)
    delay_minutes = Column(Integer, default=0)
    success = Column(Boolean, default=False)
    detection_risk = Column(Float, default=0.0)  # 0.0 to 1.0
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)

class AnonymityMetrics(Base):
    __tablename__ = "anonymity_metrics"
    
    id = Column(Integer, primary_key=True, index=True)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    anonymity_score = Column(Float, nullable=False)  # 0.0 to 1.0
    transaction_count = Column(Integer, default=0)
    obfuscated_transactions = Column(Integer, default=0)
    proxy_changes = Column(Integer, default=0)
    wallet_mixes = Column(Integer, default=0)
    detection_attempts = Column(Integer, default=0)
    successful_detections = Column(Integer, default=0)
    risk_level = Column(String, default="low")  # "low", "medium", "high"
    last_updated = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
