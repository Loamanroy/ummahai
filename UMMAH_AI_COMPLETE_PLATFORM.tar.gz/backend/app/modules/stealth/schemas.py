from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime

class StealthOperationCreate(BaseModel):
    operation_type: str
    source_account_id: int
    target_account_id: Optional[int] = None
    amount: float
    obfuscation_level: int = 5
    metadata: Optional[Dict[str, Any]] = None

class StealthOperationResponse(BaseModel):
    id: int
    operation_type: str
    status: str
    source_account_id: int
    target_account_id: Optional[int] = None
    amount: float
    obfuscation_level: int
    routing_path: Optional[List[Dict[str, Any]]] = None
    completion_percentage: float
    estimated_completion: Optional[datetime] = None
    metadata: Optional[Dict[str, Any]] = None
    created_at: datetime
    completed_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class ProxyConfigurationCreate(BaseModel):
    account_id: int
    proxy_type: str
    proxy_address: str
    proxy_port: int
    username: Optional[str] = None
    password: Optional[str] = None
    country: Optional[str] = None
    rotation_interval_minutes: int = 30

class ProxyConfigurationResponse(BaseModel):
    id: int
    account_id: int
    proxy_type: str
    proxy_address: str
    proxy_port: int
    username: Optional[str] = None
    country: Optional[str] = None
    is_active: bool
    rotation_interval_minutes: int
    last_rotation: Optional[datetime] = None
    success_rate: float
    latency_ms: int
    created_at: datetime
    
    class Config:
        from_attributes = True

class WalletMixerCreate(BaseModel):
    mixer_name: str
    mixer_type: str
    supported_currencies: List[str]
    mixing_fee_percentage: float = 0.1
    min_amount: float = 0.01
    max_amount: float = 1000.0
    api_endpoint: Optional[str] = None
    configuration: Optional[Dict[str, Any]] = None

class WalletMixerResponse(BaseModel):
    id: int
    mixer_name: str
    mixer_type: str
    supported_currencies: List[str]
    mixing_fee_percentage: float
    min_amount: float
    max_amount: float
    anonymity_score: float
    is_active: bool
    api_endpoint: Optional[str] = None
    configuration: Optional[Dict[str, Any]] = None
    created_at: datetime
    
    class Config:
        from_attributes = True

class TransactionObfuscationResponse(BaseModel):
    id: int
    original_transaction_id: str
    obfuscated_transaction_id: str
    obfuscation_method: str
    original_amount: float
    visible_amount: float
    hidden_amount: float
    split_count: int
    delay_minutes: int
    success: bool
    detection_risk: float
    created_at: datetime
    completed_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class AnonymityMetricsResponse(BaseModel):
    id: int
    account_id: int
    anonymity_score: float
    transaction_count: int
    obfuscated_transactions: int
    proxy_changes: int
    wallet_mixes: int
    detection_attempts: int
    successful_detections: int
    risk_level: str
    last_updated: datetime
    
    class Config:
        from_attributes = True

class ProfitRoutingRequest(BaseModel):
    source_account_id: int
    amount: float
    target_wallet: str
    obfuscation_level: int = 5
    max_delay_hours: int = 24

class WalletMixingRequest(BaseModel):
    account_id: int
    amount: float
    mixer_type: str = "custom"
    anonymity_target: float = 0.95
