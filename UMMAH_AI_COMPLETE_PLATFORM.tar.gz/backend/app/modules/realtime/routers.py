from fastapi import APIRouter, HTTPException
from typing import Dict, Any
import asyncio
import logging
from ...services.real_time_processor import real_time_processor, AlertSystem
from ...services.ja3_fingerprint_service import ja3_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/realtime", tags=["realtime"])

@router.post("/start-feeds")
async def start_real_time_feeds():
    """Start real-time data feeds for all exchanges"""
    try:
        asyncio.create_task(real_time_processor.start_all_feeds())
        return {"status": "success", "message": "Real-time feeds started"}
    except Exception as e:
        logger.error(f"Error starting feeds: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/metrics")
async def get_real_time_metrics():
    """Get current real-time processing metrics"""
    try:
        metrics = real_time_processor.get_metrics()
        return {"status": "success", "data": metrics}
    except Exception as e:
        logger.error(f"Error getting metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/alert")
async def process_alert(alert_data: Dict[str, Any]):
    """Process threat alert"""
    try:
        message = await AlertSystem.process_threat(alert_data)
        return {"status": "success", "message": message}
    except Exception as e:
        logger.error(f"Error processing alert: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/status")
async def get_system_status():
    """Get real-time system status"""
    try:
        metrics = real_time_processor.get_metrics()
        return {
            "status": "success",
            "data": {
                "active_exchanges": metrics["active_connections"],
                "total_exchanges": len(metrics["exchanges"]),
                "latest_latency": metrics["latency_metrics"][-1] if metrics["latency_metrics"] else None,
                "ja3_fingerprints": sum(metrics["ja3_stats"].values()),
                "system_health": "operational"
            }
        }
    except Exception as e:
        logger.error(f"Error getting status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/threat-graph-data")
async def get_threat_graph_data():
    """Get 3D threat topology graph data"""
    try:
        metrics = real_time_processor.get_metrics()
        nodes = []
        links = []
        
        for exchange in metrics["exchanges"]:
            nodes.append({
                "id": exchange,
                "group": 1,
                "alert": False,
                "exchange": exchange,
                "latency": 0
            })
        
        for exchange in metrics["exchanges"]:
            links.append({
                "source": "UMMAH",
                "target": exchange
            })
        
        nodes.append({
            "id": "UMMAH",
            "group": 0,
            "alert": False,
            "exchange": "UMMAH",
            "latency": 0
        })
        
        return {
            "status": "success",
            "data": {
                "nodes": nodes,
                "links": links
            }
        }
    except Exception as e:
        logger.error(f"Error getting threat graph data: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/geo-threats")
async def get_geo_threats():
    """Get geographical threat data for heatmap"""
    try:
        threats = [
            {"location": [40.7128, -74.0060], "exchange": "Binance", "severity": "high"},
            {"location": [51.5074, -0.1278], "exchange": "Kraken", "severity": "medium"},
            {"location": [35.6762, 139.6503], "exchange": "Bitfinex", "severity": "low"},
            {"location": [37.7749, -122.4194], "exchange": "Coinbase", "severity": "high"},
            {"location": [52.5200, 13.4050], "exchange": "OKX", "severity": "medium"}
        ]
        
        return {
            "status": "success",
            "data": threats
        }
    except Exception as e:
        logger.error(f"Error getting geo threats: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/signal-feed")
async def get_signal_feed():
    """Get top trader signal feed data"""
    try:
        metrics = real_time_processor.get_metrics()
        signals = []
        
        for i, metric in enumerate(metrics["latency_metrics"][-10:]):
            signals.append({
                "time": metric.get("time", "N/A"),
                "exchange": metric.get("exchange", "Unknown"),
                "signal": f"{round(1.2 + i * 0.1, 4)} BTC",
                "latency": metric.get("latency", 0)
            })
        
        return {
            "status": "success",
            "data": signals
        }
    except Exception as e:
        logger.error(f"Error getting signal feed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/mqtt-alert")
async def publish_mqtt_alert(alert_data: Dict[str, Any]):
    """Publish alert via MQTT"""
    try:
        message = alert_data.get("message", "Unknown alert")
        topic = alert_data.get("topic", "ummah/alerts")
        
        logger.info(f"📡 MQTT Alert Published to {topic}: {message}")
        
        return {
            "status": "success",
            "message": f"Alert published to {topic}",
            "data": {"topic": topic, "message": message}
        }
    except Exception as e:
        logger.error(f"Error publishing MQTT alert: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/ja3-heatmap")
async def get_ja3_heatmap():
    """Get JA3 fingerprint heatmap data"""
    try:
        heatmap_data = await ja3_service.get_heatmap_data()
        
        if not heatmap_data:
            exchanges = ['Binance', 'OKX', 'Bybit', 'Kraken', 'Bitfinex', 'Coinbase', 'Gemini', 'KuCoin']
            for exchange in exchanges:
                await ja3_service.capture_fingerprint({
                    "exchange": exchange,
                    "tls_version": "771",
                    "cipher_suites": "49195,49199,49196,49200",
                    "extensions": "0,23,65281,10,11,35,16,5,13,18,51,45,43,10"
                })
            heatmap_data = await ja3_service.get_heatmap_data()
        
        return heatmap_data
    except Exception as e:
        logger.error(f"Error getting JA3 heatmap: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/ja3-analytics")
async def get_ja3_analytics():
    """Get JA3 fingerprint analytics"""
    try:
        analytics = await ja3_service.get_fingerprint_analytics()
        return analytics
    except Exception as e:
        logger.error(f"Error getting JA3 analytics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/ja3-high-impact")
async def get_ja3_high_impact():
    """Get high-impact exchanges based on JA3 analysis"""
    try:
        high_impact = await ja3_service.filter_high_impact_exchanges()
        return high_impact
    except Exception as e:
        logger.error(f"Error getting high-impact exchanges: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/ja3-capture")
async def capture_ja3_fingerprint(fingerprint_data: Dict[str, Any]):
    """Capture a new JA3 fingerprint for analysis"""
    try:
        await ja3_service.capture_fingerprint(fingerprint_data)
        return {"status": "success", "message": "JA3 fingerprint captured"}
    except Exception as e:
        logger.error(f"Error capturing JA3 fingerprint: {e}")
        raise HTTPException(status_code=500, detail=str(e))
