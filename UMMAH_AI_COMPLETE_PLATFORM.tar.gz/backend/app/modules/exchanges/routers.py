from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List
from app.database import get_db
from app.modules.exchanges.models import Exchange, MarketData, TradingAccount, MirrorTrade, TopTrader
from app.modules.exchanges.schemas import (
    ExchangeCreate, ExchangeResponse, MarketDataResponse,
    TradingAccountCreate, TradingAccountResponse,
    MirrorTradeCreate, MirrorTradeResponse, TopTraderResponse
)
from app.services.exchange_manager import ExchangeManager

router = APIRouter(prefix="/api/exchanges", tags=["exchanges"])
exchange_manager = ExchangeManager()

@router.post("/", response_model=ExchangeResponse)
async def create_exchange(
    exchange: ExchangeCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new exchange integration."""
    return await exchange_manager.create_exchange(db, exchange)

@router.get("/", response_model=List[ExchangeResponse])
async def get_exchanges(db: AsyncSession = Depends(get_db)):
    """Get all configured exchanges."""
    return await exchange_manager.get_all_exchanges(db)

@router.get("/{exchange_id}/market-data", response_model=List[MarketDataResponse])
async def get_market_data(
    exchange_id: int,
    symbol: str = None,
    db: AsyncSession = Depends(get_db)
):
    """Get real-time market data from exchange."""
    return await exchange_manager.get_market_data(db, exchange_id, symbol)

@router.get("/{exchange_id}/top-traders", response_model=List[TopTraderResponse])
async def get_top_traders(
    exchange_id: int,
    limit: int = 100,
    db: AsyncSession = Depends(get_db)
):
    """Get top 100 traders from exchange for analysis."""
    return await exchange_manager.get_top_traders(db, exchange_id, limit)

@router.post("/accounts", response_model=TradingAccountResponse)
async def create_trading_account(
    account: TradingAccountCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new stealth trading account."""
    return await exchange_manager.create_trading_account(db, account)

@router.get("/accounts", response_model=List[TradingAccountResponse])
async def get_trading_accounts(db: AsyncSession = Depends(get_db)):
    """Get all trading accounts."""
    return await exchange_manager.get_all_trading_accounts(db)

@router.post("/mirror-trade", response_model=MirrorTradeResponse)
async def execute_mirror_trade(
    trade: MirrorTradeCreate,
    db: AsyncSession = Depends(get_db)
):
    """Execute a mirror trade with 1-3 second latency."""
    return await exchange_manager.execute_mirror_trade(db, trade)

@router.get("/mirror-trades", response_model=List[MirrorTradeResponse])
async def get_mirror_trades(
    exchange_id: int = None,
    status: str = None,
    db: AsyncSession = Depends(get_db)
):
    """Get mirror trade history."""
    return await exchange_manager.get_mirror_trades(db, exchange_id, status)

@router.post("/{exchange_id}/analyze-participants")
async def analyze_exchange_participants(
    exchange_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Analyze all participants on exchange to identify bots and strategies."""
    return await exchange_manager.analyze_participants(db, exchange_id)

@router.get("/{exchange_id}/stealth-status")
async def get_stealth_status(
    exchange_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Get stealth operation status for exchange."""
    return await exchange_manager.get_stealth_status(db, exchange_id)
