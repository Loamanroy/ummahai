from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey, JSON, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base

class Exchange(Base):
    __tablename__ = "exchanges"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    code = Column(String, unique=True, index=True, nullable=False)
    api_endpoint = Column(String, nullable=False)
    websocket_endpoint = Column(String)
    supported_pairs = Column(JSON)
    is_active = Column(Boolean, default=True)
    api_key_encrypted = Column(Text)
    secret_key_encrypted = Column(Text)
    rate_limit_per_minute = Column(Integer, default=1200)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    market_data = relationship("MarketData", back_populates="exchange")
    trading_accounts = relationship("TradingAccount", back_populates="exchange")
    mirror_trades = relationship("MirrorTrade", back_populates="exchange")

class MarketData(Base):
    __tablename__ = "market_data"
    
    id = Column(Integer, primary_key=True, index=True)
    exchange_id = Column(Integer, ForeignKey("exchanges.id"))
    symbol = Column(String, nullable=False)
    price = Column(Float, nullable=False)
    volume = Column(Float, nullable=False)
    bid = Column(Float)
    ask = Column(Float)
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    exchange = relationship("Exchange", back_populates="market_data")

class TradingAccount(Base):
    __tablename__ = "trading_accounts"
    
    id = Column(Integer, primary_key=True, index=True)
    exchange_id = Column(Integer, ForeignKey("exchanges.id"))
    account_name = Column(String, nullable=False)
    visible_balance = Column(Float, default=1000.0)
    actual_balance = Column(Float, default=0.0)
    hidden_balance = Column(Float, default=0.0)
    is_stealth_mode = Column(Boolean, default=True)
    proxy_config = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    exchange = relationship("Exchange", back_populates="trading_accounts")
    mirror_trades = relationship("MirrorTrade", back_populates="account")

class MirrorTrade(Base):
    __tablename__ = "mirror_trades"
    
    id = Column(Integer, primary_key=True, index=True)
    exchange_id = Column(Integer, ForeignKey("exchanges.id"))
    account_id = Column(Integer, ForeignKey("trading_accounts.id"))
    target_trader_id = Column(String, nullable=False)
    symbol = Column(String, nullable=False)
    side = Column(String, nullable=False)  # "buy" or "sell"
    amount = Column(Float, nullable=False)
    price = Column(Float, nullable=False)
    latency_ms = Column(Integer)
    status = Column(String, default="pending")  # "pending", "executed", "failed"
    profit_hidden = Column(Float, default=0.0)
    executed_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    exchange = relationship("Exchange", back_populates="mirror_trades")
    account = relationship("TradingAccount", back_populates="mirror_trades")

class TopTrader(Base):
    __tablename__ = "top_traders"
    
    id = Column(Integer, primary_key=True, index=True)
    exchange_id = Column(Integer, ForeignKey("exchanges.id"))
    trader_id = Column(String, nullable=False)
    trader_name = Column(String)
    total_volume = Column(Float, default=0.0)
    win_rate = Column(Float, default=0.0)
    avg_profit = Column(Float, default=0.0)
    trading_patterns = Column(JSON)
    is_bot = Column(Boolean, default=False)
    bot_strategy = Column(String)
    last_activity = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    exchange = relationship("Exchange")
