from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime

class ExchangeBase(BaseModel):
    name: str
    code: str
    api_endpoint: str
    websocket_endpoint: Optional[str] = None
    supported_pairs: Optional[List[str]] = None
    is_active: bool = True

class ExchangeCreate(ExchangeBase):
    api_key: str
    secret_key: str

class ExchangeResponse(ExchangeBase):
    id: int
    rate_limit_per_minute: int
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class MarketDataResponse(BaseModel):
    id: int
    exchange_id: int
    symbol: str
    price: float
    volume: float
    bid: Optional[float] = None
    ask: Optional[float] = None
    timestamp: datetime
    
    class Config:
        from_attributes = True

class TradingAccountCreate(BaseModel):
    exchange_id: int
    account_name: str
    visible_balance: float = 1000.0
    proxy_config: Optional[Dict[str, Any]] = None

class TradingAccountResponse(BaseModel):
    id: int
    exchange_id: int
    account_name: str
    visible_balance: float
    is_stealth_mode: bool
    created_at: datetime
    
    class Config:
        from_attributes = True

class MirrorTradeCreate(BaseModel):
    exchange_id: int
    account_id: int
    target_trader_id: str
    symbol: str
    side: str
    amount: float
    price: float

class MirrorTradeResponse(BaseModel):
    id: int
    exchange_id: int
    account_id: int
    target_trader_id: str
    symbol: str
    side: str
    amount: float
    price: float
    latency_ms: Optional[int] = None
    status: str
    profit_hidden: float
    executed_at: Optional[datetime] = None
    created_at: datetime
    
    class Config:
        from_attributes = True

class TopTraderResponse(BaseModel):
    id: int
    exchange_id: int
    trader_id: str
    trader_name: Optional[str] = None
    total_volume: float
    win_rate: float
    avg_profit: float
    trading_patterns: Optional[Dict[str, Any]] = None
    is_bot: bool
    bot_strategy: Optional[str] = None
    last_activity: Optional[datetime] = None
    
    class Config:
        from_attributes = True
