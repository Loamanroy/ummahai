"""
User Management Microservice

Dedicated service for user accounts, authentication, and authorization.
Handles all user-related functionality including account management,
authentication, and user preferences.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import os
from app.core.config import settings
from app.database import engine, Base
from app.modules.accounts.routers import router as accounts_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    """User Service lifespan manager."""
    print("User Management Service starting up...")
    try:
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
    except Exception as e:
        print(f"Database initialization skipped: {e}")
    yield
    await engine.dispose()
    print("User Management Service shutting down...")

app = FastAPI(
    title="UMMAH AI - User Service",
    description="User management microservice with authentication",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

app.include_router(accounts_router, prefix="/api/v1/accounts", tags=["accounts"])

@app.get("/health")
async def health_check():
    """Health check for user service."""
    return {
        "status": "healthy",
        "service": "user-management",
        "version": "1.0.0"
    }

@app.get("/")
async def root():
    """Root endpoint for user service."""
    return {"message": "UMMAH AI - User Service"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", 8003)))
