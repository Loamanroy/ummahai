"""
Market Data Microservice

Dedicated service for real-time market data, WebSocket connections, and data feeds.
Handles all market data functionality including real-time feeds, historical data,
and WebSocket connections for live updates.
"""

from fastapi import FastAPI, WebSocket, Query, Form
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import json
import random
import asyncio
from datetime import datetime
import os
from app.core.config import settings
from app.modules.realtime.routers import router as realtime_router
from app.modules.xr.routers import router as xr_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Market Data Service lifespan manager."""
    print("Market Data Service starting up...")
    yield
    print("Market Data Service shutting down...")

app = FastAPI(
    title="UMMAH AI - Market Data Service",
    description="Market data microservice with real-time feeds",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

app.include_router(realtime_router, prefix="/api/v1/realtime", tags=["realtime"])
app.include_router(xr_router, prefix="/api/v1/xr", tags=["xr"])

dao_sessions = {}
clients = []

@app.websocket("/ws/scene")
async def websocket_scene(ws: WebSocket, session_id: str = Query("")):
    """WebSocket endpoint for real-time market data."""
    await ws.accept()
    
    if session_id:
        if session_id not in dao_sessions:
            dao_sessions[session_id] = []
        dao_sessions[session_id].append(ws)
        
        welcome_message = {
            "type": "session_initialized",
            "session_id": session_id,
            "quantum_coherence": 1.0,
            "ai_agents_available": ["cerebellum_bot", "quantum_predictor", "stealth_executor"],
            "federated_learning_enabled": True
        }
        await ws.send_text(json.dumps(welcome_message))
        
        async def send_signals():
            while True:
                try:
                    signal = {
                        "type": "trading_signal",
                        "exchange": session_id,
                        "symbol": random.choice(["BTCUSDT", "ETHUSDT", "ADAUSDT"]),
                        "action": random.choice(["BUY", "SELL"]),
                        "price": round(random.uniform(20000, 70000), 2),
                        "confidence": round(random.uniform(0.7, 0.99), 3),
                        "profit": round(random.uniform(-50, 200), 2),
                        "timestamp": datetime.utcnow().isoformat()
                    }
                    await ws.send_text(json.dumps(signal))
                    await asyncio.sleep(random.uniform(2, 5))
                except:
                    break
        
        asyncio.create_task(send_signals())
    else:
        clients.append(ws)
    
    try:
        while True:
            data = await ws.receive_text()
            await ws.send_text(data)
    except:
        if session_id and session_id in dao_sessions:
            dao_sessions[session_id].remove(ws)
        elif ws in clients:
            clients.remove(ws)

@app.get("/health")
async def health_check():
    """Health check for market data service."""
    return {
        "status": "healthy",
        "service": "market-data",
        "version": "1.0.0",
        "active_connections": len(clients) + sum(len(sessions) for sessions in dao_sessions.values())
    }

@app.get("/")
async def root():
    """Root endpoint for market data service."""
    return {"message": "UMMAH AI - Market Data Service"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", 8004)))
