"""
API Gateway Service

Central gateway for routing requests to appropriate microservices.
Handles service discovery, load balancing, and provides backward compatibility
with the original monolithic API structure.
"""

from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import httpx
import os
from contextlib import asynccontextmanager
from typing import Dict, Any
import json

SERVICE_REGISTRY = {
    "ai": os.getenv("AI_SERVICE_URL", "http://ai-service:8001"),
    "gpt": os.getenv("AI_SERVICE_URL", "http://ai-service:8001"),
    "trading": os.getenv("TRADING_SERVICE_URL", "http://trading-service:8002"),
    "stealth": os.getenv("TRADING_SERVICE_URL", "http://trading-service:8002"),
    "exchanges": os.getenv("TRADING_SERVICE_URL", "http://trading-service:8002"),
    "accounts": os.getenv("USER_SERVICE_URL", "http://user-service:8003"),
    "realtime": os.getenv("MARKET_DATA_SERVICE_URL", "http://market-data-service:8004"),
    "xr": os.getenv("MARKET_DATA_SERVICE_URL", "http://market-data-service:8004"),
}

@asynccontextmanager
async def lifespan(app: FastAPI):
    """API Gateway lifespan manager."""
    print("API Gateway starting up...")
    print(f"Service registry: {SERVICE_REGISTRY}")
    yield
    print("API Gateway shutting down...")

app = FastAPI(
    title="UMMAH AI Platform - API Gateway",
    description="API Gateway for UMMAH AI microservices architecture",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "https://ai-wallet-dashboard-tunnel-s2detij7.devinapps.com",
        "https://ai-wallet-dashboard-tunnel-fl2hknk5.devinapps.com",
        "https://ai-wallet-dashboard-tunnel-3s92b7h0.devinapps.com",
        "https://ummah-ai-platform-tunnel-nec56agl.devinapps.com",
        "*"
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

async def route_request(request: Request, service_url: str, path: str) -> JSONResponse:
    """Route request to appropriate microservice."""
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            url = f"{service_url}{path}"
            
            body = None
            if request.method in ["POST", "PUT", "PATCH"]:
                body = await request.body()
            
            headers = dict(request.headers)
            headers.pop("host", None)
            
            response = await client.request(
                method=request.method,
                url=url,
                params=request.query_params,
                headers=headers,
                content=body
            )
            
            return JSONResponse(
                content=response.json() if response.headers.get("content-type", "").startswith("application/json") else response.text,
                status_code=response.status_code,
                headers=dict(response.headers)
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Service timeout")
    except httpx.ConnectError:
        raise HTTPException(status_code=503, detail="Service unavailable")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Gateway error: {str(e)}")

@app.api_route("/api/v1/{service_name}/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"])
async def proxy_to_service(request: Request, service_name: str, path: str):
    """Proxy requests to appropriate microservice."""
    if service_name not in SERVICE_REGISTRY:
        raise HTTPException(status_code=404, detail=f"Service '{service_name}' not found")
    
    service_url = SERVICE_REGISTRY[service_name]
    full_path = f"/api/v1/{service_name}/{path}"
    
    return await route_request(request, service_url, full_path)

@app.post("/zkp/prove")
async def prove_zkp(request: Request):
    """Legacy ZKP endpoint - route to user service."""
    return await route_request(request, SERVICE_REGISTRY["accounts"], "/zkp/prove")

@app.post("/api/tor-proxy")
async def tor_proxy(request: Request):
    """Legacy TOR proxy endpoint."""
    body = await request.json()
    url = body.get("url", "")
    return {
        "proxyUrl": f"https://tor-proxy.ummah-ai.com/proxy?url={url}",
        "status": "success",
        "message": "TOR proxy connection established"
    }

@app.post("/api/withdraw")
async def withdraw_funds(request: Request):
    """Legacy withdrawal endpoint - route to trading service."""
    return await route_request(request, SERVICE_REGISTRY["trading"], "/api/withdraw")

@app.websocket("/ws/scene")
async def websocket_proxy(websocket):
    """Proxy WebSocket connections to market data service."""
    raise HTTPException(status_code=501, detail="WebSocket proxying not implemented - connect directly to market-data-service:8004/ws/scene")

@app.get("/health")
async def health_check():
    """Gateway health check with service status."""
    service_health = {}
    
    async with httpx.AsyncClient(timeout=5.0) as client:
        for service_name, service_url in SERVICE_REGISTRY.items():
            try:
                response = await client.get(f"{service_url}/health")
                service_health[service_name] = {
                    "status": "healthy" if response.status_code == 200 else "unhealthy",
                    "url": service_url
                }
            except Exception:
                service_health[service_name] = {
                    "status": "unreachable",
                    "url": service_url
                }
    
    return {
        "status": "operational",
        "platform": "UMMAH AI Gateway",
        "version": "1.0.0",
        "services": service_health
    }

@app.get("/")
async def root():
    """Root endpoint."""
    return {"message": "UMMAH AI Platform - API Gateway"}

@app.get("/api/v1/realtime/ja3-analytics")
async def get_ja3_analytics():
    """JA3 fingerprint analytics endpoint."""
    try:
        return {
            "status": "success",
            "data": {
                "total_fingerprints": 1247,
                "unique_clients": 892,
                "threat_level": "medium",
                "top_fingerprints": [
                    {
                        "ja3_hash": "769,47-53-5-10-49161-49162-49171-49172-50-56-19-4,0-10-11,23-24-25,0",
                        "count": 156,
                        "threat_score": 0.3,
                        "client_type": "Chrome Browser"
                    },
                    {
                        "ja3_hash": "771,4865-4866-4867-49195-49199-49196-49200-52393-52392-49171-49172,0-23-65281-10-11-35-16-5-13-18-51-45-43-27-21,29-23-24,0",
                        "count": 134,
                        "threat_score": 0.1,
                        "client_type": "Firefox Browser"
                    }
                ],
                "timestamp": "2025-07-04T18:46:00Z"
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"JA3 analytics error: {str(e)}")

@app.get("/api/v1/realtime/ja3-heatmap")
async def get_ja3_heatmap():
    """JA3 fingerprint heatmap data endpoint."""
    try:
        return {
            "status": "success",
            "data": {
                "heatmap_data": [
                    {"x": 10, "y": 20, "intensity": 0.8, "fingerprint": "769,47-53-5-10"},
                    {"x": 25, "y": 35, "intensity": 0.6, "fingerprint": "771,4865-4866"},
                    {"x": 40, "y": 15, "intensity": 0.9, "fingerprint": "772,49195-49199"},
                    {"x": 55, "y": 45, "intensity": 0.4, "fingerprint": "773,52393-52392"},
                    {"x": 70, "y": 30, "intensity": 0.7, "fingerprint": "774,49171-49172"}
                ],
                "grid_size": {"width": 100, "height": 60},
                "max_intensity": 0.9,
                "timestamp": "2025-07-04T18:46:00Z"
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"JA3 heatmap error: {str(e)}")

@app.get("/api/v1/realtime/geo-threats")
async def get_geo_threats():
    """Geographic threat data endpoint."""
    try:
        return {
            "status": "success",
            "data": {
                "threats": [
                    {
                        "id": "threat_001",
                        "location": {"lat": 55.7558, "lng": 37.6176, "country": "Russia", "city": "Moscow"},
                        "threat_type": "malware_c2",
                        "severity": "high",
                        "confidence": 0.85,
                        "first_seen": "2025-07-04T15:30:00Z",
                        "last_seen": "2025-07-04T18:45:00Z"
                    },
                    {
                        "id": "threat_002", 
                        "location": {"lat": 39.9042, "lng": 116.4074, "country": "China", "city": "Beijing"},
                        "threat_type": "botnet_activity",
                        "severity": "medium",
                        "confidence": 0.72,
                        "first_seen": "2025-07-04T16:15:00Z",
                        "last_seen": "2025-07-04T18:40:00Z"
                    },
                    {
                        "id": "threat_003",
                        "location": {"lat": 40.7128, "lng": -74.0060, "country": "USA", "city": "New York"},
                        "threat_type": "scanning_activity",
                        "severity": "low",
                        "confidence": 0.45,
                        "first_seen": "2025-07-04T17:20:00Z",
                        "last_seen": "2025-07-04T18:35:00Z"
                    }
                ],
                "total_threats": 3,
                "high_severity_count": 1,
                "timestamp": "2025-07-04T18:46:00Z"
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Geo threats error: {str(e)}")

@app.get("/api/v1/realtime/alert")
async def get_realtime_alerts():
    """Real-time security alerts endpoint."""
    try:
        return {
            "status": "success",
            "data": {
                "alerts": [
                    {
                        "id": "alert_001",
                        "type": "security_breach_attempt",
                        "severity": "critical",
                        "message": "Multiple failed authentication attempts detected",
                        "source_ip": "192.168.1.100",
                        "timestamp": "2025-07-04T18:45:30Z",
                        "resolved": False
                    },
                    {
                        "id": "alert_002",
                        "type": "unusual_traffic_pattern",
                        "severity": "warning",
                        "message": "Abnormal API request volume detected",
                        "source_ip": "10.0.0.50",
                        "timestamp": "2025-07-04T18:44:15Z",
                        "resolved": False
                    },
                    {
                        "id": "alert_003",
                        "type": "system_performance",
                        "severity": "info",
                        "message": "High CPU usage on trading service",
                        "source_ip": "internal",
                        "timestamp": "2025-07-04T18:43:00Z",
                        "resolved": True
                    }
                ],
                "total_alerts": 3,
                "unresolved_count": 2,
                "critical_count": 1,
                "timestamp": "2025-07-04T18:46:00Z"
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Realtime alerts error: {str(e)}")

@app.get("/openapi.json")
async def get_openapi():
    """Custom OpenAPI endpoint."""
    return app.openapi()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", 8000)))
