"""
Trading Execution Microservice

Dedicated service for trading execution, stealth protocols, and exchange connectivity.
Handles all trading-related functionality including order execution, stealth trading,
and multi-exchange operations.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import os
from app.core.config import settings
from app.modules.trading.routers import router as trading_router
from app.modules.stealth.routers import router as stealth_router
from app.modules.exchanges.routers import router as exchanges_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Trading Service lifespan manager."""
    print("Trading Execution Service starting up...")
    yield
    print("Trading Execution Service shutting down...")

app = FastAPI(
    title="UMMAH AI - Trading Service",
    description="Trading execution microservice with stealth protocols",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

app.include_router(trading_router, prefix="/api/v1/trading", tags=["trading"])
app.include_router(stealth_router, prefix="/api/v1/stealth", tags=["stealth"])
app.include_router(exchanges_router, prefix="/api/v1/exchanges", tags=["exchanges"])

@app.get("/health")
async def health_check():
    """Health check for trading service."""
    return {
        "status": "healthy",
        "service": "trading-execution",
        "version": "1.0.0"
    }

@app.get("/")
async def root():
    """Root endpoint for trading service."""
    return {"message": "UMMAH AI - Trading Service"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", 8002)))
