"""
AI Prediction Microservice

Dedicated service for AI prediction, quantum algorithms, and machine learning models.
Handles all AI-related functionality including market prediction, sentiment analysis,
and quantum-enhanced trading algorithms.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import os
from app.core.config import settings
from app.modules.ai.routers import router as ai_router
from app.modules.ai.gpt_routers import router as gpt_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    """AI Service lifespan manager."""
    print("AI Prediction Service starting up...")
    yield
    print("AI Prediction Service shutting down...")

app = FastAPI(
    title="UMMAH AI - Prediction Service",
    description="AI prediction microservice with quantum-enhanced algorithms",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

app.include_router(ai_router, prefix="/api/v1/ai", tags=["ai"])
app.include_router(gpt_router, prefix="/api/v1/gpt", tags=["gpt"])

@app.get("/health")
async def health_check():
    """Health check for AI service."""
    return {
        "status": "healthy",
        "service": "ai-prediction",
        "version": "1.0.0"
    }

@app.get("/")
async def root():
    """Root endpoint for AI service."""
    return {"message": "UMMAH AI - Prediction Service"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", 8001)))
