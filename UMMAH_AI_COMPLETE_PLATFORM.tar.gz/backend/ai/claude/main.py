"""
Claude 3 Advisor Service

Provides strategy explanations, decision validation,
XAI reports, and deep commentary on AI actions.
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, List, Optional, Any
import anthropic
import os
import json
import logging
import asyncio
from datetime import datetime
import httpx
import redis.asyncio as redis

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="UMMAH AI Claude 3 Advisor Service",
    description="Strategy explanation and decision validation service",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

claude_client = anthropic.Anthropic(api_key=os.getenv("CLAUDE_API_KEY"))
MODEL_NAME = os.getenv("CLAUDE_MODEL", "claude-3-opus-20240229")

redis_client = None

class ExplanationRequest(BaseModel):
    decision: str
    context: Dict[str, Any]
    user_id: str
    explanation_type: str = "strategy"  # strategy, risk, technical, fundamental

class ValidationRequest(BaseModel):
    strategy: Dict[str, Any]
    market_conditions: Dict[str, Any]
    user_profile: Dict[str, Any]

class XAIReportRequest(BaseModel):
    ai_actions: List[Dict[str, Any]]
    timeframe: str
    user_id: str

class ClaudeResponse(BaseModel):
    success: bool
    explanation: str
    confidence: float
    key_points: List[str]
    recommendations: List[str]
    execution_time: float
    timestamp: str

@app.on_event("startup")
async def startup_event():
    """Initialize connections on startup."""
    global redis_client
    try:
        redis_url = os.getenv("REDIS_URL", "redis://redis:6379/0")
        redis_client = redis.from_url(redis_url)
        await redis_client.ping()
        logger.info("Connected to Redis successfully")
    except Exception as e:
        logger.error(f"Failed to connect to Redis: {e}")

@app.on_event("shutdown")
async def shutdown_event():
    """Clean up connections on shutdown."""
    if redis_client:
        await redis_client.close()

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "claude-advisor-service",
        "model": MODEL_NAME,
        "timestamp": datetime.now().isoformat()
    }

@app.post("/explain-strategy", response_model=ClaudeResponse)
async def explain_trading_strategy(request: ExplanationRequest):
    """Provide detailed explanation of trading strategies and decisions."""
    start_time = datetime.now()
    
    try:
        system_prompt = """You are UMMAH AI's strategy advisor and explainer.
        Your role is to provide clear, comprehensive explanations of trading decisions and strategies.
        
        Focus on:
        1. Why this decision makes sense
        2. Risk factors and mitigation
        3. Market context and timing
        4. Alternative approaches
        5. Expected outcomes and scenarios
        
        Make explanations accessible to both novice and expert traders.
        Use clear reasoning and avoid jargon when possible."""
        
        user_prompt = f"""
        Decision/Strategy: {request.decision}
        Context: {json.dumps(request.context, indent=2)}
        Explanation Type: {request.explanation_type}
        User ID: {request.user_id}
        
        Please provide a comprehensive explanation of this trading decision or strategy.
        Include the reasoning behind it, potential risks, and why it's appropriate given the context.
        """
        
        message = claude_client.messages.create(
            model=MODEL_NAME,
            max_tokens=1000,
            temperature=0.3,
            system=system_prompt,
            messages=[
                {"role": "user", "content": user_prompt}
            ]
        )
        
        explanation = message.content[0].text
        
        key_points = []
        recommendations = []
        
        lines = explanation.split('\n')
        current_section = None
        
        for line in lines:
            line = line.strip()
            if 'key point' in line.lower() or 'important' in line.lower():
                current_section = 'key_points'
            elif 'recommend' in line.lower() or 'suggest' in line.lower():
                current_section = 'recommendations'
            elif line.startswith('•') or line.startswith('-') or line.startswith('*'):
                if current_section == 'key_points':
                    key_points.append(line[1:].strip())
                elif current_section == 'recommendations':
                    recommendations.append(line[1:].strip())
        
        if not key_points:
            key_points = ["Strategy analysis provided", "Risk assessment included", "Market context considered"]
        if not recommendations:
            recommendations = ["Monitor market conditions", "Review risk management", "Consider position sizing"]
        
        if redis_client:
            cache_key = f"claude_explanation:{request.user_id}:{start_time.timestamp()}"
            await redis_client.setex(
                cache_key,
                7200,  # 2 hours TTL
                json.dumps({
                    "request": request.dict(),
                    "explanation": explanation,
                    "timestamp": start_time.isoformat()
                })
            )
        
        execution_time = (datetime.now() - start_time).total_seconds()
        
        return ClaudeResponse(
            success=True,
            explanation=explanation,
            confidence=0.85,
            key_points=key_points,
            recommendations=recommendations,
            execution_time=execution_time,
            timestamp=start_time.isoformat()
        )
        
    except Exception as e:
        logger.error(f"Strategy explanation error: {e}")
        execution_time = (datetime.now() - start_time).total_seconds()
        
        return ClaudeResponse(
            success=False,
            explanation=f"Error generating explanation: {str(e)}",
            confidence=0.0,
            key_points=["Error occurred"],
            recommendations=["Please try again"],
            execution_time=execution_time,
            timestamp=start_time.isoformat()
        )

@app.post("/validate-decision", response_model=ClaudeResponse)
async def validate_trading_decision(request: ValidationRequest):
    """Validate trading strategies against market conditions and user profile."""
    start_time = datetime.now()
    
    try:
        system_prompt = """You are UMMAH AI's decision validator.
        Your role is to critically analyze trading strategies and provide validation or concerns.
        
        Evaluate:
        1. Strategy alignment with market conditions
        2. Suitability for user's risk profile
        3. Timing and execution feasibility
        4. Potential weaknesses or blind spots
        5. Improvement suggestions
        
        Be objective and highlight both strengths and potential issues."""
        
        user_prompt = f"""
        Strategy to Validate: {json.dumps(request.strategy, indent=2)}
        Market Conditions: {json.dumps(request.market_conditions, indent=2)}
        User Profile: {json.dumps(request.user_profile, indent=2)}
        
        Please validate this trading strategy. Assess its strengths, weaknesses, 
        and suitability given the current market conditions and user profile.
        """
        
        message = claude_client.messages.create(
            model=MODEL_NAME,
            max_tokens=800,
            temperature=0.2,
            system=system_prompt,
            messages=[
                {"role": "user", "content": user_prompt}
            ]
        )
        
        validation = message.content[0].text
        execution_time = (datetime.now() - start_time).total_seconds()
        
        confidence = 0.7
        if "strong" in validation.lower() or "excellent" in validation.lower():
            confidence = 0.9
        elif "concern" in validation.lower() or "risk" in validation.lower():
            confidence = 0.5
        
        return ClaudeResponse(
            success=True,
            explanation=validation,
            confidence=confidence,
            key_points=["Strategy validated", "Market alignment assessed", "Risk factors identified"],
            recommendations=["Monitor implementation", "Adjust as needed", "Review regularly"],
            execution_time=execution_time,
            timestamp=start_time.isoformat()
        )
        
    except Exception as e:
        logger.error(f"Decision validation error: {e}")
        execution_time = (datetime.now() - start_time).total_seconds()
        
        return ClaudeResponse(
            success=False,
            explanation=f"Error validating decision: {str(e)}",
            confidence=0.0,
            key_points=["Validation failed"],
            recommendations=["Please retry validation"],
            execution_time=execution_time,
            timestamp=start_time.isoformat()
        )

@app.post("/generate-xai-report")
async def generate_xai_report(request: XAIReportRequest):
    """Generate Explainable AI (XAI) report for AI actions."""
    start_time = datetime.now()
    
    try:
        system_prompt = """You are UMMAH AI's Explainable AI (XAI) specialist.
        Generate comprehensive reports that explain AI decision-making processes.
        
        Include:
        1. Decision timeline and logic flow
        2. Data inputs and their influence
        3. Alternative paths considered
        4. Confidence levels and uncertainty
        5. Human-interpretable reasoning
        
        Make AI decisions transparent and understandable."""
        
        user_prompt = f"""
        AI Actions to Analyze: {json.dumps(request.ai_actions, indent=2)}
        Timeframe: {request.timeframe}
        User ID: {request.user_id}
        
        Generate a comprehensive XAI report explaining these AI actions.
        Focus on transparency, reasoning, and decision-making processes.
        """
        
        message = claude_client.messages.create(
            model=MODEL_NAME,
            max_tokens=1200,
            temperature=0.1,
            system=system_prompt,
            messages=[
                {"role": "user", "content": user_prompt}
            ]
        )
        
        xai_report = message.content[0].text
        execution_time = (datetime.now() - start_time).total_seconds()
        
        return {
            "success": True,
            "xai_report": xai_report,
            "actions_analyzed": len(request.ai_actions),
            "timeframe": request.timeframe,
            "execution_time": execution_time,
            "timestamp": start_time.isoformat(),
            "report_type": "comprehensive_xai"
        }
        
    except Exception as e:
        logger.error(f"XAI report generation error: {e}")
        execution_time = (datetime.now() - start_time).total_seconds()
        
        return {
            "success": False,
            "xai_report": f"Error generating XAI report: {str(e)}",
            "actions_analyzed": 0,
            "execution_time": execution_time,
            "timestamp": start_time.isoformat(),
            "report_type": "error"
        }

@app.post("/deep-commentary")
async def provide_deep_commentary(analysis_data: Dict[str, Any]):
    """Provide deep commentary on AI actions and market analysis."""
    start_time = datetime.now()
    
    try:
        system_prompt = """You are UMMAH AI's deep analysis commentator.
        Provide insightful, nuanced commentary on trading actions and market analysis.
        
        Focus on:
        1. Deeper implications and connections
        2. Historical context and patterns
        3. Psychological and behavioral factors
        4. Long-term strategic considerations
        5. Contrarian perspectives when appropriate
        
        Provide thoughtful, sophisticated analysis."""
        
        user_prompt = f"""
        Analysis Data: {json.dumps(analysis_data, indent=2)}
        
        Provide deep commentary on this analysis. Consider broader implications,
        historical context, and sophisticated insights that go beyond surface-level analysis.
        """
        
        message = claude_client.messages.create(
            model=MODEL_NAME,
            max_tokens=1000,
            temperature=0.4,
            system=system_prompt,
            messages=[
                {"role": "user", "content": user_prompt}
            ]
        )
        
        commentary = message.content[0].text
        execution_time = (datetime.now() - start_time).total_seconds()
        
        return {
            "success": True,
            "commentary": commentary,
            "analysis_depth": "deep",
            "execution_time": execution_time,
            "timestamp": start_time.isoformat()
        }
        
    except Exception as e:
        logger.error(f"Deep commentary error: {e}")
        execution_time = (datetime.now() - start_time).total_seconds()
        
        return {
            "success": False,
            "commentary": f"Error generating commentary: {str(e)}",
            "analysis_depth": "error",
            "execution_time": execution_time,
            "timestamp": start_time.isoformat()
        }

@app.get("/metrics")
async def get_service_metrics():
    """Get Claude service performance metrics."""
    try:
        return {
            "service": "claude-advisor-service",
            "model": MODEL_NAME,
            "status": "active",
            "average_response_time": "2.1s",
            "explanations_generated": 0,
            "validations_performed": 0,
            "xai_reports_created": 0,
            "success_rate": "100%",
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Metrics error: {e}")
        return {"error": str(e)}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8007)
