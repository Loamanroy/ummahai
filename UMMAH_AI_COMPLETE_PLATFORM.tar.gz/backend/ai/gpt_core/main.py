"""
GPT-4o Core Service

Main executor for trading commands, strategy generation,
and real-time reactions (1-2 seconds response time).
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, List, Optional, Any
import openai
import os
import json
import logging
import asyncio
from datetime import datetime
import httpx
import redis.asyncio as redis

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="UMMAH AI GPT-4o Core Service",
    description="Real-time trading command executor and strategy generator",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

openai.api_key = os.getenv("OPENAI_API_KEY")
MODEL_NAME = os.getenv("OPENAI_MODEL", "gpt-4o")

redis_client = None

class TradingCommand(BaseModel):
    command: str
    user_id: str
    exchange: str = "binance"
    symbol: Optional[str] = None
    amount: Optional[float] = None
    price: Optional[float] = None
    context: Optional[Dict[str, Any]] = None

class StrategyRequest(BaseModel):
    market_data: Dict[str, Any]
    user_preferences: Dict[str, Any]
    risk_tolerance: str = "medium"
    timeframe: str = "1h"

class GPTResponse(BaseModel):
    success: bool
    response: str
    action: Optional[str] = None
    confidence: float
    execution_time: float
    timestamp: str

@app.on_event("startup")
async def startup_event():
    """Initialize connections on startup."""
    global redis_client
    try:
        redis_url = os.getenv("REDIS_URL", "redis://redis:6379/0")
        redis_client = redis.from_url(redis_url)
        await redis_client.ping()
        logger.info("Connected to Redis successfully")
    except Exception as e:
        logger.error(f"Failed to connect to Redis: {e}")

@app.on_event("shutdown")
async def shutdown_event():
    """Clean up connections on shutdown."""
    if redis_client:
        await redis_client.close()

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "gpt-core-service",
        "model": MODEL_NAME,
        "timestamp": datetime.now().isoformat()
    }

@app.post("/execute-command", response_model=GPTResponse)
async def execute_trading_command(command: TradingCommand):
    """Execute trading command with GPT-4o analysis."""
    start_time = datetime.now()
    
    try:
        system_prompt = """You are UMMAH AI's core trading executor. 
        Analyze trading commands and provide immediate, actionable responses.
        Focus on:
        1. Risk assessment (1-10 scale)
        2. Market timing analysis
        3. Execution strategy
        4. Expected outcomes
        
        Respond in JSON format with: action, reasoning, risk_score, confidence."""
        
        user_prompt = f"""
        Trading Command: {command.command}
        Exchange: {command.exchange}
        Symbol: {command.symbol}
        Amount: {command.amount}
        Price: {command.price}
        User Context: {json.dumps(command.context) if command.context else 'None'}
        
        Current Time: {datetime.now().isoformat()}
        """
        
        response = await openai.ChatCompletion.acreate(
            model=MODEL_NAME,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            max_tokens=500,
            temperature=0.3
        )
        
        gpt_response = response.choices[0].message.content
        
        try:
            parsed_response = json.loads(gpt_response)
            action = parsed_response.get("action", "analyze")
            confidence = parsed_response.get("confidence", 0.5)
        except json.JSONDecodeError:
            action = "analyze"
            confidence = 0.5
        
        if redis_client:
            cache_key = f"gpt_command:{command.user_id}:{start_time.timestamp()}"
            await redis_client.setex(
                cache_key, 
                3600,  # 1 hour TTL
                json.dumps({
                    "command": command.dict(),
                    "response": gpt_response,
                    "timestamp": start_time.isoformat()
                })
            )
        
        execution_time = (datetime.now() - start_time).total_seconds()
        
        return GPTResponse(
            success=True,
            response=gpt_response,
            action=action,
            confidence=confidence,
            execution_time=execution_time,
            timestamp=start_time.isoformat()
        )
        
    except Exception as e:
        logger.error(f"GPT command execution error: {e}")
        execution_time = (datetime.now() - start_time).total_seconds()
        
        return GPTResponse(
            success=False,
            response=f"Error executing command: {str(e)}",
            action="error",
            confidence=0.0,
            execution_time=execution_time,
            timestamp=start_time.isoformat()
        )

@app.post("/generate-strategy", response_model=GPTResponse)
async def generate_trading_strategy(strategy_request: StrategyRequest):
    """Generate trading strategy based on market data."""
    start_time = datetime.now()
    
    try:
        system_prompt = """You are UMMAH AI's strategy generator.
        Create comprehensive trading strategies based on market data and user preferences.
        Include:
        1. Entry/exit points
        2. Risk management rules
        3. Position sizing
        4. Market analysis
        5. Timeframe considerations
        
        Provide actionable, specific recommendations."""
        
        user_prompt = f"""
        Market Data: {json.dumps(strategy_request.market_data)}
        User Preferences: {json.dumps(strategy_request.user_preferences)}
        Risk Tolerance: {strategy_request.risk_tolerance}
        Timeframe: {strategy_request.timeframe}
        
        Generate a comprehensive trading strategy.
        """
        
        response = await openai.ChatCompletion.acreate(
            model=MODEL_NAME,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            max_tokens=1000,
            temperature=0.4
        )
        
        gpt_response = response.choices[0].message.content
        execution_time = (datetime.now() - start_time).total_seconds()
        
        return GPTResponse(
            success=True,
            response=gpt_response,
            action="strategy_generated",
            confidence=0.8,
            execution_time=execution_time,
            timestamp=start_time.isoformat()
        )
        
    except Exception as e:
        logger.error(f"Strategy generation error: {e}")
        execution_time = (datetime.now() - start_time).total_seconds()
        
        return GPTResponse(
            success=False,
            response=f"Error generating strategy: {str(e)}",
            action="error",
            confidence=0.0,
            execution_time=execution_time,
            timestamp=start_time.isoformat()
        )

@app.post("/real-time-reaction")
async def real_time_market_reaction(market_event: Dict[str, Any]):
    """Provide real-time reactions to market events (1-2 second response)."""
    start_time = datetime.now()
    
    try:
        system_prompt = """You are UMMAH AI's real-time market analyst.
        Provide immediate reactions to market events in under 2 seconds.
        Focus on:
        1. Immediate impact assessment
        2. Quick action recommendations
        3. Risk alerts
        4. Opportunity identification
        
        Be concise and actionable."""
        
        user_prompt = f"""
        Market Event: {json.dumps(market_event)}
        Timestamp: {datetime.now().isoformat()}
        
        Provide immediate analysis and recommendations.
        """
        
        response = await openai.ChatCompletion.acreate(
            model=MODEL_NAME,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            max_tokens=200,
            temperature=0.2
        )
        
        gpt_response = response.choices[0].message.content
        execution_time = (datetime.now() - start_time).total_seconds()
        
        return {
            "success": True,
            "reaction": gpt_response,
            "execution_time": execution_time,
            "timestamp": start_time.isoformat(),
            "alert_level": "medium" if "risk" in gpt_response.lower() else "low"
        }
        
    except Exception as e:
        logger.error(f"Real-time reaction error: {e}")
        execution_time = (datetime.now() - start_time).total_seconds()
        
        return {
            "success": False,
            "reaction": f"Error processing market event: {str(e)}",
            "execution_time": execution_time,
            "timestamp": start_time.isoformat(),
            "alert_level": "error"
        }

@app.get("/metrics")
async def get_service_metrics():
    """Get GPT service performance metrics."""
    try:
        if redis_client:
            metrics_key = "gpt_service_metrics"
            cached_metrics = await redis_client.get(metrics_key)
            
            if cached_metrics:
                return json.loads(cached_metrics)
        
        return {
            "service": "gpt-core-service",
            "model": MODEL_NAME,
            "status": "active",
            "average_response_time": "1.2s",
            "requests_processed": 0,
            "success_rate": "100%",
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Metrics error: {e}")
        return {"error": str(e)}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8006)
