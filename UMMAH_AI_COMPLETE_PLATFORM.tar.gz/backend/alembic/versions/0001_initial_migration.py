"""Initial migration

Revision ID: 0001
Revises: 
Create Date: 2025-01-04 18:16:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = '0001'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table('users',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('email', sa.String(length=255), nullable=False),
        sa.Column('username', sa.String(length=100), nullable=False),
        sa.Column('hashed_password', sa.String(length=255), nullable=False),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('is_verified', sa.Boolean(), nullable=True),
        sa.Column('role', sa.String(length=50), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_users_email'), 'users', ['email'], unique=True)
    op.create_index(op.f('ix_users_username'), 'users', ['username'], unique=True)

    op.create_table('trading_pairs',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('symbol', sa.String(length=20), nullable=False),
        sa.Column('base_asset', sa.String(length=10), nullable=False),
        sa.Column('quote_asset', sa.String(length=10), nullable=False),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_trading_pairs_symbol'), 'trading_pairs', ['symbol'], unique=True)

    op.create_table('market_data',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('symbol', sa.String(length=20), nullable=False),
        sa.Column('price', sa.Numeric(precision=18, scale=8), nullable=False),
        sa.Column('volume', sa.Numeric(precision=18, scale=8), nullable=True),
        sa.Column('high_24h', sa.Numeric(precision=18, scale=8), nullable=True),
        sa.Column('low_24h', sa.Numeric(precision=18, scale=8), nullable=True),
        sa.Column('change_24h', sa.Numeric(precision=8, scale=4), nullable=True),
        sa.Column('timestamp', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_market_data_symbol'), 'market_data', ['symbol'])
    op.create_index(op.f('ix_market_data_timestamp'), 'market_data', ['timestamp'])

    op.create_table('trades',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('symbol', sa.String(length=20), nullable=False),
        sa.Column('side', sa.String(length=10), nullable=False),
        sa.Column('quantity', sa.Numeric(precision=18, scale=8), nullable=False),
        sa.Column('price', sa.Numeric(precision=18, scale=8), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=True),
        sa.Column('order_type', sa.String(length=20), nullable=True),
        sa.Column('executed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_trades_user_id'), 'trades', ['user_id'])
    op.create_index(op.f('ix_trades_symbol'), 'trades', ['symbol'])
    op.create_index(op.f('ix_trades_created_at'), 'trades', ['created_at'])

    op.create_table('ai_predictions',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('symbol', sa.String(length=20), nullable=False),
        sa.Column('prediction_type', sa.String(length=50), nullable=False),
        sa.Column('predicted_price', sa.Numeric(precision=18, scale=8), nullable=True),
        sa.Column('confidence_score', sa.Numeric(precision=5, scale=4), nullable=True),
        sa.Column('time_horizon', sa.String(length=20), nullable=True),
        sa.Column('model_version', sa.String(length=50), nullable=True),
        sa.Column('features_used', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_ai_predictions_symbol'), 'ai_predictions', ['symbol'])
    op.create_index(op.f('ix_ai_predictions_created_at'), 'ai_predictions', ['created_at'])

    op.create_table('user_portfolios',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('asset', sa.String(length=10), nullable=False),
        sa.Column('balance', sa.Numeric(precision=18, scale=8), nullable=False),
        sa.Column('locked_balance', sa.Numeric(precision=18, scale=8), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_user_portfolios_user_id'), 'user_portfolios', ['user_id'])
    op.create_index(op.f('ix_user_portfolios_asset'), 'user_portfolios', ['asset'])


def downgrade() -> None:
    op.drop_index(op.f('ix_user_portfolios_asset'), table_name='user_portfolios')
    op.drop_index(op.f('ix_user_portfolios_user_id'), table_name='user_portfolios')
    op.drop_table('user_portfolios')
    op.drop_index(op.f('ix_ai_predictions_created_at'), table_name='ai_predictions')
    op.drop_index(op.f('ix_ai_predictions_symbol'), table_name='ai_predictions')
    op.drop_table('ai_predictions')
    op.drop_index(op.f('ix_trades_created_at'), table_name='trades')
    op.drop_index(op.f('ix_trades_symbol'), table_name='trades')
    op.drop_index(op.f('ix_trades_user_id'), table_name='trades')
    op.drop_table('trades')
    op.drop_index(op.f('ix_market_data_timestamp'), table_name='market_data')
    op.drop_index(op.f('ix_market_data_symbol'), table_name='market_data')
    op.drop_table('market_data')
    op.drop_index(op.f('ix_trading_pairs_symbol'), table_name='trading_pairs')
    op.drop_table('trading_pairs')
    op.drop_index(op.f('ix_users_username'), table_name='users')
    op.drop_index(op.f('ix_users_email'), table_name='users')
    op.drop_table('users')
