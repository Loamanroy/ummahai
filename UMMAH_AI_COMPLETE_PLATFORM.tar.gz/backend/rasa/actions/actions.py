"""
RASA Custom Actions for UMMAH AI Platform

This module contains custom actions that integrate with the UMMAH AI trading platform.
Actions handle trading operations, portfolio management, market analysis, and voice commands.
"""

from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.events import SlotSet
import httpx
import asyncio
import os
import json
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

UMMAH_API_URL = os.getenv("UMMAH_API_URL", "http://api-gateway:8000")
API_TIMEOUT = 30.0

class ActionExecuteTrade(Action):
    """Execute trading operations (buy/sell)."""

    def name(self) -> Text:
        return "action_execute_trade"

    async def run(self, dispatcher: CollectingDispatcher,
                  tracker: Tracker,
                  domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        try:
            symbol = tracker.get_slot("trading_symbol")
            amount = tracker.get_slot("trading_amount")
            price = tracker.get_slot("trading_price")
            
            intent = tracker.latest_message.get("intent", {}).get("name")
            
            if not symbol:
                dispatcher.utter_message(text="Пожалуйста, укажите символ для торговли.")
                return []
            
            trade_data = {
                "symbol": symbol,
                "amount": amount or 0,
                "price": price,
                "action": "buy" if intent == "trading_buy" else "sell",
                "user_id": tracker.sender_id
            }
            
            async with httpx.AsyncClient(timeout=API_TIMEOUT) as client:
                response = await client.post(
                    f"{UMMAH_API_URL}/api/v1/trading/execute",
                    json=trade_data
                )
                
                if response.status_code == 200:
                    result = response.json()
                    dispatcher.utter_message(
                        text=f"✅ Операция выполнена: {trade_data['action']} {symbol} "
                             f"на сумму {amount}. ID: {result.get('trade_id', 'N/A')}"
                    )
                else:
                    dispatcher.utter_message(
                        text=f"❌ Ошибка выполнения операции: {response.status_code}"
                    )
            
        except Exception as e:
            logger.error(f"Trade execution error: {e}")
            dispatcher.utter_message(
                text="❌ Произошла ошибка при выполнении операции."
            )
        
        return []

class ActionGetPortfolio(Action):
    """Get user portfolio information."""

    def name(self) -> Text:
        return "action_get_portfolio"

    async def run(self, dispatcher: CollectingDispatcher,
                  tracker: Tracker,
                  domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        try:
            user_id = tracker.sender_id
            
            async with httpx.AsyncClient(timeout=API_TIMEOUT) as client:
                response = await client.get(
                    f"{UMMAH_API_URL}/api/v1/portfolio/{user_id}"
                )
                
                if response.status_code == 200:
                    portfolio = response.json()
                    
                    total_value = portfolio.get("total_value", 0)
                    positions = portfolio.get("positions", [])
                    
                    message = f"💼 Ваш портфель:\n"
                    message += f"💰 Общая стоимость: ${total_value:,.2f}\n\n"
                    
                    if positions:
                        message += "📊 Позиции:\n"
                        for pos in positions[:5]:  # Show top 5 positions
                            symbol = pos.get("symbol", "N/A")
                            amount = pos.get("amount", 0)
                            value = pos.get("value", 0)
                            message += f"• {symbol}: {amount} (${value:,.2f})\n"
                    else:
                        message += "📭 Нет открытых позиций"
                    
                    dispatcher.utter_message(text=message)
                else:
                    dispatcher.utter_message(
                        text="❌ Не удалось получить информацию о портфеле."
                    )
            
        except Exception as e:
            logger.error(f"Portfolio retrieval error: {e}")
            dispatcher.utter_message(
                text="❌ Ошибка при получении портфеля."
            )
        
        return []

class ActionAnalyzeMarket(Action):
    """Analyze market conditions for a specific symbol."""

    def name(self) -> Text:
        return "action_analyze_market"

    async def run(self, dispatcher: CollectingDispatcher,
                  tracker: Tracker,
                  domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        try:
            symbol = tracker.get_slot("trading_symbol") or "BTC"
            
            async with httpx.AsyncClient(timeout=API_TIMEOUT) as client:
                response = await client.get(
                    f"{UMMAH_API_URL}/api/v1/market/analyze/{symbol}"
                )
                
                if response.status_code == 200:
                    analysis = response.json()
                    
                    price = analysis.get("current_price", 0)
                    trend = analysis.get("trend", "neutral")
                    sentiment = analysis.get("sentiment", "neutral")
                    recommendation = analysis.get("recommendation", "hold")
                    
                    trend_emoji = {
                        "bullish": "📈",
                        "bearish": "📉",
                        "neutral": "➡️"
                    }
                    
                    message = f"📊 Анализ рынка для {symbol}:\n\n"
                    message += f"💰 Текущая цена: ${price:,.2f}\n"
                    message += f"{trend_emoji.get(trend, '➡️')} Тренд: {trend}\n"
                    message += f"🎯 Настроение: {sentiment}\n"
                    message += f"💡 Рекомендация: {recommendation}\n"
                    
                    if "ai_insights" in analysis:
                        insights = analysis["ai_insights"]
                        message += f"\n🤖 AI анализ:\n{insights}"
                    
                    dispatcher.utter_message(text=message)
                else:
                    dispatcher.utter_message(
                        text=f"❌ Не удалось проанализировать {symbol}."
                    )
            
        except Exception as e:
            logger.error(f"Market analysis error: {e}")
            dispatcher.utter_message(
                text="❌ Ошибка при анализе рынка."
            )
        
        return []

class ActionSetPriceAlert(Action):
    """Set price alerts for cryptocurrencies."""

    def name(self) -> Text:
        return "action_set_price_alert"

    async def run(self, dispatcher: CollectingDispatcher,
                  tracker: Tracker,
                  domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        try:
            symbol = tracker.get_slot("trading_symbol")
            price = tracker.get_slot("trading_price")
            user_id = tracker.sender_id
            
            if not symbol or not price:
                dispatcher.utter_message(
                    text="Пожалуйста, укажите символ и цену для алерта."
                )
                return []
            
            alert_data = {
                "symbol": symbol,
                "target_price": price,
                "user_id": user_id,
                "alert_type": "price_target"
            }
            
            async with httpx.AsyncClient(timeout=API_TIMEOUT) as client:
                response = await client.post(
                    f"{UMMAH_API_URL}/api/v1/alerts/create",
                    json=alert_data
                )
                
                if response.status_code == 200:
                    result = response.json()
                    dispatcher.utter_message(
                        text=f"🔔 Алерт установлен для {symbol} по цене ${price:,.2f}. "
                             f"ID: {result.get('alert_id', 'N/A')}"
                    )
                else:
                    dispatcher.utter_message(
                        text="❌ Не удалось установить алерт."
                    )
            
        except Exception as e:
            logger.error(f"Price alert error: {e}")
            dispatcher.utter_message(
                text="❌ Ошибка при установке алерта."
            )
        
        return []

class ActionRiskAssessment(Action):
    """Perform risk assessment for trading decisions."""

    def name(self) -> Text:
        return "action_risk_assessment"

    async def run(self, dispatcher: CollectingDispatcher,
                  tracker: Tracker,
                  domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        try:
            user_id = tracker.sender_id
            symbol = tracker.get_slot("trading_symbol") or "BTC"
            
            async with httpx.AsyncClient(timeout=API_TIMEOUT) as client:
                response = await client.get(
                    f"{UMMAH_API_URL}/api/v1/risk/assess/{user_id}?symbol={symbol}"
                )
                
                if response.status_code == 200:
                    risk_data = response.json()
                    
                    risk_level = risk_data.get("risk_level", "medium")
                    risk_score = risk_data.get("risk_score", 5)
                    recommendations = risk_data.get("recommendations", [])
                    
                    risk_emoji = {
                        "low": "🟢",
                        "medium": "🟡",
                        "high": "🔴"
                    }
                    
                    message = f"⚠️ Оценка рисков:\n\n"
                    message += f"{risk_emoji.get(risk_level, '🟡')} Уровень риска: {risk_level}\n"
                    message += f"📊 Оценка: {risk_score}/10\n\n"
                    
                    if recommendations:
                        message += "💡 Рекомендации:\n"
                        for rec in recommendations[:3]:
                            message += f"• {rec}\n"
                    
                    dispatcher.utter_message(text=message)
                else:
                    dispatcher.utter_message(
                        text="❌ Не удалось выполнить оценку рисков."
                    )
            
        except Exception as e:
            logger.error(f"Risk assessment error: {e}")
            dispatcher.utter_message(
                text="❌ Ошибка при оценке рисков."
            )
        
        return []

class ActionGenerateStrategy(Action):
    """Generate trading strategies using AI."""

    def name(self) -> Text:
        return "action_generate_strategy"

    async def run(self, dispatcher: CollectingDispatcher,
                  tracker: Tracker,
                  domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        try:
            user_id = tracker.sender_id
            symbol = tracker.get_slot("trading_symbol") or "BTC"
            
            strategy_request = {
                "user_id": user_id,
                "symbol": symbol,
                "strategy_type": "ai_generated",
                "timeframe": "1h"
            }
            
            async with httpx.AsyncClient(timeout=API_TIMEOUT) as client:
                response = await client.post(
                    f"{UMMAH_API_URL}/api/v1/ai/generate-strategy",
                    json=strategy_request
                )
                
                if response.status_code == 200:
                    strategy = response.json()
                    
                    strategy_name = strategy.get("name", "AI Strategy")
                    description = strategy.get("description", "")
                    entry_points = strategy.get("entry_points", [])
                    exit_points = strategy.get("exit_points", [])
                    
                    message = f"🧠 AI Стратегия: {strategy_name}\n\n"
                    message += f"📝 Описание: {description}\n\n"
                    
                    if entry_points:
                        message += "🎯 Точки входа:\n"
                        for entry in entry_points[:3]:
                            message += f"• ${entry:,.2f}\n"
                    
                    if exit_points:
                        message += "\n🚪 Точки выхода:\n"
                        for exit in exit_points[:3]:
                            message += f"• ${exit:,.2f}\n"
                    
                    dispatcher.utter_message(text=message)
                else:
                    dispatcher.utter_message(
                        text="❌ Не удалось сгенерировать стратегию."
                    )
            
        except Exception as e:
            logger.error(f"Strategy generation error: {e}")
            dispatcher.utter_message(
                text="❌ Ошибка при генерации стратегии."
            )
        
        return []

class ActionSwitchLanguage(Action):
    """Switch conversation language."""

    def name(self) -> Text:
        return "action_switch_language"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        language = tracker.get_slot("user_language") or "ru"
        
        language_map = {
            "english": "en",
            "russian": "ru",
            "arabic": "ar",
            "turkish": "tr",
            "английский": "en",
            "русский": "ru",
            "арабский": "ar",
            "турецкий": "tr"
        }
        
        lang_code = language_map.get(language.lower(), language)
        
        confirmations = {
            "en": "Language switched to English",
            "ru": "Язык изменен на русский",
            "ar": "تم تغيير اللغة إلى العربية",
            "tr": "Dil Türkçe olarak değiştirildi"
        }
        
        confirmation_msg = confirmations.get(lang_code, confirmations["ru"])
        dispatcher.utter_message(text=confirmation_msg)
        
        return [SlotSet("user_language", lang_code)]

class ActionVoiceCommandHandler(Action):
    """Handle voice commands and route them appropriately."""

    def name(self) -> Text:
        return "action_voice_command_handler"

    async def run(self, dispatcher: CollectingDispatcher,
                  tracker: Tracker,
                  domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        try:
            message_text = tracker.latest_message.get("text", "")
            user_id = tracker.sender_id
            
            voice_data = {
                "text": message_text,
                "user_id": user_id,
                "language": tracker.get_slot("user_language") or "ru"
            }
            
            async with httpx.AsyncClient(timeout=API_TIMEOUT) as client:
                response = await client.post(
                    f"{UMMAH_API_URL}/api/v1/voice/process",
                    json=voice_data
                )
                
                if response.status_code == 200:
                    result = response.json()
                    
                    command_type = result.get("command_type", "unknown")
                    response_text = result.get("response", "Команда обработана")
                    
                    dispatcher.utter_message(text=f"🎤 {response_text}")
                    
                    if "symbol" in result:
                        return [SlotSet("trading_symbol", result["symbol"])]
                    
                else:
                    dispatcher.utter_message(
                        text="❌ Не удалось обработать голосовую команду."
                    )
            
        except Exception as e:
            logger.error(f"Voice command error: {e}")
            dispatcher.utter_message(
                text="❌ Ошибка при обработке голосовой команды."
            )
        
        return []
